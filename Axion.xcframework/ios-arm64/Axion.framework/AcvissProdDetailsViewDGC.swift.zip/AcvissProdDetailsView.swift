//
//  AcvissProdDetailsView.swift
//  LoyaltySaampleApp
//
//  Created by Sreedeep on 26/11/24.
//

import SwiftUI
import AVKit
import WebKit
//import AcvissCore
import SafariServices
import YouTubePlayerKit


struct AcvissProdDetailsView: View {
    @StateObject var viewmodel: AcvissProdDetailsViewModel
    @State private var player: AVPlayer?
    @Environment(\.dismiss) private var dismiss

    // Rate/Thank you states
    @State private var showRateSheet: Bool = false
    @State private var rating: Int = 0
    @State private var feedback: String = ""

    @State private var showReportSheet: Bool = false
    @State private var reportEmail: String = ""
    @State private var reportDescription: String = ""

    @State private var showThankYou: Bool = false
    @Environment(\.presentationMode) private var presentationMode

    init(isSuccess: Bool, jsonResult: [String: Any]) {
        _viewmodel = StateObject(wrappedValue: AcvissProdDetailsViewModel(isSuccess: isSuccess, jsonResult: jsonResult))
    }

    var body: some View {
        ZStack(alignment: .bottomTrailing) {
            ScrollView {
                VStack(spacing: 16) {

                    if let message = viewmodel.productMessageText, !message.isEmpty {
                        HStack(spacing: 8) {
//                            Image(systemName: viewmodel.isSuccess ? "checkmark.circle.fill" : "xmark.octagon.fill")
//                                .font(.system(size: 16, weight: .semibold))
//                                .foregroundColor(.white)
                            Group {
                                if viewmodel.isSuccess {
                                    // Use your asset for the success icon. Replace "success_tick" with the asset name in Assets.xcassets
                                    Image("success_tick", bundle: AxionBundle.bundle)
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 18, height: 18)        // match approx size of system icon
                                } else {
                                    Image(systemName: "xmark.octagon.fill")
                                        .font(.system(size: 16, weight: .semibold))
                                        .foregroundColor(.white)
                                }
                            }

                            Text(message)
                                .font(.subheadline)
                                .foregroundColor(.black)
                                .multilineTextAlignment(.leading)
                                .fixedSize(horizontal: false, vertical: true) // This allows vertical expansion
                                .frame(maxWidth: .infinity, alignment: .leading) // Take available width
                        }
                        .padding(.horizontal, 12)
                        .padding(.vertical, 8)
                        .background(
                            RoundedRectangle(cornerRadius: 10)
                                .fill(viewmodel.isSuccess ? Color("success_color", bundle: AxionBundle.bundle) : Color("failure_color", bundle: AxionBundle.bundle))
                        )
                    }

                    // --- top graphic: use product image as the rounded-card background when success ---
                    VStack(spacing: 0) {
                        ZStack {
                            Image(viewmodel.isSuccess ? "product_success" : "product_failure",bundle: AxionBundle.bundle)
                                .resizable()
                                .scaledToFill() // fill the available space completely
                                .frame(maxWidth: .infinity, maxHeight: 200)
                                .clipped() // crop any overflow
                        }
                        .frame(maxWidth: .infinity, maxHeight: 200)
                        .clipShape(RoundedRectangle(cornerRadius: 8))
                        .overlay(
                            RoundedRectangle(cornerRadius: 8)
                                .stroke(Color.gray.opacity(0.08), lineWidth: 1)
                        )
                    }
                    .frame(maxWidth: .infinity, maxHeight: 200)

                    // Points card (unchanged)
                    if let pts = viewmodel.productPoints {
                        if pts > 0 {
                            PointsCard(points: pts)
                                .padding(.top, 6)
                        }
                    }

                    // Serial / Batch block
                    if viewmodel.serialNumber != nil || viewmodel.batchCode != nil {
                        VStack(spacing: 0) {
                            if let serialNum = viewmodel.serialNumber {
                                HStack {
                                    Text("Serial Number")
                                        .font(.subheadline)
                                        .foregroundColor(Color("light_text", bundle: AxionBundle.bundle))
                                    Spacer()
                                    Text(String("\(serialNum.data as? Int ?? 0)"))
                                        .font(.subheadline)
                                        .fontWeight(.bold)
                                        .foregroundColor(.black)
                                }
                                .padding(.vertical, 12)
                                .padding(.horizontal, 12)
                                Divider()
                            }

                            if let batchCode = viewmodel.batchCode {
                                HStack {
                                    Text("Batch Code")
                                        .font(.subheadline)
                                        .foregroundColor(Color("light_text", bundle: AxionBundle.bundle))
                                    Spacer()
                                    Text(String(batchCode.data as? String ?? ""))
                                        .font(.subheadline)
                                        .fontWeight(.bold)
                                        .foregroundColor(.black)
                                }
                                .padding(.vertical, 12)
                                .padding(.horizontal, 12)
                            }
                        }
                        .background(RoundedRectangle(cornerRadius: 8).fill(Color.gray.opacity(0.2)))
                    }

                    if viewmodel.isSuccess {
                        ProductDescriptionCard(viewmodel: viewmodel)
                    }

//                    Divider()
                    CustomerDetailsCard(viewmodel: viewmodel)

                    Color.clear.frame(height: 120)
                }
                .padding(.horizontal)
            }
            .background(Color.white)

            // Footer buttons
            VStack {
                Spacer()
                HStack(spacing: 16) {
//                    Button(action: {
//                        withAnimation {
//                            if viewmodel.isSuccess {
//                                showRateSheet = true
//                            } else {
//                                showReportSheet = true
//                            }
//                        }
//                    }) {
//                        Text(viewmodel.isSuccess ? "Rate us" : "Report To Brand")
//                            .font(.system(size: 16, weight: .semibold))
//                            .frame(maxWidth: .infinity)
//                            .padding(.vertical, 14)
//                    }
//                    .background(Color.white)
//                    .overlay(RoundedRectangle(cornerRadius: 8).stroke(acvissAccentColor(), lineWidth: 2))
//                    .foregroundColor(acvissAccentColor())
//                    .cornerRadius(8)

                    Button(action: {
                        withAnimation { dismissProductDetailsAndReturnToScanner() }
                    }) {
                        Text("Scan Again")
                            .font(.system(size: 16, weight: .semibold))
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                    }
                    .background(acvissAccentColor())
                    .foregroundColor(.white)
                    .cornerRadius(8)
                }
                .padding(.horizontal, 16)
                .padding(.top, 12)
                .padding(.bottom, bottomSafeAreaPadding() > 0 ? bottomSafeAreaPadding() : 16)
                .background(VisualEffectBlur(blurStyle: .systemMaterial).opacity(0.98).edgesIgnoringSafeArea(.bottom))
            }
            .edgesIgnoringSafeArea(.bottom)

            // Rate / Report / Thank you modals (unchanged)
            if showRateSheet {
                VisualEffectBlur(blurStyle: .systemThinMaterialDark).edgesIgnoringSafeArea(.all).transition(.opacity).zIndex(0)
                //                RateUsDialog(rating: $rating, feedback: $feedback, isPresented: $showRateSheet) {
                //                    // feedback submit flow unchanged
                //                    // ... your existing submission code ...
                //                }
                RateUsDialog(rating: $rating, feedback: $feedback, isPresented: $showRateSheet) {
                    // Note: capture weak self to avoid retain cycles
                    // 1) prepare request payload
                    // prefer serial number (from viewmodel.serialNumber.data) else product id
                    let productIdInt: Int = {
                        if let snTable = viewmodel.serialNumber, let sn = snTable.data as? Int {
                            return sn
                        } else if let pid = viewmodel.productDetailsObj?.id {
                            return pid
                        }
                        return 0
                    }()
                    
                    // barcode: try batchCode (or you may have a real barcode in viewmodel; replace if so)
                    let barcodeString: String = {
                        if let bc = viewmodel.batchCode?.data as? String, !bc.isEmpty { return bc }
                        return "" // fallback
                    }()
                    
                    // rating and feedback are bound variables (Int and String)
                    let ratingValue = rating
                    let feedbackValue = feedback.trimmingCharacters(in: .whitespacesAndNewlines)
                    
                    // final request dictionary expected by API
                    let requestPayload: [String: Any] = [
                        "product_id": productIdInt,
                        "barcode": barcodeString,
                        "is_genuine": viewmodel.isSuccess,     // boolean
                        "type": "FEEDBACK",
                        "rating": ratingValue,
                        "email": "test@acviss.com",            // change to actual if you have it
                        "feedback": feedbackValue
                    ]
                    
                    // 2) find a parent UIViewController to pass to the API helper
                    guard let parentVC =  UIApplication.shared.topViewController() else {
                        // fallback: close dialog and show thank you or an error as needed
                        withAnimation {
                            showRateSheet = false
                        }
                        // optionally show an alert to user — simplified here:
                        return
                    }
                    
                    // Optionally show a loader here (if you have one)
                    viewmodel.provide_product_feedback(parent: parentVC, request: requestPayload) { response, error in
                        DispatchQueue.main.async {
                            // close rate sheet, show thank you, clear local fields
                            withAnimation {
                                showRateSheet = false
                            }
                            // small delay to make transitions smooth (same as current flow)
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.18) {
                                withAnimation {
                                    showThankYou = true
                                }
                                rating = 0
                                feedback = ""
                            }
                            
                            // handle response / error if you want to show any message
                            if let err = error {
                                print("feedback API error: \(err.localizedDescription)")
                                // Optionally surface a failure UI to user
                            } else {
                                print("feedback API response: \(String(describing: response))")
                            }
                        }
                    }
                }
                .transition(.scale.combined(with: .opacity))
                .zIndex(1)
            }

            if showReportSheet {
                VisualEffectBlur(blurStyle: .systemThinMaterialDark).edgesIgnoringSafeArea(.all).transition(.opacity).zIndex(0)
                //                ReportIssueDialog(email: $reportEmail, description: $reportDescription, isPresented: $showReportSheet) {
                //                    // your submit logic here
                //                }
                ReportIssueDialog(email: $reportEmail,
                                  description: $reportDescription,
                                  isPresented: $showReportSheet,
                                  onSubmit: {
                    // Called when user taps Submit Report
                    // 1) close the sheet
                    withAnimation { showReportSheet = false }
                    
                    // 2) call viewmodel API to send report if you have one
                    //    Implement `submitReport(email:desc:completion:)` inside your viewmodel
                    let email = reportEmail.trimmingCharacters(in: .whitespacesAndNewlines)
                    let desc = reportDescription.trimmingCharacters(in: .whitespacesAndNewlines)
                    
                    // Example: call a viewmodel method (implement it)
                    viewmodel.submitReport(email: email, description: desc) { success, error in
                        DispatchQueue.main.async {
                            if success {
                                // Optionally show a small confirmation (reusing ThankYouDialog or a toast)
                                // For now we show the ThankYouDialog briefly:
                                withAnimation { showThankYou = true }
                                DispatchQueue.main.asyncAfter(deadline: .now() + 1.6) {
                                    withAnimation { showThankYou = false }
                                }
                            } else {
                                // handle error (show an alert, toast, or keep sheet open)
                                print("Report failed:", error?.localizedDescription ?? "unknown")
                            }
                            // clear fields
                            reportEmail = ""
                            reportDescription = ""
                        }
                    }
                })
                .transition(.scale.combined(with: .opacity))
                .zIndex(1)
            }

            if showThankYou {
                VisualEffectBlur(blurStyle: .systemThinMaterialDark).edgesIgnoringSafeArea(.all).transition(.opacity).zIndex(5)
                VStack { Spacer(); ThankYouDialog(isPresented: $showThankYou) { withAnimation { showThankYou = false } }; Spacer() }
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .center)
                    .zIndex(6)
            }
        }
        .onAppear {
            if let support = viewmodel.productSupportObj, let logo = support.logo, !logo.isEmpty, let url = URL(string: logo) {
                if viewmodel.logoImageData == nil { viewmodel.downloadImage(url: url, identity: viewmodel.clientLogo) }
            }
            if let prod = viewmodel.productDetailsObj, let first = prod.images?.first, let url = URL(string: first) {
                if viewmodel.productImageData == nil { viewmodel.downloadImage(url: url, identity: viewmodel.productImage) }
            }
        }
    }

    // MARK: - Helpers
    private func bottomSafeAreaPadding() -> CGFloat {
        let window = UIApplication.shared.connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .flatMap { $0.windows }
            .first { $0.isKeyWindow }
        return window?.safeAreaInsets.bottom ?? 0
    }

    private func acvissAccentColor() -> Color {
//        if UIColor(named: "acviss_blue") != nil { return Color("acviss_blue", bundle: AxionBundle.bundle) }
//        if UIColor(named: "blue_text") != nil { return Color("light_text", bundle: AxionBundle.bundle) }
        return Color.blue
    }

    private func dismissProductDetailsAndReturnToScanner() {
        presentationMode.wrappedValue.dismiss()
        dismiss()

        DispatchQueue.main.asyncAfter(deadline: .now() + 0.06) {
            guard let top = UIApplication.shared.topViewController() else {
                NotificationCenter.default.post(name: .acvissScanAgain, object: nil)
                return
            }

            if let nav = top.navigationController, nav.viewControllers.count > 1 {
                nav.popViewController(animated: true)
                NotificationCenter.default.post(name: .acvissScanAgain, object: nil)
                return
            }

            if top.presentingViewController != nil {
                top.dismiss(animated: true) {
                    NotificationCenter.default.post(name: .acvissScanAgain, object: nil)
                }
                return
            }

            var candidate: UIViewController? = top
            while let parent = candidate?.parent {
                if String(describing: type(of: parent)).contains("UIHostingController") {
                    parent.dismiss(animated: true) {
                        NotificationCenter.default.post(name: .acvissScanAgain, object: nil)
                    }
                    return
                }
                candidate = parent
            }

            NotificationCenter.default.post(name: .acvissScanAgain, object: nil)
        }
    }
}

// MARK: - Report Issue Dialog component
fileprivate struct ReportIssueDialog: View {
    @Binding var email: String
    @Binding var description: String
    @Binding var isPresented: Bool
    var onSubmit: () -> Void

    var body: some View {
        VStack(spacing: 16) {
            header
            helpText
            emailSection
            descriptionSection
            submitButton
        }
        .padding(20)
        .frame(maxWidth: 520)
        .background(cardBackground)
        .overlay(cardStroke)
        .shadow(color: Color.black.opacity(0.25), radius: 18, x: 0, y: 10)
        .padding(.horizontal, 20)
        .padding(.vertical, 40)
    }

    // MARK: - Parts

    private var header: some View {
        HStack {
            Text("Report Issue to the Brand")
                .font(.headline)
                .foregroundColor(Color("light_text", bundle: AxionBundle.bundle))
            Spacer()
            Button(action: { withAnimation { isPresented = false } }) {
                Image(systemName: "xmark")
                    .padding(8)
                    .foregroundColor(Color.gray)
            }
            .buttonStyle(PlainButtonStyle())
        }
        .padding(.top, 6)
    }

    private var helpText: some View {
        Text("Help us understand the problem so the brand can take appropriate action.")
            .font(.subheadline)
            .foregroundColor(Color("light_text", bundle: AxionBundle.bundle).opacity(0.7))
            .fixedSize(horizontal: false, vertical: true)
    }

    private var emailSection: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Email")
                .font(.subheadline)
                .foregroundColor(Color("light_text", bundle: AxionBundle.bundle))

            ZStack {
                RoundedRectangle(cornerRadius: 6)
                    .stroke(Color.gray.opacity(0.25), lineWidth: 1)
                    .background(RoundedRectangle(cornerRadius: 6).fill(Color.white))
                    .frame(height: 44)

                TextField("Enter your email", text: $email)
                    .padding(.horizontal, 12)
                    .keyboardType(.emailAddress)
                    .autocapitalization(.none)
                    .disableAutocorrection(true)
            }
        }
    }

    private var descriptionSection: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Describe the issue")
                .font(.subheadline)
                .foregroundColor(Color("light_text", bundle: AxionBundle.bundle))

            ZStack(alignment: .topLeading) {
                RoundedRectangle(cornerRadius: 6)
                    .stroke(Color.gray.opacity(0.25), lineWidth: 1)
                    .background(RoundedRectangle(cornerRadius: 6).fill(Color.white))
                    .frame(height: 140)

                // placeholder text
                if description.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    Text("Describe the issue you faced with this product...")
                        .foregroundColor(Color.gray.opacity(0.45))
                        .padding(12)
                        .font(.subheadline)
                }

                TextEditor(text: $description)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 6)
                    .background(Color.clear)
                    .frame(height: 140)
            }
        }
    }

    private var submitButton: some View {
        Button(action: {
            onSubmit()
        }) {
            Text("Submit Report")
                .frame(maxWidth: .infinity)
                .padding(.vertical, 12)
                .font(.system(size: 16, weight: .semibold))
                .foregroundColor(.white)
                .background(acvissAccentColor())
                .cornerRadius(8)
        }
    }

    // MARK: - Decorations (split out to simplify the view expression)
    private var cardBackground: some View {
        RoundedRectangle(cornerRadius: 12)
            .fill(Color.white)
    }

    private var cardStroke: some View {
        RoundedRectangle(cornerRadius: 12)
            .stroke(Color.gray.opacity(0.18), lineWidth: 1)
    }

    // reuse your accent color helper
    private func acvissAccentColor() -> Color {
        if UIColor(named: "acviss_blue") != nil {
            return Color("acviss_blue", bundle: AxionBundle.bundle)
        } else if UIColor(named: "blue_text") != nil {
            return Color("blue_text", bundle: AxionBundle.bundle)
        } else {
            return Color.blue
        }
    }
}
import SwiftUI
import Combine

final class KeyboardResponder: ObservableObject {
    @Published var currentHeight: CGFloat = 0

    private var cancellables = Set<AnyCancellable>()

    init() {
        let willShow = NotificationCenter.default
            .publisher(for: UIResponder.keyboardWillShowNotification)
            .merge(with: NotificationCenter.default.publisher(for: UIResponder.keyboardWillChangeFrameNotification))
            .compactMap { $0.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect }
            .map { $0.height }

        let willHide = NotificationCenter.default
            .publisher(for: UIResponder.keyboardWillHideNotification)
            .map { _ in CGFloat(0) }

        Publishers.Merge(willShow, willHide)
            .receive(on: RunLoop.main)
            .sink { [weak self] height in
                withAnimation(.easeOut(duration: 0.25)) {
                    self?.currentHeight = height
                }
            }
            .store(in: &cancellables)
    }

    deinit {
        cancellables.forEach { $0.cancel() }
    }
}

struct CustomTextView: UIViewRepresentable {
    @Binding var text: String
    var placeholder: String = ""
    var onReturn: (() -> Void)? = nil

    func makeUIView(context: Context) -> UITextView {
        let tv = UITextView()
        tv.delegate = context.coordinator
        tv.isScrollEnabled = true
        tv.backgroundColor = .clear
        tv.font = UIFont.preferredFont(forTextStyle: .body)
        tv.returnKeyType = .done
        tv.autocorrectionType = .yes
        tv.textContainerInset = UIEdgeInsets(top: 8, left: 6, bottom: 8, right: 6)
        // placeholder handling
        if text.isEmpty {
            tv.text = placeholder
            tv.textColor = UIColor.systemGray3
        } else {
            tv.text = text
            tv.textColor = UIColor.label
        }
        return tv
    }

    func updateUIView(_ uiView: UITextView, context: Context) {
        if uiView.text != text {
            uiView.text = text
            uiView.textColor = UIColor.label
        }
        // show placeholder if needed
        if text.isEmpty, !uiView.isFirstResponder {
            uiView.text = placeholder
            uiView.textColor = UIColor.systemGray3
        } else if uiView.textColor == UIColor.systemGray3 && uiView.isFirstResponder {
            uiView.text = ""
            uiView.textColor = UIColor.label
        }
    }

    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }

    final class Coordinator: NSObject, UITextViewDelegate {
        var parent: CustomTextView

        init(_ parent: CustomTextView) {
            self.parent = parent
        }

        func textViewDidBeginEditing(_ textView: UITextView) {
            // remove placeholder when editing begins
            if textView.textColor == UIColor.systemGray3 {
                textView.text = ""
                textView.textColor = UIColor.label
            }
        }

        func textViewDidEndEditing(_ textView: UITextView) {
            // sync binding, show placeholder if empty
            parent.text = textView.text ?? ""
            if parent.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                textView.text = parent.placeholder
                textView.textColor = UIColor.systemGray3
            }
        }

        func textViewDidChange(_ textView: UITextView) {
            parent.text = textView.text ?? ""
        }

        // Intercept Return: call onReturn and dismiss keyboard (prevent newline)
        func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
            if text == "\n" {
                // notify
                parent.onReturn?()
                // resign
                textView.resignFirstResponder()
                return false // prevent newline insertion
            }
            return true
        }
    }
}

fileprivate struct RateUsDialog: View {
    @Binding var rating: Int
    @Binding var feedback: String
    @Binding var isPresented: Bool
    var onSubmit: () -> Void

    // observe keyboard
    @StateObject private var keyboard = KeyboardResponder()

    var body: some View {
        VStack(spacing: 16) {
            // Header
            HStack {
                Text("Rate Us")
                    .font(.headline)
                    .foregroundColor(Color("light_text", bundle: AxionBundle.bundle))
                Spacer()
                Button(action: {
                    withAnimation { isPresented = false }
                    // dismiss keyboard too
                    dismissKeyboard()
                }) {
                    Image(systemName: "xmark")
                        .padding(8)
                        .foregroundColor(Color.gray)
                }
                .buttonStyle(PlainButtonStyle())
            }
            .padding(.top, 8)

            // Description
            Text("Your insights are important. Rate us to refine your experience.")
                .font(.subheadline)
                .foregroundColor(Color("light_text", bundle: AxionBundle.bundle).opacity(0.8))
                .fixedSize(horizontal: false, vertical: true)

            // Stars
            Text("Rate your experience")
                .font(.subheadline)
                .frame(maxWidth: .infinity, alignment: .leading)
                .foregroundColor(Color("light_text", bundle: AxionBundle.bundle))
            HStack(spacing: 14) {
                ForEach(1...5, id: \.self) { i in
                    Image(systemName: rating >= i ? "star.fill" : "star")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 36, height: 36)
                        .foregroundColor(rating >= i ? acvissAccentColorStatic() : Color.gray.opacity(0.5))
                        .onTapGesture {
                            withAnimation { rating = i }
                        }
                }
            }

            // Feedback input
            Text("Your feedback")
                .font(.subheadline)
                .frame(maxWidth: .infinity, alignment: .leading)
                .foregroundColor(Color("light_text", bundle: AxionBundle.bundle))

            ZStack(alignment: .topLeading) {
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color.gray.opacity(0.25), lineWidth: 1)
                    .background(RoundedRectangle(cornerRadius: 8).fill(Color.white))
                    .frame(height: 160)

                // TextEditor with toolbar Done button (iOS 14+ / 15+)
                CustomTextView(text: $feedback,
                                   placeholder: "",
                                   onReturn: {
                                        // dismiss keyboard (this triggers keyboard hide notifications)
                                        #if canImport(UIKit)
                                        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
                                        #endif
                                   })
                        .frame(height: 160)
                        .cornerRadius(8)

                if feedback.isEmpty {
                    Text("Describe your experience here")
                        .foregroundColor(Color.gray.opacity(0.5))
                        .padding(.top, 12)
                        .padding(.leading, 14)
                        .font(.subheadline)
                }
            }

            // Submit button
            Button(action: {
                // Dismiss keyboard before submit for better UX
                dismissKeyboard()
                onSubmit()
            }) {
                Text("Submit")
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.white)
                    .background(acvissAccentColorStatic())
                    .cornerRadius(8)
            }
        }
        .padding(20)
        .background(RoundedRectangle(cornerRadius: 12).fill(Color.white))
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.gray.opacity(0.18), lineWidth: 1))
        .frame(maxWidth: 420)
        .shadow(color: Color.black.opacity(0.25), radius: 18, x: 0, y: 10)

        // IMPORTANT: move the dialog up when keyboard appears so Submit isn't covered.
        // We use offset by half the keyboard height to avoid moving it too far.
        .offset(y: keyboard.currentHeight > 0 ? -min(keyboard.currentHeight, 450) / 2 : 0)
        .animation(.easeOut(duration: 0.25), value: keyboard.currentHeight)

        // outer padding that keeps the dialog from touching screen edges
        .padding(.horizontal, 20)
        .padding(.vertical, 40)
    }

    // helper to resign first responder (dismiss keyboard)
    private func dismissKeyboard() {
        #if canImport(UIKit)
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
        #endif
    }

    private func acvissAccentColorStatic() -> Color {
        if UIColor(named: "acviss_blue") != nil {
            return Color("acviss_blue", bundle: AxionBundle.bundle)
        } else if UIColor(named: "blue_text") != nil {
            return Color("blue_text", bundle: AxionBundle.bundle)
        } else {
            return Color.blue
        }
    }
}

// MARK: - Thank You Dialog
fileprivate struct ThankYouDialog: View {
    @Binding var isPresented: Bool
    public var backToHomeAction: () -> Void
    
    var body: some View {
        VStack(spacing: 16) {
            // Close X
            HStack {
                Spacer()
                Button(action: {
                    withAnimation { isPresented = false }
                }) {
                    Image(systemName: "xmark")
                        .foregroundColor(Color.gray)
                        .padding(8)
                }
                .buttonStyle(PlainButtonStyle())
            }
            
            // Badge / Icon
            ZStack {
                // badge
                Image("tick_mark")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 80, height: 80)
                    .foregroundColor(.white)
            }
            .padding(.top, -8)
            
            // Title
            Text("Thank You for Sharing Your\nExperience!")
                .font(.title3)
                .multilineTextAlignment(.center)
                .fontWeight(.semibold)
                .foregroundColor(Color("light_text", bundle: AxionBundle.bundle))
            
            // Description
            Text("Your input helps us improve and enhance our services. We appreciate your time!")
                .font(.subheadline)
                .multilineTextAlignment(.center)
                .foregroundColor(Color("light_text", bundle: AxionBundle.bundle).opacity(0.8))
                .fixedSize(horizontal: false, vertical: true)
            
            // Back to home link
            Button(action: {
                backToHomeAction()
            }) {
                Text("Back to home")
                    .font(.subheadline)
                    .foregroundColor(Color.black)
            }
            .padding(.top, 4)
        }
        .padding(20)
        .background(RoundedRectangle(cornerRadius: 12).fill(Color.white))
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(Color.gray.opacity(0.18), lineWidth: 1))
        .frame(maxWidth: 420)
        .shadow(color: Color.black.opacity(0.25), radius: 18, x: 0, y: 10)
        .padding(.horizontal, 20)
        .padding(.vertical, 40)
    }
    
    private func acvissAccentColorStatic() -> Color {
        if UIColor(named: "acviss_blue") != nil {
            return Color("acviss_blue", bundle: AxionBundle.bundle)
        } else if UIColor(named: "blue_text") != nil {
            return Color("blue_text", bundle: AxionBundle.bundle)
        } else {
            return Color.blue
        }
    }
}

// Customer Details card (logo + name + icons)
struct CustomerDetailsCard: View {
    @ObservedObject var viewmodel: AcvissProdDetailsViewModel
    
    private func logoImage() -> Image {
        if let logoData = viewmodel.logoImageData, let ui = UIImage(data: logoData) {
            return Image(uiImage: ui)
        } else {
            return Image("acviss_logo") // fallback asset
        }
    }
    
    var body: some View {
        if let support = viewmodel.support?.data as? ProductSupport {
            HStack(spacing: 0) {
                // Left: Logo area
                logoImage()
                    .resizable()
                    .scaledToFit()
                    .frame(width: 120, height: 72)
                    .padding(12)
                    .background(
                        RoundedRectangle(cornerRadius: 8)
                            .fill(Color.white)
                    )
                    .padding(.leading, 8)
                
                // Vertical divider
                Rectangle()
                    .fill(Color.gray.opacity(0.22))
                    .frame(width: 1)
                    .padding(.vertical, 12)
                    .padding(.horizontal, 12)
                
                // Right: Title and icons
                VStack(alignment: .center, spacing: 8) {
                    // Title
                    Text(support.name ?? "")
                        .font(.title3)
                        .fontWeight(.semibold)
                        .foregroundColor(Color("light_text", bundle: AxionBundle.bundle))
                        .lineLimit(2)
                        .fixedSize(horizontal: false, vertical: true)
                    
                    // Icons row aligned to trailing
                    HStack(spacing: 20) {
                        // Mail
                        IconCircle(systemName: "envelope", action: {
                            if let email = support.email, let url = URL(string: "mailto:\(email)") {
                                UIApplication.shared.open(url)
                            }
                        })
                        
                        // Phone
                        IconCircle(systemName: "phone", action: {
                            if let phone = support.phoneNumber, let url = URL(string: "tel:\(phone)") {
                                UIApplication.shared.open(url)
                            }
                        })
                        
                        // Web / Globe
                        IconCircle(systemName: "globe", action: {
                            if let web = support.webSite, let url = URL(string: web) {
                                UIApplication.shared.open(url)
                            }
                        })
                    }
                    .frame(maxWidth: .infinity, alignment: .trailing)
                }
                .padding(.vertical, 12)
                .padding(.trailing, 16)
            }
            .background(
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color.white)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.gray.opacity(0.22), lineWidth: 1)
            )
            //            .padding(.horizontal)
            .padding(.top, 6)
            .padding(.bottom, 4)
        }
    }
}

fileprivate struct IconCircle: View {
    let systemName: String
    let action: () -> Void
    
    init(systemName: String, action: @escaping () -> Void = {}) {
        self.systemName = systemName
        self.action = action
    }
    
    // Use a named color 'blue_text' or 'acviss_blue' in Assets.xcassets for exact match, fallback to Color.blue
    private var accent: Color {
        if UIColor(named: "blue_text") != nil {
            return Color("blue_text", bundle: AxionBundle.bundle)
        } else if UIColor(named: "acviss_blue") != nil {
            return Color("acviss_blue", bundle: AxionBundle.bundle)
        } else {
            return Color.blue
        }
    }
    
    var body: some View {
        Button(action: action) {
            ZStack {
                // white rounded box
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color.white)
                    .frame(width: 44, height: 44)
                
                // the symbol, tinted blue
                Image(systemName: systemName)
                    .resizable()
                    .scaledToFit()
                    .frame(width: 30, height: 30)
                    .foregroundColor(accent)
            }
        }
        .buttonStyle(PlainButtonStyle())
    }
}

// --- Add this helper if you don't already have it ---
fileprivate struct InfoRow: View {
    let left: String
    let right: String
    
    var body: some View {
        HStack {
            Text(left)
                .font(.subheadline)
                .foregroundColor(Color("light_text", bundle: AxionBundle.bundle).opacity(0.7))
            Spacer()
            Text(right)
                .font(.subheadline)
                .fontWeight(.bold)
                .foregroundColor(Color("light_text", bundle: AxionBundle.bundle))
        }
        .padding(.vertical, 8)
    }
}

// MARK: - VisualEffectBlur (light wrapper for blur background)
fileprivate struct VisualEffectBlur: UIViewRepresentable {
    var blurStyle: UIBlurEffect.Style = .systemMaterial
    
    func makeUIView(context: Context) -> UIVisualEffectView {
        UIVisualEffectView(effect: UIBlurEffect(style: blurStyle))
    }
    
    func updateUIView(_ uiView: UIVisualEffectView, context: Context) {
        uiView.effect = UIBlurEffect(style: blurStyle)
    }
}
fileprivate struct PointsCard: View {
    let points: Double
    private let backgroundAssetName = "celebration" // <- your asset name
    
    private func formattedPoints(_ p: Double) -> String {
        if p.truncatingRemainder(dividingBy: 1) == 0 {
            return String(format: "%.0f", p)
        } else {
            return String(format: "%.1f", p)
        }
    }
    
    var body: some View {
        ZStack {
            // Background artwork (confetti) clipped to rounded rectangle
            Image(backgroundAssetName)
                .resizable()
                .scaledToFill()
                .opacity(0.18)                     // tweak to taste (keeps text readable)
                .clipped()
                .cornerRadius(12)
                .overlay(
                    // subtle overlay so text contrasts on bright images
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color.white.opacity(0.0))
                )
            
            // White card content with padding over the artwork
            VStack(alignment: .center, spacing: 5) {
                Text("Congrats!")
                    .font(.title3)
                    .fontWeight(.semibold)
                    .foregroundColor(Color("light_text", bundle: AxionBundle.bundle))
                
                Text("You have won")
                    .font(.subheadline)
                    .foregroundColor(Color("light_text", bundle: AxionBundle.bundle).opacity(0.8))
                
                HStack(spacing: 10) {
                    ZStack {
                        Circle()
                            .fill(Color.yellow)
                            .frame(width: 44, height: 44)
                        Image(systemName: "star.fill")
                            .foregroundColor(.white)
                            .font(.system(size: 18, weight: .semibold))
                    }
                    
                    Text("\(formattedPoints(points)) Points")
                        .font(.title2)
                        .fontWeight(.semibold)
                        .foregroundColor(Color("light_text", bundle: AxionBundle.bundle))
                }
                
                // small share / action button
                Button(action: {
                    // implement share action
                }) {
                    Image(systemName: "square.and.arrow.up")
                        .foregroundColor(acvissAccentColor())
                        .padding(10)
                        .background(Color("light_text", bundle: AxionBundle.bundle).opacity(0.06))
                        .clipShape(Circle())
                }
                .buttonStyle(PlainButtonStyle())
                .padding(.top, 4)
            }
            .padding(16)
            .background(
                // keep content on a slightly white card to preserve readability on top of artwork
                RoundedRectangle(cornerRadius: 12)
                    .fill(Color.white.opacity(0.92))
            )
        }
        .frame(maxWidth: .infinity)
        .shadow(color: Color.black.opacity(0.03), radius: 6, x: 0, y: 2)
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color.gray.opacity(0.12), lineWidth: 1)
        )
        // Do NOT add outer horizontal padding here if parent already has it
    }
    
    private func acvissAccentColor() -> Color {
        if UIColor(named: "acviss_blue") != nil {
            return Color("acviss_blue", bundle: AxionBundle.bundle)
        } else if UIColor(named: "blue_text") != nil {
            return Color("blue_text", bundle: AxionBundle.bundle)
        } else {
            return Color.blue
        }
    }
}

// --- Expandable Product Description Card ---
// --- Expandable Product Description Card (updated to render dynamic key/value rows) ---
fileprivate struct ProductDescriptionCard: View {
    @ObservedObject var viewmodel: AcvissProdDetailsViewModel
    @State private var isExpanded: Bool = true

    // helper: detect if text contains any URL
    private func containsURL(_ text: String) -> Bool {
        guard !text.isEmpty else { return false }
        if let detector = try? NSDataDetector(types: NSTextCheckingResult.CheckingType.link.rawValue) {
            let range = NSRange(location: 0, length: (text as NSString).length)
            return detector.firstMatch(in: text, options: [], range: range) != nil
        }
        return false
    }
    
    @ViewBuilder
    private func descriptionView(for desc: String) -> some View {
        if containsURL(desc) {
            if #available(iOS 15.0, *) {
                // Use iOS 15+ Text with links
                Text(.init(desc))
                    .font(.subheadline)
                    .lineSpacing(4.0)
                    .foregroundStyle(Color("light_text", bundle: AxionBundle.bundle).opacity(0.6))
                    .fixedSize(horizontal: false, vertical: true)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .tint(.blue)
            } else {
                // Fallback for iOS 14 - use LinkTextView
                LinkTextView(
                    text: desc,
                    font: UIFont.systemFont(ofSize: 15),
                    textColor: UIColor(Color("light_text", bundle: AxionBundle.bundle)),
                    linkColor: UIColor.systemBlue,
                    alignment: .natural
                )
                .frame(maxWidth: .infinity, alignment: .leading)
                .fixedSize(horizontal: false, vertical: true)
            }
        } else {
            // Regular text without URLs
            Text(desc)
                .font(.subheadline)
                .lineSpacing(4.0)
                .foregroundStyle(Color("light_text", bundle: AxionBundle.bundle).opacity(0.6))
                .fixedSize(horizontal: false, vertical: true)
                .frame(maxWidth: .infinity, alignment: .leading)
        }
    }

    var body: some View {
        VStack(spacing: 0) {
            // Header (unchanged)
            HStack(spacing: 8) {
                // ... header code remains same ...
                Text("Product Description")
                    .font(.subheadline)
                    .fontWeight(.bold)
                    .foregroundColor(Color("light_text", bundle: AxionBundle.bundle))
                Spacer()
                Button(action: { withAnimation(.easeInOut) { isExpanded.toggle() } }) {
                    Image(systemName: "chevron.down")
                        .rotationEffect(.degrees(isExpanded ? 180 : 0))
                        .foregroundColor(Color("light_text", bundle: AxionBundle.bundle))
                }
                .buttonStyle(PlainButtonStyle())
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 10)

            if isExpanded {
                VStack(alignment: .leading, spacing: 12) {
                    
                    if let product = viewmodel.productDetailsObj {
                        
                        VStack(alignment: .leading, spacing: 8) {
                            if let prodImage = viewmodel.productImageData, let img = UIImage(data: prodImage) {
                                Image(uiImage: img)
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(maxWidth: .infinity, maxHeight: 150)
                                    .clipped()
                                    .cornerRadius(8)
                                    .padding(.top, 4)
                            }
                            if let name = product.name, !name.isEmpty {
                                Text(name)
                                    .font(.custom("Nunito Sans", size: 16))
                                    .fontWeight(.semibold)
                                    .foregroundStyle(Color("light_text", bundle: AxionBundle.bundle))
                            }

                            // --- Description: use LinkTextView if it contains any URL ---
//                            if let desc = product.description, !desc.isEmpty {
//                                // if desc contains a URL, render with LinkTextView so it wraps and becomes tappable;
//                                // otherwise fall back to normal Text but allow two lines.
//                                if containsURL(desc) {
//                                    LinkTextView(
//                                        text: desc,
//                                        font: UIFont.systemFont(ofSize: 15),                 // match your Text size
//                                        textColor: UIColor(Color("light_text", bundle: AxionBundle.bundle)),
//                                        linkColor: UIColor.systemBlue,
//                                        alignment: .natural,
//                                        maxLines: 4
//                                    )
//                                    .frame(maxWidth: .infinity, alignment: .leading)
//                                    .frame(maxHeight: 48)    // ~2 lines for 15pt (tweak to 44..56 to fit)
//                                    .padding(.top, 2)
//                                } else {
//                                    Text(desc)
//                                        .font(.subheadline)
//                                        .lineSpacing(4.0)
//                                        .foregroundStyle(Color("light_text", bundle: AxionBundle.bundle).opacity(0.6))
//                                        .fixedSize(horizontal: false, vertical: true)
//                                        .lineLimit(2)
//                                        .padding(.top, 2)
//                                }
//                            }
//                            if let desc = product.description, !desc.isEmpty {
//                                descriptionView(for: desc)
//                                    .padding(.top, 2)
//                            }
                            if let desc = product.description, !desc.isEmpty {
                                Text(.init(desc)) // This automatically handles links in iOS 15+
                                    .font(.subheadline)
                                    .lineSpacing(4.0)
                                    .foregroundStyle(Color("light_text", bundle: AxionBundle.bundle).opacity(0.6))
                                    .fixedSize(horizontal: false, vertical: true)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    .tint(.blue) // Link color
                                    .padding(.top, 2)
                            }

                            // existing image / divider...
                            Divider().padding(.top, 8)

                            // Render grouped sections from viewmodel.attributeSections (titles removed)
                            let sections = viewmodel.attributeSections
                            ForEach(0..<sections.count, id: \.self) { secIdx in
                                let section = sections[secIdx]
                                if secIdx > 0 { Divider().padding(.vertical, 3) }

                                VStack(spacing: 0) {
                                    ForEach(0..<section.rows.count, id: \.self) { rowIdx in
                                        let row = section.rows[rowIdx]

                                        HStack(alignment: .top, spacing: 12) {
                                            // LEFT: stable column for key (allows up to 2 lines)
                                            Text(row.0)
                                                .font(.subheadline)
                                                .foregroundColor(Color("light_text", bundle: AxionBundle.bundle).opacity(0.7))
                                                .frame(width: 120, alignment: .leading)    // stable column width — tweak to taste
                                                .fixedSize(horizontal: false, vertical: true)
                                                .lineLimit(2)

                                            // RIGHT: flexible column for value; use LinkTextView if value contains URL
                                            Group {
                                                if containsURL(row.1) {
                                                    Text(.init(row.1)) // iOS 15+ automatic link handling
                                                        .font(.subheadline)
                                                        .foregroundColor(Color("light_text", bundle: AxionBundle.bundle))
                                                        .multilineTextAlignment(.trailing)
                                                        .fixedSize(horizontal: false, vertical: true)
                                                        .frame(maxWidth: .infinity, alignment: .trailing)
                                                        .tint(.blue) // Link color
                                                } else {
                                                    Text(row.1)
                                                        .font(.subheadline)
                                                        .foregroundColor(Color("light_text", bundle: AxionBundle.bundle))
                                                        .multilineTextAlignment(.trailing)
                                                        .fixedSize(horizontal: false, vertical: true)
                                                        .frame(maxWidth: .infinity, alignment: .trailing)
                                                }
                                            }
                                        }
                                        .padding(.vertical, 10)
                                    }


                                } // VStack
                            } // sections
                        } // inner VStack
                        .padding(.horizontal, 12)
                    } // if product exists
                    // Video (if present)
                    YouTubePlayerContainer(viewmodel: viewmodel)

//                                       if let prod = viewmodel.productDetailsObj,
//                                          let videoUrl = prod.videos?.first,
//                                          let videoId = viewmodel.extractYoutubeID(from: videoUrl) {
//                                           YouTubePlayerView(
//                                                       "https://www.youtube.com/watch?v=h6b5d4VEgGQ"
//                                                   ).frame(height: 200)
//                                                                                          .cornerRadius(8)
//                                                                                          .padding(.horizontal, 12)
////                                           YouTubeVideoPlayer(videoId: videoId, videoUrl: videoUrl)
////                                           YouTubeView(videoId: videoId)
////                                               .frame(height: 200)
////                                               .cornerRadius(8)
////                                               .padding(.horizontal, 12)
//                                       }

                    // video & certificates unchanged...
                } // VStack content
                .padding(.bottom, 12)
            } // if expanded
        } // outer VStack
        .background(RoundedRectangle(cornerRadius: 10).fill(Color.white))
        .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.gray.opacity(0.22), lineWidth: 1))
    }
}

struct YouTubePlayerContainer: View {
    let viewmodel: AcvissProdDetailsViewModel
    
    var body: some View {
        if let prod = viewmodel.productDetailsObj,
           let videoUrl = prod.videos?.first,
           let videoId = viewmodel.extractYoutubeID(from: videoUrl) {
            
            // Create YouTubePlayer instance from the URL string
            let youTubePlayer: YouTubePlayer = YouTubePlayer(stringLiteral: videoUrl)
            
            YouTubePlayerView(youTubePlayer)
                .frame(height: 200)
                .cornerRadius(8)
                .padding(.horizontal, 12)
        }
    }
}
fileprivate func containsURL(_ s: String) -> Bool {
    if s.isEmpty { return false }
    if let detector = try? NSDataDetector(types: NSTextCheckingResult.CheckingType.link.rawValue) {
        let matches = detector.matches(in: s, options: [], range: NSRange(location: 0, length: s.utf16.count))
        return !matches.isEmpty
    }
    return false
}


/// A small UITextView wrapper that detects links and opens them in an SFSafariViewController when tapped.
/// Use it where you need inline tappable links inside paragraph / attribute values.


// MARK: - LinkTextView (UITextView wrapper that detects links and wraps)

struct LinkTextView: UIViewRepresentable {
    let text: String
    let font: UIFont
    let textColor: UIColor
    let linkColor: UIColor
    var alignment: NSTextAlignment = .natural

    func makeCoordinator() -> Coordinator { Coordinator(self) }

    func makeUIView(context: Context) -> UITextView {
        let tv = UITextView()
        tv.delegate = context.coordinator
        tv.isEditable = false
        tv.isSelectable = true
        tv.dataDetectorTypes = [.link]
        tv.backgroundColor = .clear

        // CRITICAL: Allow text view to expand fully
        tv.isScrollEnabled = false
        tv.textContainer.lineFragmentPadding = 0
        tv.textContainerInset = .zero
        tv.textContainer.lineBreakMode = .byWordWrapping
        tv.textContainer.maximumNumberOfLines = 0 // Unlimited lines
        tv.textContainer.widthTracksTextView = true

        tv.font = font
        tv.textColor = textColor
        tv.linkTextAttributes = [
            .foregroundColor: linkColor,
            .underlineStyle: NSUnderlineStyle.single.rawValue
        ]
        tv.textAlignment = alignment

        // Allow proper sizing
        tv.setContentCompressionResistancePriority(.defaultLow, for: .horizontal)
        tv.setContentHuggingPriority(.defaultLow, for: .horizontal)
        tv.setContentCompressionResistancePriority(.required, for: .vertical)
        tv.setContentHuggingPriority(.required, for: .vertical)

        tv.attributedText = attributedString(from: text)
        return tv
    }

    func updateUIView(_ uiView: UITextView, context: Context) {
        let new = attributedString(from: text)
        if uiView.attributedText != new {
            uiView.attributedText = new
        }
        
        // Ensure the text view updates its intrinsic content size
        uiView.invalidateIntrinsicContentSize()
    }

    private func attributedString(from plain: String) -> NSAttributedString {
        let attr = NSMutableAttributedString(string: plain)
        let full = NSRange(location: 0, length: attr.length)
        attr.addAttributes([.font: font, .foregroundColor: textColor], range: full)

        if let detector = try? NSDataDetector(types: NSTextCheckingResult.CheckingType.link.rawValue) {
            detector.enumerateMatches(in: plain, options: [], range: full) { match, _, _ in
                guard let m = match, let url = m.url else { return }
                attr.addAttribute(.link, value: url, range: m.range)
            }
        }
        return attr
    }

    final class Coordinator: NSObject, UITextViewDelegate {
        var parent: LinkTextView
        init(_ p: LinkTextView) { parent = p }

        func textView(_ textView: UITextView, shouldInteractWith URL: URL, in characterRange: NSRange, interaction: UITextItemInteraction) -> Bool {
            UIApplication.shared.open(URL)
            return false
        }
    }
}



//struct YouTubeView: UIViewRepresentable {
//    let videoId: String
//    func makeUIView(context: Context) ->  WKWebView {
//        return WKWebView()
//    }
//    func updateUIView(_ uiView: WKWebView, context: Context) {
//        guard let demoURL = URL(string: "https://www.youtube.com/embed/\(videoId)") else { return }
//        print("Demo url is \(demoURL)")
//        uiView.scrollView.isScrollEnabled = false
//        uiView.load(URLRequest(url: demoURL))
//    }
//}

// MARK: - Public SwiftUI wrapper
import SwiftUI
import WebKit
struct YouTubeVideoPlayer: View {
    let videoId: String
    let videoUrl: String
    @State private var showError = false
    @State private var isLoading = true
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Product Video")
                .font(.subheadline)
                .fontWeight(.semibold)
                .foregroundColor(Color("light_text", bundle: AxionBundle.bundle))
            
            ZStack {
                YouTubeView(videoId: videoId)
                    .frame(height: 200)
                    .cornerRadius(8)
                    .opacity(showError ? 0 : 1)
                
                if showError {
                    VideoFallbackView(videoId: videoId, videoUrl: videoUrl)
                }
                
                if isLoading {
                    ProgressView()
                        .scaleEffect(1.2)
                        .progressViewStyle(CircularProgressViewStyle(tint: .white))
                }
            }
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color.gray.opacity(0.3), lineWidth: 1)
            )
        }
        .padding(.horizontal, 12)
        .padding(.top, 8)
    }
}

struct VideoFallbackView: View {
    let videoId: String
    let videoUrl: String
    
    var body: some View {
        VStack(spacing: 12) {
            Image(systemName: "play.circle.fill")
                .font(.system(size: 40))
                .foregroundColor(.gray)
            
            Text("Video cannot be played in the app")
                .font(.subheadline)
                .foregroundColor(.gray)
                .multilineTextAlignment(.center)
            
            Button("Watch on YouTube") {
                openInYouTube()
            }
            .font(.system(size: 14, weight: .medium))
            .foregroundColor(.blue)
            .padding(.horizontal, 16)
            .padding(.vertical, 8)
            .background(Color.blue.opacity(0.1))
            .cornerRadius(6)
        }
        .frame(height: 200)
        .frame(maxWidth: .infinity)
        .background(Color.black.opacity(0.8))
        .cornerRadius(8)
    }
    
    private func openInYouTube() {
        // Try to open in YouTube app first, then fallback to Safari
        let youtubeAppURL = URL(string: "youtube://watch?v=\(videoId)")!
        let youtubeWebURL = URL(string: "https://www.youtube.com/watch?v=\(videoId)")!
        
        if UIApplication.shared.canOpenURL(youtubeAppURL) {
            UIApplication.shared.open(youtubeAppURL)
        } else {
            UIApplication.shared.open(youtubeWebURL)
        }
    }
}

struct YouTubeView: UIViewRepresentable {
    let videoId: String
    @State private var showError = false
    
    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        
        // Enable JavaScript and better content handling
        if #available(iOS 14.0, *) {
            let preferences = WKWebpagePreferences()
            preferences.allowsContentJavaScript = true
            preferences.preferredContentMode = .mobile
            config.defaultWebpagePreferences = preferences
        } else {
            config.preferences.javaScriptEnabled = true
        }
        
        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.scrollView.isScrollEnabled = false
        webView.backgroundColor = .black
        webView.isOpaque = false
        
        return webView
    }
    
    func updateUIView(_ uiView: WKWebView, context: Context) {
        // Use a more comprehensive embed URL with additional parameters
        let embedURLString = "https://www.youtube.com/embed/\(videoId)?playsinline=1&rel=0&modestbranding=1&autohide=1&showinfo=0&controls=1&fs=1"
        
        guard let url = URL(string: embedURLString) else { return }
        
        var request = URLRequest(url: url)
        request.setValue("strict-origin-when-cross-origin", forHTTPHeaderField: "Referrer-Policy")
        request.setValue("https://www.youtube.com", forHTTPHeaderField: "Referer")
        
        uiView.load(request)
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate {
        let parent: YouTubeView
        
        init(_ parent: YouTubeView) {
            self.parent = parent
        }
        
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            print("✅ YouTube video loaded successfully: \(parent.videoId)")
            
            // Inject JavaScript to monitor for errors
            let errorDetectionScript = """
            function checkForErrors() {
                // Check for error messages in the player
                const errorElements = document.querySelectorAll('.ytp-error, .ytp-preview, [class*="error"]');
                for (let element of errorElements) {
                    if (element.textContent.includes('error') || element.style.display !== 'none') {
                        return true;
                    }
                }
                return false;
            }
            
            // Check initially
            setTimeout(() => {
                if (checkForErrors()) {
                    window.webkit.messageHandlers.youTubeError.postMessage('error_detected');
                }
            }, 2000);
            
            // Monitor for changes
            setInterval(() => {
                if (checkForErrors()) {
                    window.webkit.messageHandlers.youTubeError.postMessage('error_detected');
                }
            }, 3000);
            """
            
            webView.evaluateJavaScript(errorDetectionScript) { _, error in
                if let error = error {
                    print("JavaScript injection error: \(error)")
                }
            }
        }
        
        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            print("❌ YouTube navigation failed: \(error.localizedDescription)")
            showFallbackMessage()
        }
        
        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            print("❌ YouTube provisional navigation failed: \(error.localizedDescription)")
            showFallbackMessage()
        }
        
        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            decisionHandler(.allow)
        }
        
        private func showFallbackMessage() {
            // This would need to communicate back to SwiftUI to show fallback
            print("🔄 Showing fallback message for video: \(parent.videoId)")
        }
    }
}

// MARK: - Wrapper for WKWebView



#Preview {
    var json: [String: Any] = [:]
    let data = try! Data(contentsOf: URL(fileURLWithPath: Bundle.main.path(forResource: "prod_details", ofType: "json")!), options: .mappedIfSafe)
    let jsonResult = try! JSONSerialization.jsonObject(with: data, options: .mutableLeaves)
    //    json = jsonResult as! [String: Any]
    AcvissProdDetailsView(isSuccess: true, jsonResult: jsonResult as! [String: Any])
}
extension AcvissProdDetailsViewModel {
    func submitReport(email: String, description: String, completion: @escaping (Bool, Error?) -> Void) {
        // Build payload — include product id / batch / serial as appropriate
        let productId = productDetailsObj?.id ?? 0
        let barcode = batchCode?.data as? String ?? ""
        let payload: [String: Any] = [
            "product_id": productId,
            "barcode": barcode,
            "is_genuine": true,
            "rating": 5,
            "type": "ISSUE",
            "email": email,
            "feedback": description
        ]

        // TODO: replace with your network code. For now simulate success
        print("Submitting report payload: \(payload)")
        DispatchQueue.global().asyncAfter(deadline: .now() + 0.6) {
            completion(true, nil)
        }
    }
}
