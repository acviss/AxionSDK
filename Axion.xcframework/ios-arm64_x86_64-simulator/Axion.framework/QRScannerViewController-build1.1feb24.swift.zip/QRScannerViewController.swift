import UIKit
import SwiftUI
import AVFoundation
import Vision
import CoreImage
import AVFoundation


final class QRCodeScannerViewController: UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate, AVCapturePhotoCaptureDelegate {
    
    // MARK: - UI Elements
    private var previewView: UIView!
    var testingLabel: String = "Original"
    private var audioButton: UIButton!
    private var audioPlayer: AVAudioPlayer?
    private var isAudioEnabled: Bool = true
//    private var resultImageView: UIImageView!
    private var instructionLabel: UILabel!
    private var logoImageView: UIImageView!
    private var stage1Label: UILabel!
    private var stage2Label: UILabel!
    private var stage3Label: UILabel!
    private var refreshButton: UIButton!
    private var cornerBoxLayer = CAShapeLayer()
    private var statusLabel: UILabel!
    private var torchButton: UIButton!
    private var processingTimer: Timer?
    private let processingTimeout: TimeInterval = 5.0 // 5 seconds timeout
    private var closeButton: UIButton!
    private var isClosing = false
    var onClose: (() -> Void)?
    private var focusButton: UIButton!
    private var focusStatusView: UIView!
    // MARK: - AVFoundation Properties
    private var captureSession: AVCaptureSession!
    private var videoPreviewLayer: AVCaptureVideoPreviewLayer!
    private var videoDevice: AVCaptureDevice?
    private var videoDataOutput: AVCaptureVideoDataOutput!
    private var photoOutput: AVCapturePhotoOutput!
    
    // Timer that will trigger periodic sends
    private var scanTimer: Timer?
    private let scanInterval: TimeInterval = 30.0
    // Small guard to avoid overlapping network uploads
    private var isUploading: Bool = false
    private var pendingTestingLabel: String? = nil
    
    // Optional: keep last captured image if you prefer sending an already-captured image
    private var lastCapturedImage: UIImage?
    
    // MARK: - Vision Properties
    private var visionRequests = [VNRequest]()
    private var isQRCodeDetected = false
    // Store the observation itself to get accurate bounding box later
    private var detectedBarcode: VNBarcodeObservation?
    
    private var performRequestCount = 0
    private var lastBarcode: VNBarcodeObservation?
    private var lastDetectionTime: Date?
    
    
    private var zoomSlider: UISlider!
    private var currentZoom: CGFloat = 2.0
    private let minZoom: CGFloat = 1.0
    private let maxZoom: CGFloat = 8.0
    private let zoomStep: CGFloat = 0.1
    private var zoomLabel: UILabel!
    private var detectedQRCodeValue: String?
    private var isAudioSessionConfigured = false

    private let audioQueue = DispatchQueue(label: "com.axion.scanner.audio",
                                           qos: .background)
    deinit {
        print("QRCodeScannerViewController deallocated")
    }
    
    // MARK: - Lifecycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupCamera()
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        DispatchQueue.global(qos: .userInitiated).async {
            guard let session = self.captureSession else { return }
            if !session.isRunning {
                session.startRunning()
            }
            
            self.toggleTorch()
            // 🔊 Start audio AFTER camera kicks off
            self.audioQueue.async { [weak self] in
                    self?.startAudioIfNeeded()
                }

            DispatchQueue.main.async {
                self.startScanTimer()
            }
        }
    }
    
    private func startScanTimer() {
        stopScanTimer() // ensure single timer
        scanTimer = Timer.scheduledTimer(timeInterval: scanInterval,
                                         target: self,
                                         selector: #selector(scanTimerFired),
                                         userInfo: nil,
                                         repeats: true)
        RunLoop.main.add(scanTimer!, forMode: .common)
        print("⏱️ scan timer started")
    }

    private func stopScanTimer() {
        scanTimer?.invalidate()
        scanTimer = nil
        print("⏹️ scan timer stopped")
    }

    private func resetScanTimer() {
        stopScanTimer()
        startScanTimer()
    }
    
    @objc private func scanTimerFired() {
        // Skip if we're already processing a detected QR or uploading
        guard !isQRCodeDetected, !isUploading else {
            print("⏱️ scanTimer skipped (isQRCodeDetected=\(isQRCodeDetected), isUploading=\(isUploading))")
            return
        }
        
        // Mark that this capture is periodic and should upload with this label
        
        print("⏰ scanTimer fired — capturing photo for periodic upload")
        pendingTestingLabel = "Periodic"
        // Trigger a fresh high-res capture; the photo delegate will call sendImagetoModelAPI(...)
        //        capturePhoto()
      
       stopScanTimer()
        self.showAlert(title: "QR not validated", message: "The QR label could not be verified as original. This product may be invalid.")
    }

    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if self.captureSession?.isRunning == true {
            self.captureSession.stopRunning()
        }
        stopScanTimer()
    }
    
//    override func viewDidLayoutSubviews() {
//        super.viewDidLayoutSubviews()
//        updateCornerBoxes()
//    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()

        // 🔑 THIS IS MANDATORY
        videoPreviewLayer?.frame = previewView.bounds
        cornerBoxLayer.frame = previewView.bounds

        // your existing logic
        updateCornerBoxes()
    }

    private func setupUI() {
        view.backgroundColor = .black
        
        // Preview view (full screen)
        previewView = UIView()
        previewView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(previewView)
        
        // Instruction label
        instructionLabel = UILabel()
        instructionLabel.translatesAutoresizingMaskIntoConstraints = false
        instructionLabel.text = "Make sure the QR Code is centred\nand clearly visible"
        instructionLabel.textColor = .white
        instructionLabel.textAlignment = .center
        instructionLabel.numberOfLines = 0
        instructionLabel.font = .systemFont(ofSize: 18, weight: .medium)
        view.addSubview(instructionLabel)
        
        // Add this near the top of setupUI() after instructionLabel creation
        closeButton = UIButton(type: .system)
        closeButton.translatesAutoresizingMaskIntoConstraints = false
        closeButton.setImage(UIImage(systemName: "chevron.left"), for: .normal)
        closeButton.tintColor = .white
        closeButton.backgroundColor = UIColor(white: 0.0, alpha: 0.35)
        closeButton.layer.cornerRadius = 20
        closeButton.addTarget(self, action: #selector(closeTapped), for: .touchUpInside)
        view.addSubview(closeButton)
        // Make sure the button is always on top so touches reach it
        view.bringSubviewToFront(closeButton)
        audioButton = UIButton(type: .system)
        audioButton.translatesAutoresizingMaskIntoConstraints = false

        let config = UIImage.SymbolConfiguration(pointSize: 20, weight: .semibold)
        audioButton.setImage(
            UIImage(systemName: "speaker.wave.2.fill")?.withConfiguration(config),
            for: .normal
        )

        audioButton.tintColor = .white
        audioButton.backgroundColor = UIColor.black.withAlphaComponent(0.35)
        audioButton.layer.cornerRadius = 22
        audioButton.clipsToBounds = true

        audioButton.addTarget(self, action: #selector(toggleAudio), for: .touchUpInside)
        view.addSubview(audioButton)
        // Prevent preview view intercepting touches (preview is passive)
        previewView.isUserInteractionEnabled = false

        NSLayoutConstraint.activate([
            closeButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            closeButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 12),
            closeButton.widthAnchor.constraint(equalToConstant: 40),
            closeButton.heightAnchor.constraint(equalToConstant: 40),
            audioButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
                audioButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 12),
                audioButton.widthAnchor.constraint(equalToConstant: 44),
                audioButton.heightAnchor.constraint(equalToConstant: 44)
        ])

        
        // Status label (for "QR Code detected")
        statusLabel = UILabel()
        statusLabel.translatesAutoresizingMaskIntoConstraints = false
        statusLabel.text = ""
        statusLabel.textColor = .white
        statusLabel.textAlignment = .center
        statusLabel.font = .systemFont(ofSize: 16, weight: .medium)
        statusLabel.alpha = 0
        view.addSubview(statusLabel)
        
        // Zoom slider
        zoomSlider = UISlider()
        zoomSlider.translatesAutoresizingMaskIntoConstraints = false
        zoomSlider.minimumValue = Float(minZoom)
        zoomSlider.maximumValue = Float(maxZoom)
        zoomSlider.value = Float(currentZoom)
        zoomSlider.minimumTrackTintColor = .white
        zoomSlider.maximumTrackTintColor = .darkGray
        zoomSlider.addTarget(self, action: #selector(zoomSliderValueChanged(_:)), for: .valueChanged)
        view.addSubview(zoomSlider)
        
        // In setupUI(), add:
        zoomLabel = UILabel()
        zoomLabel.translatesAutoresizingMaskIntoConstraints = false
        zoomLabel.text = "\(currentZoom)x"
        zoomLabel.textColor = .white
        zoomLabel.textAlignment = .center
        zoomLabel.font = .systemFont(ofSize: 14, weight: .medium)
        view.addSubview(zoomLabel)
        
        focusButton = UIButton(type: .system)
                focusButton.translatesAutoresizingMaskIntoConstraints = false
                focusButton.setImage(UIImage(systemName: "scope"), for: .normal)
                focusButton.tintColor = .white
                focusButton.addTarget(self, action: #selector(triggerAutoFocus), for: .touchUpInside)
                view.addSubview(focusButton)
        
                // Add constraints for focus button
                NSLayoutConstraint.activate([
                    focusButton.topAnchor.constraint(equalTo: instructionLabel.bottomAnchor, constant: 20),
                    focusButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
                    focusButton.widthAnchor.constraint(equalToConstant: 44),
                    focusButton.heightAnchor.constraint(equalToConstant: 44)
                ])
        
        // Bottom controls
        let bottomControls = UIStackView()
        bottomControls.translatesAutoresizingMaskIntoConstraints = false
        bottomControls.axis = .horizontal
        bottomControls.alignment = .center
        bottomControls.distribution = .equalCentering
        view.addSubview(bottomControls)
        
        // Refresh button
        refreshButton = UIButton(type: .system)
        refreshButton.translatesAutoresizingMaskIntoConstraints = false
        refreshButton.setImage(UIImage(systemName: "arrow.clockwise"), for: .normal)
        refreshButton.tintColor = .white
        refreshButton.addTarget(self, action: #selector(restartScan), for: .touchUpInside)
        bottomControls.addArrangedSubview(refreshButton)
        
        // Logo image (center)
        let logoImageView = UIImageView()
        logoImageView.translatesAutoresizingMaskIntoConstraints = false
        logoImageView.image = UIImage(named: "logo_placeholder")
        logoImageView.contentMode = .scaleAspectFit
        bottomControls.addArrangedSubview(logoImageView)
        
        NSLayoutConstraint.activate([
            logoImageView.widthAnchor.constraint(lessThanOrEqualTo: view.widthAnchor, multiplier: 0.4),
            logoImageView.heightAnchor.constraint(equalToConstant: 40)
        ])
        
        // Torch button
        torchButton = UIButton(type: .system)
        torchButton.translatesAutoresizingMaskIntoConstraints = false
        torchButton.setImage(UIImage(systemName: "bolt.fill"), for: .normal)
        torchButton.tintColor = .white
        torchButton.addTarget(self, action: #selector(toggleTorch), for: .touchUpInside)
        bottomControls.addArrangedSubview(torchButton)
        
        // Corner boxes
        cornerBoxLayer.strokeColor = UIColor.white.cgColor
        cornerBoxLayer.lineWidth = 3.0
        cornerBoxLayer.fillColor = UIColor.clear.cgColor
        cornerBoxLayer.frame = previewView.bounds
        previewView.layer.addSublayer(cornerBoxLayer)
        
        // Constraints
        NSLayoutConstraint.activate([
            previewView.topAnchor.constraint(equalTo: view.topAnchor),
            previewView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            previewView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            previewView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            
            instructionLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            instructionLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40),
            instructionLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -40),
            
            statusLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            statusLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40),
            statusLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -40),
            
            zoomSlider.bottomAnchor.constraint(equalTo: bottomControls.topAnchor, constant: -20),
            zoomSlider.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40),
            zoomSlider.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -40),
            zoomLabel.bottomAnchor.constraint(equalTo: zoomSlider.topAnchor, constant: -8),
            zoomLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            
            bottomControls.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -30),
            bottomControls.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40),
            bottomControls.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -40),
            bottomControls.heightAnchor.constraint(equalToConstant: 50)
        ])
        
        updateCornerBoxes()
    }
    
    @objc private func toggleAudio() {
        isAudioEnabled.toggle()

        let iconName = isAudioEnabled ? "speaker.wave.2.fill" : "speaker.slash.fill"
        let config = UIImage.SymbolConfiguration(pointSize: 20, weight: .semibold)

        DispatchQueue.main.async {
            self.audioButton.setImage(
                UIImage(systemName: iconName)?.withConfiguration(config),
                for: .normal
            )
        }

        audioQueue.async {
            if self.isAudioEnabled {
                self.startAudioIfNeeded()
            } else {
                self.audioPlayer?.pause()
            }
        }
    }
    private func configureAudioSessionIfNeeded() {
        guard !isAudioSessionConfigured else { return }

        DispatchQueue.main.async {
            do {
                let session = AVAudioSession.sharedInstance()
                try session.setCategory(.playback, mode: .default, options: [.mixWithOthers])
                try session.setActive(true)
                self.isAudioSessionConfigured = true
            } catch {
                print("❌ Audio session error: \(error)")
            }
        }
    }
    private func startAudioIfNeeded() {
        guard isAudioEnabled else { return }

        if let player = audioPlayer {
            if !player.isPlaying {
                player.play()
            }
            return
        }

        configureAudioSessionIfNeeded()

        // 🔑 LOAD FROM SDK BUNDLE
        guard let url = AxionBundle.bundle.url(
            forResource: "en_qr_code_instr",
            withExtension: "m4a"
        ) else {
            print("❌ Audio file not found in AxionBundle.bundle")
            return
        }

        do {
            let player = try AVAudioPlayer(contentsOf: url)
            player.numberOfLoops = -1       // loop instruction
            player.prepareToPlay()
            audioPlayer = player

            if isAudioEnabled {
                player.play()
            }
        } catch {
            print("❌ Audio init error: \(error.localizedDescription)")
        }
    }


    @available(iOS 13.0, *)
        private func monitorFocusState() {
            guard let device = videoDevice else { return }
    
            device.addObserver(self, forKeyPath: "adjustingFocus", options: [.new], context: nil)
            device.addObserver(self, forKeyPath: "lensPosition", options: [.new], context: nil)
        }
    
        override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
            if keyPath == "adjustingFocus" {
                if let adjusting = change?[.newKey] as? Bool {
                    DispatchQueue.main.async {
                        self.updateFocusStatus(isFocused: !adjusting)
                    }
                }
            }
        }
        private func setupFocusStatusIndicator() {
            focusStatusView = UIView()
            focusStatusView.translatesAutoresizingMaskIntoConstraints = false
            focusStatusView.backgroundColor = .red
            focusStatusView.layer.cornerRadius = 4
            focusStatusView.alpha = 0
            view.addSubview(focusStatusView)
    
            NSLayoutConstraint.activate([
                focusStatusView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10),
                focusStatusView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -10),
                focusStatusView.widthAnchor.constraint(equalToConstant: 8),
                focusStatusView.heightAnchor.constraint(equalToConstant: 8)
            ])
        }
    
        private func updateFocusStatus(isFocused: Bool) {
            UIView.animate(withDuration: 0.3) {
                self.focusStatusView.backgroundColor = isFocused ? .green : .red
                self.focusStatusView.alpha = isFocused ? 1 : 0.5
            }
        }
    
    @objc private func closeTapped() {
        // prevent multiple taps
        guard !isClosing else { return }
        isClosing = true
        stopScanTimer()
        closeButton.isEnabled = false
        audioQueue.async { [weak self] in
            self?.audioPlayer?.stop()
            self?.audioPlayer = nil
        }
        // Stop capture session on background queue — wait until it finishes
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self = self else { return }

            if let session = self.captureSession, session.isRunning {
                session.stopRunning() // blocking call — will return when stopped
                print("✅ capture session stopped")
            }

            // Remove any observers/timers that might keep VC alive
            DispatchQueue.main.async {
                self.processingTimer?.invalidate()
                self.processingTimer = nil

                // If you added KVO observers (e.g., on device), remove them safely:
                // try? self.videoDevice?.removeObserver(self, forKeyPath: "adjustingFocus")

                // If VC is embedded in a navigation controller, dismiss the whole nav
                if let nav = self.navigationController, nav.presentingViewController != nil {
                    nav.dismiss(animated: true) {
                        self.onClose?()
                        self.cleanupAfterDismiss()
                    }
                } else {
                    self.dismiss(animated: true) {
                        self.onClose?()
                        self.cleanupAfterDismiss()
                    }
                }
            }
        }
    }

    private func cleanupAfterDismiss() {
        // Optional: tidy up to ensure deinit happens
        self.captureSession = nil
        self.videoDevice = nil
        self.videoPreviewLayer?.removeFromSuperlayer()
        self.videoPreviewLayer = nil
        self.isClosing = false
    }
        @objc private func triggerAutoFocus() {
            guard let device = videoDevice else { return }
    
            do {
                try device.lockForConfiguration()
    
                // Trigger autofocus
                if device.isFocusModeSupported(.autoFocus) {
                    device.focusMode = .autoFocus
                }
    
                // Trigger auto exposure
                if device.isExposureModeSupported(.autoExpose) {
                    device.exposureMode = .autoExpose
                }
    
                device.unlockForConfiguration()
    
                // Show feedback
                showFocusFeedback()
    
            } catch {
                print("❌ Auto focus trigger failed: \(error)")
            }
        }
    
        private func showFocusFeedback() {
            let generator = UIImpactFeedbackGenerator(style: .medium)
            generator.impactOccurred()
    
            UIView.animate(withDuration: 0.2, animations: {
                self.focusButton.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
            }) { _ in
                UIView.animate(withDuration: 0.2) {
                    self.focusButton.transform = CGAffineTransform.identity
                }
            }
        }
        private func optimizeForLowLight() {
            guard let device = videoDevice else { return }
    
            do {
                try device.lockForConfiguration()
    
                // Enable low light boost if available
                if device.isLowLightBoostSupported {
                    device.automaticallyEnablesLowLightBoostWhenAvailable = true
                    print("✅ Low light boost enabled")
                }
    
                // Set longer exposure if needed for low light
                if device.isExposureModeSupported(.custom) {
                    // You can adjust these values based on testing
                    let minISO = device.activeFormat.minISO
                    let maxISO = device.activeFormat.maxISO
                    device.setExposureModeCustom(duration: CMTimeMake(value: 1, timescale: 30),
                                                 iso: max(minISO * 2, min(maxISO, minISO * 4)),
                                                 completionHandler: nil)
                }
    
                device.unlockForConfiguration()
    
            } catch {
                print("❌ Low light optimization failed: \(error)")
            }
        }
        // MARK: - Update Detection Status
        private func updateDetectionStatus(isDetected: Bool) {
            DispatchQueue.main.async {
                if isDetected {
                    self.cornerBoxLayer.strokeColor = UIColor.green.cgColor
                    self.statusLabel.text = "Align QR code in the frame"
                    UIView.animate(withDuration: 0.3) {
                        self.statusLabel.alpha = 1
                    }
                } else {
                    self.cornerBoxLayer.strokeColor = UIColor.white.cgColor
                    self.statusLabel.text = "Scanning..."
                    UIView.animate(withDuration: 0.3) {
                        self.statusLabel.alpha = 0
                    }
                }
            }
        }
        // Call this when QR code is detected
        //        private func qrCodeDetected() {
        //            cornerBoxLayer.strokeColor = UIColor.green.cgColor
        //            statusLabel.text = "QR Code detected"
        //            ProgressHUD.shared.show(in: view, message: "Processing...")
        //            UIView.animate(withDuration: 0.3) {
        //                self.statusLabel.alpha = 1
        //            }
        //        }
    
        private func freezePreview() {
            DispatchQueue.main.async {
                self.videoPreviewLayer.connection?.isEnabled = false
            }
        }

    // MARK: - Corner Box Drawing
    private func createStageView(number: String, title: String, isActive: Bool) -> UIStackView {
            let container = UIStackView()
            container.axis = .vertical
            container.alignment = .center
            container.spacing = 4
            
            let numberLabel = UILabel()
            numberLabel.text = number
            numberLabel.textColor = isActive ? .white : .lightGray
            numberLabel.font = .systemFont(ofSize: 16, weight: .bold)
            
            let titleLabel = UILabel()
            titleLabel.text = title
            titleLabel.textColor = isActive ? .white : .lightGray
            titleLabel.font = .systemFont(ofSize: 14, weight: .medium)
            
            container.addArrangedSubview(numberLabel)
            container.addArrangedSubview(titleLabel)
            
            return container
        }
    // Update your updateCornerBoxes method to handle empty bounds:
    private func updateCornerBoxes() {
        let path = UIBezierPath()
        let boxSize: CGFloat = 40 // Increased from 30 to 40
        let viewBounds = previewView.bounds
        
        // Calculate center box dimensions
        let centerBoxWidth: CGFloat = 250 // Width of the centered box area
        let centerBoxHeight: CGFloat = 250 // Height of the centered box area
        let centerX = viewBounds.midX - centerBoxWidth/2
        let centerY = viewBounds.midY - centerBoxHeight/2
        
        // Top left (adjusted to be centered)
        path.move(to: CGPoint(x: centerX, y: centerY + boxSize))
        path.addLine(to: CGPoint(x: centerX, y: centerY))
        path.addLine(to: CGPoint(x: centerX + boxSize, y: centerY))
        
        // Top right
        path.move(to: CGPoint(x: centerX + centerBoxWidth - boxSize, y: centerY))
        path.addLine(to: CGPoint(x: centerX + centerBoxWidth, y: centerY))
        path.addLine(to: CGPoint(x: centerX + centerBoxWidth, y: centerY + boxSize))
        
        // Bottom left
        path.move(to: CGPoint(x: centerX, y: centerY + centerBoxHeight - boxSize))
        path.addLine(to: CGPoint(x: centerX, y: centerY + centerBoxHeight))
        path.addLine(to: CGPoint(x: centerX + boxSize, y: centerY + centerBoxHeight))
        
        // Bottom right
        path.move(to: CGPoint(x: centerX + centerBoxWidth - boxSize, y: centerY + centerBoxHeight))
        path.addLine(to: CGPoint(x: centerX + centerBoxWidth, y: centerY + centerBoxHeight))
        path.addLine(to: CGPoint(x: centerX + centerBoxWidth, y: centerY + centerBoxHeight - boxSize))
        
        cornerBoxLayer.path = path.cgPath
    }
    
   
    
    // MARK: - Torch Button Action
    // MARK: - Torch Button Action
    @objc private func toggleTorchButton() {
        toggleTorch()
    }

    @objc private func toggleTorch() {
        guard let device = videoDevice, device.hasTorch else {
            torchButton.isHidden = true
            return
        }
        
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self = self else { return }
            
            do {
                try device.lockForConfiguration()
                
                let newMode: AVCaptureDevice.TorchMode = device.torchMode == .off ? .on : .off
                var success = true
                
                if newMode == .on {
                    // Try to turn on with max brightness
                    do {
                        try device.setTorchModeOn(level: AVCaptureDevice.maxAvailableTorchLevel)
                    } catch {
                        success = false
                        print("Failed to set torch level: \(error)")
                    }
                } else {
                    device.torchMode = .off
                }
                
                device.unlockForConfiguration()
                
                // Update UI on main thread
                DispatchQueue.main.async {
                    if success {
                        self.torchButton.tintColor = newMode == .on ? .yellow : .white
                        print("🔦 Torch toggled: \(newMode == .on ? "ON" : "OFF")")
                    } else {
                        self.torchButton.tintColor = .white
                        print("⚠️ Torch operation failed")
                    }
                }
            } catch {
                print("❌ Torch error: \(error)")
                DispatchQueue.main.async {
                    self.torchButton.tintColor = .white
                }
            }
        }
    }
    // MARK: - Update Detection Status

    @objc public func restartScan() {
        print("🔄 Restarting scan...")
        self.zoomLabel.text = "2.0x"
        // 1. Reset all detection states
        self.isQRCodeDetected = false
        self.detectedBarcode = nil
        self.lastBarcode = nil
        self.performRequestCount = 0
        self.currentZoom = 2.0 // Reset zoom to 2.0x
        NSObject.cancelPreviousPerformRequests(withTarget: self)
        
        // 2. Reset UI
        self.updateDetectionStatus(isDetected: false)
        self.instructionLabel.text = "Point camera at a QR code"
        self.zoomSlider.value = Float(self.currentZoom) // Reset slider position
        
        // Update zoom label if you added it
        // self.zoomLabel.text = "2.0x"
        
//        ProgressHUD.shared.hide()
        
        // 3. Re-enable preview first
        self.videoPreviewLayer.connection?.isEnabled = true
        
        // 4. Reset camera configuration with proper zoom
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self = self else { return }
            
            // 4a. Configure device with 2.0x zoom
            if let device = self.videoDevice {
                do {
                    try device.lockForConfiguration()
                    
                    // Reset zoom to 2.0x
                    device.videoZoomFactor = 2.0
                    print("✅ Zoom reset to 2.0x")
                    
                    device.unlockForConfiguration()
                } catch {
                    print("❌ Could not reset zoom: \(error)")
                }
            }
            
            // 4b. Restart session properly
            if let session = self.captureSession {
                if !session.isRunning {
                    // Add slight delay to ensure clean restart
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        session.startRunning()
                        print("✅ Capture session restarted with 2.0x zoom")
                    }
                } else {
                    print("ℹ️ Session already running")
                }
            }
        }
        self.resetScanTimer()
        audioQueue.async { [weak self] in
            guard let self = self else { return }
            if self.isAudioEnabled {
                self.audioPlayer?.currentTime = 0
                self.audioPlayer?.play()
            }
        }
    }
    
    func isImageBlurry(_ image: UIImage, threshold: Float = 1000.0) -> Bool {
        guard let cgImage = image.cgImage else { return false }

        // 1) Create CIImage
        var ciImage = CIImage(cgImage: cgImage)

        // 2) Downscale to fixed width (helps make threshold stable)
        let targetWidth: CGFloat = 600.0
        let scale = min(1.0, targetWidth / ciImage.extent.width)
        if scale < 1.0 {
            ciImage = ciImage.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
        }

        // 3) Convert to luminance (grayscale) using CIColorMatrix
        let colorMatrixFilter = CIFilter(name: "CIColorMatrix")!
        // Luminance weights: 0.299, 0.587, 0.114
        colorMatrixFilter.setValue(ciImage, forKey: kCIInputImageKey)
        colorMatrixFilter.setValue(CIVector(x: 0.299, y: 0.299, z: 0.299, w: 0), forKey: "inputRVector")
        colorMatrixFilter.setValue(CIVector(x: 0.587, y: 0.587, z: 0.587, w: 0), forKey: "inputGVector")
        colorMatrixFilter.setValue(CIVector(x: 0.114, y: 0.114, z: 0.114, w: 0), forKey: "inputBVector")
        colorMatrixFilter.setValue(CIVector(x: 0, y: 0, z: 0, w: 0), forKey: "inputBiasVector")
        guard let gray = colorMatrixFilter.outputImage else { return false }

        // 4) Apply Laplacian using CIConvolution3X3
        let kernel: [CGFloat] = [
            -1, -1, -1,
            -1,  8, -1,
            -1, -1, -1
        ]
        let convFilter = CIFilter(name: "CIConvolution3X3")!
        convFilter.setValue(gray, forKey: kCIInputImageKey)
        convFilter.setValue(CIVector(values: kernel, count: 9), forKey: "inputWeights")
        convFilter.setValue(0.0, forKey: "inputBias")
        guard let laplacianImage = convFilter.outputImage else { return false }

        // 5) Render the laplacian result to RGBA8 (we'll read the R channel — it's grayscale)
        let context = CIContext(options: nil)
        let extent = laplacianImage.extent.integral
        guard let outCG = context.createCGImage(laplacianImage, from: extent) else { return false }

        // 6) Read pixel bytes
        let width = outCG.width
        let height = outCG.height
        let bytesPerRow = width * 4
        let bufferSize = bytesPerRow * height
        guard let data = malloc(bufferSize) else { return false }
        defer { free(data) }

        let colorSpace = CGColorSpaceCreateDeviceRGB()
        guard let ctx = CGContext(data: data,
                                  width: width,
                                  height: height,
                                  bitsPerComponent: 8,
                                  bytesPerRow: bytesPerRow,
                                  space: colorSpace,
                                  bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else {
            return false
        }
        ctx.draw(outCG, in: CGRect(x: 0, y: 0, width: width, height: height))

        // 7) Compute mean and variance on the R channel (grayscale)
        let ptr = data.bindMemory(to: UInt8.self, capacity: bufferSize)
        var sum: Double = 0
        var sumSq: Double = 0
        let pixelCount = width * height

        for i in 0..<pixelCount {
            let r = Double(ptr[i * 4]) // R channel; image is grayscale so R==G==B
            sum += r
            sumSq += r * r
        }

        let n = Double(pixelCount)
        guard n > 0 else { return false }

        let mean = sum / n
        let variance = (sumSq / n) - (mean * mean) // E[x^2] - (E[x])^2

        print("isImageBlurry: laplacian variance = \(variance)  (mean = \(mean))")

        // 8) Decide blur: low variance => blurry
        return variance < Double(threshold)
    }
    
    // MARK: - Camera Setup
    private func setupCamera() {
        captureSession = AVCaptureSession()
        captureSession.sessionPreset = .photo // Use photo preset for high-resolution images
        
        // 1. Get the default video device
        guard let device = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back) else {
            print("Failed to get the camera device.")
            instructionLabel.text = "Camera not available."
            return
        }
        self.videoDevice = device
        
        // 2. Create the video input
        guard let videoInput = try? AVCaptureDeviceInput(device: device) else {
            print("Failed to create video input.")
            return
        }
        
        if captureSession.canAddInput(videoInput) {
            captureSession.addInput(videoInput)
        }
        
        // 3. Create the video data output
        videoDataOutput = AVCaptureVideoDataOutput()
        videoDataOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "videoQueue"))
        if captureSession.canAddOutput(videoDataOutput) {
            captureSession.addOutput(videoDataOutput)
        }
        
        // 4. Create the photo output for capturing images
        photoOutput = AVCapturePhotoOutput()
        if captureSession.canAddOutput(photoOutput) {
            captureSession.addOutput(photoOutput)
        }
        
        // 5. Setup the preview layer
        videoPreviewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        videoPreviewLayer.videoGravity = .resizeAspectFill
        previewView.layer.addSublayer(videoPreviewLayer)
        
        previewView.layer.insertSublayer(cornerBoxLayer, above: videoPreviewLayer)
        // Check torch availability
            if let device = videoDevice {
                torchButton.isHidden = !device.hasTorch
            } else {
                torchButton.isHidden = true
            }
        // Set initial frame for the preview layer
//        DispatchQueue.main.async {
//            self.videoPreviewLayer.frame = self.previewView.bounds
//        }
        justZoom()
        // 6. Setup Vision request
        setupVision()
    }
    
    
    
    // MARK: - Vision Setup
    private func setupVision() {
        // Create a barcode detection request
        let barcodeRequest = VNDetectBarcodesRequest { [weak self] request, error in
            self?.processBarcodes(for: request, error: error)
        }
        // We are interested in QR codes
        barcodeRequest.symbologies = [.qr]
        self.visionRequests = [barcodeRequest]
    }
    
    // MARK: - AVCaptureVideoDataOutputSampleBufferDelegate
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
        // If we've already detected a QR code and are in the process of capturing, don't process more frames.
        if isQRCodeDetected { return }
        
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
        
        // Perform the vision request on the pixel buffer
        var requestOptions: [VNImageOption: Any] = [:]
        if let cameraIntrinsicData = CMGetAttachment(sampleBuffer, key: kCMSampleBufferAttachmentKey_CameraIntrinsicMatrix, attachmentModeOut: nil) {
            requestOptions = [.cameraIntrinsics: cameraIntrinsicData]
        }
        
        let imageRequestHandler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up, options: requestOptions)
        
        do {
            try imageRequestHandler.perform(self.visionRequests)
        } catch {
            print("Failed to perform Vision request: \(error)")
        }
    }
    
    // MARK: - Update your barcode detection method

    

    private func processBarcodes(for request: VNRequest, error: Error?) {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            
            // Throttle
            if let lastTime = self.lastDetectionTime,
               Date().timeIntervalSince(lastTime) < 0.3 {
                return
            }
            self.lastDetectionTime = Date()
            
            if let error = error {
                print("❌ Vision error: \(error.localizedDescription)")
                return
            }
            
            guard let results = request.results,
                  let barcode = results.first as? VNBarcodeObservation,
                  barcode.confidence > 0.9,
                  self.isQRCodeFullyVisible(barcode)
            else {
                self.updateDetectionStatus(isDetected: false)
                return
            }
            
            // Store the QR code value
            if let qrCodeValue = barcode.payloadStringValue {
                self.detectedQRCodeValue = qrCodeValue
                print("📱 QR Code detected: \(qrCodeValue)")
            }

            
            // Only reset timer if QR code has changed
            if let last = self.lastBarcode,
               last.payloadStringValue == barcode.payloadStringValue {
                // same QR → do nothing, timer already running
            } else {
                self.lastBarcode = barcode
                NSObject.cancelPreviousPerformRequests(withTarget: self,
                                                       selector: #selector(self.handleStabilizedQRCode),
                                                       object: nil)
                self.perform(#selector(self.handleStabilizedQRCode), with: nil, afterDelay: 0.5)
                print("🔍 New QR detected – stabilization timer started")
            }
        }
    }


    @objc private func handleStabilizedQRCode() {
        guard let barcode = self.lastBarcode, !self.isQRCodeDetected else {
            print("⚠️ No barcode available or already processing")
            return
        }
        
        // Capture a weak reference to avoid retain cycles
        ProgressHUD.shared.show(in: view, message: "Processing...")
        print("✅ QR Code stabilized - processing")
        self.isQRCodeDetected = true
        self.updateDetectionStatus(isDetected: true)
        self.detectedBarcode = barcode
        self.freezePreview()
        
        // Give a small delay to ensure everything is ready
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { [weak self] in
            self?.zoomAndCapture()
        }
    }
    private func isQRCodeFullyVisible(_ barcode: VNBarcodeObservation) -> Bool {
        // Convert normalized coordinates to view coordinates
        let boundingBox = barcode.boundingBox
        
        // Check if all corners are within the image bounds (0-1 range)
        let topLeft = CGPoint(x: boundingBox.minX, y: boundingBox.maxY)
        let topRight = CGPoint(x: boundingBox.maxX, y: boundingBox.maxY)
        let bottomLeft = CGPoint(x: boundingBox.minX, y: boundingBox.minY)
        let bottomRight = CGPoint(x: boundingBox.maxX, y: boundingBox.minY)
        
        // Define a small margin (e.g., 5% of the frame)
        let margin: CGFloat = 0.05
        
        // Check all corners are within the frame with margin
        let isFullyVisible =
            topLeft.x > margin && topLeft.y < (1 - margin) &&
            topRight.x < (1 - margin) && topRight.y < (1 - margin) &&
            bottomLeft.x > margin && bottomLeft.y > margin &&
            bottomRight.x < (1 - margin) && bottomRight.y > margin
        
        // Additional check for the black circle (assuming it's part of the QR code)
        // We can check if the bounding box is large enough relative to the frame
        let minRelativeSize: CGFloat = 0.3 // At least 30% of frame width/height
        let isLargeEnough =
            boundingBox.width > minRelativeSize &&
            boundingBox.height > minRelativeSize
        
//        return isFullyVisible && isLargeEnough
        return isFullyVisible
    }
    @objc private func zoomSliderValueChanged(_ sender: UISlider) {
        let roundedValue = round(sender.value / Float(zoomStep)) * Float(zoomStep)
        sender.value = roundedValue
        
        let newZoom = CGFloat(roundedValue)
        currentZoom = newZoom
        
        // Update zoom label
        zoomLabel.text = String(format: "%.1fx", newZoom)
        
        setZoom(newZoom)
    }

    private func setZoom(_ zoom: CGFloat) {
        guard let device = videoDevice else { return }
        
        do {
            try device.lockForConfiguration()
            
            // Apply zoom with clamping to device limits
            let clampedZoom = max(minZoom, min(zoom, maxZoom))
            device.videoZoomFactor = clampedZoom
            
            device.unlockForConfiguration()
            
            print("🔍 Zoom set to: \(clampedZoom)x")
            
        } catch {
            print("❌ Could not set zoom: \(error)")
        }
    }
    func justZoom() {
        guard let device = videoDevice else { return }
        
        do {
            try device.lockForConfiguration()
            
            // Use currentZoom instead of hardcoded value
            device.videoZoomFactor = max(1.0, min(currentZoom, device.activeFormat.videoMaxZoomFactor))
            
            device.unlockForConfiguration()
            
        } catch {
            print("Could not lock device for configuration: \(error)")
        }
    }
    // MARK: - Camera Actions (Zoom and Capture)
    private func zoomAndCapture() {
        guard let device = videoDevice else { return }
        
        do {
            //            try device.lockForConfiguration()
            //
            //            // --- Zoom Logic ---
            //            // Let's zoom to a factor of 2.5x. You can adjust this.
            //            // We clamp the value to be within the device's available zoom range.
            //            let desiredZoomFactor: CGFloat = 2.5
            //            device.videoZoomFactor = max(1.0, min(desiredZoomFactor, device.activeFormat.videoMaxZoomFactor))
            //
            //            device.unlockForConfiguration()
            
            // Give the camera a moment to adjust focus and exposure after zooming.
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.capturePhoto()
            }
            
        } catch {
            print("Could not lock device for configuration: \(error)")
        }
    }
    
    private func capturePhoto() {
        let settings: AVCapturePhotoSettings
        
        // Use a high-resolution format if available by creating the settings with a format dictionary.
        if self.photoOutput.availablePhotoPixelFormatTypes.contains(kCVPixelFormatType_420YpCbCr8BiPlanarFullRange) {
            settings = AVCapturePhotoSettings(format: [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_420YpCbCr8BiPlanarFullRange])
        } else {
            // Fallback to default settings if the desired format is not available.
            settings = AVCapturePhotoSettings()
        }
        
        photoOutput.capturePhoto(with: settings, delegate: self)
    }
    private func debugImageInfo(_ ciImage: CIImage, _ barcode: VNBarcodeObservation?) {
        print("=== DEBUG IMAGE INFO ===")
        print("CIImage extent: \(ciImage.extent)")
        print("CIImage properties: \(ciImage.properties)")
        
        if let barcode = barcode {
            print("Barcode boundingBox: \(barcode.boundingBox)")
            print("Barcode confidence: \(barcode.confidence)")
            print("Barcode payload: \(barcode.payloadStringValue ?? "nil")")
            
            // Convert to image coordinates for debugging
            let imageSize = ciImage.extent.size
            let originX = barcode.boundingBox.origin.x * imageSize.width
            let originY = (1 - barcode.boundingBox.origin.y - barcode.boundingBox.height) * imageSize.height
            let width = barcode.boundingBox.width * imageSize.width
            let height = barcode.boundingBox.height * imageSize.height
            
            print("Barcode in image coordinates: (\(originX), \(originY), \(width), \(height))")
        }
        print("========================")
    }
    // MARK: - AVCapturePhotoCaptureDelegate
    // MARK: - AVCapturePhotoCaptureDelegate
//    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
//        if let error = error {
////            print("❌ Photo processing error: \(error.localizedDescription)")
//            ProgressHUD.shared.hide()
//            resetDetection()
//            return
//        }
//        
//        guard let imageData = photo.fileDataRepresentation() else {
//            print("❌ Could not get image data")
//            ProgressHUD.shared.hide()
//            resetDetection()
//            return
//        }
//        
//        print("✅ Captured photo successfully")
//        
//        // Process the image
//        guard let ciImage = CIImage(data: imageData) else {
//            print("❌ Could not create CIImage from data")
//            ProgressHUD.shared.hide()
//            resetDetection()
//            return
//        }
//        
//        DispatchQueue.global(qos: .userInitiated).async {
//            // Save original for debugging
//            let context = CIContext()
//            if let cgImage = context.createCGImage(ciImage, from: ciImage.extent) {
//                let originalImage = UIImage(cgImage: cgImage)
////                UIImageWriteToSavedPhotosAlbum(originalImage, nil, nil, nil)
//            }
//            
//            // Try multiple cropping methods
//            var croppedImage: UIImage?
//            
//            // Method 1: Enhanced CIDetector with scale/rotation
//            croppedImage = self.cropSquareNow(ciImage)
//            
//            // Method 2: Fallback to Vision bounds if available
//            if croppedImage == nil, let detected = self.detectedBarcode {
//                print("🔄 Falling back to Vision-based cropping")
//                croppedImage = self.cropUsingVisionObservation(ciImage, observation: detected)
//            }
//            
//            // Method 3: Last resort - center crop
//            if croppedImage == nil {
//                print("🔄 Using center crop as last resort")
//                croppedImage = self.manualCenterCrop(ciImage)
//            }
//            
//            guard let finalImage = croppedImage else {
//                print("❌ All cropping methods failed")
//                DispatchQueue.main.async {
//                    ProgressHUD.shared.hide()
//                    self.instructionLabel.text = "Failed to process image"
//                    self.resetDetection()
//                }
//                return
//            }
//            
//            // Save cropped image for verification
//            UIImageWriteToSavedPhotosAlbum(finalImage, nil, nil, nil)
//            
//            // Check image quality
//
//            if !self.isImageBlurry(finalImage, threshold: 70) {
//                DispatchQueue.main.async {
//                    self.sendImagetoModelAPI(image: finalImage, testingLabel: self.testingLabel) { result in
//                        switch result {
//                        case .success(let src):
//                            print("Image uploaded successfully. Source URL: \(src)")
//                        case .failure(let error):
//                            print("Error uploading image: \(error.localizedDescription)")
//                        }
//                    }
//                    self.instructionLabel.text = "Capture Complete!"
//                }
//            }
//            else {
//                print("❌ Cropped image is blurry")
//                DispatchQueue.main.async {
//                    self.instructionLabel.text = "Image is blurry - try holding steady"
//                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
//                        ProgressHUD.shared.hide()
//                        self.resetDetection()
//                    }
//                }
//            }
//        }
//    }
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        if let error = error {
            print("❌ Photo processing error: \(error.localizedDescription)")
            ProgressHUD.shared.hide()
            resetDetection()
            return
        }

        guard let imageData = photo.fileDataRepresentation() else {
            print("❌ Could not get image data")
            ProgressHUD.shared.hide()
            resetDetection()
            return
        }

        print("✅ Captured photo successfully")

        guard let ciImage = CIImage(data: imageData) else {
            print("❌ Could not create CIImage from data")
            ProgressHUD.shared.hide()
            resetDetection()
            return
        }

        DispatchQueue.global(qos: .userInitiated).async {
            // Try primary crop (QR bounding box × 2.1x)
            var finalImage = self.cropSquareNow(ciImage)

            // Only fall back to center crop if primary fails
            if finalImage == nil {
                print("⚠️ cropSquareNow failed — using center crop fallback")
                finalImage = self.manualCenterCrop(ciImage)
            }

            guard let imageToSend = finalImage else {
                print("❌ All cropping methods failed")
                DispatchQueue.main.async {
                    ProgressHUD.shared.hide()
                    self.instructionLabel.text = "Failed to process image"
                    self.resetDetection()
                }
                return
            }

            // Save cropped image for verification/debugging
            UIImageWriteToSavedPhotosAlbum(imageToSend, nil, nil, nil)

            if !self.isImageBlurry(imageToSend, threshold: 70) {
                DispatchQueue.main.async {
                    self.sendImagetoModelAPI(image: imageToSend, testingLabel: self.testingLabel) { result in
                        switch result {
                        case .success(let src):
                            print("✅ Image uploaded successfully. Source URL: \(src)")
                        case .failure(let error):
                            print("❌ Error uploading image: \(error.localizedDescription)")
                        }
                    }
                    self.instructionLabel.text = "Capture Complete!"
                }
            } else {
                print("❌ Cropped image is blurry")
                DispatchQueue.main.async {
                    self.instructionLabel.text = "Image is blurry - try holding steady"
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                        ProgressHUD.shared.hide()
                        self.resetDetection()
                    }
                }
            }
        }
    }
    // MARK: - Helper Methods
    private func resetDetection() {
        self.zoomLabel.text = "2.0x"
        // 1. Cancel any pending operations
        NSObject.cancelPreviousPerformRequests(withTarget: self)
        processingTimer?.invalidate()
        processingTimer = nil
        
        // 2. Reset all detection states
        isQRCodeDetected = false
        detectedBarcode = nil
        lastBarcode = nil
        performRequestCount = 0
        currentZoom = 2.0 // Reset zoom to 2.0x
        
        DispatchQueue.main.async {
            // 3. Reset UI
            self.instructionLabel.text = "Point camera at a QR code"
            self.updateDetectionStatus(isDetected: false)
            self.zoomSlider.value = Float(self.currentZoom) // Reset slider position
            
            // Update zoom label if you added it
            // self.zoomLabel.text = "2.0x"
            
            // 4. Handle device configuration
            guard let device = self.videoDevice else { return }
            
            do {
                try device.lockForConfiguration()
                
                // Reset zoom to 2.0x
                device.videoZoomFactor = 2.0
                
                // Maintain torch state
                if device.hasTorch && device.isTorchActive {
                    try device.setTorchModeOn(level: AVCaptureDevice.maxAvailableTorchLevel)
                }
                
                device.unlockForConfiguration()
                print("✅ Device reset with 2.0x zoom")
                
            } catch {
                print("❌ Could not reset device configuration: \(error)")
            }
            
            // 5. Restart session if needed
            if let session = self.captureSession, !session.isRunning {
                DispatchQueue.global(qos: .userInitiated).asyncAfter(deadline: .now() + 0.1) {
                    session.startRunning()
                    print("✅ Capture session restarted with 2.0x zoom")
                }
            }
            
            // 6. Re-enable preview
            self.videoPreviewLayer.connection?.isEnabled = true
        }
    }
    

    
    func sendImagetoModelAPI(image: UIImage, testingLabel: String, completion: @escaping (Result<String, Error>) -> Void) {
        let boundary = "Boundary-\(UUID().uuidString)"
//        UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
        // Prepare the multipart form data
        var body = Data()
        
        // Add image data to the request
        let filename = "uploaded_image.jpg"
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"file\"; filename=\"\(filename)\"\r\n".data(using: .utf8)!)
        body.append("Content-Type: image/jpeg\r\n\r\n".data(using: .utf8)!)
        
        guard let imageData = image.jpegData(compressionQuality: 0.8) else {
            completion(.failure(NSError(domain: "ImageError", code: -1, userInfo: [NSLocalizedDescriptionKey: "Failed to convert image to JPEG"])))
            return
        }
        
        body.append(imageData)
        body.append("\r\n".data(using: .utf8)!)
        body.append("--\(boundary)--\r\n".data(using: .utf8)!)
        
        // Create the request
        var request = URLRequest(url: URL(string: "http://3.7.254.234:8089/predict/")!)
//        var request = URLRequest(url: URL(string: "http://13.203.201.117:8080/predict/")!)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "accept")
        request.setValue("asdnkj62df21asd1", forHTTPHeaderField: "auth-id")
        request.setValue("asf1323sfa6s5", forHTTPHeaderField: "auth-token")
//        request.setValue("sdnakjdnlasnd", forHTTPHeaderField: "auth-id")
//        request.setValue("asdhagsdh7878q22", forHTTPHeaderField: "auth-token")
        request.setValue(testingLabel, forHTTPHeaderField: "Testinglabel")
//        request.setValue("offset", forHTTPHeaderField: "Printingtype")
        request.setValue("digital", forHTTPHeaderField: "Printingtype")
        //        print("UIDevice.modelNameForAPI \(UIDevice.modelNameForAPI)")
//        request.setValue("iphone SE", forHTTPHeaderField: "device-details")
        request.setValue("ios", forHTTPHeaderField: "DeviceType")
        request.httpBody = body
        print("Testinglabel: '\(testingLabel)'")
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            // Handle the response on main thread
            DispatchQueue.main.async {
                if let error = error {
                    self.showAlert(title: "Error", message: error.localizedDescription)
                    completion(.failure(error))
                    self.restartScan()
                    return
                }
                
                guard let httpResponse = response as? HTTPURLResponse else {
                    let error = NSError(domain: "NetworkError", code: -2, userInfo: [NSLocalizedDescriptionKey: "Invalid response"])
                    self.showAlert(title: "Error", message: "Invalid server response")
                    completion(.failure(error))
                    return
                }
                
                guard let data = data else {
                    let error = NSError(domain: "NetworkError", code: -3, userInfo: [NSLocalizedDescriptionKey: "No data received"])
                    self.showAlert(title: "Error", message: "No data received from server")
                    completion(.failure(error))
                    return
                }
                
                // Debug print the raw response
                let rawResponse = String(data: data, encoding: .utf8) ?? "Unable to decode response"
//                print("Raw response:", rawResponse)
//                self.showAlert(title: "Raw Response", message: rawResponse)
//                ProgressHUD.shared.hide()
                do {
                    let decoder = JSONDecoder()
                    let resp = try decoder.decode(PredictResponse.self, from: data)
                    let finalResult = resp.Data?.finalResult?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "Unknown"
                    print("Final Result from API: '\(finalResult)'")

                    // Decide whether original (case-insensitive)
                    var isOriginal = finalResult.lowercased() == "original"
//                    isOriginal = true
                    // Present result screen on main queue
//                    DispatchQueue.main.async {
//                        // hide any progress indicator first
//                        ProgressHUD.shared.hide()
//
//                        // instantiate and present the result VC
//                        let resultVC = ResultViewController(result: finalResult, isOriginal: isOriginal)
////                        self.restartScan()
//                        // present full-screen
//                        resultVC.scannerVC = self
//                        resultVC.modalPresentationStyle = .fullScreen
//                        // If this VC is inside a navigation controller you returned from wrapper,
//                        // present on the navigation controller if needed. Present from self.
//                        self.present(resultVC, animated: true)
//                    
//                    }
                    
                    if(isOriginal){
                        if self.isRunningInTestFlight() {
                            self.showToast(message: "Prediction - Original")
                        }
//                            self.uploadImage(image, imageType: "CROP",prediction: "original")
                        //bhar
            
                        self.makeApiCall_new(with: (12.948321152557963, 77.57733825952174), path: "IOS/com.acviss.app/0123459876/0123459876_17082020181440432.jpg", uCode: testingLabel, modelOutcome: "True")
                    }
                    else{
                        if self.isRunningInTestFlight() {
                            self.showToast(message: "Prediction - Fake")
                        }
//                            self.uploadImage(image, imageType: "CROP",prediction: "fake")
//                            self.makeApiCall_new(path: "IOS/com.acviss.app/9886215384/9886215384_17082020181440432.jpg",uCode: testingLabel,modelOutcome: "False")
                        self.makeApiCall_new(with: (12.948321152557963, 77.57733825952174), path: "IOS/com.acviss.app/0123459876/0123459876_17082020181440432.jpg", uCode: testingLabel, modelOutcome: "False")
                    }
                    completion(.success("Final Result: \(finalResult)"))
                } catch {
                    print("Failed to parse PredictResponse:", error)
                    DispatchQueue.main.async {
                        ProgressHUD.shared.hide()
                        self.showAlert(title: "Error", message: "Invalid server response")
                        // fallback behavior: restart scan
                        self.restartScan()
                    }
                    completion(.failure(error))
                }
                // Continue with your JSON parsing here...
                // Make sure to call completion handler on main thread if needed
            }
        }
        
        task.resume()
    }
    func isRunningInTestFlight() -> Bool {
        if let receiptURL = Bundle.main.appStoreReceiptURL {
            return receiptURL.lastPathComponent == "sandboxReceipt"
        }
        return false
    }
    func showToast(message: String, duration: Double = 2.0) {
        let toastLabel = UILabel()
        toastLabel.text = message
        toastLabel.font = UIFont.systemFont(ofSize: 14)
        toastLabel.textColor = .white
        toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.7)
        toastLabel.textAlignment = .center
        toastLabel.numberOfLines = 0
        
        toastLabel.alpha = 0.0
        toastLabel.layer.cornerRadius = 10
        toastLabel.clipsToBounds = true
        
        let maxSizeTitle = CGSize(width: self.view.bounds.size.width - 40, height: self.view.bounds.size.height)
        var expectedSize = toastLabel.sizeThatFits(maxSizeTitle)
        expectedSize.width += 20
        expectedSize.height += 10
        
        toastLabel.frame = CGRect(
            x: (self.view.frame.size.width - expectedSize.width) / 2,
            y: self.view.frame.size.height - 120,
            width: expectedSize.width,
            height: expectedSize.height
        )
        
        self.view.addSubview(toastLabel)
        
        UIView.animate(withDuration: 0.5, animations: {
            toastLabel.alpha = 1.0
        }) { _ in
            UIView.animate(withDuration: 0.5, delay: duration, options: .curveEaseOut, animations: {
                toastLabel.alpha = 0.0
            }, completion: { _ in
                toastLabel.removeFromSuperview()
            })
        }
    }
    private func makeApiCall_new(with coordinates: (latitude: Double, longitude: Double) = (latitude: 0.0, longitude: 0.0), path: String, uCode : String, modelOutcome: String) {
             
              let location: [String: Double] = [
                  "latitude": coordinates.latitude,
                  "longitude": coordinates.longitude
              ]
            var parameters: [String: Any] = [
                
                "ucode_data": uCode,
                
            ]
        
        if let qrCodeValue = detectedQRCodeValue {
            parameters["ucode_data"] = qrCodeValue
//            parameters["ucode_data"] = String(qrCodeValue.dropLast())
//            parameters["ucode_data"] = "e1~19_278,2y00u0s9mqd10fqe,2"
           }
            
              parameters["location"] = location
              parameters["captured_frame_path"] = path
              parameters["unique_id"] = "23232323"
              parameters["yellow_code_response"] = modelOutcome
//              parameters["yellow_code_response"] = "True"
//        ProgressHUD.shared.hide()
//        self.simulateProductDetails()
//        return
//
        
//              print("acvission verification parameters \(parameters)")
              NetworkManager.shared.makeAPICall(
                  httpMethod: .post,
                  endPoint: .AuthenticityYelloCodeVerification,
                  parameters: parameters,
                  viewController: nil,
                  errorHandlers: [.HandledByViewController],
                  type: .WithoutLoader,
                  result: { data,error  in

           
                      ProgressHUD.shared.hide()
                      self.scanTimer?.invalidate()
                      self.scanTimer = nil
                      self.audioQueue.async { [weak self] in
                          self?.audioPlayer?.stop()
                          self?.audioPlayer = nil
                      }
                      
//                      self.lapsedSeconds = 0
                      if data != nil, let responseJson = data as? [String : Any] {
                          print("acvissScanProductInfo 222 \(responseJson)")
                          
                          DispatchQueue.main.async {
                              let responseCode = responseJson["response_code"] as? Int
//                              let responseCode = (jsonResult["result"] as? [String: Any])?["response_code"] as? Int
                              let isSuccess = (responseCode == 100)
                              self.resetDetection()
                              // create the SwiftUI view and hosting controller
                              let prodView = UIHostingController(rootView: AcvissProdDetailsView(isSuccess: isSuccess, jsonResult: responseJson))
                              prodView.title = "Product Details" // shown in nav bar

                              DispatchQueue.main.async {
                                  if let nav = self.navigationController {
                                      // we have a navigation controller — push normally
                                      nav.pushViewController(prodView, animated: true)
                                  } else {
                                      // no navigation controller — present one modally so we get a nav bar and back button
                                      let nav = UINavigationController(rootViewController: prodView)
                                      nav.modalPresentationStyle = .fullScreen // or .automatic / .pageSheet as you prefer

                                      // optional: configure nav appearance (optional)
                                      // nav.navigationBar.prefersLargeTitles = false
                                      prodView.navigationItem.leftBarButtonItem = UIBarButtonItem(
                                                          barButtonSystemItem: .close,
                                                          target: self,
                                                          action: #selector(self.prodDetailsCloseTapped)
                                                      )
                                      self.present(nav, animated: true, completion: nil)
                                  }
                              }
//                              let prodView = UIHostingController(rootView: AcvissProdDetailsView(isSuccess: response_code == 100, jsonResult: responseJson ?? [:]))
//                                  self.navigationController?.pushViewController(prodView, animated: true)
                          }
                    
                      } else {
//                          self.isAcvissCodeAPISuccess = false
                      }
                  }
              )
          }
    @objc private func prodDetailsCloseTapped() {
        // If VisionViewController presented the nav controller, dismiss it
        self.presentedViewController?.dismiss(animated: true, completion: nil)
    }
    private func showAlert(title: String, message: String) {
        DispatchQueue.main.async {
            // Get the current key window's root view controller
            guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
                  let window = windowScene.windows.first,
                  let rootViewController = window.rootViewController else {
                print("No root view controller found")
                return
            }
            
            // Find the topmost presented view controller
            var topController = rootViewController
            while let presentedViewController = topController.presentedViewController {
                topController = presentedViewController
            }
            
            // Only present if the view controller's view is in the window hierarchy
            if topController.view.window != nil {
                let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default) { [weak self] _ in
                    // Call restartScan when OK is tapped
                    self?.restartScan()
                    self?.resetScanTimer()
                })
                topController.present(alert, animated: true)
            } else {
                print("View controller not in window hierarchy - delaying alert presentation")
                // Retry after a delay if needed
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    self.showAlert(title: title, message: message)
                }
            }
        }
    }
 
    // Replace cropSquareNow with this new function
//    func cropSquareNow(_ image: CIImage?) -> UIImage? {
//        guard let ciImage = image else {
//            print("No CIImage provided")
//            return nil
//        }
//        
//        guard let observation = self.detectedBarcode else {
//            print("❌ No stored barcode observation available")
//            return nil
//        }
//        
//        print("Starting QR code square cropping using Vision observation")
//        print("Original image extent: \(ciImage.extent)")
//        
//        let context = CIContext()
//        
//        // The key insight: Vision detected the QR in video frames with orientation .up
//        // But the captured photo might have different EXIF orientation
//        // We need to work with the image in its natural orientation
//        
//        let imageSize = ciImage.extent
//        print("Image size: \(imageSize)")
//        
//        // Vision's bounding box is in normalized coordinates (0-1)
//        // and uses bottom-left origin (UIKit/Vision coordinate system)
//        let boundingBox = observation.boundingBox
//        print("Vision bounding box (normalized): \(boundingBox)")
//        
//        // Try different coordinate transformations to find the QR code
//        let transformations: [(name: String, transform: (CGRect) -> CGRect)] = [
//            // Standard Vision to CIImage (flip Y)
//            ("Standard flip Y", { box in
//                CGRect(
//                    x: box.origin.x * imageSize.width,
//                    y: (1 - box.origin.y - box.height) * imageSize.height,
//                    width: box.width * imageSize.width,
//                    height: box.height * imageSize.height
//                )
//            }),
//            // Try without Y flip (in case image is already oriented)
//            ("No Y flip", { box in
//                CGRect(
//                    x: box.origin.x * imageSize.width,
//                    y: box.origin.y * imageSize.height,
//                    width: box.width * imageSize.width,
//                    height: box.height * imageSize.height
//                )
//            }),
//            // Rotated 90 degrees (landscape)
//            ("Rotated 90", { box in
//                CGRect(
//                    x: box.origin.y * imageSize.width,
//                    y: box.origin.x * imageSize.height,
//                    width: box.height * imageSize.width,
//                    height: box.width * imageSize.height
//                )
//            }),
//            // Rotated 90 with Y flip
//            ("Rotated 90 + flip", { box in
//                CGRect(
//                    x: (1 - box.origin.y - box.height) * imageSize.width,
//                    y: box.origin.x * imageSize.height,
//                    width: box.height * imageSize.width,
//                    height: box.width * imageSize.height
//                )
//            })
//        ]
//        
//        var bestCropImage: UIImage?
//        
//        for (name, transform) in transformations {
//            print("\n🔍 Trying transformation: \(name)")
//            
//            let qrRect = transform(boundingBox)
//            print("   QR rect in image coords: \(qrRect)")
//            
//            // Validate the rectangle is within bounds
//            guard qrRect.minX >= 0 && qrRect.minY >= 0 &&
//                  qrRect.maxX <= imageSize.width && qrRect.maxY <= imageSize.height else {
//                print("   ❌ Rectangle out of bounds")
//                continue
//            }
//            
//            // Add padding (60% total = 1.60x)
//            let paddingMultiplier: CGFloat = 2.2
//            let paddedWidth = qrRect.width * paddingMultiplier
//            let paddedHeight = qrRect.height * paddingMultiplier
//            
//            // Make it square
//            let squareSize = max(paddedWidth, paddedHeight)
//            
//            // Calculate crop rect centered on QR code
//            let cropRect = CGRect(
//                x: qrRect.midX - squareSize / 2,
//                y: qrRect.midY - squareSize / 2,
//                width: squareSize,
//                height: squareSize
//            )
//            
//            print("   Calculated crop rect: \(cropRect)")
//            
//            // Ensure crop rect is within image bounds
//            let adjustedCropRect = cropRect.intersection(imageSize)
//            
//            guard !adjustedCropRect.isEmpty &&
//                  adjustedCropRect.width > 100 &&
//                  adjustedCropRect.height > 100 else {
//                print("   ❌ Crop rect too small or empty")
//                continue
//            }
//            
//            print("   Adjusted crop rect: \(adjustedCropRect)")
//            
//            // Crop the image
//            let croppedCIImage = ciImage.cropped(to: adjustedCropRect)
//            
//            // Convert to UIImage
//            guard let cgImage = context.createCGImage(croppedCIImage, from: croppedCIImage.extent) else {
//                print("   ❌ Failed to create CGImage")
//                continue
//            }
//            
//            let croppedImage = UIImage(cgImage: cgImage, scale: 1.0, orientation: .up)
//            
//            // Verify this crop actually contains a QR code using CIDetector
//            if verifyQRCodeInImage(croppedImage) {
//                print("   ✅ QR code verified in cropped image!")
//                bestCropImage = croppedImage
//                break
//            } else {
//                print("   ⚠️ Could not verify QR in this crop, trying next...")
//            }
//        }
//        
//        if let finalImage = bestCropImage {
//            print("\n✅ Successfully created verified cropped image with size: \(finalImage.size)")
//            return finalImage
//        }
////        else
////        {
////            
//////                    DispatchQueue.main.async {
//////                        self.showAlert(title: "Scan again",
//////                                     message: "Looks like there is some issue with your environment. Please ensure the following and try again:\n\n1) Good lighting\n2) Stable hands\n3) Clean Lens of Camera")
//////                        ProgressHUD.shared.hide()
//////                        self.restartScan()
//////                    }
//////
////            DispatchQueue.main.async {
////                self.showAlertLightingconditions(
////                    title: "Scan again",
////                    message: """
////            Looks like there is some issue with your environment. Please ensure the following and try again:
////
////            1) Good lighting
////            2) Stable hands
////            3) Clean Lens of Camera
////            """,
////                    onOk: {
////                        // 🔥 runs only when the user taps OK
////                        ProgressHUD.shared.hide()
////                        self.restartScan()
////                    }
////                )
////            }
////            return nil
////        }
//        
//        print("\n❌ Could not find valid crop with any transformation")
//        
//        // Last resort: Use the first reasonable crop even without verification
//        for (name, transform) in transformations {
//            let qrRect = transform(boundingBox)
//            let paddingMultiplier: CGFloat = 1.60
//            let paddedWidth = qrRect.width * paddingMultiplier
//            let paddedHeight = qrRect.height * paddingMultiplier
//            let squareSize = max(paddedWidth, paddedHeight)
//            
//            let cropRect = CGRect(
//                x: qrRect.midX - squareSize / 2,
//                y: qrRect.midY - squareSize / 2,
//                width: squareSize,
//                height: squareSize
//            )
//            
//            let adjustedCropRect = cropRect.intersection(imageSize)
//            
//            if !adjustedCropRect.isEmpty && adjustedCropRect.width > 100 {
//                let croppedCIImage = ciImage.cropped(to: adjustedCropRect)
//                if let cgImage = context.createCGImage(croppedCIImage, from: croppedCIImage.extent) {
//                    print("⚠️ Using unverified crop from: \(name)")
//                    return UIImage(cgImage: cgImage, scale: 1.0, orientation: .up)
//                }
//            }
//        }
//        
//        return nil
//    }
    func cropSquareNow(_ image: CIImage?) -> UIImage? {
        guard let ciImage = image else {
            print("❌ No CIImage provided")
            return nil
        }
        guard let observation = self.detectedBarcode else {
            print("❌ No stored barcode observation")
            return nil
        }

        let imageExtent = ciImage.extent
        let imageW = imageExtent.width
        let imageH = imageExtent.height
        let bb = observation.boundingBox  // normalized, bottom-left origin

        print("📐 Image extent: \(imageExtent)")
        print("📐 Vision bounding box: \(bb)")

        // Vision and CIImage both use bottom-left origin — no Y-flip needed.
        // CIImage(data:) already EXIF-corrects the photo to portrait orientation.
        let qrX = bb.origin.x * imageW
        let qrY = bb.origin.y * imageH
        let qrW = bb.width  * imageW
        let qrH = bb.height * imageH

        let qrRectInImage = CGRect(x: qrX, y: qrY, width: qrW, height: qrH)
        print("📐 QR rect in image pixels: \(qrRectInImage)")

        // 2.1x captures the QR + all 6 surrounding security boxes with a small safety margin.
        // Measured empirically from reference images: surrounding boxes require exactly 2.0x.
        let paddingMultiplier: CGFloat = 2.1

        let expandedW = qrW * paddingMultiplier
        let expandedH = qrH * paddingMultiplier

        let cropRect = CGRect(
            x: qrRectInImage.midX - expandedW / 2,
            y: qrRectInImage.midY - expandedH / 2,
            width:  expandedW,
            height: expandedH
        )
        print("📐 Desired crop rect: \(cropRect)")

        let clampedRect = cropRect.intersection(imageExtent)
        guard !clampedRect.isEmpty,
              clampedRect.width > 100,
              clampedRect.height > 100 else {
            print("❌ Crop rect invalid after clamping: \(clampedRect)")
            return nil
        }
        print("📐 Clamped crop rect: \(clampedRect)")

        let context = CIContext()
        let cropped = ciImage.cropped(to: clampedRect)

        guard let cgImage = context.createCGImage(cropped, from: cropped.extent) else {
            print("❌ Failed to create CGImage")
            return nil
        }

        let result = UIImage(cgImage: cgImage, scale: 1.0, orientation: .up)
        print("✅ Crop successful: \(result.size)")
        return result
    }
    private func showAlertLightingconditions(
        title: String,
        message: String,
        onOk: (() -> Void)? = nil
    ) {
        DispatchQueue.main.async {
            // Get current topmost VC
            guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
                  let window = windowScene.windows.first,
                  let root = window.rootViewController else {
                return
            }

            var top = root
            while let presented = top.presentedViewController {
                top = presented
            }

            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)

            alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in
                onOk?()   // 🔥 callback when user taps OK
            })

            top.present(alert, animated: true)
        }
    }
    // Helper function to verify QR code exists in cropped image
    private func verifyQRCodeInImage(_ image: UIImage) -> Bool {
        guard let cgImage = image.cgImage else { return false }
        
        let ciImage = CIImage(cgImage: cgImage)
        let context = CIContext()
        
        guard let detector = CIDetector(
            ofType: CIDetectorTypeQRCode,
            context: context,
            options: [CIDetectorAccuracy: CIDetectorAccuracyHigh]
        ) else {
            return false
        }
        
        let features = detector.features(in: ciImage)
        return !features.isEmpty
    }

    // Fallback method when QR detection fails
    private func manualCenterCrop(_ ciImage: CIImage) -> UIImage? {
        print("🔄 Using manual center crop fallback")
        let context = CIContext()
        
        let extent = ciImage.extent
        let size = min(extent.width, extent.height)
        let center = CGPoint(x: extent.midX, y: extent.midY)
        
        let cropRect = CGRect(
            x: center.x - size / 2,
            y: center.y - size / 2,
            width: size,
            height: size
        )
        
        let croppedCIImage = ciImage.cropped(to: cropRect)
        
        guard let cgImage = context.createCGImage(croppedCIImage, from: croppedCIImage.extent) else {
            return nil
        }
        
        return UIImage(cgImage: cgImage, scale: 1.0, orientation: .up)
    }


    private func cropUsingVisionObservation(_ ciImage: CIImage, observation: VNBarcodeObservation) -> UIImage? {
        let context = CIContext()
        let imageSize = ciImage.extent
        
        print("Image size: \(imageSize)")
        print("Vision bounding box (normalized): \(observation.boundingBox)")
        
        // Vision uses normalized coordinates (0-1) with bottom-left origin
        // Convert to CIImage coordinates (top-left origin, pixel values)
        let boundingBox = observation.boundingBox
        
        // Calculate the QR code rect in image coordinates
        // Flip Y coordinate because Vision uses bottom-left origin
        let x = boundingBox.origin.x * imageSize.width
        let y = (1 - boundingBox.origin.y - boundingBox.height) * imageSize.height
        let width = boundingBox.width * imageSize.width
        let height = boundingBox.height * imageSize.height
        
        let qrRect = CGRect(x: x, y: y, width: width, height: height)
        print("QR rect in image coordinates: \(qrRect)")
        
        // Add padding (60% total = 1.60x)
        let paddingMultiplier: CGFloat = 1.60
        let paddedWidth = width * paddingMultiplier
        let paddedHeight = height * paddingMultiplier
        
        // Make it square using the larger dimension
        let squareSize = max(paddedWidth, paddedHeight)
        
        // Center the square on the QR code
        let cropRect = CGRect(
            x: qrRect.midX - squareSize / 2,
            y: qrRect.midY - squareSize / 2,
            width: squareSize,
            height: squareSize
        )
        
        print("Calculated crop rect: \(cropRect)")
        
        // Clamp to image bounds
        let adjustedCropRect = cropRect.intersection(imageSize)
        
        guard !adjustedCropRect.isEmpty else {
            print("❌ Crop rect is empty after intersection")
            return nil
        }
        
        print("Adjusted crop rect: \(adjustedCropRect)")
        
        // Crop the image
        let croppedCIImage = ciImage.cropped(to: adjustedCropRect)
        
        // Convert to UIImage
        guard let cgImage = context.createCGImage(croppedCIImage, from: croppedCIImage.extent) else {
            print("❌ Failed to create CGImage")
            return nil
        }
        
        let finalImage = UIImage(cgImage: cgImage, scale: 1.0, orientation: .up)
        print("✅ Successfully created cropped image with size: \(finalImage.size)")
        
        return finalImage
    }


}
