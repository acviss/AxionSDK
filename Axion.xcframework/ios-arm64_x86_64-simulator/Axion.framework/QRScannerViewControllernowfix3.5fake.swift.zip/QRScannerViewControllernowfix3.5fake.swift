import UIKit
import SwiftUI
import AVFoundation
import Vision
import CoreImage
import AVFoundation
import CoreMotion
import CoreLocation


final class QRCodeScannerViewController: UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate, AVCapturePhotoCaptureDelegate {
    
    // MARK: - UI Elements
    private var previewView: UIView!
    var testingLabel: String = "Original"
    // Forwarded to the model API as `Printingtype`. Set by the host via presentScanner().
    var printingType: String = "digital"
    private var audioButton: UIButton!
    private var audioPlayer: AVAudioPlayer?
    private var isAudioEnabled: Bool = true
//    private var resultImageView: UIImageView!
    private var instructionLabel: UILabel!
    private var logoImageView: UIImageView!
    private var stage1Label: UILabel!
    private var stage2Label: UILabel!
    private var stage3Label: UILabel!
    private var refreshButton: UIButton!
    private var cornerBoxLayer = CAShapeLayer()
    private let dimOverlayLayer = CAShapeLayer()
    // Central scan-window size used by both the dim overlay cutout and the corner brackets.
    private let scanWindowSize = CGSize(width: 250, height: 250)
    private let scanWindowCornerRadius: CGFloat = 16
    /// Semi-transparent guide image shown inside the scan window so the
    /// user can physically align the code with the guide. Loaded from
    /// the "overlay" asset in `AxionBundle.bundle`.
    private var overlayImageView: UIImageView!
    /// Alpha for the overlay guide — 0.0 invisible, 1.0 fully opaque.
    /// 0.45 keeps the live preview readable through the guide. Tune as
    /// needed.
    private let overlayImageAlpha: CGFloat = 0.45
    private var statusLabel: UILabel!
    private var torchButton: UIButton!
    private var processingTimer: Timer?
    private let processingTimeout: TimeInterval = 5.0 // 5 seconds timeout
    private var closeButton: UIButton!
    private var isClosing = false
    var onClose: (() -> Void)?
    private var focusButton: UIButton!
    private var focusStatusView: UIView!
    private var validationFrameCompletion: ((UIImage?) -> Void)?
    // Set on the validation-API path (scanTimerFired + hasAllClasses) so that
    // the next photo arriving at `photoOutput(_:didFinishProcessingPhoto:)`
    // is handed to this closure instead of running the genuine `/predict/`
    // pipeline. Consumed exactly once; cleared as soon as it fires.
    private var pendingFakePhotoCompletion: ((CIImage?) -> Void)?
    /// Set on the /validate/ path (scanTimerFired + hasAllClasses) so
    /// that the next high-res photo arriving at
    /// `photoOutput(_:didFinishProcessingPhoto:)` is routed here for
    /// upload to /validate/ instead of running the /predict/ pipeline.
    /// Uses the SAME photo-output capture the /predict/ path uses, so
    /// /validate/ gets the exact same native ~4032×3024 sensor pixels
    /// (rather than the reduced ~1920×1440 video-preview frames the
    /// older captureFrameForValidation path delivered).
    /// Consumed exactly once; cleared as soon as it fires.
    private var pendingValidatePhotoCompletion: ((CIImage?) -> Void)?
    // MARK: - AVFoundation Properties
    private var captureSession: AVCaptureSession!
    private var videoPreviewLayer: AVCaptureVideoPreviewLayer!
    private var videoDevice: AVCaptureDevice?
    private var videoDataOutput: AVCaptureVideoDataOutput!
    private var photoOutput: AVCapturePhotoOutput!
    
    // Timer that will trigger periodic sends
    private var scanTimer: Timer?
    // Mutable so we can switch to the extended 15s retry window after the
    // /validate/ fallback returns "Original" with an empty qr_value. The
    // progress bar's CADisplayLink reads this same property every tick, so
    // updating it transparently lengthens the countdown UI as well.
    private var scanInterval: TimeInterval = 6.0
    private let scanIntervalDefault: TimeInterval = 6.0
    private let scanIntervalExtended: TimeInterval = 7.5
    // True once we've already taken our one retry with the extended window.
    // If the extended timer also expires we go straight to the fake-product
    // screen rather than looping the validation API again.
    private var isInExtendedScanMode: Bool = false

    // Progress bar driven by the scan interval
    private var scanProgressView: UIProgressView!
    private var progressDisplayLink: CADisplayLink?
    private var progressStartTime: CFTimeInterval = 0

    // MARK: - Mid-interval torch toggle (helps detection across lighting)
    //
    // Field reports suggested some users only manage a successful QR
    // decode with the flash ON (low light, glossy labels, poor contrast)
    // and others only with the flash OFF (bright ambient, glare on the
    // print). Single-state torch handling can't cover both. Strategy:
    //
    //   1. Every fresh scan starts with the torch ON
    //      (see engageTorchAfterRestart()).
    //   2. If we hit `autoTorchOffAtFraction` (70%) of the scan interval
    //      without a Vision QR decode, automatically switch the torch
    //      OFF for the remaining 30% — gives the "torch causes glare"
    //      users their window.
    //
    // The guard flag below prevents this from firing more than once per
    // interval. It's reset to false in `startProgressAnimation()` so a
    // fresh countdown gets a fresh chance to fire.
    /// Fraction of the scan interval at which we flip the torch off if
    /// the QR hasn't been decoded yet. 0.7 leaves ~30% of the window
    /// for the "no-torch" pass, which on a 12 s interval is ~3.6 s —
    /// long enough for Vision to lock onto a sharp frame.
    private let autoTorchOffAtFraction: Double = 0.7
    /// Latch — flips true the moment we mid-interval-switch the torch
    /// off, prevents the CADisplayLink from re-firing the switch on
    /// every frame. Cleared in startProgressAnimation().
    private var hasAutoSwitchedTorchOffThisInterval: Bool = false

    // Motion-stability gating: scan timer only runs while the device is fairly steady.
    private let motionManager = CMMotionManager()
    // Start above the threshold so we don't claim "stable" before we have evidence.
    private var smoothedMotion: Double = 1.0
    // Tunable: combined accel + rotation magnitude allowed for "steady hand-held".
    // Small hand sway: ~0.02–0.05.  Moving phone toward QR: ~0.20+.
    private let motionStabilityThreshold: Double = 0.10
    // Whether we currently consider the device steady enough to count.
    private var isMotionStable: Bool = false
    // Whether the caller wants the scan timer running (gets gated by stability).
    private var pendingScanTimerStart: Bool = false
    // Small guard to avoid overlapping network uploads
    private var isUploading: Bool = false
    private var pendingTestingLabel: String? = nil
    
    private var tiltCheckTimer: Timer?
    private var isTiltChecking: Bool = false
    
    // Optional: keep last captured image if you prefer sending an already-captured image
    private var lastCapturedImage: UIImage?
    
    // MARK: - Vision Properties
    private var visionRequests = [VNRequest]()
    private var isQRCodeDetected = false
    // Store the observation itself to get accurate bounding box later
    private var detectedBarcode: VNBarcodeObservation?
    
    private var performRequestCount = 0
    private var lastBarcode: VNBarcodeObservation?
    private var lastDetectionTime: Date?
    
    
    private var zoomSlider: UISlider!
    // Raised from 2.5 → 3.5 alongside the switch to .builtInWideAngleCamera-
    // only camera picking. Higher default zoom means the same physical
    // code fills the scan window at a greater working distance, which
    // keeps users above the main wide's ~10 cm minimum focus distance
    // and avoids the "blur when held close" problem that auto-macro
    // (only available on .builtInTripleCamera) used to paper over.
    // Digital-zoom quality loss is negligible on Pro 48MP sensors —
    // even at 3.5× we pull from a ~4MP effective region, plenty for
    // QR decoding.
    private var currentZoom: CGFloat = 3.5
    private let minZoom: CGFloat = 1.0
    private let maxZoom: CGFloat = 8.0
    private let zoomStep: CGFloat = 0.1
    private var zoomLabel: UILabel!
    private var detectedQRCodeValue: String?
    private var isAudioSessionConfigured = false

    // MARK: - App lifecycle gating
    // True while the app is not active (background or inactive). Every
    // periodic/throttled piece of work in this controller checks this flag
    // first so we don't burn battery — or worse, fire the periodic upload —
    // while the user can't even see the camera.
    private var isAppInBackground: Bool = false

    // MARK: - Location services
    /// Best-known device coordinates, used as the `location` form field
    /// in `sendImageToAuthenticityVerificationWithImage` and
    /// `makeApiCall_new`. Stay at 0.0 if the user denies permission,
    /// the host app's Info.plist lacks NSLocationWhenInUseUsageDescription,
    /// or we just haven't got a fix yet.
    private var currentLatitude: Double = 0.0
    private var currentLongitude: Double = 0.0
    /// Owned by this VC's lifecycle. Started in viewDidLoad, stopped in
    /// viewWillDisappear / closeTapped.
    private var locationManager: CLLocationManager?

    /// Host-app override flag. When `true`, the API uploads carry a
    /// hardcoded test-mode latitude/longitude regardless of what the
    /// real CoreLocation fix says (or even if location permission was
    /// denied). Set by the host app via `AxionScannerSDK.presentScanner(
    /// …, spoofLocation: true, …)` — typically triggered by a hidden
    /// debug gesture in the host's UI. Independent of the `#if DEBUG`
    /// auto-override (which forces spoofed location in every Xcode-run
    /// build); this flag works in Release builds too.
    var spoofLocation: Bool = false

    // MARK: - Focus / sharpness gating
    // True while the camera's autofocus is mid-adjustment. We never arm the scan
    // timer while this is true so the periodic upload can't fire on a blurry frame.
    private var isAutoFocusAdjusting: Bool = true
    // Updated from a throttled Laplacian-variance probe on the live preview buffer.
    private var isFrameSharp: Bool = false
    // Throttle the live sharpness probe — Laplacian is the most expensive thing
    // we do per-frame so cap it to ~3 Hz.
    private var lastSharpnessCheckTime: CFTimeInterval = 0
    private let sharpnessCheckInterval: CFTimeInterval = 0.35
    // Live-preview Laplacian-variance threshold. Kept for reference and
    // for the belt-and-braces sharpness check inside scanTimerFired's
    // pre-capture branch — Laplacian is cheap and good enough as a
    // coarse first filter there. NOT used by the main live-probe gate
    // anymore; see `liveTenengradThreshold` below.
    private let liveSharpnessThreshold: Double = 500.0
    // Live-preview TENENGRAD threshold (0-100 scale). This is what now
    // gates the scan timer. Tenengrad is far more discriminating than
    // Laplacian on uniformly soft "user is too close" frames where
    // sensor noise can fool a Laplacian-variance threshold into
    // declaring sharp. Real on-device readings on a tack-sharp Axion
    // code crop sit in the 60-90 range; visibly blurry close-to-focus
    // frames sit under 25. 35 is a wide-margin reject line.
    private let liveTenengradThreshold: Double = 35.0
    // Hysteresis: require N consecutive sharp probes before flipping
    // `isFrameSharp` from false → true. Any single blurry probe flips it
    // straight back to false (asymmetric debounce). This kills the class
    // of bug where a single noise-driven "sharp" reading during an AF
    // transition arms the timer prematurely.
    private let sharpnessHysteresisRequired: Int = 2
    private var consecutiveSharpProbes: Int = 0
    // Flagged true when the live probe says blurry AND lensPosition is at
    // the near-focus limit, meaning the user is physically inside the
    // camera's minimum focus distance — no amount of waiting will resolve
    // it. The label flow uses this to prompt "Move slightly farther away"
    // instead of the generic "Hold steady" hint.
    private var userIsTooCloseToFocus: Bool = false
    // The threshold under which we consider the lens "parked at near
    // limit". On the iPhone wide camera lensPosition is 0..1 (0=near,
    // 1=far); when the lens has given up it sits exactly at 0, but we
    // give a tiny tolerance for floating-point reads.
    private let lensPositionTooCloseThreshold: Float = 0.05
    // KVO registration latch so we never add/remove the observer twice.
    private var focusObserversRegistered: Bool = false

    // MARK: - Far-detection (driven off captureOutput, no Timer)
    //
    // Sole source of the "You are far. Come closer" instruction label
    // (performLiveTiltCheck deliberately does NOT write that message —
    // the matching line is commented out there). Runs its own throttled
    // TFLite pass on the live preview pixel buffer and uses the YOLO
    // QR-class rect fraction to decide whether to surface the hint.
    //
    // Auto-zoom, auto-focus, tilt and sharpness gating in
    // performLiveTiltCheck are NOT touched by this path.
    //
    // ── Tunables — adjust to dial sensitivity ─────────────────────────
    /// Minimum seconds between TFLite calls inside captureOutput. The
    /// tilt check already runs TFLite at 1.5 s cadence elsewhere; 1.0
    /// gives responsive far/close transitions without doubling CPU
    /// load. Raise to 1.5–2.0 if profiling shows the video queue
    /// stuttering.
    private let farDetectionInterval: TimeInterval = 1.0
    /// QR-class rect fraction (longest dim / frame longest dim) below
    /// which we call the user "far". 0.05 = QR occupies less than 5%
    /// of the frame's longest dimension. RAISE this number to fire the
    /// message at shorter distances (user has to come closer before
    /// it dismisses); LOWER it to fire only at very far distances.
    private let farDetectionFractionThreshold: CGFloat = 0.05
    /// Hysteresis: how many consecutive ticks must read "far" before we
    /// flip `isUserCurrentlyFar` true. Higher = less flicker, slower
    /// trigger. 2 ticks at the 1.0 s interval ≈ 2 s of consistent
    /// "far" reading before the message appears.
    private let farDetectionConsecutiveTrigger: Int = 2
    /// How many consecutive "not far" ticks before we clear the flag.
    /// Higher = message lingers longer after the user moves closer.
    private let farDetectionConsecutiveClear: Int = 2

    // ── Internal state — not user-tunable ─────────────────────────────
    private var lastFarCheckTime: CFTimeInterval = 0
    private var isFarDetectionInflight: Bool = false
    private var consecutiveFarFrames: Int = 0
    private var consecutiveCloseFrames: Int = 0
    private var isUserCurrentlyFar: Bool = false

    // MARK: - QR-in-scan-window gate
    //
    // When YOLO detects a QR-class rect that doesn't sufficiently overlap
    // the four-corner overlay (the scan window), block the scan timer
    // from arming. Symptom we're fixing: user holds the code at the edge
    // of the preview, YOLO sees it, motion / focus / sharpness all pass,
    // and the countdown bar starts even though the code isn't inside
    // the brackets.
    //
    // Behaviour:
    //   • Default flag = TRUE  → before any YOLO data is available, the
    //     existing gates (motion/focus/sharpness) apply unchanged.
    //   • YOLO detects a QR-class rect and ≥ qrInScanWindowMinOverlap
    //     of its area is inside the scan window → flag stays TRUE.
    //   • YOLO detects a QR-class rect and < qrInScanWindowMinOverlap
    //     is inside → flag flips FALSE → scan timer is cancelled and
    //     held at 0% until the user re-positions.
    //   • YOLO detects NO QR-class rect → flag → TRUE (don't block when
    //     there's nothing to position; let the other gates apply).
    //
    /// Fraction of the QR-class rect that must lie inside the scan
    /// window for the timer to be allowed to arm. 0.5 = "at least half
    /// the code is centred under the brackets" — generous enough that
    /// the user doesn't have to nail dead-centre alignment.
    private let qrInScanWindowMinOverlap: CGFloat = 0.5
    /// Flag read by `canArmScanTimerNow()`. Updated from the tilt-
    /// check timer (see performLiveTiltCheck) on the same 1.5 s cadence
    /// that produces the rotation hints, so transitions are responsive
    /// without adding any new TFLite work.
    private var isQRSufficientlyInScanWindow: Bool = true

    // MARK: - Pre-capture validation state
    //
    // Runs between Vision-decoded-QR and the actual high-res capture.
    // Goal: confirm on a sharp live preview frame that YOLO sees a
    // proper Axion code (6 pattern boxes, all roughly square) before
    // playing the shutter and going through the /predict/ pipeline.
    // See handleStabilizedQRCode → startPreCaptureValidation →
    // attemptPreCaptureValidation → commitToCapture.
    private var preCaptureValidationAttempts: Int = 0
    /// Guards against duplicate capture kick-off. See commitToCapture()
    /// for the specific race we're preventing (a late TFLite pass fires
    /// commit at the same time as the max-attempts fallback).
    private var isCommittedToCapture: Bool = false
    /// After this many failed live-frame validations, commit to capture
    /// anyway. The server-side model is the authoritative authenticity
    /// judgement; better to hand it an imperfect crop than to leave
    /// the user hanging with a red box and no explanation. Empirically
    /// 8 tries at 0.2s cadence = ~1.6s max wait, which stays under the
    /// user's "did it hang?" perception threshold.
    private let preCaptureValidationMaxAttempts: Int = 8
    /// How long to wait between validation attempts when the current
    /// frame is either not sharp yet or failed the pattern-box check.
    private let preCaptureValidationRetryInterval: TimeInterval = 0.2

    // MARK: - Ambient lux estimation (for /predict headers)
    //
    // iOS does NOT expose an ambient-light-sensor reading via a public
    // API. The conventional workaround is to read the EXIF BrightnessValue
    // (BV) attached to every camera sample buffer — it's a logarithmic
    // measure of scene luminance the imaging pipeline computes anyway —
    // and convert via the photographic relation:
    //
    //     lux ≈ 2.5 * 2^BV     (the "K = 2.5" calibration constant
    //                           used by reflected-light meters)
    //
    // This isn't a calibrated lux meter — it's an estimate, but it's
    // monotonic and stable enough to bucket scenes into "dim / room /
    // bright / direct sun". Server-side it's mainly useful for
    // correlating "scan failed" with "user was in pitch black".
    //
    // We sample on the videoQueue inside captureOutput (where the
    // sample buffer is fresh) and stash the latest value behind a
    // serial lock so the main-thread /predict path can read it cheaply.
    private var latestAmbientLux: Double = 0
    private let ambientLuxLock = NSLock()

    /// Read the EXIF BrightnessValue (BV) from the sample buffer's
    /// `MetadataDictionary` attachment, convert to an approximate lux
    /// value, and cache it for the /predict header. The buffer's exif
    /// dict is populated by the imaging pipeline itself (no extra work
    /// for us); reading it costs essentially nothing per frame.
    ///
    /// Conversion uses the standard photographic relation
    ///   `lux ≈ K * 2^BV` with K = 2.5 (reflected-light reading).
    /// BV ranges roughly from -5 (very dim) to +12 (direct sunlight),
    /// mapping to ~0.08 lux .. ~10000 lux — same dynamic range
    /// app-level light meters use.
    ///
    /// Runs on the videoQueue. Writes go through `ambientLuxLock` so
    /// readers on other queues (e.g. main, when /predict is built) see
    /// a consistent value.
    private func sampleAmbientLux(from sampleBuffer: CMSampleBuffer) {
        // CMGetAttachment with kCGImagePropertyExifDictionary returns
        // a CFDictionary; bridge to Swift and look up BrightnessValue.
        guard let metadataDict = CMCopyDictionaryOfAttachments(
            allocator: kCFAllocatorDefault,
            target: sampleBuffer,
            attachmentMode: kCMAttachmentMode_ShouldPropagate
        ) as? [String: Any] else { return }
        guard let exif = metadataDict[kCGImagePropertyExifDictionary as String] as? [String: Any] else { return }
        // BrightnessValue may be Double, Float, or NSNumber depending
        // on the iOS version — bridge defensively.
        let bv: Double = {
            if let d = exif[kCGImagePropertyExifBrightnessValue as String] as? Double { return d }
            if let n = exif[kCGImagePropertyExifBrightnessValue as String] as? NSNumber { return n.doubleValue }
            return Double.nan
        }()
        guard bv.isFinite else { return }
        let lux = 2.5 * pow(2.0, bv)
        ambientLuxLock.lock()
        latestAmbientLux = lux
        ambientLuxLock.unlock()
    }

    /// Thread-safe read for the /predict path. Returns the most recent
    /// cached lux estimate (0 if no frame has been processed yet, which
    /// would only happen if /predict somehow fired before the first
    /// video frame arrived — essentially impossible in practice).
    private func currentAmbientLuxEstimate() -> Double {
        ambientLuxLock.lock()
        defer { ambientLuxLock.unlock() }
        return latestAmbientLux
    }

    // MARK: - Auto-zoom (fit 6 YOLO patterns into the scan window)
    // Once the user touches the slider we hand control to them and keep it.
    private var userZoomOverride: Bool = false
    // Throttle auto-zoom corrections so the lens isn't constantly hunting.
    private var lastAutoZoomTime: CFTimeInterval = 0
    private let autoZoomInterval: CFTimeInterval = 0.7
    // Target fill: what fraction of the scan window auto-zoom should
    // try to make the code occupy. Lowered from 0.90 → 0.60 after
    // switching to wide-only camera with 3.5× default zoom.
    //
    // Rationale (MFD math on 14 Pro Max main wide):
    //
    //   Main wide MFD ≈ 10 cm. At 3.5× zoom the effective FOV is
    //   ~20° horizontal. At MFD distance the frame captures ~3.5 cm
    //   of world width. An 8 mm code fills 23% of that, and the
    //   scan window is 64% of the preview → code fills only 36% of
    //   the scan window BEFORE auto-zoom kicks in.
    //
    //   With target = 0.90, auto-zoom needs to push to 3.5 × (90/36)
    //   = 8.75×, but maxZoom = 8.0 — auto-zoom saturates BEFORE
    //   reaching target. Users see "not quite filled", instinctively
    //   move closer → hit MFD → blur. That's the loop the user
    //   reported ("blurry until I go far from the image").
    //
    //   With target = 0.60, auto-zoom needs 3.5 × (60/36) = 5.8×,
    //   comfortably within maxZoom. Users can hold at MFD or
    //   further, auto-zoom pushes zoom high enough to fill 60% of
    //   the window without prompting the "move closer" instinct.
    //   7 mm codes need 6.8×, also within maxZoom.
    //
    // Trade-off: code appears smaller inside the scan window
    // visually. Detection is unaffected (Vision decodes down to
    // small module sizes given sharp focus), and it's a better UX
    // than requiring users to violate MFD to make the code look
    // "properly framed".
    private let autoZoomTargetFraction: CGFloat = 0.60
    // Don't react to tiny ratios — within ±8% of target we consider it "fitted".
    private let autoZoomDeadband: CGFloat = 0.08
    // Cap per-step zoom change so the camera moves smoothly, not in jumps.
    private let autoZoomMaxStep: CGFloat = 0.6

    private let audioQueue = DispatchQueue(label: "com.axion.scanner.audio",
                                           qos: .background)
    deinit {
        print("QRCodeScannerViewController deallocated")
    }
    
    // MARK: - Lifecycle Methods
    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupCamera()
        registerAppLifecycleObservers()
        setupLocationServices()
        // Opt-in to battery monitoring so UIDevice.current.batteryLevel
        // returns a real value (0.0–1.0) instead of -1.0. We read this
        // when building the /predict request so the server can correlate
        // capture quality with device power state. iOS dispatches battery-
        // change notifications on a small background queue — we don't
        // subscribe, we just sample the latest value at upload time.
        UIDevice.current.isBatteryMonitoringEnabled = true
    }

    // MARK: - Location services

    /// Stand up the CLLocationManager and request When-In-Use permission.
    /// The first launch shows the system permission alert; subsequent
    /// launches re-use the granted/denied decision silently. On denied
    /// or restricted, currentLatitude/currentLongitude stay at 0.0,
    /// which is the requested fallback for the API form field.
    ///
    /// IMPORTANT for host integrators: the host app's Info.plist must
    /// include `NSLocationWhenInUseUsageDescription` with a human-
    /// readable purpose string, otherwise `requestWhenInUseAuthorization`
    /// is silently ignored by iOS and the permission prompt never shows.
    private func setupLocationServices() {
        let mgr = CLLocationManager()
        mgr.delegate = self
        // Hundred-metre accuracy is plenty for "where was this product
        // scanned"; raising to .best burns battery for no practical gain.
        mgr.desiredAccuracy = kCLLocationAccuracyHundredMeters
        // Only deliver new fixes if the user moved a meaningful distance,
        // again to avoid waking the GPS chip continuously.
        mgr.distanceFilter = 50
        self.locationManager = mgr

        // Trigger the permission prompt if we haven't asked before. For
        // already-authorized launches this is a no-op (the delegate's
        // locationManagerDidChangeAuthorization will fire with the
        // existing status and we start updates from there).
        mgr.requestWhenInUseAuthorization()
        print("📍 location services setup — current authorization: \(authorizationStatusDescription(mgr.authorizationStatus))")

        // If permission is already granted from a previous run, kick off
        // updates immediately (the delegate callback won't fire on its
        // own for already-decided cases on older iOS).
        if mgr.authorizationStatus == .authorizedWhenInUse
            || mgr.authorizationStatus == .authorizedAlways {
            mgr.startUpdatingLocation()
        }
    }

    /// Pretty-prints the auth-status enum so the console log line is
    /// readable while debugging. iOS adds new cases over time; we map
    /// the known set and fall through to the raw value for anything
    /// future Apple adds.
    private func authorizationStatusDescription(_ status: CLAuthorizationStatus) -> String {
        switch status {
        case .notDetermined:        return "notDetermined"
        case .restricted:           return "restricted"
        case .denied:               return "denied"
        case .authorizedAlways:     return "authorizedAlways"
        case .authorizedWhenInUse:  return "authorizedWhenInUse"
        @unknown default:           return "unknown(\(status.rawValue))"
        }
    }

    /// JSON string for the `location` form field. Built lazily from
    /// the current best-known fix so the latest values get sent at
    /// upload time rather than capture time.
    ///
    /// DEBUG OVERRIDE: when building Debug from Xcode (Run / Build &
    /// Debug), this returns hardcoded test coordinates instead of the
    /// CoreLocation values. Useful because Xcode's "Simulate Location"
    /// GPX feature is flaky — sometimes the chosen GPX never reaches
    /// CLLocationManager and the fix stays at 0.0 forever. The
    /// hardcoded path bypasses CoreLocation entirely so the API
    /// always gets test coordinates during local development.
    ///
    /// Release / TestFlight production builds compile out the override
    /// branch and use the real device fix. Flip `useDebugLocationOverride`
    /// to false if you ever want to test the real CoreLocation path
    /// from Xcode without removing the override block.
    private func currentLocationJSONString() -> String {
        // Spoofed coordinates used by both the #if DEBUG auto-override
        // and the host-app `spoofLocation` flag. Centralised so changing
        // them updates every override path at once.
        let spoofedLatitude  = 22.8056
        let spoofedLongitude = 86.2031

        // Host-app override (works in Release too). Triggered by the
        // SDK consumer via AxionScannerSDK.presentScanner(spoofLocation:),
        // typically wired to a hidden debug gesture in the host UI
        // (e.g. triple-tap on the "AXION CODE" title in SampleAppAxion).
        if spoofLocation {
            print(String(format: "🧪 host-app spoofLocation flag is true — lat=%.7f lon=%.7f (ignoring CoreLocation)",
                         spoofedLatitude, spoofedLongitude))
            return String(format: "{\"latitude\":%.2f,\"longitude\":%.2f}",
                          spoofedLatitude, spoofedLongitude)
        }
        //TODO
//        #if DEBUG
//        // Auto-override for every Xcode-run Debug build. Toggle this
//        // local flag if you ever want Debug builds to use the real
//        // device CoreLocation values instead of the hardcoded fallback.
//        let useDebugLocationOverride = true
//        if useDebugLocationOverride {
//            print(String(format: "🧪 DEBUG location override active — lat=%.7f lon=%.7f (ignoring CoreLocation)",
//                         spoofedLatitude, spoofedLongitude))
//            return String(format: "{\"latitude\":%.2f,\"longitude\":%.2f}",
//                          spoofedLatitude, spoofedLongitude)
//        }
//        #endif

        return String(format: "{\"latitude\":%.2f,\"longitude\":%.2f}",
                      currentLatitude, currentLongitude)
    }

    // MARK: - App background / foreground gating

    private func registerAppLifecycleObservers() {
        let nc = NotificationCenter.default

        // 1) Legacy UIApplication notifications. These fire process-wide,
        //    INCLUDING in scene-based hosts — but only when ALL scenes go
        //    inactive (i.e. on iPad multi-scene they may not fire when the
        //    user just backgrounds one window). Still register them as the
        //    primary signal.
        nc.addObserver(self,
                       selector: #selector(handleAppWillResignActive),
                       name: UIApplication.willResignActiveNotification,
                       object: nil)
        nc.addObserver(self,
                       selector: #selector(handleAppDidBecomeActive),
                       name: UIApplication.didBecomeActiveNotification,
                       object: nil)
        // Also catch the harder transition — when the app/scene moves all
        // the way to background. Useful when the host suspends quickly.
        nc.addObserver(self,
                       selector: #selector(handleAppWillResignActive),
                       name: UIApplication.didEnterBackgroundNotification,
                       object: nil)
        nc.addObserver(self,
                       selector: #selector(handleAppDidBecomeActive),
                       name: UIApplication.willEnterForegroundNotification,
                       object: nil)

        // 2) UIScene notifications (iOS 13+). These fire per-scene, which
        //    is the right signal in modern host apps — UIApplication
        //    notifications can miss scene-only transitions on iPadOS.
        //    Observing both is safe: the handlers are idempotent (they
        //    just flip isAppInBackground and call teardown/restart) so a
        //    duplicate notification is harmless.
        if #available(iOS 13.0, *) {
            nc.addObserver(self,
                           selector: #selector(handleSceneWillDeactivate),
                           name: UIScene.willDeactivateNotification,
                           object: nil)
            nc.addObserver(self,
                           selector: #selector(handleSceneDidActivate),
                           name: UIScene.didActivateNotification,
                           object: nil)
            nc.addObserver(self,
                           selector: #selector(handleSceneWillDeactivate),
                           name: UIScene.didEnterBackgroundNotification,
                           object: nil)
            nc.addObserver(self,
                           selector: #selector(handleSceneDidActivate),
                           name: UIScene.willEnterForegroundNotification,
                           object: nil)
        }

        // 3) Belt-and-braces — if we got presented AFTER the host already
        //    went inactive, the notifications above won't fire until the
        //    state changes. Resync from current app state right now so
        //    isAppInBackground is correct even on first launch.
        let state = UIApplication.shared.applicationState
        print("📲 registerAppLifecycleObservers — initial UIApplication.applicationState = \(state.rawValue) (0=active 1=inactive 2=background)")
        isAppInBackground = (state != .active)
    }

    private func unregisterAppLifecycleObservers() {
        let nc = NotificationCenter.default
        // Removing by name is cheap and tolerates "wasn't registered" — we
        // can blanket-remove everything we might have added without
        // tracking iOS-version variants.
        nc.removeObserver(self, name: UIApplication.willResignActiveNotification, object: nil)
        nc.removeObserver(self, name: UIApplication.didBecomeActiveNotification, object: nil)
        nc.removeObserver(self, name: UIApplication.didEnterBackgroundNotification, object: nil)
        nc.removeObserver(self, name: UIApplication.willEnterForegroundNotification, object: nil)
        if #available(iOS 13.0, *) {
            nc.removeObserver(self, name: UIScene.willDeactivateNotification, object: nil)
            nc.removeObserver(self, name: UIScene.didActivateNotification, object: nil)
            nc.removeObserver(self, name: UIScene.didEnterBackgroundNotification, object: nil)
            nc.removeObserver(self, name: UIScene.willEnterForegroundNotification, object: nil)
        }
    }

    // MARK: - UIScene bridge

    /// Scene-level deactivation handler. In scene-based hosts (most modern
    /// apps) this fires reliably; the UIApplication-level notifications can
    /// miss the transition entirely. Forwards to the existing handler so
    /// teardown logic lives in one place.
    @available(iOS 13.0, *)
    @objc private func handleSceneWillDeactivate(_ note: Notification) {
        print("🎬 UIScene event \(note.name.rawValue) — forwarding to teardown")
        handleAppWillResignActive()
    }

    /// Scene-level activation handler — mirror of handleSceneWillDeactivate.
    @available(iOS 13.0, *)
    @objc private func handleSceneDidActivate(_ note: Notification) {
        print("🎬 UIScene event \(note.name.rawValue) — forwarding to re-arm")
        handleAppDidBecomeActive()
    }

    // MARK: - Public hooks for the host app

    /// Public escape hatch for host integrators. If the SDK's auto-detection
    /// somehow misses the background transition in your app (rare but
    /// possible in odd lifecycle setups), call this from your host's
    /// `scene(_:willResignActive:)` / `applicationWillResignActive` and the
    /// scanner will tear down cleanly. Idempotent; safe to call extra times.
    @objc public func sdkHostDidEnterBackground() {
        print("🪝 sdkHostDidEnterBackground() — host signalled background")
        handleAppWillResignActive()
    }

    /// Mirror of `sdkHostDidEnterBackground` for the foreground path. Call
    /// from your host's `scene(_:didBecomeActive:)` /
    /// `applicationDidBecomeActive` if the SDK isn't picking up the event.
    @objc public func sdkHostDidBecomeActive() {
        print("🪝 sdkHostDidBecomeActive() — host signalled foreground")
        handleAppDidBecomeActive()
    }

    /// Fires for both background and the brief "inactive" state (control
    /// centre, incoming call, app switcher). Full teardown — every periodic
    /// hardware subscriber (CMMotionManager / AVCaptureSession / audio /
    /// timers) is stopped here so the OS sees the app as truly idle while
    /// backgrounded. Foreground path (`handleAppDidBecomeActive`) re-arms
    /// everything if the scanner view is still on screen.
    @objc private func handleAppWillResignActive() {
        let state = UIApplication.shared.applicationState
        print("📴 handleAppWillResignActive — UIApplication.applicationState=\(state.rawValue) (0=active 1=inactive 2=background)")
        // Idempotent: if we're already torn down (e.g. multiple lifecycle
        // notifications fire in quick succession across UIApplication +
        // UIScene), bail out without doing the work twice.
        guard !isAppInBackground else {
            print("📴 already torn down — ignoring duplicate notification")
            return
        }
        isAppInBackground = true

        // 1) Timers + display link. cancelActiveScanTimer() doesn't touch
        //    pendingScanTimerStart so the foreground handler knows we still
        //    want to be scanning.
        cancelActiveScanTimer()
        stopTiltCheckTimer()
        progressDisplayLink?.invalidate()
        progressDisplayLink = nil
        DispatchQueue.main.async { [weak self] in
            self?.scanProgressView?.setProgress(0, animated: false)
        }

        // 2) THE BUG FIX — stop CMMotionManager. Without this the
        //    accelerometer/gyro keep streaming at 30 Hz while the app is
        //    backgrounded.
        stopMotionMonitoring()

        // 3) Stop AVCaptureSession explicitly. iOS pauses it on background
        //    automatically, but stopping it cleanly releases the camera
        //    hardware and matches the foreground startRunning() call.
        if let session = self.captureSession, session.isRunning {
            DispatchQueue.global(qos: .userInitiated).async {
                session.stopRunning()
                print("📷 capture session stopped (background)")
            }
        }

        // 4) Audio — pause the guidance loop. We resume from where it left
        //    off on didBecomeActive.
        audioQueue.async { [weak self] in
            self?.audioPlayer?.pause()
        }

        // 5) Discard pending one-shot frame callbacks. Once we go to bg the
        //    video queue stops emitting frames, so these closures would
        //    never fire. On foreground we'd risk consuming the first fresh
        //    frame for a stale validation/fake-photo request.
        validationFrameCompletion = nil
        pendingFakePhotoCompletion = nil
        pendingValidatePhotoCompletion = nil

        // 6) Drop sharpness so we don't sail back into foreground with a
        //    stale "frame is sharp" reading from before we left. Also
        //    force the next sharpness probe to actually run, not throttle.
        //    Reset the hysteresis counter too — N consecutive sharp
        //    probes after backgrounding starts from scratch.
        isFrameSharp = false
        consecutiveSharpProbes = 0
        userIsTooCloseToFocus = false
        lastSharpnessCheckTime = 0
        // Far-detection state — see maybeRunFarDetection(). Counters
        // and currentlyFar must not survive a background round-trip.
        isUserCurrentlyFar = false
        consecutiveFarFrames = 0
        consecutiveCloseFrames = 0
        lastFarCheckTime = 0
        isFarDetectionInflight = false
        // Same for focus — assume the worst until KVO/device-state says
        // otherwise on the next foreground tick.
        isAutoFocusAdjusting = true
        // Release the tilt-check guard so the foreground re-arm can start
        // a fresh tick (otherwise a stuck `true` would silently disable
        // auto-zoom + guidance after returning to foreground).
        isTiltChecking = false
    }

    // MARK: - AVCaptureSession recovery

    /// Subscribes to the three AVCaptureSession notifications that the
    /// scanner needs to react to. Without these the scanner is blind to
    /// mid-run camera failures and silently sits on a black preview:
    ///
    ///  • `AVCaptureSessionRuntimeError` — the session hit a hard error
    ///    (camera was claimed by another process, exposure/AF subsystem
    ///    crashed, etc.). Session is stopped; we must restart it.
    ///  • `AVCaptureSessionWasInterrupted` — a soft pause. The classic
    ///    reasons are an incoming call, Control Center expanding, audio
    ///    contention (our own AVAudioSession activation racing camera
    ///    startup on slower SoCs — this is the SE-class symptom we saw),
    ///    multitasking Slide Over, etc.
    ///  • `AVCaptureSessionInterruptionEnded` — the interruption cleared.
    ///    We re-startRunning() so frames flow again and the preview comes
    ///    back from black.
    ///
    /// All three are essential. Apple's docs are clear that "if your app
    /// loses control of the capture session, your app should be prepared
    /// to recover" — observers + restart is the canonical recovery path.
    private func registerCaptureSessionObservers() {
        guard let session = captureSession else { return }
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handleCaptureSessionRuntimeError(_:)),
            name: .AVCaptureSessionRuntimeError,
            object: session
        )
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handleCaptureSessionWasInterrupted(_:)),
            name: .AVCaptureSessionWasInterrupted,
            object: session
        )
        NotificationCenter.default.addObserver(
            self,
            selector: #selector(handleCaptureSessionInterruptionEnded(_:)),
            name: .AVCaptureSessionInterruptionEnded,
            object: session
        )
        print("👂 registered AVCaptureSession observers (runtime-error / interrupted / interruption-ended)")
    }

    @objc private func handleCaptureSessionRuntimeError(_ note: Notification) {
        // userInfo[AVCaptureSessionErrorKey] carries an NSError describing
        // the failure. The most common ones are code = -11800 (mediaServicesWereReset)
        // and code = -11852 (visualMediaServicesWereReset) — both recoverable
        // by simply calling startRunning() again from a background queue.
        let err = note.userInfo?[AVCaptureSessionErrorKey] as? NSError
        print("❌ AVCaptureSessionRuntimeError — \(err?.localizedDescription ?? "unknown")  code=\(err?.code ?? 0)")
        guard let session = self.captureSession else { return }
        DispatchQueue.global(qos: .userInitiated).async {
            if !session.isRunning {
                session.startRunning()
                print("🔁 capture session restarted after runtime error — isRunning=\(session.isRunning)")
                // Torch was almost certainly dropped by iOS when the session
                // died; re-engage to match the UI.
                DispatchQueue.main.async { [weak self] in
                    self?.engageTorchAfterRestart()
                }
            }
        }
    }

    @objc private func handleCaptureSessionWasInterrupted(_ note: Notification) {
        // userInfo[AVCaptureSessionInterruptionReasonKey] is a raw Int
        // matching AVCaptureSession.InterruptionReason. The juicy ones:
        //   • 1 = videoDeviceNotAvailableInBackground   (we backgrounded)
        //   • 2 = audioDeviceInUseByAnotherClient       (audio contention)
        //   • 3 = videoDeviceInUseByAnotherClient       (camera contention)
        //   • 4 = videoDeviceNotAvailableWithMultipleForegroundApps (Slide Over)
        // Reason 2 is the canonical "SE black preview" pattern: our
        // AVAudioSession.setActive(true) competed with the camera's
        // implicit audio claim and iOS pre-empted us. The pause is
        // logged for diagnostics; recovery happens in -InterruptionEnded.
        let reasonRaw = (note.userInfo?[AVCaptureSessionInterruptionReasonKey] as? Int) ?? -1
        let reasonName: String = {
            switch reasonRaw {
            case 1: return "videoDeviceNotAvailableInBackground"
            case 2: return "audioDeviceInUseByAnotherClient"
            case 3: return "videoDeviceInUseByAnotherClient"
            case 4: return "videoDeviceNotAvailableWithMultipleForegroundApps"
            case 5: return "videoDeviceNotAvailableDueToSystemPressure"
            default: return "unknown(\(reasonRaw))"
            }
        }()
        print("⚠️ AVCaptureSessionWasInterrupted — reason=\(reasonName)")
    }

    @objc private func handleCaptureSessionInterruptionEnded(_ note: Notification) {
        print("✅ AVCaptureSessionInterruptionEnded — restarting session")
        guard let session = self.captureSession else { return }
        DispatchQueue.global(qos: .userInitiated).async {
            if !session.isRunning {
                session.startRunning()
                print("🔁 capture session restarted after interruption — isRunning=\(session.isRunning)")
                // Same torch-resync rationale as the runtime-error path.
                DispatchQueue.main.async { [weak self] in
                    self?.engageTorchAfterRestart()
                }
            } else {
                print("ℹ️ session already running by the time we got -InterruptionEnded")
            }
        }
    }

    /// Re-arm the whole pipeline on foreground, BUT only if the scanner is
    /// actually still on screen. If the user backgrounded into the scanner
    /// then navigated away to a different VC, we don't want to start the
    /// camera back up under the new screen.
    @objc private func handleAppDidBecomeActive() {
        let state = UIApplication.shared.applicationState
        print("🟢 handleAppDidBecomeActive — UIApplication.applicationState=\(state.rawValue) isAppInBackground(before)=\(isAppInBackground)")
        // Idempotent: avoid spamming startRunning/audio/restart calls when
        // multiple lifecycle notifications fire in quick succession.
        guard isAppInBackground else {
            print("🟢 already foregrounded — ignoring duplicate notification")
            return
        }
        isAppInBackground = false

        // Bail if the scanner VC isn't visible — e.g., the user came back
        // to a different screen, or this VC is mid-dismiss.
        guard self.isViewLoaded, self.view.window != nil else {
            print("🟢 app became active but scanner not on screen — skipping re-arm")
            return
        }
        print("🟢 app became active — restarting scan pipeline (scanner is on screen)")

        // 1) Bring the camera hardware back. startRunning() is a blocking
        //    call so it must go on a background queue.
        if let session = self.captureSession, !session.isRunning {
            DispatchQueue.global(qos: .userInitiated).async { [weak self] in
                session.startRunning()
                print("📷 capture session restarted (foreground)")

                // Once the session is alive, restart the rest from main —
                // these all touch UIKit / RunLoop state.
                DispatchQueue.main.async { [weak self] in
                    self?.resumeScanPipelineForForeground()
                }
            }
        } else {
            // Session was already running for some reason — skip the queue
            // hop and resume directly.
            resumeScanPipelineForForeground()
        }
    }

    /// Re-arms the non-camera parts of the pipeline. Called from the
    /// capture-session restart completion so we don't try to run scans
    /// against a paused session.
    private func resumeScanPipelineForForeground() {
        // Resync focus state from the device — KVO doesn't fire on its own
        // just because we came back to the foreground.
        isAutoFocusAdjusting = videoDevice?.isAdjustingFocus ?? false

        // Make sure the lens is in continuous AF/AE — see resumeContinuousAutoFocus()
        // for why this is necessary on every entry path (one-shot AF used
        // during the validation-path capture leaves the lens `.locked`).
        resumeContinuousAutoFocus()

        // Re-engage the torch if the UI still thinks it's on. iOS turns the
        // torch hardware OFF automatically whenever session.stopRunning() is
        // called (which handleAppWillResignActive does) — but isTorchOn and
        // the button icon are untouched, so we come back to foreground with
        // a yellow torch icon and dark torch hardware. Result: black /
        // near-black preview when the user expects a lit scene (this is
        // exactly what the user's 2 AM black-screen report was — see
        // engageTorchAfterRestart() doc for the related restartScan fix).
        // The helper is idempotent and reads isTorchOn — safe even when
        // torch wasn't engaged before the background round-trip.
        engageTorchAfterRestart()

        // Resume guidance audio if it was enabled when we backgrounded.
        audioQueue.async { [weak self] in
            guard let self = self, self.isAudioEnabled else { return }
            self.audioPlayer?.play()
        }

        // startScanTimer() idempotently re-arms motion monitoring (via
        // the guard in startMotionMonitoring) and the tilt-check timer,
        // then either arms the 6-second countdown right away or holds at
        // 0% until focus + sharpness + motion gates pass.
        if pendingScanTimerStart {
            startScanTimer()
        }
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

        // Step 1: Start camera session on background thread
        DispatchQueue.global(qos: .userInitiated).async {
            guard let session = self.captureSession, !session.isRunning else { return }
            // Timing log: on slower SoCs (SE-class, A13/A15) this call
            // can block for 1–3 seconds while the camera hardware
            // initialises. Everything queued AFTER it (torch, audio,
            // scan-timer arming) is delayed by exactly that long, which
            // is what surfaces to users as "audio comes late, flash
            // comes late, preview is dark for a while". If the printed
            // duration is consistently > ~2s on real hardware, that's a
            // signal to either pre-warm the session earlier (in
            // viewWillAppear) or strip whatever's heaviest from the
            // setupCamera() configuration.
            let t0 = CACurrentMediaTime()
            session.startRunning()
            let elapsedMs = (CACurrentMediaTime() - t0) * 1000
            print(String(format: "✅ Capture session started (startRunning blocked %.0f ms)", elapsedMs))
            
            // Step 2: Torch AFTER session is running (needs active session)
            DispatchQueue.main.async {
                self.toggleTorch()
            }
            
            // Step 3: Audio completely separate — never on main thread
            self.audioQueue.async { [weak self] in
                self?.startAudioIfNeeded()
            }
            
            // Step 4: Timer on main thread (gated by motion stability)
            DispatchQueue.main.async {
                self.startMotionMonitoring()
                self.startScanTimer()
            }
        }
    }
  func startScanTimer() {
        // Caller wants the countdown running — but only let it tick when the
        // frame is genuinely capture-ready (steady + focused + sharp).
        pendingScanTimerStart = true
        cancelActiveScanTimer()

        // Re-arm motion monitoring in case a previous scan torn it down
        // (we stop it just before the upload to save power). This is a
        // no-op if monitoring is already active.
        startMotionMonitoring()

        // Tilt + auto-zoom analysis runs independently of the countdown so the
        // user keeps getting guidance even while the timer is gated.
        startTiltCheckTimer()

        guard canArmScanTimerNow() else {
            // Hold at 0% until the gating condition clears.
            progressDisplayLink?.invalidate()
            progressDisplayLink = nil
            DispatchQueue.main.async { [weak self] in
                self?.scanProgressView?.setProgress(0, animated: false)
            }
            print("⏸ scan timer waiting — \(currentArmBlockReason())")
            return
        }

        scanTimer = Timer.scheduledTimer(timeInterval: scanInterval,
                                         target: self,
                                         selector: #selector(scanTimerFired),
                                         userInfo: nil,
                                         repeats: true)
        RunLoop.main.add(scanTimer!, forMode: .common)
        print("⏱️ scan timer started")
        startProgressAnimation()
    }

    /// All gating conditions for the periodic capture timer in one place. We
    /// only let the 6-second countdown run when every one is satisfied — that
    /// way the timer can't fire on a moving / unfocused / blurry frame and
    /// upload garbage to the model API.
    ///
    /// The far-detection state also gates here: while we're showing
    /// "You are far. Come closer", we don't want the periodic timer
    /// to fire — there's nothing to validate when the QR is barely
    /// visible. The moment far state clears, `reevaluateScanTimerGate()`
    /// arms the timer again (driven from updateFarStateWithHysteresis).
    private func canArmScanTimerNow() -> Bool {
        return !isAppInBackground
            && isMotionStable
            && !isAutoFocusAdjusting
            && isFrameSharp
            && !isUserCurrentlyFar
            && isQRSufficientlyInScanWindow
    }

    /// Diagnostic helper — names whichever gate is currently blocking us so the
    /// logs are useful when debugging field reports.
    private func currentArmBlockReason() -> String {
        if isAppInBackground { return "app in background" }
        if !isMotionStable { return "motion not stable" }
        if isAutoFocusAdjusting { return "autofocus still adjusting" }
        if !isFrameSharp { return "frame not sharp yet" }
        if isUserCurrentlyFar { return "user is too far" }
        if !isQRSufficientlyInScanWindow { return "QR not sufficiently inside scan window" }
        return "ready"
    }

    private func stopScanTimer(finalProgress: Float = 1.0) {
        // Caller no longer wants the countdown running.
        pendingScanTimerStart = false
        cancelActiveScanTimer()
        // Full stop — also drop the live tilt/auto-zoom analyzer.
        stopTiltCheckTimer()
        print("⏹️ scan timer stopped")
        stopProgressAnimation(finalProgress: finalProgress)
    }

    /// Cancel the underlying countdown Timer without touching the "want it running"
    /// intent or the progress bar — used by the motion / focus / sharpness gates
    /// so we can resume once the frame is capture-ready again.
    ///
    /// NOTE: the tilt + auto-zoom analysis timer is intentionally NOT stopped here.
    /// We want live guidance and auto-zoom corrections to keep happening even
    /// while the scan countdown is gated.
    private func cancelActiveScanTimer() {
        scanTimer?.invalidate()
        scanTimer = nil
    }

    /// Pause the countdown while the user is actively interacting with a control
    /// (zoom slider drag, etc.). Cancels the underlying timer and snaps the bar
    /// back to 0% without clearing `pendingScanTimerStart`, so a follow-up
    /// `startScanTimer()` can resume cleanly.
    private func pauseScanIntervalForInteraction() {
        cancelActiveScanTimer()
        progressDisplayLink?.invalidate()
        progressDisplayLink = nil
        DispatchQueue.main.async { [weak self] in
            self?.scanProgressView?.setProgress(0, animated: false)
        }
    }

    // MARK: - Scan-interval progress

    private func startProgressAnimation() {
        progressDisplayLink?.invalidate()
        progressStartTime = CACurrentMediaTime()

        // Reset the mid-interval torch-off guard so this fresh interval
        // gets one chance to flip the torch off at the 70% mark. See
        // `autoTorchOffAtFraction` and updateScanProgress() for context.
        hasAutoSwitchedTorchOffThisInterval = false

        DispatchQueue.main.async { [weak self] in
            self?.scanProgressView?.setProgress(0, animated: false)
        }

        let link = CADisplayLink(target: self, selector: #selector(updateScanProgress))
        link.add(to: .main, forMode: .common)
        progressDisplayLink = link
    }

    private func stopProgressAnimation(finalProgress: Float) {
        progressDisplayLink?.invalidate()
        progressDisplayLink = nil
        DispatchQueue.main.async { [weak self] in
            self?.scanProgressView?.setProgress(finalProgress, animated: false)
        }
    }

    @objc private func updateScanProgress() {
        guard scanInterval > 0 else { return }
        let elapsed = CACurrentMediaTime() - progressStartTime
        let fraction = Float(min(max(elapsed / scanInterval, 0), 1))
        scanProgressView?.setProgress(fraction, animated: false)

        // Mid-interval torch toggle. If 70% of the interval has elapsed
        // and Vision still hasn't decoded a QR, switch the torch OFF
        // so the remaining ~30% covers the "flash causes glare" case.
        // Guarded by `hasAutoSwitchedTorchOffThisInterval` so this only
        // fires once per interval, no matter how many CADisplayLink
        // ticks land between the threshold and the next interval start.
        if !hasAutoSwitchedTorchOffThisInterval,
           !isQRCodeDetected,
           Double( ) >= autoTorchOffAtFraction {
            hasAutoSwitchedTorchOffThisInterval = true
            switchTorchOffMidInterval()
        }

        // Once we hit 100%, no need to keep ticking; the timer fire will reset it.
        if fraction >= 1.0 {
            progressDisplayLink?.invalidate()
            progressDisplayLink = nil
        }
    }

    // MARK: - Motion stability (gates the scan timer)

    private func startMotionMonitoring() {
        guard motionManager.isDeviceMotionAvailable else {
            // Device has no motion data — fall back to "always stable" so we don't
            // wedge the scanner on hardware that can't report it.
            isMotionStable = true
            if pendingScanTimerStart { startScanTimer() }
            return
        }
        guard !motionManager.isDeviceMotionActive else { return }

        motionManager.deviceMotionUpdateInterval = 1.0 / 30.0   // 30 Hz is plenty
        motionManager.startDeviceMotionUpdates(to: .main) { [weak self] motion, _ in
            guard let self = self, let motion = motion else { return }

            let a = motion.userAcceleration
            let r = motion.rotationRate
            let accelMag = sqrt(a.x * a.x + a.y * a.y + a.z * a.z)
            let rotMag   = sqrt(r.x * r.x + r.y * r.y + r.z * r.z)

            // Combine: acceleration dominates, rotation adds a smaller contribution.
            let combined = accelMag + 0.1 * rotMag

            // Exponential moving average — α=0.2 gives ~150 ms time constant at 30 Hz.
            let alpha = 0.2
            self.smoothedMotion = alpha * combined + (1 - alpha) * self.smoothedMotion
//            print("motion: \(self.smoothedMotion)")
            let stableNow = self.smoothedMotion < self.motionStabilityThreshold
            if stableNow != self.isMotionStable {
                self.isMotionStable = stableNow
                self.handleStabilityChange(stable: stableNow)
            }
        }
    }

    private func stopMotionMonitoring() {
        if motionManager.isDeviceMotionActive {
            motionManager.stopDeviceMotionUpdates()
        }
    }

    private func handleStabilityChange(stable: Bool) {
        if stable {
            print("🟢 motion stable — re-evaluating scan timer gate")
            // Re-evaluate gate; will arm only if focus + sharpness also pass.
            reevaluateScanTimerGate()
        } else {
            print("🟠 motion detected — pausing scan timer, resetting progress to 0")
            // Pause the underlying Timer but KEEP tilt/auto-zoom running so the
            // user still gets guidance, and keep the "we want this running"
            // intent so it auto-resumes once steady.
            cancelActiveScanTimer()
            progressDisplayLink?.invalidate()
            progressDisplayLink = nil
            DispatchQueue.main.async { [weak self] in
                self?.scanProgressView?.setProgress(0, animated: false)
            }
        }
    }

    /// Called whenever any gating signal changes (motion / focus / sharpness).
    /// Hops to main so KVO + video-queue callers don't trample the timer.
    private func reevaluateScanTimerGate() {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            guard self.pendingScanTimerStart else { return }
            if self.scanTimer == nil, self.canArmScanTimerNow() {
                self.startScanTimer()
            }
        }
    }

    private func resetScanTimer() {
        // Explicit reset: we WANT the bar to snap back to 0, not stay at
        // the completed-scan default of 1.0. Passing finalProgress: 0
        // means both stopScanTimer's async dispatch AND startScanTimer's
        // async dispatch converge on 0, so any FIFO ordering weirdness
        // between the two async blocks (or a lingering CADisplayLink
        // tick already in flight) can't leave the bar stuck at full.
        stopScanTimer(finalProgress: 0)
        startScanTimer()
    }
    
    @objc private func scanTimerFired() {
        // Skip if we're already processing a detected QR or uploading
        guard !isQRCodeDetected, !isUploading else {
            print("⏱️ scanTimer skipped (isQRCodeDetected=\(isQRCodeDetected), isUploading=\(isUploading))")
            return
        }

        // Second-chance gate: even if the timer was armed earlier, the frame
        // may have drifted out of focus / motion since. Re-check before firing
        // so we don't burn the periodic upload on a bad frame.
        guard canArmScanTimerNow() else {
            print("⏱️ scanTimer fired but gate failed — \(currentArmBlockReason()); resetting countdown")
            // Cancel the active Timer, hold the progress bar at 0%, and let
            // the gate re-arm when conditions return.
            cancelActiveScanTimer()
            progressDisplayLink?.invalidate()
            progressDisplayLink = nil
            DispatchQueue.main.async { [weak self] in
                self?.scanProgressView?.setProgress(0, animated: false)
            }
            return
        }

        // Mark that this capture is periodic and should upload with this label

        print("⏰ scanTimer fired — capturing photo for periodic upload")
        pendingTestingLabel = "Prod"

        stopScanTimer()
        
        validateWithObjectDetection { [weak self] hasAllClasses, capturedImage in
            guard let self = self else { return }
            
            if hasAllClasses {
                // Capture the next live frame, fire the v3 authenticity-
                // verification upload with that image, THEN show the fake-product
                // screen. Capture-BEFORE-navigate matters because the fake screen
                // push triggers viewWillDisappear which stops the AVCaptureSession
                // — if we captured after, no frames would arrive to fulfil the
                // completion. A 500 ms safety timeout guarantees the fake screen
                // still shows even if the camera died and never delivers a frame.
                var fakeScreenShown = false
                let showFakeScreenOnce: () -> Void = { [weak self] in
                    guard let self = self, !fakeScreenShown else { return }
                    fakeScreenShown = true
                    self.simulateFakeProductDetails()
                }

                // /VALIDATE/ HIGH-RES CAPTURE ─────────────────────────
                // Install pendingValidatePhotoCompletion, then trigger
                // capturePhoto(). photoOutput routes the resulting
                // high-res CIImage into our closure below — same native
                // ~4032×3024 photo pixels the /predict/ path receives,
                // so /validate/'s upload no longer suffers from the
                // ~4× pixel deficit of the video-preview path.
                //
                // Closure body mirrors what captureFrameForValidation
                // used to produce: build a UIImage from the CIImage with
                // orientation .right (raw landscape pixels tagged for
                // portrait display), then hand it to sendImagetoValidationAPI
                // unchanged. That function extracts .cgImage internally,
                // so it sees the raw high-res landscape pixels — bigger
                // canvas, same code path.
                self.pendingValidatePhotoCompletion = { [weak self] ciImage in
                    guard let self = self else { return }
                    guard let ciImage = ciImage else {
                        print("⚠️ /validate/ high-res capture returned nil CIImage")
                        return
                    }
                    // Pass the JPEG-backed CIImage STRAIGHT to
                    // sendImagetoValidationAPI. No createCGImage, no
                    // UIImage wrap — those extra steps introduced a
                    // full-frame raster round-trip that softened the
                    // crop compared to /predict/'s single-render path.
                    // sendImagetoValidationAPI now takes a CIImage
                    // directly and hands it to cropUsingPreferredStrategy,
                    // which lets the crop stay lazy until the final
                    // cropWithPadding renders exactly the crop region
                    // once — identical fidelity to /predict/.
                    print(String(format: "📸 /validate/ high-res CIImage handed off: %.0f×%.0f (JPEG-backed, no round-trip)",
                                 ciImage.extent.width, ciImage.extent.height))
                    self.sendImagetoValidationAPI(ciImage: ciImage, testingLabel: self.testingLabel) { result in
                        switch result {
                        case .success(let src):
                            print("✅ Validation Image uploaded successfully. Source URL: \(src)")
                        case .failure(let error):
                            print("❌ Validation Error uploading image: \(error.localizedDescription)")
                        }
                    }
                }
                // Fire the shutter. photoOutput delegate will consume
                // pendingValidatePhotoCompletion above and skip the
                // /predict/ pipeline.
                self.capturePhoto()

                // Safety net — if the camera doesn't deliver a frame within 500 ms
                // (e.g. session interrupted, app backgrounded mid-fire), proceed to
                // the fake screen anyway. `showFakeScreenOnce` is idempotent.
//                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
//                    if !fakeScreenShown {
//                        print("⚠️ /authenticity-verification-v3/ frame capture timed out — proceeding to fake screen")
//                        showFakeScreenOnce()
//                    }
//                }
            }
            else{
                self.showAlert(title: "QR not validated", message: "The QR label could not be verified as original. This product may be invalid.")
                self.captureFrameForValidation { [weak self] image in
                    guard let self = self else { return }
                    if let image = image {
                        self.sendImageToAuthenticityVerificationWithImage(
                            image: image,
                            deviceId: self.axionPersistentDeviceId(),
                            ai_predection: "The QR label could not be verified as original. This product may be invalid.",
                            device_family: self.axionDeviceFamilyName()
                        ) { result in
                            switch result {
                            case .success(let body):
                                print("✅ /authenticity-verification-v3/ success: \(body.prefix(200))")
                            case .failure(let err):
                                print("❌ /authenticity-verification-v3/ failure: \(err.localizedDescription)")
                            }
                        }
                    } else {
                        print("⚠️ /authenticity-verification-v3/ skipped — no live frame captured")
                    }
                  
                }
            }
        }
        
     
//        self.showAlert(title: "QR not validated", message: "The QR label could not be verified as original. This product may be invalid.")
//        validateWithObjectDetection { [weak self] hasAllClasses, capturedImage in
//              guard let self = self else { return }
//
//              if hasAllClasses {
//                  // All 4 classes found — Vision still couldn't decode the QR
//                  // payload though. Two cases:
//                  //   1) We've already retried with the extended 15s window —
//                  //      this is the second timeout, commit to fake screen.
//                  //   2) First timeout — try the /validate/ fallback before
//                  //      giving up. It may recover the qr_value server-side,
//                  //      mark it as fake, or ask us to retry once more.
//                  if self.isInExtendedScanMode {
//                      print("⚠️ All classes detected after extended retry — showing Fake QR")
//                      self.simulateFakeProductDetails()
//                      return
//                  }
//
//                  // Belt-and-braces sharpness check on the centre region of
//                  // the very frame TFLite just ran on. The periodic
//                  // sharpness probe samples every ~0.35s and the lens can
//                  // drift between samples — if the all-classes-present
//                  // frame is itself blurry, restart the countdown so the
//                  // next tick fires on a genuinely sharp frame instead of
//                  // committing to a fuzzy high-res capture.
//                  if let validationImage = capturedImage {
//                      let region = self.centerScanRegion(of: validationImage) ?? validationImage
//                      if self.isImageBlurry(region, threshold: Float(self.liveSharpnessThreshold)) {
//                          print("⚠️ Validation frame (scan region) is blurry — resetting scan timer instead of capturing")
//                          self.isFrameSharp = false
//                          self.startScanTimer()
//                          return
//                      }
//                  }
//
//                  print("🛟 First timeout with all classes — capturing high-res photo for /validate/ crop")
//
//                  // Match the genuine-path pipeline exactly: snap a
//                  // full-resolution photo (respects current videoZoomFactor),
//                  // crop the same way we crop `imageToValidate` before
//                  // sendImagetoModelAPI, and only then forward to
//                  // /validate/. The photoOutput delegate sees the closure
//                  // we install below and routes the capture to us instead
//                  // of running the /predict/ pipeline.
//                  //
//                  // cropSquareNow needs `self.detectedBarcode`, which is
//                  // nil on the fake path because Vision couldn't decode the
//                  // QR — so it'll return nil and we fall through to the
//                  // TFLite-derived crop (cropAroundTFLiteQR), which uses
//                  // the same 3x padding so the validate crop matches the
//                  // predict crop in shape.
//                  self.pendingFakePhotoCompletion = { [weak self] highResCIImage in
//                      guard let self = self else { return }
//
//                      guard let ciImage = highResCIImage else {
//                          print("⚠️ High-res photo capture failed — showing fake screen as fallback")
//                          self.simulateFakeProductDetails()
//                          return
//                      }
//
//                      Task.detached(priority: .userInitiated) {
//                          // 1. Try the Vision-bbox crop first. Almost always
//                          //    nil on the fake path (detectedBarcode is
//                          //    nil), but cheap and handles edge cases where
//                          //    Vision did briefly latch on.
//                          var cropped = self.cropSquareNow(ciImage)
//
//                          // 2. Fall back to a TFLite-based QR crop with the
//                          //    same 3x padding as cropSquareNow.
//                          if cropped == nil {
//                              print("⚠️ cropSquareNow failed — trying TFLite-based QR crop")
//                              cropped = self.cropAroundTFLiteQR(ciImage)
//                          }
//
//                          guard let imageToValidate = cropped else {
//                              await MainActor.run {
//                                  // No usable crop — nothing to send to
//                                  // /validate either. Go straight to the
//                                  // fake screen, same as the pre-validate
//                                  // behaviour.
//                                  print("⚠️ Both Vision and TFLite crops failed — falling back to fake screen")
////                                  self.simulateFakeProductDetails()
//                              }
//                              return
//                          }
//
//                          // 3. Final sharpness gate on the actual crop we're
//                          //    about to upload. Two metrics, both must pass:
//                          //
//                          //    (a) Laplacian variance — fast, catches the
//                          //        coarse "obviously soft" cases.
//                          //    (b) Tenengrad score (0-100) — mirrors the
//                          //        server-side Python `sharpness_score`.
//                          //        Tenengrad is more sensitive to fine-detail
//                          //        edge strength than Laplacian, which is
//                          //        exactly what we need for Axion-code prints
//                          //        where the pattern microstructure matters
//                          //        but the overall image can look "okay".
//                          //
//                          //    Either failing → reset timer, do not upload,
//                          //    do not show fake screen.
//                          if self.isImageBlurry(imageToValidate, threshold: self.validateCropSharpnessThreshold) {
//                              await MainActor.run {
//                                  print("⚠️ High-res crop failed Laplacian gate (threshold=\(self.validateCropSharpnessThreshold)) — resetting scan timer")
//                                  self.isFrameSharp = false
//                                  self.startScanTimer()
//                              }
//                              return
//                          }
//                          let tenengrad = self.sharpnessScore(imageToValidate)
//                          if tenengrad < self.validateCropTenengradThreshold {
//                              await MainActor.run {
//                                  print(String(format: "⚠️ High-res crop failed Tenengrad gate (score=%.2f < threshold=%.0f) — resetting scan timer, NOT uploading and NOT showing fake screen",
//                                               tenengrad, self.validateCropTenengradThreshold))
//                                  self.isFrameSharp = false
//                                  self.startScanTimer()
//                              }
//                              return
//                          }
//                          print(String(format: "✅ High-res crop passed sharpness gates (Tenengrad=%.2f) — proceeding to /validate/", tenengrad))
//
//                          // 4. Same pattern-square TFLite check used before
//                          //    /predict/ — guarantees the persisted /validate/
//                          //    frame has all 6 patterns visible.
//                          let patternsValid = await self.validatePatternBoxes(imageToValidate)
//
//                          await MainActor.run {
//                              if patternsValid {
//                                  print("✅ Pattern validation passed on tight high-res crop — forwarding to /validate/")
//                                  // Debug-only save matching the
//                                  // /predict/ TestFlight save.
//                                  if self.isRunningInTestFlight() {
//                                      UIImageWriteToSavedPhotosAlbum(imageToValidate, nil, nil, nil)
//                                  }
//                              } else {
//                                  print("⚠️ Pattern validation failed on tight high-res crop — forwarding to /validate/ anyway (server side decides)")
//                              }
//
//                              // Hand the crop to /validate/. Branch
//                              // handling lives inside the API method:
//                              //  - Original + qr_value → makeApiCall_new
//                              //  - not Original       → simulateFakeProductDetails(with final_result)
//                              //  - Original + empty   → restartScanWithExtendedInterval
//                              ProgressHUD.shared.show(in: self.view, message: "Validating…")
//                              self.sendImagetoValidationAPI(
//                                  image: imageToValidate,
//                                  testingLabel: "Prod"
//                              ) { _ in
//                                  // Branches handled inside the API
//                                  // call — nothing to do here.
//                              }
//                          }
//                      }
//                  }
//
//                  // Kick off the actual photo capture. The delegate routes
//                  // the result into pendingFakePhotoCompletion above.
//                  //
//                  // Uses the focus-lock-and-wait variant so the lens is
//                  // verifiably stable at the moment the shutter fires —
//                  // the live-preview sharpness probe above tells us the
//                  // frame was sharp ~0-300 ms ago, but the lens can drift
//                  // in the window between the probe and the actual photo
//                  // capture. captureSharpPhotoForValidation waits for
//                  // isAdjustingFocus/isAdjustingExposure to settle (or
//                  // gives up after ~600 ms) before pulling the trigger.
//                  self.captureSharpPhotoForValidation()
//
//              } else {
//                  // Classes missing — genuinely unreadable / not an axion code
//                  print("❌ Not all classes detected — showing QR not validated alert")
//                  self.showAlert(title: "QR not validated", message: "The QR label could not be verified as original. This product may be invalid.")
//              }
//          }
    }

    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        if self.captureSession?.isRunning == true {
            self.captureSession.stopRunning()
        }
        stopScanTimer()
        stopMotionMonitoring()
        stopMonitoringFocusState()
        unregisterAppLifecycleObservers()
        // Stop GPS too — no point keeping it on once the scanner is
        // dismissed. The locationManager itself stays referenced until
        // the VC deallocates.
        locationManager?.stopUpdatingLocation()
    }
    
//    override func viewDidLayoutSubviews() {
//        super.viewDidLayoutSubviews()
//        updateCornerBoxes()
//    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()

        // 🔑 THIS IS MANDATORY
        videoPreviewLayer?.frame = previewView.bounds
        cornerBoxLayer.frame = previewView.bounds
        dimOverlayLayer.frame = previewView.bounds

        // your existing logic
        updateDimOverlay()
        updateCornerBoxes()

        // Z-order fix for the overlay guide image: setupCamera appends
        // videoPreviewLayer / dimOverlayLayer / cornerBoxLayer AFTER
        // setupUI added overlayImageView as a subview, so the camera
        // layers end up on top and the overlay is hidden behind the
        // opaque video. bringSubviewToFront idempotently re-pins the
        // overlay to the top sublayer position. Safe to call repeatedly.
        if let overlay = overlayImageView {
            previewView.bringSubviewToFront(overlay)
        }
    }

    private func setupUI() {
        view.backgroundColor = .black
        
        // Preview view (full screen)
        previewView = UIView()
        previewView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(previewView)
        
        // Instruction label
        instructionLabel = UILabel()
        instructionLabel.translatesAutoresizingMaskIntoConstraints = false
        instructionLabel.text = "Make sure the QR Code is centred\nand clearly visible"
        instructionLabel.textColor = .white
        instructionLabel.textAlignment = .center
        instructionLabel.numberOfLines = 0
        instructionLabel.font = .systemFont(ofSize: 18, weight: .medium)
        view.addSubview(instructionLabel)

        // Scan-interval progress bar (sits just below the instruction label)
        scanProgressView = UIProgressView(progressViewStyle: .bar)
        scanProgressView.translatesAutoresizingMaskIntoConstraints = false
        scanProgressView.progressTintColor = UIColor(red: 0.20, green: 0.70, blue: 1.00, alpha: 1.0)
        scanProgressView.trackTintColor = UIColor.white.withAlphaComponent(0.25)
        scanProgressView.layer.cornerRadius = 3
        scanProgressView.clipsToBounds = true
        scanProgressView.progress = 0
        view.addSubview(scanProgressView)
        
        // Add this near the top of setupUI() after instructionLabel creation
        closeButton = UIButton(type: .system)
        closeButton.translatesAutoresizingMaskIntoConstraints = false
        closeButton.setImage(UIImage(systemName: "chevron.left"), for: .normal)
        closeButton.tintColor = .white
        closeButton.backgroundColor = UIColor(white: 0.0, alpha: 0.35)
        closeButton.layer.cornerRadius = 20
        closeButton.addTarget(self, action: #selector(closeTapped), for: .touchUpInside)
        view.addSubview(closeButton)
        // Make sure the button is always on top so touches reach it
        view.bringSubviewToFront(closeButton)
        audioButton = UIButton(type: .system)
        audioButton.translatesAutoresizingMaskIntoConstraints = false

        let config = UIImage.SymbolConfiguration(pointSize: 20, weight: .semibold)
        audioButton.setImage(
            UIImage(systemName: "speaker.wave.2.fill")?.withConfiguration(config),
            for: .normal
        )

        audioButton.tintColor = .white
        audioButton.backgroundColor = UIColor.black.withAlphaComponent(0.35)
        audioButton.layer.cornerRadius = 22
        audioButton.clipsToBounds = true

        audioButton.addTarget(self, action: #selector(toggleAudio), for: .touchUpInside)
        view.addSubview(audioButton)
        // Prevent preview view intercepting touches (preview is passive)
        previewView.isUserInteractionEnabled = false

        NSLayoutConstraint.activate([
            closeButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
            closeButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 12),
            closeButton.widthAnchor.constraint(equalToConstant: 40),
            closeButton.heightAnchor.constraint(equalToConstant: 40),
            audioButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
                audioButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 12),
                audioButton.widthAnchor.constraint(equalToConstant: 44),
                audioButton.heightAnchor.constraint(equalToConstant: 44)
        ])

        
        // Status label (for "QR Code detected")
        statusLabel = UILabel()
        statusLabel.translatesAutoresizingMaskIntoConstraints = false
        statusLabel.text = ""
        statusLabel.textColor = .white
        statusLabel.textAlignment = .center
        statusLabel.font = .systemFont(ofSize: 16, weight: .medium)
        statusLabel.alpha = 0
        view.addSubview(statusLabel)
        
        // Zoom slider
        zoomSlider = UISlider()
        zoomSlider.translatesAutoresizingMaskIntoConstraints = false
        zoomSlider.minimumValue = Float(minZoom)
        zoomSlider.maximumValue = Float(maxZoom)
        zoomSlider.value = Float(currentZoom)
        zoomSlider.minimumTrackTintColor = .white
        zoomSlider.maximumTrackTintColor = .darkGray
        zoomSlider.addTarget(self, action: #selector(zoomSliderValueChanged(_:)), for: .valueChanged)
        // Reset the 5-second countdown while the user is dragging the slider, and
        // restart it once they lift their finger.
        zoomSlider.addTarget(self, action: #selector(zoomSliderTouchBegan), for: .touchDown)
        zoomSlider.addTarget(self, action: #selector(zoomSliderTouchEnded),
                             for: [.touchUpInside, .touchUpOutside, .touchCancel])
        view.addSubview(zoomSlider)
        
        // In setupUI(), add:
        zoomLabel = UILabel()
        zoomLabel.translatesAutoresizingMaskIntoConstraints = false
        zoomLabel.text = "\(currentZoom)x"
        zoomLabel.textColor = .white
        zoomLabel.textAlignment = .center
        zoomLabel.font = .systemFont(ofSize: 14, weight: .medium)
        view.addSubview(zoomLabel)
        
        focusButton = UIButton(type: .system)
                focusButton.translatesAutoresizingMaskIntoConstraints = false
                focusButton.setImage(UIImage(systemName: "scope"), for: .normal)
                focusButton.tintColor = .white
                focusButton.addTarget(self, action: #selector(triggerAutoFocus), for: .touchUpInside)
                view.addSubview(focusButton)
        
                // Add constraints for focus button
                NSLayoutConstraint.activate([
                    focusButton.topAnchor.constraint(equalTo: scanProgressView.bottomAnchor, constant: 16),
                    focusButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
                    focusButton.widthAnchor.constraint(equalToConstant: 44),
                    focusButton.heightAnchor.constraint(equalToConstant: 44)
                ])
        
        // Bottom controls
        let bottomControls = UIStackView()
        bottomControls.translatesAutoresizingMaskIntoConstraints = false
        bottomControls.axis = .horizontal
        bottomControls.alignment = .center
        bottomControls.distribution = .equalCentering
        view.addSubview(bottomControls)
        
        // Refresh button
        refreshButton = UIButton(type: .system)
        refreshButton.translatesAutoresizingMaskIntoConstraints = false
        refreshButton.setImage(UIImage(systemName: "arrow.clockwise"), for: .normal)
        refreshButton.tintColor = .white
        refreshButton.addTarget(self, action: #selector(restartScan), for: .touchUpInside)
        bottomControls.addArrangedSubview(refreshButton)
        
        // Logo image (center)
        let logoImageView = UIImageView()
        logoImageView.translatesAutoresizingMaskIntoConstraints = false
        logoImageView.image = UIImage(named: "logo_placeholder")
        logoImageView.contentMode = .scaleAspectFit
        bottomControls.addArrangedSubview(logoImageView)
        
        NSLayoutConstraint.activate([
            logoImageView.widthAnchor.constraint(lessThanOrEqualTo: view.widthAnchor, multiplier: 0.4),
            logoImageView.heightAnchor.constraint(equalToConstant: 40)
        ])
        
        // Torch button
        torchButton = UIButton(type: .system)
        torchButton.translatesAutoresizingMaskIntoConstraints = false
        torchButton.setImage(UIImage(systemName: "bolt.fill"), for: .normal)
        torchButton.tintColor = .white
        torchButton.addTarget(self, action: #selector(torchButtonTapped), for: .touchUpInside)
        bottomControls.addArrangedSubview(torchButton)
        
        // Translucent dim overlay (clear window in the centre, dark elsewhere)
        dimOverlayLayer.fillRule = .evenOdd
        dimOverlayLayer.fillColor = UIColor.black.withAlphaComponent(0.55).cgColor
        dimOverlayLayer.fillColor = UIColor.black.withAlphaComponent(0.15).cgColor
        dimOverlayLayer.frame = previewView.bounds
        previewView.layer.addSublayer(dimOverlayLayer)

        // Corner boxes
        cornerBoxLayer.strokeColor = UIColor.red.cgColor
        cornerBoxLayer.lineWidth = 3.0
        cornerBoxLayer.fillColor = UIColor.clear.cgColor
        cornerBoxLayer.frame = previewView.bounds
        previewView.layer.addSublayer(cornerBoxLayer)

        // Overlay guide image — semi-transparent, sized to match the
        // scan window, centred inside the preview. Subviews render above
        // sublayers, so this sits naturally on top of videoPreviewLayer,
        // dimOverlayLayer, and cornerBoxLayer — exactly where the corner
        // brackets visually frame it.
        overlayImageView = UIImageView()
        overlayImageView.translatesAutoresizingMaskIntoConstraints = false
        // EXPLICIT framework bundle. Without `in: AxionBundle.bundle`,
        // UIImage(named:) defaults to Bundle.main (the host app) and the
        // SDK's framework-embedded asset won't be found.
        let loadedOverlay = UIImage(named: "overlay",
                                    in: AxionBundle.bundle,
                                    compatibleWith: nil)
        overlayImageView.image = loadedOverlay
        print("🖼️ overlayImageView image loaded: \(loadedOverlay == nil ? "NIL — check asset name + framework bundle" : "OK size=\(loadedOverlay!.size)")")
        overlayImageView.contentMode = .scaleAspectFit
        overlayImageView.alpha = overlayImageAlpha
        overlayImageView.isUserInteractionEnabled = false   // never absorb taps
        previewView.addSubview(overlayImageView)
        NSLayoutConstraint.activate([
            overlayImageView.centerXAnchor.constraint(equalTo: previewView.centerXAnchor),
            overlayImageView.centerYAnchor.constraint(equalTo: previewView.centerYAnchor),
            overlayImageView.widthAnchor.constraint(equalToConstant: scanWindowSize.width),
            overlayImageView.heightAnchor.constraint(equalToConstant: scanWindowSize.height)
        ])
        
        // Constraints
        NSLayoutConstraint.activate([
            previewView.topAnchor.constraint(equalTo: view.topAnchor),
            previewView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            previewView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            previewView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            
            instructionLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
            instructionLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40),
            instructionLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -40),

            scanProgressView.topAnchor.constraint(equalTo: instructionLabel.bottomAnchor, constant: 12),
            scanProgressView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40),
            scanProgressView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -40),
            scanProgressView.heightAnchor.constraint(equalToConstant: 6),
            
            statusLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor),
            statusLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40),
            statusLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -40),
            
            zoomSlider.bottomAnchor.constraint(equalTo: bottomControls.topAnchor, constant: -20),
            zoomSlider.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40),
            zoomSlider.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -40),
            zoomLabel.bottomAnchor.constraint(equalTo: zoomSlider.topAnchor, constant: -8),
            zoomLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            
            bottomControls.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -30),
            bottomControls.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40),
            bottomControls.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -40),
            bottomControls.heightAnchor.constraint(equalToConstant: 50)
        ])

        updateDimOverlay()
        updateCornerBoxes()
    }
    
    @objc private func toggleAudio() {
        isAudioEnabled.toggle()

        let iconName = isAudioEnabled ? "speaker.wave.2.fill" : "speaker.slash.fill"
        let config = UIImage.SymbolConfiguration(pointSize: 20, weight: .semibold)

        DispatchQueue.main.async {
            self.audioButton.setImage(
                UIImage(systemName: iconName)?.withConfiguration(config),
                for: .normal
            )
        }

        audioQueue.async {
            if self.isAudioEnabled {
                self.startAudioIfNeeded()
            } else {
                self.audioPlayer?.pause()
            }
        }
    }
    private func configureAudioSessionIfNeeded() {
        guard !isAudioSessionConfigured else { return }

        // Run entirely on the audio queue — never touch main thread
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playback, mode: .default, options: [.mixWithOthers])
            try session.setActive(true)
            isAudioSessionConfigured = true
            print("✅ Audio session configured")
        } catch {
            print("❌ Audio session error: \(error)")
        }
    }
    /// Show the fake-product screen.
    ///
    /// - parameter messageOverride: Optional human-readable string to surface
    ///   to the user via `AcvissProdDetailsViewModel.productMessageText`. When
    ///   provided we splice it into `data.message` of the parsed
    ///   `fake_details.json` so the existing configureData() pipeline picks
    ///   it up as the `.Message` section (no view-model changes required).
    ///   When `nil`, the bundled JSON's default message is shown.
    ///
    ///   The /validate/ endpoint's `final_result` (e.g. "Code is too small or
    ///   too far away. Please zoom in and try again.") gets passed through
    ///   here so the user sees the actual server-side reason rather than the
    ///   generic "fake label" line.
    private func simulateFakeProductDetails(messageOverride: String? = nil) {
        guard let url = AxionBundle.bundle.url(forResource: "fake_details", withExtension: "json") else {
            print("❌ fake_details.json not found in AxionBundle.bundle")
            return
        }

        do {
            let data = try Data(contentsOf: url)
            let any = try JSONSerialization.jsonObject(with: data, options: .mutableLeaves)

            guard var jsonResult = any as? [String: Any] else {
                print("❌ fake_details.json is not a valid [String: Any] dictionary")
                return
            }

            // Splice the override into data.message so configureData() picks
            // it up as the .Message TableData row and productMessageText
            // returns it verbatim.
            if let override = messageOverride?.trimmingCharacters(in: .whitespacesAndNewlines),
               !override.isEmpty {
                var dataDict = (jsonResult["data"] as? [String: Any]) ?? [:]
                dataDict["message"] = override
                jsonResult["data"] = dataDict
                print("📝 simulateFakeProductDetails messageOverride='\(override)'")
            }

            let responseCode = jsonResult["response_code"] as? Int
            let isSuccess = (responseCode == 100)

            self.resetDetection()

            let prodView = UIHostingController(rootView: AcvissProdDetailsView(isSuccess: isSuccess, jsonResult: jsonResult))
            prodView.title = "Product Details"

            DispatchQueue.main.async {
                if let nav = self.navigationController {
                    nav.pushViewController(prodView, animated: true)
                } else {
                    let nav = UINavigationController(rootViewController: prodView)
                    nav.modalPresentationStyle = .fullScreen
                    prodView.navigationItem.leftBarButtonItem = UIBarButtonItem(
                        barButtonSystemItem: .close,
                        target: self,
                        action: #selector(self.prodDetailsCloseTapped)
                    )
                    self.present(nav, animated: true, completion: nil)
                }
            }
        } catch {
            print("❌ simulateProductDetails: error reading JSON — \(error)")
        }
    }
    private func startAudioIfNeeded() {
        // Already on audioQueue — stay here entirely
        guard isAudioEnabled else { return }

        if let player = audioPlayer {
            if !player.isPlaying { player.play() }
            return
        }

        // Configure session here on audioQueue, not main thread
        configureAudioSessionIfNeeded()

        // Extension MUST match the bundled file. The file in
        // Axion/Scanner/ is "America.mp3" — using "m4a" here silently
        // returns nil from Bundle.url(forResource:withExtension:) and
        // we end up logging "Audio file not found" on every scan.
        // (Other audio files in the same directory ARE .m4a, which is
        // probably how the wrong extension snuck in.)
        guard let url = AxionBundle.bundle.url(
            forResource: "America",
            withExtension: "mp3"
        ) else {
            print("❌ Audio file 'America.mp3' not found in AxionBundle.bundle — check that it's in the framework's Copy Bundle Resources phase")
            return
        }

        do {
            let player = try AVAudioPlayer(contentsOf: url)
            player.numberOfLoops = 1
            player.prepareToPlay()
            audioPlayer = player
            if isAudioEnabled { player.play() }
        } catch {
            print("❌ Audio init error: \(error.localizedDescription)")
        }
    }


    @available(iOS 13.0, *)
        private func monitorFocusState() {
            guard let device = videoDevice else { return }
            // Re-entrancy guard: registering the same observer twice will crash
            // when we later try to remove it.
            guard !focusObserversRegistered else { return }

            device.addObserver(self, forKeyPath: "adjustingFocus", options: [.new, .initial], context: nil)
            device.addObserver(self, forKeyPath: "lensPosition", options: [.new], context: nil)
            focusObserversRegistered = true
        }

        private func stopMonitoringFocusState() {
            guard focusObserversRegistered, let device = videoDevice else { return }
            device.removeObserver(self, forKeyPath: "adjustingFocus")
            device.removeObserver(self, forKeyPath: "lensPosition")
            focusObserversRegistered = false
        }

        override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
            if keyPath == "adjustingFocus" {
                if let adjusting = change?[.newKey] as? Bool {
                    // Update the gating flag on the main thread (KVO can fire
                    // on arbitrary threads).
                    DispatchQueue.main.async { [weak self] in
                        guard let self = self else { return }
                        let wasAdjusting = self.isAutoFocusAdjusting
                        self.isAutoFocusAdjusting = adjusting
                        self.updateFocusStatus(isFocused: !adjusting)
                        // When focus locks back in, give the scan timer a
                        // chance to arm. Sharpness sampler will confirm the
                        // frame actually settled before the countdown starts.
                        if wasAdjusting && !adjusting {
                            // Force a fresh sharpness sample on next frame.
                            self.isFrameSharp = false
                            self.lastSharpnessCheckTime = 0
                            self.reevaluateScanTimerGate()
                        } else if adjusting && !wasAdjusting {
                            // Lens is hunting — assume frame is no longer sharp
                            // and pause the countdown immediately.
                            self.isFrameSharp = false
                            self.cancelActiveScanTimer()
                            self.progressDisplayLink?.invalidate()
                            self.progressDisplayLink = nil
                            self.scanProgressView?.setProgress(0, animated: false)
                            self.instructionLabel?.text = "Focusing…"
                            self.instructionLabel?.textColor = .yellow
                        }
                    }
                }
            }
        }
        private func setupFocusStatusIndicator() {
            focusStatusView = UIView()
            focusStatusView.translatesAutoresizingMaskIntoConstraints = false
            focusStatusView.backgroundColor = .red
            focusStatusView.layer.cornerRadius = 4
            focusStatusView.alpha = 0
            view.addSubview(focusStatusView)
    
            NSLayoutConstraint.activate([
                focusStatusView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10),
                focusStatusView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -10),
                focusStatusView.widthAnchor.constraint(equalToConstant: 8),
                focusStatusView.heightAnchor.constraint(equalToConstant: 8)
            ])
        }
    
        private func updateFocusStatus(isFocused: Bool) {
            // setupFocusStatusIndicator() is opt-in; guard so we don't crash if
            // it was never invoked by the host integration.
            guard let dot = self.focusStatusView else { return }
            UIView.animate(withDuration: 0.3) {
                dot.backgroundColor = isFocused ? .green : .red
                dot.alpha = isFocused ? 1 : 0.5
            }
        }
    
    @objc private func closeTapped() {
        // prevent multiple taps
        guard !isClosing else { return }
        isClosing = true
        stopScanTimer()
        stopMotionMonitoring()
        stopMonitoringFocusState()
        unregisterAppLifecycleObservers()
        // Stop GPS too — no point keeping it on once the scanner is
        // dismissed. The locationManager itself stays referenced until
        // the VC deallocates.
        locationManager?.stopUpdatingLocation()
        closeButton.isEnabled = false
        audioQueue.async { [weak self] in
            self?.audioPlayer?.stop()
            self?.audioPlayer = nil
        }
        // Stop capture session on background queue — wait until it finishes
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self = self else { return }

            if let session = self.captureSession, session.isRunning {
                session.stopRunning() // blocking call — will return when stopped
                print("✅ capture session stopped")
            }

            // Remove any observers/timers that might keep VC alive
            DispatchQueue.main.async {
                self.processingTimer?.invalidate()
                self.processingTimer = nil

                // If you added KVO observers (e.g., on device), remove them safely:
                // try? self.videoDevice?.removeObserver(self, forKeyPath: "adjustingFocus")

                // If VC is embedded in a navigation controller, dismiss the whole nav
                if let nav = self.navigationController, nav.presentingViewController != nil {
                    nav.dismiss(animated: true) {
                        self.onClose?()
                        self.cleanupAfterDismiss()
                    }
                } else {
                    self.dismiss(animated: true) {
                        self.onClose?()
                        self.cleanupAfterDismiss()
                    }
                }
            }
        }
    }

    private func cleanupAfterDismiss() {
        // Optional: tidy up to ensure deinit happens
        self.captureSession = nil
        self.videoDevice = nil
        self.videoPreviewLayer?.removeFromSuperlayer()
        self.videoPreviewLayer = nil
        self.isClosing = false
    }
        @objc private func triggerAutoFocus() {
            guard let device = videoDevice else { return }

            do {
                try device.lockForConfiguration()

                // Trigger autofocus
                if device.isFocusModeSupported(.autoFocus) {
                    device.focusMode = .autoFocus
                }

                // Trigger auto exposure
                if device.isExposureModeSupported(.autoExpose) {
                    device.exposureMode = .autoExpose
                }

                device.unlockForConfiguration()

                // Show feedback
                showFocusFeedback()

            } catch {
                print("❌ Auto focus trigger failed: \(error)")
            }
        }

    /// Restore the lens + exposure to *continuous* AF/AE so the camera
    /// keeps refocusing as the user moves toward a new code. We have to do
    /// this explicitly on every reset path because two code sites flip the
    /// device into one-shot mode and leave it there:
    ///   • `captureSharpPhotoForValidation` sets `.autoFocus` before the
    ///     /validate/ shutter. That's a one-shot mode — AVFoundation
    ///     transitions to `.locked` after convergence and stays locked.
    ///   • The manual focusButton's `triggerAutoFocus` does the same.
    ///
    /// Without this call, after a scan completes and the user taps
    /// "Scan Again", the lens stays focused at the previous code's
    /// distance — the user has to tap the focusButton to unstick it.
    /// Mirrors the genuine-path → /predict/ flow which similarly benefits
    /// from continuous AF resuming between scans.
    private func resumeContinuousAutoFocus() {
        guard let device = videoDevice else { return }
        do {
            try device.lockForConfiguration()
            if device.isFocusModeSupported(.continuousAutoFocus) {
                device.focusMode = .continuousAutoFocus
            } else if device.isFocusModeSupported(.autoFocus) {
                // Fallback: at least kick off one AF cycle so the lens
                // doesn't sit at the previous lock point.
                device.focusMode = .autoFocus
            }
            if device.isExposureModeSupported(.continuousAutoExposure) {
                device.exposureMode = .continuousAutoExposure
            } else if device.isExposureModeSupported(.autoExpose) {
                device.exposureMode = .autoExpose
            }
            device.unlockForConfiguration()
            print("🎯 resumed continuous AF/AE")
        } catch {
            print("❌ resumeContinuousAutoFocus: lockForConfiguration failed — \(error.localizedDescription)")
        }
    }
    
        private func showFocusFeedback() {
            let generator = UIImpactFeedbackGenerator(style: .medium)
            generator.impactOccurred()
    
            UIView.animate(withDuration: 0.2, animations: {
                self.focusButton.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
            }) { _ in
                UIView.animate(withDuration: 0.2) {
                    self.focusButton.transform = CGAffineTransform.identity
                }
            }
        }
        private func optimizeForLowLight() {
            guard let device = videoDevice else { return }
    
            do {
                try device.lockForConfiguration()
    
                // Enable low light boost if available
                if device.isLowLightBoostSupported {
                    device.automaticallyEnablesLowLightBoostWhenAvailable = true
                    print("✅ Low light boost enabled")
                }
    
                // Set longer exposure if needed for low light
                if device.isExposureModeSupported(.custom) {
                    // You can adjust these values based on testing
                    let minISO = device.activeFormat.minISO
                    let maxISO = device.activeFormat.maxISO
                    device.setExposureModeCustom(duration: CMTimeMake(value: 1, timescale: 30),
                                                 iso: max(minISO * 2, min(maxISO, minISO * 4)),
                                                 completionHandler: nil)
                }
    
                device.unlockForConfiguration()
    
            } catch {
                print("❌ Low light optimization failed: \(error)")
            }
        }
        // MARK: - Update Detection Status
        private func updateDetectionStatus(isDetected: Bool) {
            DispatchQueue.main.async {
                if isDetected {
                    self.cornerBoxLayer.strokeColor = UIColor.green.cgColor
                    self.statusLabel.text = "Align QR code in the frame"
                    UIView.animate(withDuration: 0.3) {
                        self.statusLabel.alpha = 1
                    }
                } else {
                    self.cornerBoxLayer.strokeColor = UIColor.red.cgColor
                    self.statusLabel.text = "Scanning..."
                    UIView.animate(withDuration: 0.3) {
                        self.statusLabel.alpha = 0
                    }
                }
            }
        }
        // Call this when QR code is detected
        //        private func qrCodeDetected() {
        //            cornerBoxLayer.strokeColor = UIColor.green.cgColor
        //            statusLabel.text = "QR Code detected"
        //            ProgressHUD.shared.show(in: view, message: "Processing...")
        //            UIView.animate(withDuration: 0.3) {
        //                self.statusLabel.alpha = 1
        //            }
        //        }
    
        private func freezePreview() {
            DispatchQueue.main.async {
                self.videoPreviewLayer.connection?.isEnabled = false
            }
        }

    // MARK: - Corner Box Drawing
    private func createStageView(number: String, title: String, isActive: Bool) -> UIStackView {
            let container = UIStackView()
            container.axis = .vertical
            container.alignment = .center
            container.spacing = 4
            
            let numberLabel = UILabel()
            numberLabel.text = number
            numberLabel.textColor = isActive ? .white : .lightGray
            numberLabel.font = .systemFont(ofSize: 16, weight: .bold)
            
            let titleLabel = UILabel()
            titleLabel.text = title
            titleLabel.textColor = isActive ? .white : .lightGray
            titleLabel.font = .systemFont(ofSize: 14, weight: .medium)
            
            container.addArrangedSubview(numberLabel)
            container.addArrangedSubview(titleLabel)
            
            return container
        }
    // Returns the rect of the central clear scan window in previewView coordinates.
    private func scanWindowRect() -> CGRect {
        let viewBounds = previewView.bounds
        return CGRect(
            x: viewBounds.midX - scanWindowSize.width / 2,
            y: viewBounds.midY - scanWindowSize.height / 2,
            width: scanWindowSize.width,
            height: scanWindowSize.height
        )
    }

    /// Returns the fraction (0…1) of the YOLO-detected QR rect that
    /// lies inside the on-screen scan window. Used by the
    /// `isQRSufficientlyInScanWindow` gate to block the scan timer
    /// when the user has framed the code outside the brackets.
    ///
    /// Both rects are mapped into a common coordinate system —
    /// normalized portrait — by:
    ///   • Rotating the landscape YOLO rect 90° right (matches the
    ///     UIImage(cgImage:, orientation:.right) we hand to TFLite),
    ///   • Working out the scan window's position within the
    ///     scaled-and-cropped buffer that aspectFill puts on screen.
    ///
    /// Returns 0 on any inconsistency (missing buffer dims, empty
    /// preview, zero-area rects) so the caller treats it as "not in
    /// window" rather than "fully in window".
    ///
    /// MUST be called on the main thread (reads previewView.bounds).
    private func qrToScanWindowOverlap(yoloRect: CGRect,
                                       bufferLandscapeSize: CGSize) -> CGFloat {
        let bufferW = bufferLandscapeSize.width
        let bufferH = bufferLandscapeSize.height
        let previewSize = previewView?.bounds.size ?? .zero
        guard bufferW > 0, bufferH > 0,
              previewSize.width > 0, previewSize.height > 0 else {
            return 0
        }

        // 1) YOLO rect (landscape buffer pixels) → normalized portrait
        // coords (0…1). .right rotation: buffer's left edge becomes
        // portrait top, buffer's top edge becomes portrait right.
        let qrNorm = CGRect(
            x: 1.0 - (yoloRect.minY + yoloRect.height) / bufferH,
            y: yoloRect.minX / bufferW,
            width: yoloRect.height / bufferH,
            height: yoloRect.width / bufferW
        )

        // 2) Scan window → same normalized portrait coords.
        //    Buffer in portrait orientation: width = bufferH, height = bufferW.
        //    aspectFill picks the LARGER scale so both axes fill or overflow.
        let portraitBufferW = bufferH
        let portraitBufferH = bufferW
        let scale = max(previewSize.width / portraitBufferW,
                        previewSize.height / portraitBufferH)
        let scaledBufferW = portraitBufferW * scale
        let scaledBufferH = portraitBufferH * scale
        // How much of the scaled buffer is hidden on each side by the
        // preview's smaller-than-scaled-buffer dimension.
        let cropOffsetX = (scaledBufferW - previewSize.width)  / 2
        let cropOffsetY = (scaledBufferH - previewSize.height) / 2

        // Scan window position in preview coords (centred 250×250)
        let swLeftInPreview = previewSize.width  / 2 - scanWindowSize.width  / 2
        let swTopInPreview  = previewSize.height / 2 - scanWindowSize.height / 2
        // Reposition into scaled-buffer coords by undoing the crop
        let swLeftScaled = swLeftInPreview + cropOffsetX
        let swTopScaled  = swTopInPreview  + cropOffsetY
        let scanNorm = CGRect(
            x: swLeftScaled / scaledBufferW,
            y: swTopScaled  / scaledBufferH,
            width:  scanWindowSize.width  / scaledBufferW,
            height: scanWindowSize.height / scaledBufferH
        )

        // 3) Intersection / QR area
        let intersection = qrNorm.intersection(scanNorm)
        let qrArea = qrNorm.width * qrNorm.height
        guard qrArea > 0 else { return 0 }
        let interArea = intersection.isEmpty ? 0
            : intersection.width * intersection.height
        return interArea / qrArea
    }

    // Builds the translucent overlay: full-bounds rect with a rounded cutout in the centre.
    private func updateDimOverlay() {
        let viewBounds = previewView.bounds
        guard !viewBounds.isEmpty else { return }

        let outer = UIBezierPath(rect: viewBounds)
        let cutout = UIBezierPath(roundedRect: scanWindowRect(),
                                  cornerRadius: scanWindowCornerRadius)
        outer.append(cutout)
        outer.usesEvenOddFillRule = true

        dimOverlayLayer.path = outer.cgPath
    }

    // Update your updateCornerBoxes method to handle empty bounds:
    private func updateCornerBoxes() {
        let path = UIBezierPath()
        let boxSize: CGFloat = 40 // Increased from 30 to 40
        let viewBounds = previewView.bounds
        guard !viewBounds.isEmpty else { return }

        // Centered box dimensions (shared with the dim overlay cutout)
        let rect = scanWindowRect()
        let centerX = rect.minX
        let centerY = rect.minY
        let centerBoxWidth = rect.width
        let centerBoxHeight = rect.height

        // Top left (adjusted to be centered)
        path.move(to: CGPoint(x: centerX, y: centerY + boxSize))
        path.addLine(to: CGPoint(x: centerX, y: centerY))
        path.addLine(to: CGPoint(x: centerX + boxSize, y: centerY))

        // Top right
        path.move(to: CGPoint(x: centerX + centerBoxWidth - boxSize, y: centerY))
        path.addLine(to: CGPoint(x: centerX + centerBoxWidth, y: centerY))
        path.addLine(to: CGPoint(x: centerX + centerBoxWidth, y: centerY + boxSize))

        // Bottom left
        path.move(to: CGPoint(x: centerX, y: centerY + centerBoxHeight - boxSize))
        path.addLine(to: CGPoint(x: centerX, y: centerY + centerBoxHeight))
        path.addLine(to: CGPoint(x: centerX + boxSize, y: centerY + centerBoxHeight))

        // Bottom right
        path.move(to: CGPoint(x: centerX + centerBoxWidth - boxSize, y: centerY + centerBoxHeight))
        path.addLine(to: CGPoint(x: centerX + centerBoxWidth, y: centerY + centerBoxHeight))
        path.addLine(to: CGPoint(x: centerX + centerBoxWidth, y: centerY + centerBoxHeight - boxSize))

        cornerBoxLayer.path = path.cgPath
    }
    
   
    
    // MARK: - Torch Button Action
    // MARK: - Torch Button Action
    @objc private func toggleTorchButton() {
        toggleTorch()
    }

    /// User-initiated torch tap (different from the auto-toggle on launch).
    /// Resets the 5-second countdown so the periodic scan doesn't fire mid-adjustment.
    @objc private func torchButtonTapped() {
        toggleTorch()
        startScanTimer()
    }

    /// Force the torch ON and sync the torchButton tint to yellow. Used
    /// by `restartScan` and `resetDetection` because two interactions
    /// can desync the visual state from the LED state:
    ///
    ///   1. Result-screen round-trip: when the AcvissProdDetails VC is
    ///      pushed, `viewWillDisappear` stops the capture session, which
    ///      turns the torch OFF as a side effect. The session restart
    ///      doesn't re-engage the torch automatically.
    ///   2. `lockForConfiguration` in restartScan / resetDetection sets
    ///      zoom + focus mode + exposure mode in a single lock cycle; on
    ///      some devices this resets the torch even if the session keeps
    ///      running.
    ///
    /// In both cases the torchButton stayed yellow (carried over from
    /// the auto-toggle in viewDidAppear) while the LED was off — exactly
    /// the "icon shows ON but torch is off" bug. This helper makes the
    /// LED match the button.
    ///
    /// On failure (e.g. session not yet running), we sync the button to
    /// WHITE so the visual state still matches the actual LED state.
    /// Mid-interval torch-off, fired from updateScanProgress() when the
    /// progress bar passes `autoTorchOffAtFraction`. Only acts if the
    /// torch is actually ON right now (no point flipping a switch that
    /// was off already, e.g. if the user manually turned it off after
    /// the scan started). Mirrors the LED state into the button tint
    /// so the icon stays in sync.
    private func switchTorchOffMidInterval() {
        guard let device = videoDevice, device.hasTorch else { return }
        // device.torchMode is only meaningful when the session is
        // alive; we're inside the scan flow so the session is up.
        guard device.torchMode == .on else {
            print("🔦 70% torch-off skipped — torch already off")
            return
        }
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self = self else { return }
            do {
                try device.lockForConfiguration()
                device.torchMode = .off
                device.unlockForConfiguration()
                DispatchQueue.main.async {
                    self.torchButton?.tintColor = .white
                }
                print(String(format: "🔦 70%% torch-off fired — interval=%.1fs, switching to no-flash for the remaining %.0f%%",
                             self.scanInterval,
                             (1.0 - self.autoTorchOffAtFraction) * 100))
            } catch {
                print("❌ switchTorchOffMidInterval failed: \(error.localizedDescription)")
            }
        }
    }

    private func engageTorchAfterRestart() {
        guard let device = videoDevice else { return }
        guard device.hasTorch else {
            DispatchQueue.main.async {
                self.torchButton?.isHidden = true
            }
            return
        }
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self = self else { return }
            do {
                try device.lockForConfiguration()
                try device.setTorchModeOn(level: AVCaptureDevice.maxAvailableTorchLevel)
                device.unlockForConfiguration()
                DispatchQueue.main.async {
                    self.torchButton?.tintColor = .yellow
                }
                print("🔦 engageTorchAfterRestart: torch ON, button synced yellow")
            } catch {
                print("❌ engageTorchAfterRestart failed: \(error.localizedDescription)")
                // Defensive resync so the icon doesn't lie about the LED.
                DispatchQueue.main.async {
                    self.torchButton?.tintColor = .white
                }
            }
        }
    }

    @objc private func toggleTorch() {
        guard let device = videoDevice, device.hasTorch else {
            torchButton.isHidden = true
            return
        }
        
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self = self else { return }
            
            do {
                try device.lockForConfiguration()
                
                let newMode: AVCaptureDevice.TorchMode = device.torchMode == .off ? .on : .off
                var success = true
                
                if newMode == .on {
                    // Try to turn on with max brightness
                    do {
                        try device.setTorchModeOn(level: AVCaptureDevice.maxAvailableTorchLevel)
                    } catch {
                        success = false
                        print("Failed to set torch level: \(error)")
                    }
                } else {
                    device.torchMode = .off
                }
                
                device.unlockForConfiguration()
                
                // Update UI on main thread
                DispatchQueue.main.async {
                    if success {
                        self.torchButton.tintColor = newMode == .on ? .yellow : .white
                        print("🔦 Torch toggled: \(newMode == .on ? "ON" : "OFF")")
                    } else {
                        self.torchButton.tintColor = .white
                        print("⚠️ Torch operation failed")
                    }
                }
            } catch {
                print("❌ Torch error: \(error)")
                DispatchQueue.main.async {
                    self.torchButton.tintColor = .white
                }
            }
        }
    }
    // MARK: - Update Detection Status

    @objc public func restartScan() {
        print("🔄 Restarting scan...")

        // Belt-and-braces synchronous progress-bar reset. Everything
        // else in this function eventually converges on the bar being
        // at 0% (see resetScanTimer's stopScanTimer(finalProgress: 0)),
        // but those paths go through DispatchQueue.main.async blocks
        // that don't run until this function returns. In the meantime
        // there's a narrow window where a lingering CADisplayLink tick
        // (already scheduled before we invalidate it) can fire
        // updateScanProgress with a stale progressStartTime and paint
        // the bar at ~1.0. Setting it synchronously to 0 here means
        // the user sees an immediate visual reset the moment they tap
        // Scan Again — even if all the async ordering downstream is
        // slightly off.
        self.progressDisplayLink?.invalidate()
        self.progressDisplayLink = nil
        self.scanProgressView?.setProgress(0, animated: false)

        self.zoomLabel.text = "3.5x"
        // 1. Reset all detection states
        self.isQRCodeDetected = false
        self.detectedBarcode = nil
        self.lastBarcode = nil
        self.performRequestCount = 0
        self.currentZoom = 3.5 // Reset zoom to 3.5x (raised from 2.5x for wide-only camera + higher MFD headroom)
        // Show the overlay guide again — fresh scan, fresh visual aid.
        self.overlayImageView?.isHidden = false
        // Clear focus/sharpness/auto-zoom state — every scan starts fresh and
        // the user is no longer locked out of auto-zoom even if they touched
        // the slider previously.
        //
        // NOTE: read the real device focus state rather than assuming the lens
        // is still adjusting. KVO on `adjustingFocus` only fires when the lens
        // MOVES — if it's already settled, an artificial `true` here would
        // never get flipped back and the scan timer gate would stay blocked
        // forever (= "progress bar doesn't start after first scan").
        self.userZoomOverride = false
        self.lastAutoZoomTime = 0
        self.isFrameSharp = false
        self.consecutiveSharpProbes = 0
        self.userIsTooCloseToFocus = false
        self.isAutoFocusAdjusting = self.videoDevice?.isAdjustingFocus ?? false
        self.lastSharpnessCheckTime = 0
        // Far-detection state — see maybeRunFarDetection(). A fresh
        // scan starts at zero counters and "currently far" cleared.
        self.isUserCurrentlyFar = false
        self.consecutiveFarFrames = 0
        self.consecutiveCloseFrames = 0
        self.lastFarCheckTime = 0
        self.isFarDetectionInflight = false
        // Tilt-check guard can get stuck `true` if a `captureFrameForValidation`
        // completion was overwritten before it fired. Force-release it so the
        // next 1.5 s tick can run and auto-zoom resumes.
        self.isTiltChecking = false
        // Always start a fresh scan at the default 6s window. The
        // /validate/ extended-retry path will set these back up afterwards
        // (see restartScanWithExtendedInterval()).
        self.scanInterval = self.scanIntervalDefault
        self.isInExtendedScanMode = false
        // Discard any unconsumed validation-path capture closure — a fresh
        // scan should never inherit a stale callback from the previous one.
        self.pendingFakePhotoCompletion = nil
        self.pendingValidatePhotoCompletion = nil
        // Pre-capture validation state — see attemptPreCaptureValidation.
        // Clear both counters so the next scan's loop starts from zero
        // and can't inherit a "committed" flag from a previous scan
        // (which would silently drop the shutter + green-box handoff).
        self.preCaptureValidationAttempts = 0
        self.isCommittedToCapture = false
        NSObject.cancelPreviousPerformRequests(withTarget: self)
        
        // 2. Reset UI
        self.updateDetectionStatus(isDetected: false)
        self.instructionLabel.text = "Point camera at a QR code"
        self.zoomSlider.value = Float(self.currentZoom) // Reset slider position
        
        // Update zoom label if you added it
        // self.zoomLabel.text = "2.5x"
        
//        ProgressHUD.shared.hide()
        
        // 3. Re-enable preview first
        self.videoPreviewLayer.connection?.isEnabled = true
        
        // 4. Reset camera configuration with proper zoom
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self = self else { return }
            
            // 4a. Configure device with 2.5x zoom
            if let device = self.videoDevice {
                do {
                    try device.lockForConfiguration()

                    // Reset zoom to 2.5x
                    device.videoZoomFactor = 3.5
                    print("✅ Zoom reset to 3.5x")

                    // Return the lens + exposure to CONTINUOUS AF/AE in the
                    // same lock-cycle so the camera autofocuses on the
                    // next code without the user tapping the focusButton.
                    // Without this, the previous scan left the device in
                    // `.locked` (a side-effect of the one-shot `.autoFocus`
                    // used during validation capture) and stays there.
                    if device.isFocusModeSupported(.continuousAutoFocus) {
                        device.focusMode = .continuousAutoFocus
                    } else if device.isFocusModeSupported(.autoFocus) {
                        device.focusMode = .autoFocus
                    }
                    if device.isExposureModeSupported(.continuousAutoExposure) {
                        device.exposureMode = .continuousAutoExposure
                    } else if device.isExposureModeSupported(.autoExpose) {
                        device.exposureMode = .autoExpose
                    }
                    print("🎯 restartScan: focus/exposure → continuous")

                    device.unlockForConfiguration()
                } catch {
                    print("❌ Could not reset zoom: \(error)")
                }
            }

            // 4b. Restart session properly. After session is alive (either
            // because we just restarted it or because it was already
            // running), re-engage the torch and resync the button — see
            // engageTorchAfterRestart() for the bug this addresses.
            if let session = self.captureSession {
                if !session.isRunning {
                    // Add slight delay to ensure clean restart
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        session.startRunning()
                        print("✅ Capture session restarted with 3.5x zoom")
                        self.engageTorchAfterRestart()
                    }
                } else {
                    print("ℹ️ Session already running")
                    self.engageTorchAfterRestart()
                }
            }
        }
        self.resetScanTimer()
        audioQueue.async { [weak self] in
            guard let self = self else { return }
            if self.isAudioEnabled {
                self.audioPlayer?.currentTime = 0
                self.audioPlayer?.play()
            }
        }
    }
    
    // MARK: - Live sharpness probe (gates the scan timer)
    /// Cheap Laplacian-variance estimate on the central crop of the live
    /// preview frame. Called from `captureOutput` and throttled to
    /// `sharpnessCheckInterval` so we don't murder the CPU. When the variance
    /// crosses `liveSharpnessThreshold`, the scan timer gate flips and the
    /// 6-second countdown is allowed to arm — until then the timer is held at
    /// 0% and the user is told to hold steady.
    // MARK: - Far-detection (runs from captureOutput, no Timer)

    /// Throttled TFLite pass off the live preview pixel buffer to
    /// decide whether the user is "far" (QR-class rect occupies too
    /// little of the frame). Called from `captureOutput` on every
    /// video tick but capped to `farDetectionInterval` seconds between
    /// actual TFLite runs.
    ///
    /// IMPORTANT: this path is independent of `performLiveTiltCheck`.
    /// It does NOT call `maybeApplyAutoZoom`, it does NOT touch focus
    /// state, and it never writes the label unless a hysteresis-
    /// debounced transition triggers it. Auto-zoom and auto-focus
    /// logic stay exactly as they are.
    private func maybeRunFarDetection(_ pixelBuffer: CVPixelBuffer) {
        // Skip conditions mirror sampleFrameSharpness so we don't burn
        // CPU when nothing useful can come of it.
        if isAppInBackground || isQRCodeDetected { return }
        if isFarDetectionInflight { return }
        let now = CACurrentMediaTime()
        if now - lastFarCheckTime < farDetectionInterval { return }
        lastFarCheckTime = now
        isFarDetectionInflight = true

        // Build a UIImage from the pixel buffer right here on the video
        // queue. Cheap (~5–10 ms); we explicitly use orientation .right
        // so YOLO sees the same pixel layout the tilt-path TFLite does
        // — no surprises in the detection rect coordinates.
        let ciImage = CIImage(cvPixelBuffer: pixelBuffer)
        let ctx = CIContext(options: nil)
        guard let cgImage = ctx.createCGImage(ciImage, from: ciImage.extent) else {
            isFarDetectionInflight = false
            return
        }
        let image = UIImage(cgImage: cgImage, scale: 1.0, orientation: .right)

        // Heavy TFLite work off both the video queue AND main — never
        // blocks frame delivery, never causes a UI hitch.
        Task.detached(priority: .utility) { [weak self] in
            guard let self = self else { return }
            defer {
                Task { @MainActor in self.isFarDetectionInflight = false }
            }
            do {
                let detections = try TFLiteInference.run(
                    on: image,
                    modelName: "model",
                    bundle: AxionBundle.bundle
                )
                let frameLong = CGFloat(max(
                    image.cgImage?.width ?? 0,
                    image.cgImage?.height ?? 0
                ))
                // QR-class rect = cleanest "how big does the code
                // appear" signal. Patterns can be polluted by false
                // positives at long range; the QR class is one rect
                // per frame.
                let qrRect = detections
                    .filter { $0.classId == YOLOClass.qr.rawValue }
                    .sorted { $0.confidence > $1.confidence }
                    .first?.rect
                let qrFraction: CGFloat = {
                    guard let r = qrRect, frameLong > 0 else { return 0 }
                    return max(r.width, r.height) / frameLong
                }()
                let isFarNow = qrFraction < self.farDetectionFractionThreshold

                await MainActor.run {
                    self.updateFarStateWithHysteresis(isFarNow: isFarNow,
                                                      measuredFraction: qrFraction)
                }
            } catch {
                // Swallow — defer clears inflight, next throttle window retries.
            }
        }
    }

    /// Asymmetric hysteresis on the far/close transition so the label
    /// doesn't flicker. Requires N consecutive "far" ticks to set the
    /// flag, N consecutive "close" ticks to clear it. Only writes the
    /// label on a RISING-edge "becoming far" event — on the falling
    /// edge we leave the label alone so `performLiveTiltCheck`'s next
    /// tick can restore the appropriate message (hold steady /
    /// scanning / default hint) without us fighting it.
    private func updateFarStateWithHysteresis(isFarNow: Bool,
                                              measuredFraction: CGFloat) {
        print(String(format: "🪧 far-detection qrFraction=%.4f far=%@ (consecFar=%d, consecClose=%d, currentlyFar=%@)",
                     measuredFraction,
                     isFarNow ? "Y" : "N",
                     consecutiveFarFrames, consecutiveCloseFrames,
                     isUserCurrentlyFar ? "Y" : "N"))

        if isFarNow {
            consecutiveFarFrames += 1
            consecutiveCloseFrames = 0
            if consecutiveFarFrames >= farDetectionConsecutiveTrigger,
               !isUserCurrentlyFar {
                isUserCurrentlyFar = true
                instructionLabel.text = "Come closer and fit within the overlay"
                instructionLabel.textColor = .yellow
                // Rising edge: stop the periodic capture timer while
                // we're showing the far hint. `cancelActiveScanTimer()`
                // tears down the underlying Timer and tilt-check
                // partner WITHOUT clearing `pendingScanTimerStart`, so
                // the moment far state clears we can re-arm cleanly
                // (see falling-edge branch below). Progress bar snaps
                // to 0 so the user doesn't see a stale fill.
//                cancelActiveScanTimer()
//                progressDisplayLink?.invalidate()
//                progressDisplayLink = nil
//                scanProgressView?.setProgress(0, animated: false)
                print("⏸ scan timer cancelled — user is too far")
            }
        } else {
            consecutiveCloseFrames += 1
            consecutiveFarFrames = 0
            if consecutiveCloseFrames >= farDetectionConsecutiveClear,
               isUserCurrentlyFar {
                isUserCurrentlyFar = false
                // Intentionally leave the label alone — the next
                // performLiveTiltCheck tick will write the appropriate
                // message naturally.
                //
                // Falling edge: the user moved closer. Re-arm the scan
                // timer immediately (subject to the other gates —
                // motion, focus, sharpness). reevaluateScanTimerGate()
                // is a no-op if anything else is still blocking; if
                // everything else is good, the timer arms within the
                // same runloop tick.
                print("▶️ user back in range — re-evaluating scan-timer gate")
                reevaluateScanTimerGate()
            }
        }
    }

    private func sampleFrameSharpness(_ pixelBuffer: CVPixelBuffer) {
        // Skip sharpness work entirely while backgrounded — the camera
        // session is paused, frames are stale, and we don't want to flip
        // `isFrameSharp = true` just before we read the gate.
        if isAppInBackground { return }
        let now = CACurrentMediaTime()
        if now - lastSharpnessCheckTime < sharpnessCheckInterval { return }
        lastSharpnessCheckTime = now

        // Switched from Laplacian variance to Tenengrad because on uniformly
        // soft frames (close-to-focus, user inside minimum focus distance)
        // Laplacian was being fooled by sensor noise. Tenengrad responds
        // to real edge content and discriminates that case correctly.
        let tenengrad = computeCentralTenengradScore(pixelBuffer)
        let probeSharp = tenengrad >= liveTenengradThreshold

        // Read lensPosition off the video device — 0.0 means the lens has
        // parked at its NEAR-focus limit. If the user is physically
        // closer than the minimum focus distance, the lens parks here and
        // can't recover no matter how long it tries; the right thing is
        // to tell them to move back.
        let lensPosition: Float = self.videoDevice?.lensPosition ?? -1

        // Hop to main: state read by timer-arm gate + UI hint, plus the
        // hysteresis counter is read/written here too.
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }

            // Per-probe log so you can see real Tenengrad scores from the
            // device and tune `liveTenengradThreshold` from data — not
            // just the single line on a flip. Keep `🔬` so it's easy to
            // grep, and include lensPosition for the "too close"
            // diagnosis path below.
            print(String(format: "🔬 sharpness probe tenengrad=%.2f (threshold=%.0f) lensPos=%.3f → probeSharp=%@, consecutiveSharp=%d, currentlyArmed=%@",
                         tenengrad,
                         self.liveTenengradThreshold,
                         Double(lensPosition),
                         probeSharp ? "Y" : "N",
                         self.consecutiveSharpProbes,
                         self.isFrameSharp ? "Y" : "N"))

            // Hysteresis:
            //   • Sharp probe → bump consecutive count, only flip
            //     `isFrameSharp = true` once we've seen N in a row.
            //   • Blurry probe → reset count to 0 AND flip
            //     `isFrameSharp = false` immediately (asymmetric debounce
            //     so a single blurry frame stops the progress bar).
            let wasSharp = self.isFrameSharp
            if probeSharp {
                self.consecutiveSharpProbes += 1
                if self.consecutiveSharpProbes >= self.sharpnessHysteresisRequired {
                    self.isFrameSharp = true
                }
            } else {
                self.consecutiveSharpProbes = 0
                self.isFrameSharp = false
            }

            // "Too close" detection: blurry AND lensPosition parked at
            // near-focus limit. This is the case where the user is inside
            // the camera's minimum focus distance and the lens has given
            // up — no further focusing will help, the user must back off.
            // Sharp probes always clear the flag.
            if probeSharp {
                self.userIsTooCloseToFocus = false
            } else if lensPosition >= 0,
                      lensPosition < self.lensPositionTooCloseThreshold {
                if !self.userIsTooCloseToFocus {
                    print("📏 user appears too close (lensPos=\(String(format: "%.3f", Double(lensPosition))) at near limit, tenengrad=\(String(format: "%.2f", tenengrad)))")
                }
                self.userIsTooCloseToFocus = true
            } else {
                // Blurry but lens still hunting somewhere mid-range — not
                // necessarily "too close". Clear the flag.
                self.userIsTooCloseToFocus = false
            }

            if self.isFrameSharp != wasSharp {
                print("📷 sharpness flipped → \(self.isFrameSharp ? "SHARP" : "blurry") (tenengrad=\(String(format: "%.2f", tenengrad)), lensPos=\(String(format: "%.3f", Double(lensPosition))))")
                if self.isFrameSharp {
                    // Try to arm the countdown now.
                    self.reevaluateScanTimerGate()
                } else if self.scanTimer != nil {
                    // Was armed, just went blurry — pause the countdown but
                    // leave pendingScanTimerStart=true so it auto-resumes.
                    self.cancelActiveScanTimer()
                    self.progressDisplayLink?.invalidate()
                    self.progressDisplayLink = nil
                    self.scanProgressView?.setProgress(0, animated: false)
                }
            } else if !self.isFrameSharp && self.scanTimer != nil {
                // Belt-and-braces: even if state didn't FLIP this probe (we
                // were already blurry), make sure the progress bar isn't
                // somehow still advancing. Cheap idempotent reset.
                self.cancelActiveScanTimer()
                self.progressDisplayLink?.invalidate()
                self.progressDisplayLink = nil
                self.scanProgressView?.setProgress(0, animated: false)
            }
        }
    }

    /// Run a Laplacian-3x3 over a centre crop of the live pixel buffer and
    /// return the variance of its grayscale output. Mirrors `isImageBlurry`
    /// but works directly on a CVPixelBuffer and only inspects the centre to
    /// stay cheap enough for ~3 Hz sampling.
    /// Live-preview Tenengrad sharpness score (0-100 scale, matches the
    /// server-side Python and the post-capture `sharpnessScore` used for
    /// `/validate/` decisions).
    ///
    /// Why this exists alongside the Laplacian version: on uniformly soft
    /// frames (the close-to-focus case where the user is inside the
    /// camera's minimum focus distance) Laplacian variance is dominated by
    /// sensor noise and gives misleadingly high values. Tenengrad
    /// (Sobel-based gradient magnitude) responds to actual edge content
    /// and discriminates "blurry with noise" from "sharp" much more
    /// cleanly. We use a smaller working size (256 px) than the
    /// post-capture path's 800 px to keep ~3 Hz sampling cheap.
    private func computeCentralTenengradScore(_ pixelBuffer: CVPixelBuffer) -> Double {
        let full = CIImage(cvPixelBuffer: pixelBuffer)
        let extent = full.extent
        guard extent.width > 0, extent.height > 0 else { return 0 }

        // Centre crop covering ~50% of the shorter dim — same region as
        // the Laplacian probe.
        let side = min(extent.width, extent.height) * 0.5
        let cropRect = CGRect(
            x: extent.midX - side / 2,
            y: extent.midY - side / 2,
            width: side, height: side
        )
        var ciImage = full.cropped(to: cropRect)
        ciImage = ciImage.transformed(by: CGAffineTransform(translationX: -cropRect.minX, y: -cropRect.minY))

        // Downscale to 256 wide for cheap inner loop. Tenengrad is
        // scale-stable in the 200-800 range — the score doesn't shift
        // meaningfully across that range on the same scene.
        let targetWidth: CGFloat = 256.0
        let scale = min(1.0, targetWidth / ciImage.extent.width)
        if scale < 1.0 {
            ciImage = ciImage.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
        }

        // Luminance (BT.601 weights — matches OpenCV's cvtColor default).
        guard let colorMatrix = CIFilter(name: "CIColorMatrix") else { return 0 }
        colorMatrix.setValue(ciImage, forKey: kCIInputImageKey)
        colorMatrix.setValue(CIVector(x: 0.299, y: 0.299, z: 0.299, w: 0), forKey: "inputRVector")
        colorMatrix.setValue(CIVector(x: 0.587, y: 0.587, z: 0.587, w: 0), forKey: "inputGVector")
        colorMatrix.setValue(CIVector(x: 0.114, y: 0.114, z: 0.114, w: 0), forKey: "inputBVector")
        colorMatrix.setValue(CIVector(x: 0, y: 0, z: 0, w: 0), forKey: "inputBiasVector")
        guard let gray = colorMatrix.outputImage else { return 0 }

        // Render to a tight RGBA8 buffer (same pattern as the Laplacian
        // helper — R==G==B because the image is already grayscale).
        let ctx = CIContext(options: nil)
        let outExtent = gray.extent.integral
        guard let outCG = ctx.createCGImage(gray, from: outExtent) else { return 0 }
        let w = outCG.width
        let h = outCG.height
        guard w >= 3, h >= 3 else { return 0 }

        let bytesPerRow = w * 4
        let bufferSize = bytesPerRow * h
        guard let data = malloc(bufferSize) else { return 0 }
        defer { free(data) }

        let colorSpace = CGColorSpaceCreateDeviceRGB()
        guard let cctx = CGContext(data: data,
                                   width: w, height: h,
                                   bitsPerComponent: 8, bytesPerRow: bytesPerRow,
                                   space: colorSpace,
                                   bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else {
            return 0
        }
        cctx.draw(outCG, in: CGRect(x: 0, y: 0, width: w, height: h))

        // Open-coded Sobel — same arithmetic as `sharpnessScore`,
        // operating on the R channel. Stride by 4 because we rendered to
        // RGBA, not single-channel grayscale.
        let ptr = data.bindMemory(to: UInt8.self, capacity: bufferSize)
        var sumSq: Double = 0
        var count = 0
        for y in 1..<(h - 1) {
            let rowAbove = (y - 1) * w
            let rowSame  =  y      * w
            let rowBelow = (y + 1) * w
            for x in 1..<(w - 1) {
                let p00 = Int(ptr[(rowAbove + (x - 1)) * 4])
                let p01 = Int(ptr[(rowAbove + x      ) * 4])
                let p02 = Int(ptr[(rowAbove + (x + 1)) * 4])
                let p10 = Int(ptr[(rowSame  + (x - 1)) * 4])
                let p12 = Int(ptr[(rowSame  + (x + 1)) * 4])
                let p20 = Int(ptr[(rowBelow + (x - 1)) * 4])
                let p21 = Int(ptr[(rowBelow + x      ) * 4])
                let p22 = Int(ptr[(rowBelow + (x + 1)) * 4])

                let gx = -p00 + p02 - (p10 << 1) + (p12 << 1) - p20 + p22
                let gy = -p00 - (p01 << 1) - p02 + p20 + (p21 << 1) + p22

                sumSq += Double(gx * gx + gy * gy)
                count += 1
            }
        }
        guard count > 0 else { return 0 }
        let meanSq = sumSq / Double(count)

        // Same normalisation as the post-capture `sharpnessScore` and the
        // Python — clip(meanSq / 2000 × 100, 0, 100).
        return min(100.0, max(0.0, meanSq / 2000.0 * 100.0))
    }

    private func computeCentralLaplacianVariance(_ pixelBuffer: CVPixelBuffer) -> Double {
        let full = CIImage(cvPixelBuffer: pixelBuffer)
        let extent = full.extent
        guard extent.width > 0, extent.height > 0 else { return 0 }

        // Centre crop covering ~50% of the shorter dim — this is the area the
        // user is aiming the scan window at, regardless of buffer orientation.
        let side = min(extent.width, extent.height) * 0.5
        let cropRect = CGRect(
            x: extent.midX - side / 2,
            y: extent.midY - side / 2,
            width: side, height: side
        )
        var ciImage = full.cropped(to: cropRect)
        // Re-anchor at origin so filters render predictably.
        ciImage = ciImage.transformed(by: CGAffineTransform(translationX: -cropRect.minX, y: -cropRect.minY))

        // Downscale to ~256 wide — variance is scale-stable enough and this
        // keeps the read-back tiny.
        let targetWidth: CGFloat = 256.0
        let scale = min(1.0, targetWidth / ciImage.extent.width)
        if scale < 1.0 {
            ciImage = ciImage.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
        }

        // → luminance
        guard let colorMatrix = CIFilter(name: "CIColorMatrix") else { return 0 }
        colorMatrix.setValue(ciImage, forKey: kCIInputImageKey)
        colorMatrix.setValue(CIVector(x: 0.299, y: 0.299, z: 0.299, w: 0), forKey: "inputRVector")
        colorMatrix.setValue(CIVector(x: 0.587, y: 0.587, z: 0.587, w: 0), forKey: "inputGVector")
        colorMatrix.setValue(CIVector(x: 0.114, y: 0.114, z: 0.114, w: 0), forKey: "inputBVector")
        colorMatrix.setValue(CIVector(x: 0, y: 0, z: 0, w: 0), forKey: "inputBiasVector")
        guard let gray = colorMatrix.outputImage else { return 0 }

        // → Laplacian
        let kernel: [CGFloat] = [
            -1, -1, -1,
            -1,  8, -1,
            -1, -1, -1
        ]
        guard let conv = CIFilter(name: "CIConvolution3X3") else { return 0 }
        conv.setValue(gray, forKey: kCIInputImageKey)
        conv.setValue(CIVector(values: kernel, count: 9), forKey: "inputWeights")
        conv.setValue(0.0, forKey: "inputBias")
        guard let lap = conv.outputImage else { return 0 }

        let ctx = CIContext(options: nil)
        let outExtent = lap.extent.integral
        guard let outCG = ctx.createCGImage(lap, from: outExtent) else { return 0 }

        let w = outCG.width
        let h = outCG.height
        let bytesPerRow = w * 4
        let bufferSize = bytesPerRow * h
        guard let data = malloc(bufferSize) else { return 0 }
        defer { free(data) }

        let colorSpace = CGColorSpaceCreateDeviceRGB()
        guard let cctx = CGContext(data: data,
                                   width: w, height: h,
                                   bitsPerComponent: 8, bytesPerRow: bytesPerRow,
                                   space: colorSpace,
                                   bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else {
            return 0
        }
        cctx.draw(outCG, in: CGRect(x: 0, y: 0, width: w, height: h))

        let ptr = data.bindMemory(to: UInt8.self, capacity: bufferSize)
        var sum: Double = 0
        var sumSq: Double = 0
        let count = w * h
        for i in 0..<count {
            let v = Double(ptr[i * 4])
            sum += v
            sumSq += v * v
        }
        guard count > 0 else { return 0 }
        let mean = sum / Double(count)
        return (sumSq / Double(count)) - mean * mean
    }

    func isImageBlurry(_ image: UIImage, threshold: Float = 1000.0) -> Bool {
        guard let cgImage = image.cgImage else { return false }

        // 1) Create CIImage
        var ciImage = CIImage(cgImage: cgImage)

        // 2) Downscale to fixed width (helps make threshold stable)
        let targetWidth: CGFloat = 600.0
        let scale = min(1.0, targetWidth / ciImage.extent.width)
        if scale < 1.0 {
            ciImage = ciImage.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
        }

        // 3) Convert to luminance (grayscale) using CIColorMatrix
        let colorMatrixFilter = CIFilter(name: "CIColorMatrix")!
        // Luminance weights: 0.299, 0.587, 0.114
        colorMatrixFilter.setValue(ciImage, forKey: kCIInputImageKey)
        colorMatrixFilter.setValue(CIVector(x: 0.299, y: 0.299, z: 0.299, w: 0), forKey: "inputRVector")
        colorMatrixFilter.setValue(CIVector(x: 0.587, y: 0.587, z: 0.587, w: 0), forKey: "inputGVector")
        colorMatrixFilter.setValue(CIVector(x: 0.114, y: 0.114, z: 0.114, w: 0), forKey: "inputBVector")
        colorMatrixFilter.setValue(CIVector(x: 0, y: 0, z: 0, w: 0), forKey: "inputBiasVector")
        guard let gray = colorMatrixFilter.outputImage else { return false }

        // 4) Apply Laplacian using CIConvolution3X3
        let kernel: [CGFloat] = [
            -1, -1, -1,
            -1,  8, -1,
            -1, -1, -1
        ]
        let convFilter = CIFilter(name: "CIConvolution3X3")!
        convFilter.setValue(gray, forKey: kCIInputImageKey)
        convFilter.setValue(CIVector(values: kernel, count: 9), forKey: "inputWeights")
        convFilter.setValue(0.0, forKey: "inputBias")
        guard let laplacianImage = convFilter.outputImage else { return false }

        // 5) Render the laplacian result to RGBA8 (we'll read the R channel — it's grayscale)
        let context = CIContext(options: nil)
        let extent = laplacianImage.extent.integral
        guard let outCG = context.createCGImage(laplacianImage, from: extent) else { return false }

        // 6) Read pixel bytes
        let width = outCG.width
        let height = outCG.height
        let bytesPerRow = width * 4
        let bufferSize = bytesPerRow * height
        guard let data = malloc(bufferSize) else { return false }
        defer { free(data) }

        let colorSpace = CGColorSpaceCreateDeviceRGB()
        guard let ctx = CGContext(data: data,
                                  width: width,
                                  height: height,
                                  bitsPerComponent: 8,
                                  bytesPerRow: bytesPerRow,
                                  space: colorSpace,
                                  bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else {
            return false
        }
        ctx.draw(outCG, in: CGRect(x: 0, y: 0, width: width, height: height))

        // 7) Compute mean and variance on the R channel (grayscale)
        let ptr = data.bindMemory(to: UInt8.self, capacity: bufferSize)
        var sum: Double = 0
        var sumSq: Double = 0
        let pixelCount = width * height

        for i in 0..<pixelCount {
            let r = Double(ptr[i * 4]) // R channel; image is grayscale so R==G==B
            sum += r
            sumSq += r * r
        }

        let n = Double(pixelCount)
        guard n > 0 else { return false }

        let mean = sum / n
        let variance = (sumSq / n) - (mean * mean) // E[x^2] - (E[x])^2

        print("isImageBlurry: laplacian variance = \(variance)  (mean = \(mean))")

        // 8) Decide blur: low variance => blurry
        return variance < Double(threshold)
    }

    // MARK: - Tenengrad sharpness score (mirrors server-side Python)
    /// Native iOS port of the host team's Python `sharpness_score` —
    /// returns a Tenengrad sharpness score in 0-100 where higher = sharper.
    ///
    /// Algorithm (matches `cv2.Sobel(..., CV_64F, ksize=3)` exactly):
    ///   1. Render the image to an 8-bit grayscale buffer (no premult, no
    ///      RGBA — that's what cv2.IMREAD_GRAYSCALE delivers).
    ///   2. Compute Sobel X and Sobel Y per pixel with full Int precision
    ///      (the Python uses Float64; our Int range is wider than the
    ///      ±1020 max Sobel response on [0,255] input so we don't lose
    ///      data, and Int arithmetic is significantly faster than CIFilter
    ///      round-tripping through 8-bit RGBA which would clamp the
    ///      negative half of the gradient).
    ///   3. score = mean(sobelx² + sobely²) over the inner (W-2)×(H-2)
    ///      region (cv2 produces zeros at the borders; we just skip them).
    ///   4. Normalise: clip(score / 2000 × 100, 0, 100).
    ///
    /// Returns 0 on any failure path.
    private func sharpnessScore(_ image: UIImage) -> Double {
        guard let cgImage = image.cgImage else { return 0 }

        // 1) Downscale to ~800 px wide for speed. Tenengrad is scale-stable
        //    enough that a 2-3× downsample barely shifts the score, but
        //    cuts inner-loop pixel count by ~10× on a high-res photo.
        //    Skip if already small.
        let originalW = cgImage.width
        let originalH = cgImage.height
        guard originalW > 0, originalH > 0 else { return 0 }
        let targetMaxDim = 800
        let scale: Double
        if max(originalW, originalH) > targetMaxDim {
            scale = Double(targetMaxDim) / Double(max(originalW, originalH))
        } else {
            scale = 1.0
        }
        let scaledW = max(3, Int(Double(originalW) * scale))
        let scaledH = max(3, Int(Double(originalH) * scale))

        // 2) Render to a tight 8-bit grayscale buffer. CGColorSpace.gray
        //    + alpha:.none gives one byte per pixel — matches cv2's
        //    grayscale layout exactly so no per-pixel channel arithmetic
        //    is needed in the hot loop.
        let bytesPerRow = scaledW
        let bufferSize = bytesPerRow * scaledH
        guard let data = malloc(bufferSize) else { return 0 }
        defer { free(data) }

        let colorSpace = CGColorSpaceCreateDeviceGray()
        let bitmapInfo = CGImageAlphaInfo.none.rawValue
        guard let ctx = CGContext(data: data,
                                  width: scaledW,
                                  height: scaledH,
                                  bitsPerComponent: 8,
                                  bytesPerRow: bytesPerRow,
                                  space: colorSpace,
                                  bitmapInfo: bitmapInfo) else {
            return 0
        }
        ctx.draw(cgImage, in: CGRect(x: 0, y: 0, width: scaledW, height: scaledH))

        let ptr = data.bindMemory(to: UInt8.self, capacity: bufferSize)

        // 3) Sobel kernels, applied in the inner loop directly. Reading
        //    9 neighbours per pixel; the multiply-add pattern below is
        //    the same arithmetic OpenCV does, just open-coded.
        //
        //   Sobel X:                Sobel Y:
        //     -1  0  1                -1 -2 -1
        //     -2  0  2                 0  0  0
        //     -1  0  1                 1  2  1
        //
        // Skip the 1-pixel border to match cv2's default BORDER_REFLECT_101
        // contribution on the inner region. (cv2 zeros the border in
        // practice for the boundary pixels we skip; the difference at
        // image scale ≥ ~200 px is negligible.)
        var sumSq: Double = 0
        var count = 0
        for y in 1..<(scaledH - 1) {
            let rowAbove  = (y - 1) * scaledW
            let rowSame   =  y      * scaledW
            let rowBelow  = (y + 1) * scaledW
            for x in 1..<(scaledW - 1) {
                let p00 = Int(ptr[rowAbove + (x - 1)])
                let p01 = Int(ptr[rowAbove + x])
                let p02 = Int(ptr[rowAbove + (x + 1)])
                let p10 = Int(ptr[rowSame  + (x - 1)])
                // p11 = centre — not used by either kernel.
                let p12 = Int(ptr[rowSame  + (x + 1)])
                let p20 = Int(ptr[rowBelow + (x - 1)])
                let p21 = Int(ptr[rowBelow + x])
                let p22 = Int(ptr[rowBelow + (x + 1)])

                // Sobel X = -p00 + p02 - 2·p10 + 2·p12 - p20 + p22
                let gx = -p00 + p02 - (p10 << 1) + (p12 << 1) - p20 + p22
                // Sobel Y = -p00 - 2·p01 - p02 + p20 + 2·p21 + p22
                let gy = -p00 - (p01 << 1) - p02 + p20 + (p21 << 1) + p22

                sumSq += Double(gx * gx + gy * gy)
                count += 1
            }
        }
        guard count > 0 else { return 0 }
        let meanSq = sumSq / Double(count)

        // 4) Same normalisation as the Python: meanSq / 2000 * 100,
        //    clipped to [0, 100].
        let normalised = min(100.0, max(0.0, meanSq / 2000.0 * 100.0))
        print(String(format: "📐 sharpnessScore: meanSq=%.1f → score=%.2f (image: %dx%d → %dx%d)",
                     meanSq, normalised, originalW, originalH, scaledW, scaledH))
        return normalised
    }

    // MARK: - Camera Setup
    private func setupCamera() {
        captureSession = AVCaptureSession()
        captureSession.sessionPreset = .photo // Use photo preset for high-resolution images
        // Observe session lifecycle notifications so we can recover from
        // mid-run interruptions instead of silently sitting on a paused
        // session forever. Apple's docs strongly recommend this; without
        // it, audio-resource contention (e.g. our own AVAudioSession
        // activation racing the camera startup on SE-class hardware) can
        // pause the capture session with no path back, producing a
        // permanent black preview. See registerCaptureSessionObservers()
        // for the full diagnosis & recovery logic.
        registerCaptureSessionObservers()

        // 1. Pick the best available rear camera.
        //
        // Fallback chain — on each phone we take the first one that exists:
        //   • .builtInTripleCamera   — iPhone 11/12/13/14/15 Pro & Pro Max
        //   • .builtInWideAngleCamera — everything else
        //
        // Why .builtInDualWideCamera is DELIBERATELY NOT in the chain:
        // We now pick .builtInWideAngleCamera UNCONDITIONALLY on
        // every device — including Pro models that also have a
        // .builtInTripleCamera available.
        //
        // Why we no longer prefer triple camera on Pro devices:
        // .builtInTripleCamera is a virtual device that abstracts the
        // three constituent lenses (ultra-wide, main wide, telephoto)
        // as a unified output. iOS caps that unified output at 12MP
        // regardless of which constituent is active — the physical
        // 48MP main wide sensor on 14/15/16 Pro Max cannot deliver
        // 48MP through the virtual device. .builtInWideAngleCamera,
        // as a standalone physical device, DOES expose the 48MP
        // formats. So this switch unlocks ~4× more pixels per crop
        // for /predict/ and /validate/ uploads on Pro devices, which
        // is what the backend team asked for.
        //
        // Trade-off: loses auto-macro on Pro. .builtInTripleCamera
        // silently switches to ultra-wide when the subject is <10cm
        // to enable macro focus. With wide-only, the main wide's
        // ~10cm minimum focus distance is a hard limit — hold the
        // phone closer than that and the frame goes blurry. Paired
        // with `defaultZoom = 3.5` (raised from 2.5), users naturally
        // work at a greater physical distance where MFD isn't an
        // issue, and the higher zoom compensates for the smaller
        // visual size of the code at that distance.
        //
        // Non-Pro devices (SE, standard 11/13/15/16 non-Pro, etc.)
        // were already using .builtInWideAngleCamera — no behavioural
        // change for them.
        let pickedDevice: AVCaptureDevice? = {
            print("📷 picked .builtInWideAngleCamera (single physical lens — 48MP-capable on Pro sensors, deterministic focus on all devices)")
            return AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back)
        }()

        guard let device = pickedDevice else {
            print("Failed to get the camera device.")
            instructionLabel.text = "Camera not available."
            return
        }
        self.videoDevice = device

        // 2. Create the video input
        guard let videoInput = try? AVCaptureDeviceInput(device: device) else {
            print("Failed to create video input.")
            return
        }

        // Note on auto-macro mode: when this device is a multi-cam virtual
        // device (only .builtInTripleCamera in our chain — Pro models),
        // AVFoundation automatically switches to the ultra-wide
        // constituent lens when the focus subject moves closer than
        // ~12 cm. No flag needs to be set — selecting the right device
        // above is what unlocks this. Non-Pro phones (whether multi-
        // lens or not) get the plain .builtInWideAngleCamera so the
        // virtual-device AF quirks at 2.5x default zoom don't bite us.
        if #available(iOS 13.0, *), device.isVirtualDevice {
            print("📷 device is virtual (constituents=\(device.constituentDevices.count)) — auto-macro will engage when held close")
        }

        if captureSession.canAddInput(videoInput) {
            captureSession.addInput(videoInput)
        }

        // ── Pick the highest-resolution format for the device ────────
        //
        // Problem: sessionPreset = .photo picks a "safe" format that
        // typically caps photo output at 12MP (4032×3024) even on
        // sensors that support much higher resolutions. On 14 Pro Max
        // the main wide sensor supports 48MP (8064×6048) captures,
        // but only when a format that lists those dimensions in its
        // `supportedMaxPhotoDimensions` is active. Log observed on
        // user's 14 Pro Max was:
        //   "photoOutput.maxPhotoDimensions unlocked → 4032×3024
        //    (from 1 supported option)"
        // ← that "1 supported option" is the giveaway that the
        // sessionPreset-chosen format is a limited one.
        //
        // Fix: scan every format the device advertises, find the one
        // with the largest supportedMaxPhotoDimensions, and switch
        // the device to that format. Requires sessionPreset =
        // .inputPriority (which means "use whatever format the input
        // has" and disables the preset's automatic format choice).
        //
        // Safeguards: only switch if the new format supports at least
        // 2× the pixel area of the current one. Prevents pointless
        // switches on non-Pro devices where no format offers more
        // than the sensor native ~12MP.
        //
        // Effects verified safe:
        //   • QR detection: runs on video output, unaffected by photo
        //     format choice
        //   • AF: iOS ties AF to the constituent lens, not the format
        //     — no known regressions from format switching
        //   • Preview layer: also runs off the video output — max
        //     frame rate might change if the new format has different
        //     videoSupportedFrameRateRanges, but our preview only
        //     needs 30fps for smooth display (well below any format's
        //     min FPS)
        if #available(iOS 16.0, *) {
            var bestFormat: AVCaptureDevice.Format? = nil
            var bestArea: Int = 0
            for format in device.formats {
                for dims in format.supportedMaxPhotoDimensions {
                    let area = Int(dims.width) * Int(dims.height)
                    if area > bestArea {
                        bestArea = area
                        bestFormat = format
                    }
                }
            }
            let currentBestArea: Int = device.activeFormat.supportedMaxPhotoDimensions
                .map { Int($0.width) * Int($0.height) }.max() ?? 0
            if let best = bestFormat, bestArea > currentBestArea * 2 {
                // Format worth switching to — significantly higher
                // photo resolution than what the default preset gave us.
                let bestDims = best.supportedMaxPhotoDimensions.max(by: {
                    Int($0.width) * Int($0.height) < Int($1.width) * Int($1.height)
                })!
                do {
                    captureSession.beginConfiguration()
                    // .inputPriority tells the session "don't try to pick
                    // a format for me — use whatever the input's active
                    // format is". Required for manual format selection.
                    captureSession.sessionPreset = .inputPriority
                    try device.lockForConfiguration()
                    device.activeFormat = best
                    device.unlockForConfiguration()
                    captureSession.commitConfiguration()
                    print("📷 format switched → max photo dims \(bestDims.width)×\(bestDims.height) (previous cap ≈ \(Int(sqrt(Double(currentBestArea))))² ≈ \(currentBestArea / 1_000_000)MP, new cap = \(bestArea / 1_000_000)MP)")
                } catch {
                    print("⚠️ Could not switch to higher-res format: \(error.localizedDescription) — leaving sessionPreset=.photo default in place")
                    captureSession.commitConfiguration()
                }
            } else if let best = bestFormat {
                print("📷 format scan: best available has area=\(bestArea) vs current=\(currentBestArea) — not worth switching (need >2×)")
                _ = best  // silence unused warning
            }
        }

        // ── (REVERTED) Triple-camera constituent lock ────────────────
        //
        // We tried setPrimaryConstituentDeviceSwitchingBehavior(.locked)
        // on iPhone 14 Pro Max to stop iOS auto-switching to ultra-wide
        // (the "pixelated crops" symptom backend team reported). The
        // lock worked but broke FOCUS: at our default 2.5× zoom users
        // have to hold the phone close enough to fill the scan window,
        // which puts them inside main wide's ~10 cm MFD. With no
        // macro auto-switch available anymore, the frame just went
        // blurry and the QR couldn't be decoded.
        //
        // Reverted: default triple-camera auto-switching restored.
        // Ultra-wide crops on Pro will look grainier than main-wide
        // crops on non-Pro, but focus works reliably at every working
        // distance the user might choose — which is the more important
        // constraint for scan success.
        //
        // Alternative directions worth trying if backend still cares
        // about Pro-device crop quality:
        //   • Raise default zoom to ~3.5× so users naturally work at
        //     a greater distance (above main wide MFD, no macro
        //     needed). Would restore main-wide constituent for most
        //     captures without changing focus behaviour.
        //   • Server-side model-specific normalization to compensate
        //     for the constituent difference.
        //   • Prompt the user to move back when we detect
        //     userIsTooCloseToFocus (lensPosition ≈ 0) — at least
        //     they'd get an actionable message before the silent
        //     switch quietly degrades their crop.

        // 3. Create the video data output
        videoDataOutput = AVCaptureVideoDataOutput()
        videoDataOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "videoQueue"))
        if captureSession.canAddOutput(videoDataOutput) {
            captureSession.addOutput(videoDataOutput)
        }

        // 4. Create the photo output for capturing images
        photoOutput = AVCapturePhotoOutput()
        if captureSession.canAddOutput(photoOutput) {
            captureSession.addOutput(photoOutput)
        }

        // 4b. Enable max-resolution capture on the photo output.
        //
        // On iOS 16+ this requires TWO independent settings:
        //   1. photoOutput.maxPhotoQualityPrioritization = .quality
        //      — lets settings.photoQualityPrioritization = .quality
        //        actually take effect at capture time.
        //   2. photoOutput.maxPhotoDimensions = <sensor max>
        //      — unlocks the sensor's full pixel count. Without this,
        //        the output defaults to a low ceiling (~12MP binned
        //        even on 48MP sensors) and settings.maxPhotoDimensions
        //        in capturePhoto has nothing bigger to read back.
        //
        // Concrete effect on 14 Pro Max: unlocks 48MP main-wide
        // captures (8064×6048) instead of the default 12MP binned
        // (4032×3024). AxionCode crops end up ~2× wider in each
        // dimension — the exact resolution jump the backend team
        // asked for.
        //
        // On non-Pro devices, the max is just their sensor native
        // (typically 12MP / 4032×3024) so the call is a no-op in
        // terms of the ceiling, but still explicit and correct.
        //
        // The .max(by:) picks the highest-area dimensions from all
        // supported values — some formats list multiple options and
        // we always want the biggest.
        if #available(iOS 16.0, *) {
            photoOutput.maxPhotoQualityPrioritization = .quality
            let dims = device.activeFormat.supportedMaxPhotoDimensions
            if let biggest = dims.max(by: { Int($0.width) * Int($0.height) < Int($1.width) * Int($1.height) }) {
                photoOutput.maxPhotoDimensions = biggest
                print("📷 photoOutput.maxPhotoDimensions unlocked → \(biggest.width)×\(biggest.height) (from \(dims.count) supported option\(dims.count == 1 ? "" : "s"))")
            } else {
                print("⚠️ activeFormat.supportedMaxPhotoDimensions was empty — photo output stays at default ceiling")
            }
        } else {
            photoOutput.isHighResolutionCaptureEnabled = true
        }
        
        // 5. Setup the preview layer
        videoPreviewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        videoPreviewLayer.videoGravity = .resizeAspectFill
        previewView.layer.addSublayer(videoPreviewLayer)
        
        previewView.layer.insertSublayer(dimOverlayLayer, above: videoPreviewLayer)
        previewView.layer.insertSublayer(cornerBoxLayer, above: dimOverlayLayer)
        // Check torch availability
            if let device = videoDevice {
                torchButton.isHidden = !device.hasTorch
            } else {
                torchButton.isHidden = true
            }
        // Set initial frame for the preview layer
//        DispatchQueue.main.async {
//            self.videoPreviewLayer.frame = self.previewView.bounds
//        }
        justZoom()
        // Start KVO on adjustingFocus / lensPosition so we can gate the scan
        // timer on focus lock and react instantly when the lens starts hunting.
        if #available(iOS 13.0, *) {
            monitorFocusState()
        }
        // 6. Setup Vision request
        setupVision()
    }
    
    
    
    // MARK: - Vision Setup
    private func setupVision() {
        // Create a barcode detection request
        let barcodeRequest = VNDetectBarcodesRequest { [weak self] request, error in
            self?.processBarcodes(for: request, error: error)
        }
        // We are interested in QR codes
        barcodeRequest.symbologies = [.qr]
        self.visionRequests = [barcodeRequest]
    }
    
//    private func setupVision() {
//        let barcodeRequest = VNDetectBarcodesRequest { [weak self] request, error in
//            self?.processBarcodes(for: request, error: error)
//        }
//        barcodeRequest.symbologies = [.qr]
//        
//        // Use the latest revision for better detection at angles
//        if #available(iOS 14.0, *) {
//            barcodeRequest.revision = VNDetectBarcodesRequestRevision1
//        }
//        
//        self.visionRequests = [barcodeRequest]
//    }
    
    // MARK: - AVCaptureVideoDataOutputSampleBufferDelegate
    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {

        // Cheap (~10 µs) read of the EXIF BrightnessValue attached to
        // every camera sample buffer — see latestAmbientLux for the
        // full rationale. Runs every frame; the actual /predict path
        // just reads the most-recent cached value.
        sampleAmbientLux(from: sampleBuffer)

        // If we've already detected a QR code and are in the process of capturing, don't process more frames.
        // ── One-shot frame grab for TFLite validation ──────────────
          if let validationCompletion = validationFrameCompletion {
              validationFrameCompletion = nil   // consume immediately — fire once only
              
              if let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) {
                  let ciImage  = CIImage(cvPixelBuffer: pixelBuffer)
                  let context  = CIContext()
                  if let cgImage = context.createCGImage(ciImage, from: ciImage.extent) {
                      let image = UIImage(cgImage: cgImage,
                                          scale: 1.0,
                                          orientation: .right)
                      DispatchQueue.main.async { validationCompletion(image) }
                  } else {
                      DispatchQueue.main.async { validationCompletion(nil) }
                  }
              } else {
                  DispatchQueue.main.async { validationCompletion(nil) }
              }
              return   // don't run normal QR scanning on this frame
          }
        
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

        // Throttled live sharpness probe — flips `isFrameSharp` and arms /
        // disarms the scan-timer gate. Cheap enough to run on the video queue
        // at ~3 Hz; see sampleFrameSharpness() for the throttle.
        //
        // IMPORTANT: sharpness sampling runs BEFORE the isQRCodeDetected
        // guard so that the pre-capture validation loop (see
        // attemptPreCaptureValidation) can still observe fresh sharpness
        // readings after Vision decodes a QR. Without this, the loop
        // waiting on `isFrameSharp` would deadlock the first time through
        // — no sharpness updates arrive because we've already flipped
        // `isQRCodeDetected = true`.
        sampleFrameSharpness(pixelBuffer)

        if isQRCodeDetected { return }

        // Throttled far-detection probe — runs at most once per
        // `farDetectionInterval` seconds, decides whether to surface
        // "You are far. Come closer". Independent of the tilt check,
        // auto-zoom, and auto-focus paths — see maybeRunFarDetection().
        maybeRunFarDetection(pixelBuffer)

        // Perform the vision request on the pixel buffer
        var requestOptions: [VNImageOption: Any] = [:]
        if let cameraIntrinsicData = CMGetAttachment(sampleBuffer, key: kCMSampleBufferAttachmentKey_CameraIntrinsicMatrix, attachmentModeOut: nil) {
            requestOptions = [.cameraIntrinsics: cameraIntrinsicData]
        }
        
        let imageRequestHandler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up, options: requestOptions)
        
        do {
            try imageRequestHandler.perform(self.visionRequests)
        } catch {
            print("Failed to perform Vision request: \(error)")
        }
    }
    
    // MARK: - Update your barcode detection method

    

//    private func processBarcodes(for request: VNRequest, error: Error?) {
//        DispatchQueue.main.async { [weak self] in
//            guard let self = self else { return }
//            
//            // Throttle
//            if let lastTime = self.lastDetectionTime,
//               Date().timeIntervalSince(lastTime) < 0.3 {
//                return
//            }
//            self.lastDetectionTime = Date()
//            
//            if let error = error {
//                print("❌ Vision error: \(error.localizedDescription)")
//                return
//            }
//            
//            guard let results = request.results,
//                  let barcode = results.first as? VNBarcodeObservation,
//                  barcode.confidence > 0.9,
//                  self.isQRCodeFullyVisible(barcode)
//            else {
//                self.updateDetectionStatus(isDetected: false)
//                return
//            }
//            
//            // Store the QR code value
//            if let qrCodeValue = barcode.payloadStringValue {
//                self.detectedQRCodeValue = qrCodeValue
//                print("📱 QR Code full visible: \(qrCodeValue)")
//            }
//
//            
//            // Only reset timer if QR code has changed
//            if let last = self.lastBarcode,
//               last.payloadStringValue == barcode.payloadStringValue {
//                // same QR → do nothing, timer already running
//            } else {
//                self.lastBarcode = barcode
//                NSObject.cancelPreviousPerformRequests(withTarget: self,
//                                                       selector: #selector(self.handleStabilizedQRCode),
//                                                       object: nil)
//                self.perform(#selector(self.handleStabilizedQRCode), with: nil, afterDelay: 0.5)
//                print("🔍 New QR detected – stabilization timer started")
//            }
//        }
//    }
    private func processBarcodes(for request: VNRequest, error: Error?) {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            
            // 1. Throttle check
            if let lastTime = self.lastDetectionTime,
               Date().timeIntervalSince(lastTime) < 0.3 {
                return
            }
            self.lastDetectionTime = Date()
            
            if let error = error {
                print("❌ Vision error: \(error.localizedDescription)")
                return
            }

            // 2. Initial Results check
            guard let results = request.results,
                  let barcode = results.first as? VNBarcodeObservation else {
                // This is the most common state while waving the phone around
                self.updateDetectionStatus(isDetected: false)
                return
            }

            print("🔍 Found potential QR...")

            // 3. Confidence Log
            print("📊 Confidence: \(barcode.confidence)")
            if barcode.confidence <= 0.9 {
                print("⚠️ Dropped: Confidence too low (\(barcode.confidence))")
                self.updateDetectionStatus(isDetected: false)
                return
            }

            // 4. Visibility Log
            let visible = self.isQRCodeFullyVisible(barcode)
            print("👁️ Is Fully Visible: \(visible)")
            if !visible {
                print("⚠️ Dropped: QR is partially off-screen or too small")
                self.updateDetectionStatus(isDetected: false)
                return
            }

            // --- IF IT REACHES HERE, ALL GUARDS PASSED ---
            print("✅ ALL CHECKS PASSED - Proceeding to payload")

            // Store the QR code value
            if let qrCodeValue = barcode.payloadStringValue {
                self.detectedQRCodeValue = qrCodeValue
                print("📱 QR Code detected: \(qrCodeValue)")
            }

            // Stabilization Logic
            if let last = self.lastBarcode,
               last.payloadStringValue == barcode.payloadStringValue {
                // same QR
            } else {
                self.lastBarcode = barcode
                NSObject.cancelPreviousPerformRequests(withTarget: self,
                                                       selector: #selector(self.handleStabilizedQRCode),
                                                       object: nil)
                self.perform(#selector(self.handleStabilizedQRCode), with: nil, afterDelay: 0.5)
                print("🔍 New QR detected – stabilization timer started")
            }
        }
    }


    @objc private func handleStabilizedQRCode() {
        guard let barcode = self.lastBarcode, !self.isQRCodeDetected else {
            print("⚠️ No barcode available or already processing")
            return
        }
        stopTiltCheckTimer()
        print("✅ QR Code stabilized — starting pre-capture pattern validation on live preview frames")

        // Lock re-entry: further Vision decodes must not re-arm this
        // handler while we're validating. sampleFrameSharpness has
        // already been moved above the isQRCodeDetected guard in
        // captureOutput, so `isFrameSharp` will keep updating from
        // fresh preview frames throughout this loop.
        self.isQRCodeDetected = true
        self.detectedBarcode = barcode

        // DELIBERATELY DO NOT do the following here (they now live in
        // commitToCapture(), called once TFLite says the frame contains
        // a proper Axion code):
        //   • ProgressHUD.shared.show(...)
        //   • updateDetectionStatus(isDetected: true)   ← green corner box
        //   • freezePreview()
        //   • overlayImageView?.isHidden = true
        //   • zoomAndCapture()                          ← fires shutter sound
        //
        // Rationale: the shutter sound + green box give the user the
        // strong impression "you nailed it" the moment Vision decodes.
        // If validatePatternBoxes then finds the frame's crop is missing
        // corner patterns, the user is confused ("why do I have to try
        // again — I heard the click, I saw green"). Deferring both until
        // TFLite confirms the frame is capture-worthy removes that whole
        // class of confusion.
        startPreCaptureValidation()
    }

    // MARK: - Pre-capture validation
    //
    // Sequence between "Vision decoded QR" and "we play the shutter":
    //
    //   handleStabilizedQRCode → startPreCaptureValidation
    //     ↓
    //   attemptPreCaptureValidation (may loop up to
    //                                preCaptureValidationMaxAttempts times)
    //     ├─ if !isFrameSharp: wait retryInterval and re-enter
    //     ├─ grab live frame via captureFrameForValidation
    //     ├─ run validatePatternBoxes on that frame
    //     ├─ pass → commitToCapture (green box + shutter + capture)
    //     └─ fail → wait retryInterval and re-enter
    //     ↓ (attempts exhausted)
    //   commitToCapture   ← still commits; server /predict/ decides

    /// Kick off the pre-capture pattern-validation loop. Zeroes the
    /// attempt counter and dispatches the first probe on the main
    /// queue (validatePatternBoxes uses Task.detached internally so
    /// TFLite doesn't tie up the main thread).
    private func startPreCaptureValidation() {
        preCaptureValidationAttempts = 0
        attemptPreCaptureValidation()
    }

    /// One iteration of the pre-capture validation loop. Called
    /// recursively via asyncAfter for retries; caps at
    /// preCaptureValidationMaxAttempts to guarantee forward progress.
    private func attemptPreCaptureValidation() {
        preCaptureValidationAttempts += 1
        if preCaptureValidationAttempts > preCaptureValidationMaxAttempts {
            print("⚠️ Pre-capture validation exhausted \(preCaptureValidationMaxAttempts) attempts — committing to capture anyway, server /predict/ will judge")
            commitToCapture()
            return
        }

        // Wait for a Tenengrad-sharp frame — no point running TFLite on
        // a blurry frame, we'd just misfire and burn an attempt. Sharpness
        // is refreshed in captureOutput even while isQRCodeDetected is
        // true (see the moved sampleFrameSharpness call).
        guard isFrameSharp else {
            print("🔄 pre-capture validation attempt \(preCaptureValidationAttempts): waiting for Tenengrad-sharp frame")
            DispatchQueue.main.asyncAfter(deadline: .now() + preCaptureValidationRetryInterval) { [weak self] in
                self?.attemptPreCaptureValidation()
            }
            return
        }

        // Sharp — grab the next preview frame via the existing one-shot
        // callback slot, then run YOLO on it.
        captureFrameForValidation { [weak self] image in
            guard let self = self else { return }
            guard let image = image else {
                print("🔄 pre-capture validation attempt \(self.preCaptureValidationAttempts): frame grab returned nil — retrying")
                DispatchQueue.main.asyncAfter(deadline: .now() + self.preCaptureValidationRetryInterval) { [weak self] in
                    self?.attemptPreCaptureValidation()
                }
                return
            }

            Task.detached(priority: .userInitiated) { [weak self] in
                guard let self = self else { return }
                let ok = await self.validatePatternBoxes(image)
                await MainActor.run {
                    if ok {
                        print("✅ pre-capture validation passed on attempt \(self.preCaptureValidationAttempts) — proceeding to capture")
                        self.commitToCapture()
                    } else {
                        print("🔄 pre-capture validation attempt \(self.preCaptureValidationAttempts): pattern check failed — retrying")
                        DispatchQueue.main.asyncAfter(deadline: .now() + self.preCaptureValidationRetryInterval) { [weak self] in
                            self?.attemptPreCaptureValidation()
                        }
                    }
                }
            }
        }
    }

    /// Do all the UI transitions the old handleStabilizedQRCode used to
    /// do inline: show HUD, flip corner box to green, freeze preview,
    /// hide overlay guide, then trigger the high-res photo capture
    /// (which is what plays the system shutter sound).
    ///
    /// Kept idempotent-ish via `isCommittedToCapture` — the retry logic
    /// theoretically could double-fire if a stale asyncAfter races with
    /// the max-attempts fallback. We swallow duplicates cheaply here.
    private func commitToCapture() {
        // Guard against a race where the max-attempts branch fires
        // commitToCapture() at the same time a late TFLite pass also
        // returns true and calls it. `zoomAndCapture` MUST NOT double-
        // fire — capturePhoto returns a hard error and the user sees
        // a spurious failure alert.
        if isCommittedToCapture {
            print("ℹ️ commitToCapture: already committed — ignoring duplicate")
            return
        }
        isCommittedToCapture = true

        ProgressHUD.shared.show(in: view, message: "Processing.Please dont move..")
        self.updateDetectionStatus(isDetected: true)   // green corner box
        self.freezePreview()
        // Hide the overlay guide — its job is done once we have a
        // decoded QR AND a validated frame. resetDetection / restartScan
        // show it again on the next scan.
        self.overlayImageView?.isHidden = true

        // Small delay lets the UI transitions land before iOS steals
        // focus for the photo capture. Same 0.1s the old code used.
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { [weak self] in
            self?.zoomAndCapture()
        }
    }

    private func isQRCodeFullyVisible(_ barcode: VNBarcodeObservation) -> Bool {
        // Convert normalized coordinates to view coordinates
        let boundingBox = barcode.boundingBox
        
        // Check if all corners are within the image bounds (0-1 range)
        let topLeft = CGPoint(x: boundingBox.minX, y: boundingBox.maxY)
        let topRight = CGPoint(x: boundingBox.maxX, y: boundingBox.maxY)
        let bottomLeft = CGPoint(x: boundingBox.minX, y: boundingBox.minY)
        let bottomRight = CGPoint(x: boundingBox.maxX, y: boundingBox.minY)
        
        // Define a small margin (e.g., 5% of the frame)
        let margin: CGFloat = 0.05
        
        // Check all corners are within the frame with margin
        let isFullyVisible =
            topLeft.x > margin && topLeft.y < (1 - margin) &&
            topRight.x < (1 - margin) && topRight.y < (1 - margin) &&
            bottomLeft.x > margin && bottomLeft.y > margin &&
            bottomRight.x < (1 - margin) && bottomRight.y > margin
        
        // Additional check for the black circle (assuming it's part of the QR code)
        // We can check if the bounding box is large enough relative to the frame
        let minRelativeSize: CGFloat = 0.3 // At least 30% of frame width/height
        let isLargeEnough =
            boundingBox.width > minRelativeSize &&
            boundingBox.height > minRelativeSize
        
//        return isFullyVisible && isLargeEnough
        return isFullyVisible
    }
//    private func isQRCodeFullyVisible(_ barcode: VNBarcodeObservation) -> Bool {
//        // 1. Get the actual corners (these stay accurate even if QR is diagonal)
//        let corners = [
//            barcode.topLeft,
//            barcode.topRight,
//            barcode.bottomLeft,
//            barcode.bottomRight
//        ]
//        
//        let margin: CGFloat = 0.05
//        
//        // 2. Check if every individual corner is within the screen bounds
//        for corner in corners {
//            if corner.x < margin || corner.x > (1 - margin) ||
//               corner.y < margin || corner.y > (1 - margin) {
//                print("⚠️ Corner outside margin: \(corner)")
//                return false
//            }
//        }
//        
//        // 3. Check for "Steep Angle" (Optional)
//        // If the QR is too diagonal, the TFLite model might struggle later.
//        // You can check the width/height ratio of the bounding box.
//        let bb = barcode.boundingBox
//        let aspect = bb.width / bb.height
//        if aspect < 0.5 || aspect > 2.0 {
//            print("⚠️ Angle too steep (aspect ratio: \(aspect))")
//            return false
//        }
//        
//        return true
//    }
    @objc private func zoomSliderValueChanged(_ sender: UISlider) {
        let roundedValue = round(sender.value / Float(zoomStep)) * Float(zoomStep)
        sender.value = roundedValue

        let newZoom = CGFloat(roundedValue)
        currentZoom = newZoom

        // Update zoom label
        zoomLabel.text = String(format: "%.1fx", newZoom)

        setZoom(newZoom)
    }

    @objc private func zoomSliderTouchBegan() {
        // User started dragging the slider — pause the countdown AND hand
        // zoom control over to them for the rest of the session. Auto-zoom
        // will stay out of the way until resetDetection() (or scan refresh)
        // clears the flag.
        userZoomOverride = true
        pauseScanIntervalForInteraction()
    }

    @objc private func zoomSliderTouchEnded() {
        // User lifted finger — restart the 5-second countdown (gated by motion).
        startScanTimer()
    }

    private func setZoom(_ zoom: CGFloat) {
        guard let device = videoDevice else { return }
        
        do {
            try device.lockForConfiguration()
            
            // Apply zoom with clamping to device limits
            let clampedZoom = max(minZoom, min(zoom, maxZoom))
            device.videoZoomFactor = clampedZoom
            
            device.unlockForConfiguration()
            
            print("🔍 Zoom set to: \(clampedZoom)x")
            
        } catch {
            print("❌ Could not set zoom: \(error)")
        }
    }
    func justZoom() {
        guard let device = videoDevice else { return }
        
        do {
            try device.lockForConfiguration()
            
            // Use currentZoom instead of hardcoded value
            device.videoZoomFactor = max(1.0, min(currentZoom, device.activeFormat.videoMaxZoomFactor))
            
            device.unlockForConfiguration()
            
        } catch {
            print("Could not lock device for configuration: \(error)")
        }
    }
    // MARK: - Camera Actions (Zoom and Capture)
    private func zoomAndCapture() {
        guard let device = videoDevice else { return }
        
        do {
            //            try device.lockForConfiguration()
            //
            //            // --- Zoom Logic ---
            //            // Let's zoom to a factor of 2.0x. You can adjust this.
            //            // We clamp the value to be within the device's available zoom range.
            //            let desiredZoomFactor: CGFloat = 2.0
            //            device.videoZoomFactor = max(1.0, min(desiredZoomFactor, device.activeFormat.videoMaxZoomFactor))
            //
            //            device.unlockForConfiguration()
            
            // Give the camera a moment to adjust focus and exposure after zooming.
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.capturePhoto()
            }
            
        } catch {
            print("Could not lock device for configuration: \(error)")
        }
    }
    
    private func capturePhoto() {
        let settings: AVCapturePhotoSettings

        // Use a high-resolution format if available by creating the settings with a format dictionary.
        if self.photoOutput.availablePhotoPixelFormatTypes.contains(kCVPixelFormatType_420YpCbCr8BiPlanarFullRange) {
            settings = AVCapturePhotoSettings(format: [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_420YpCbCr8BiPlanarFullRange])
        } else {
            // Fallback to default settings if the desired format is not available.
            settings = AVCapturePhotoSettings()
        }

        // Ask for the highest resolution the sensor can deliver. Without
        // these knobs the photo output caps around 1920×1440 even on a
        // 4032×3024 sensor, which is the single biggest reason our
        // cropped uploads end up at ~800×800 vs Scandit's ~2000×2000.
        if #available(iOS 16.0, *) {
            // iOS 16+: use the modern photo-quality + maxPhotoDimensions API.
            // photoOutput.maxPhotoDimensions was unlocked in setupCamera
            // to the sensor's true max (e.g. 8064×6048 on 14 Pro Max
            // 48MP main wide) — reading it back here and setting the
            // per-capture settings.maxPhotoDimensions to match asks
            // for that full resolution.
            settings.photoQualityPrioritization = .quality
            let maxDims = photoOutput.maxPhotoDimensions
            if maxDims.width > 0 && maxDims.height > 0 {
                settings.maxPhotoDimensions = maxDims
                print("📸 capturePhoto: requesting max dims \(maxDims.width)×\(maxDims.height), priority=.quality")
            } else {
                print("⚠️ capturePhoto: photoOutput.maxPhotoDimensions was 0×0 — capture will use default (low) resolution")
            }
        } else {
            // iOS 13-15: use the legacy isHighResolutionPhotoEnabled flag.
            settings.isHighResolutionPhotoEnabled = true
        }

        photoOutput.capturePhoto(with: settings, delegate: self)
    }

    // MARK: - Sharpness-aware capture for the /validate/ path
    /// Maximum time we'll wait for the lens to settle before snapping. Most
    /// AF converges in <250 ms when the live preview was already in focus;
    /// 600 ms is generous headroom for hard cases (low light, scene change).
    private let validateFocusSettleMaxWait: TimeInterval = 0.6
    /// Threshold used by the high-res crop's blur check inside
    /// `pendingFakePhotoCompletion`. The live-preview threshold (70) is
    /// tuned for ~256-wide downscaled frames; full-resolution Axion-code
    /// crops produce Laplacian variance an order of magnitude higher, so a
    /// far stricter floor is appropriate here. Tune in-field if real-world
    /// crops are getting rejected.
    private let validateCropSharpnessThreshold: Float = 200
    /// Tenengrad sharpness threshold (0-100 scale, matches server-side
    /// Python `sharpness_score`). Crops scoring BELOW this value never
    /// reach /validate/ — the timer is reset and we try again. The Python
    /// scale produces ~80+ for a tack-sharp print, ~30-50 for visible-but-
    /// soft, ~10-25 for obviously blurry. We start at 50 to reject most
    /// soft frames; tune from the log output if real-world hits are too
    /// strict or too lenient.
    private let validateCropTenengradThreshold: Double = 50

    // MARK: - Upload image-quality knobs
    //
    // These exist together so you can A/B them against Scandit on the
    // same device by flipping one constant at a time.

    /// JPEG quality for both /predict/ and /validate/ uploads. The default
    /// 0.8 used to dissolve fine print detail (offset-printer dots merged
    /// into smears) at the sizes we upload. Raised from 0.95 to 1.00
    /// (essentially lossless) after the backend team asked for more
    /// distinct per-pixel edges on the QR modules — even the ~5%
    /// quality drop between 0.95 and 1.00 was smearing offset-printed
    /// dot patterns enough to affect their downstream analysis.
    /// Cost: ~30% larger upload than 0.95 (still typically < 500 KB
    /// per crop). Acceptable because /predict/ / /validate/ aren't
    /// hot per-frame paths — one upload per scan.
    private let uploadJpegQuality: CGFloat = 1.00
    /// Padding multiplier around the QR rect when cropping for upload.
    ///
    /// Empirical history (please don't reset to "obvious" values without
    /// re-testing the post-crop `validatePatternBoxes` check):
    ///   • 3.0×  — was the safe default; QR + 6 outer patterns + a
    ///             visible strip of background. "Some extra area" the
    ///             user noted in screenshots.
    ///   • 2.5×  — slightly tighter; small but visible margin.
    ///   • 2.2×  — current. QR + 6 outer patterns fit edge-to-edge with
    ///             a thin safety strip so a slightly off-centre QR
    ///             doesn't clip a pattern (which would fail
    ///             validatePatternBoxes).
    ///   • 2.0×  — patterns extend exactly to the crop edges; moderate
    ///             risk of clipping when Vision's bounding box isn't
    ///             perfectly centred.
    ///   • 1.5×  — TRIED AND REJECTED — cuts the outer patterns in
    ///             half, every capture fails validation with "QR
    ///             pattern incomplete — try again".
    ///
    /// Used by both `cropSquareNow` (Vision-bbox path) and
    /// `cropAroundTFLiteQR` (TFLite-bbox fallback path).
    private let cropQRPaddingMultiplier: CGFloat = 2.2
    /// Padding applied around the YOLO-derived AxionCode-class rect when
    /// cropping the high-res photo for upload. 1.0 = use the YOLO box
    /// exactly. Slightly above 1.0 gives a thin background border that
    /// guarantees the 6 outer pattern boxes aren't sliced through when
    /// YOLO's bbox lands a few pixels inside one of them — which happens
    /// for off-axis / low-contrast captures.
    ///
    /// Sweep notes (updated after the TFLite letterbox preprocessing
    /// fix — see TFLiteInference.preprocessImageLetterbox):
    ///   • 1.00 — CURRENT DEFAULT. Tight to YOLO's AxionCode-class
    ///            box. With the letterbox preprocessing fix, YOLO's
    ///            bbox is now accurately aligned with the printed
    ///            code (previously the stretch preprocess made it
    ///            drift, which forced us to over-pad to compensate).
    ///            The debug save (see saveAxionCodeDebugFrame) shows
    ///            exactly this box in blue — what you see is what
    ///            gets sent to /predict/.
    ///   • 1.08 — 4% per side. Kept only for reference; no longer
    ///            needed now that the bbox is accurate.
    ///   • 1.20 — 10% per side. Was needed to compensate for the
    ///            stretch-preprocess-induced bbox drift. Not needed
    ///            with the letterbox fix.
    ///
    /// Bump ONLY if we see the AxionCode class regress (e.g. new
    /// model version) and clip patterns again.
    private let cropAxionCodePaddingMultiplier: CGFloat = 1.00

    // MARK: - QR-class + physical-padding crop strategy
    //
    // Alternative to the AxionCode-class + percentage-padding crop.
    // Rationale: YOLO's AxionCode-class bbox sometimes drifts a few
    // tens of pixels — enough to clip a corner pattern box even at
    // paddingMultiplier=1.20. The QR-class bbox is typically much
    // tighter (the QR itself is a stable, high-contrast rectangle),
    // so if we use IT as our reference and expand by a physically-
    // meaningful margin, the result is:
    //   1. more robust to model bbox drift, because we're anchored
    //      to a well-detected class;
    //   2. semantically clearer — "0.7 cm around the QR" ≈ "outer
    //      patterns + safety buffer", which is what the /predict/
    //      and /validate/ models want to see.

    /// Feature flag. When TRUE, `cropUsingPreferredStrategy` tries the
    /// QR-class + physical-padding path first and falls back to
    /// AxionCode-class only if QR isn't detected. When FALSE, the
    /// AxionCode-class path is used exclusively.
    ///
    /// CURRENTLY FALSE per the request "crop along the blue line for
    /// AxionCode pattern": the crop that reaches /predict/ must match
    /// exactly what the debug frame shows as the blue AxionCode box.
    /// With this flag off + cropAxionCodePaddingMultiplier=1.00, the
    /// crop is dimensionally identical to the blue box in the debug
    /// save — what you see in Photos is what the server receives.
    private let useQrPhysicalPaddingCrop: Bool = false

    /// Assumed physical edge length of the printed QR (without the
    /// outer pattern boxes). Used only to convert pixels ↔ cm inside
    /// `cropToQRWithPhysicalPadding` — no other code path reads this.
    ///
    /// Defaulted to 0.7 cm (7 mm), the SMALLER of our two currently-
    /// supported print sizes. This choice is deliberate: assuming a
    /// smaller physical size ⇒ over-estimating pixelsPerCm ⇒ slightly
    /// larger crops. Larger is safe (more background included, no
    /// clipping). If we assumed 0.8 cm (8 mm) and encountered a 7 mm
    /// print in the field, the crop would come out ~12% too small
    /// and corner patterns would clip — exactly the failure mode
    /// we're trying to avoid.
    ///
    /// If a third print size is introduced later, default to the
    /// smallest.
    private let expectedQRSizeCm: CGFloat = 0.7

    /// Physical padding added to each side of the QR-class rect.
    /// 0.7 cm ≈ QR-edge → outer-pattern-edge distance + safety buffer
    /// on our printed layout.
    private let qrPhysicalPaddingCm: CGFloat = 0.7
    /// Whether `validatePatternBoxes` is allowed to BLOCK an upload
    /// after Vision has already decoded the QR.
    ///
    /// Background: when Vision decodes a QR, the scanner plays the
    /// capture sound and freezes the corner-box overlay — at that point
    /// the user expects a result, not a retry prompt. The old behaviour
    /// then ran TFLite on the crop, demanded ≥ 6 square Pattern boxes,
    /// and on failure showed the "QR pattern incomplete — try again"
    /// toast. Two real-world problems:
    ///
    ///   1. The check failed routinely on legitimate scans whenever the
    ///      crop padding wasn't generous enough to include all six
    ///      patterns whole — confusing the user despite the QR being
    ///      perfectly framed.
    ///
    ///   2. Even when the check is right (crop did clip a pattern),
    ///      retrying produces another capture of the same printed code
    ///      at roughly the same framing, so the user just bounces off
    ///      the toast repeatedly.
    ///
    /// New behaviour with `enforcePatternBoxValidation = false` (default):
    /// the validation TFLite pass still runs and its result is logged
    /// for diagnostics, but the upload always proceeds. The server-side
    /// /predict/ model is the authoritative authenticity judgement; if
    /// the crop genuinely is too partial to decide, the server returns
    /// low confidence / "fake" and the user sees the proper outcome
    /// screen rather than a retry prompt.
    ///
    /// Flip this back to `true` if you want the old behaviour while
    /// debugging crop logic.
    private let enforcePatternBoxValidation: Bool = false
    /// Whether to apply `CIUnsharpMask` to the cropped image before
    /// JPEG-encoding it for upload. The mask emphasises edges so print
    /// dots stay crisp through the encode step. Turn off if you want to
    /// compare raw-vs-sharpened uploads against Scandit.
    private let applyUnsharpenForUpload: Bool = true
    /// CIUnsharpMask `inputRadius`. Lowered from 2.0 → 1.5 to better
    /// match the pixel scale of QR modules on the cropped upload —
    /// broader halos smeared adjacent modules together, which was the
    /// opposite of "distinct pixels". 1.5 gives a tight halo confined
    /// to the immediate edge without visible ringing.
    private let unsharpenRadius: CGFloat = 1.5
    /// CIUnsharpMask `inputIntensity`. Raised from 0.5 → 1.0 to lift
    /// module edges more decisively. 1.0 is the ceiling of the "still
    /// looks natural" range in Apple's CIUnsharpMask; above that you
    /// start seeing crunchy artefacts on smooth regions. For QR data,
    /// crunchy IS the goal — but we cap here so faces / logos in the
    /// same crop still look sane if anyone inspects the JPEG visually.
    private let unsharpenIntensity: CGFloat = 1.0

    /// Whether to apply a mild contrast boost after unsharp masking.
    /// Black-white QR modules gain crispness from `contrast > 1`
    /// because gray transition pixels along module edges get pushed
    /// harder toward pure black or pure white. Set to `false` to
    /// disable the extra step.
    private let applyContrastBoostForUpload: Bool = true
    /// CIColorControls `inputContrast`. 1.0 is unchanged, 1.15 is a
    /// subtle boost visible on print details but not saturating skin
    /// tones or logos in the same crop. Backend team asked for
    /// "distinct pixels" — this is the last-mile knob for that.
    private let uploadContrastFactor: CGFloat = 1.15

    /// Optional 1.5× Lanczos upsample before the sharpen+contrast
    /// pipeline. Off by default (triples upload size). Turn ON if the
    /// backend explicitly requests higher resolution uploads or if
    /// visual inspection of the crop still looks pixelated at the
    /// current default 3.5x zoom + ~500 px crop. Lanczos preserves
    /// sharpness better than the default bilinear resample.
    private let applyUpscaleBeforeSharpen: Bool = false
    /// Upscale factor when the flag above is on. 1.5 doubles pixel
    /// count (1.5² = 2.25), 2.0 quadruples it (4× file size).
    private let uploadUpscaleFactor: CGFloat = 1.5

    // MARK: - /validate/ crop-scale parity with /predict/
    //
    // Historical note: previously we Lanczos-upsampled the /validate/
    // crop by ~2.1× to compensate for the pixel-count deficit vs
    // /predict/ (video output was ~1920×1440 vs photo output's
    // ~4032×3024). That gave dimensional parity but not real detail
    // — Lanczos can't invent information the sensor never captured.
    //
    // Current approach: /validate/ now goes through the same photo-
    // output pipeline as /predict/. See `pendingValidatePhotoCompletion`
    // and the hasAllClasses branch in scanTimerFired for the wiring.
    // Both endpoints receive genuinely-native ~4032×3024 sensor pixels
    // — no upsampling needed, and the crops are pixel-for-pixel of
    // equivalent quality.

    /// Validation-path capture. Triggers a fresh AF/AE cycle, polls
    /// `device.isAdjustingFocus` / `isAdjustingExposure` until they're
    /// false (or we hit `validateFocusSettleMaxWait`), then runs the
    /// regular `capturePhoto` so the shutter only fires once the lens is
    /// stable. This kills the class of bug where the live-preview probe
    /// said "sharp" but the lens drifted in the ~200 ms between the timer
    /// firing and the shutter actually releasing.
    private func captureSharpPhotoForValidation() {
        guard let device = videoDevice else {
            // No device? Fall back to the original behaviour so the flow
            // doesn't hang.
            capturePhoto()
            return
        }

        // Kick a fresh AF/AE cycle. `.autoFocus` resnaps once and then
        // returns to `.locked` until disturbed — exactly what we want for
        // a one-shot still capture.
        do {
            try device.lockForConfiguration()
            if device.isFocusModeSupported(.autoFocus) {
                device.focusMode = .autoFocus
            }
            if device.isExposureModeSupported(.autoExpose) {
                device.exposureMode = .autoExpose
            }
            device.unlockForConfiguration()
        } catch {
            print("⚠️ captureSharpPhotoForValidation: lockForConfiguration failed — \(error.localizedDescription)")
            // Continue anyway — better to capture a possibly-blurry frame
            // than to deadlock the flow.
            capturePhoto()
            return
        }

        // Poll for convergence on the main thread. KVO would be cleaner
        // but it'd require teardown plumbing and we want a small,
        // self-contained helper.
        let start = CACurrentMediaTime()
        let pollInterval: TimeInterval = 0.04 // ~25 Hz, cheap
        func poll() {
            let elapsed = CACurrentMediaTime() - start
            let stillAdjusting = (videoDevice?.isAdjustingFocus ?? false)
                || (videoDevice?.isAdjustingExposure ?? false)
            if !stillAdjusting {
                print(String(format: "🎯 validate-path AF/AE converged after %.2f s — capturing", elapsed))
                capturePhoto()
                return
            }
            if elapsed >= validateFocusSettleMaxWait {
                print(String(format: "⏰ validate-path AF/AE didn't settle within %.2f s — capturing anyway", elapsed))
                capturePhoto()
                return
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + pollInterval) {
                poll()
            }
        }
        poll()
    }
    private func debugImageInfo(_ ciImage: CIImage, _ barcode: VNBarcodeObservation?) {
        print("=== DEBUG IMAGE INFO ===")
        print("CIImage extent: \(ciImage.extent)")
        print("CIImage properties: \(ciImage.properties)")
        
        if let barcode = barcode {
            print("Barcode boundingBox: \(barcode.boundingBox)")
            print("Barcode confidence: \(barcode.confidence)")
            print("Barcode payload: \(barcode.payloadStringValue ?? "nil")")
            
            // Convert to image coordinates for debugging
            let imageSize = ciImage.extent.size
            let originX = barcode.boundingBox.origin.x * imageSize.width
            let originY = (1 - barcode.boundingBox.origin.y - barcode.boundingBox.height) * imageSize.height
            let width = barcode.boundingBox.width * imageSize.width
            let height = barcode.boundingBox.height * imageSize.height
            
            print("Barcode in image coordinates: (\(originX), \(originY), \(width), \(height))")
        }
        print("========================")
    }
    
    // MARK: - Validate Pattern Boxes Are Complete Squares
    private func validatePatternBoxes(_ image: UIImage) async -> Bool {
        do {
            let detections = try TFLiteInference.run(
                on: image,
                modelName: "model",
                bundle: AxionBundle.bundle
            )
            
            // Filter only "Pattern" class detections (classId == 2)
            let patternDetections = detections.filter {
                $0.classId == YOLOClass.pattern.rawValue
            }
            
            print("🔲 Pattern detections found: \(patternDetections.count)")
            
            // Must have exactly 6 Pattern boxes
            guard patternDetections.count >= 6 else {
                print("❌ Pattern count mismatch: expected 6, got \(patternDetections.count)")
                return false
            }
            
            // Each Pattern box must be a complete square
            // A box is a square if width ≈ height within a tolerance of 30%
            let squareTolerance: CGFloat = 0.30
            
            for (i, det) in patternDetections.enumerated() {
                let w = det.rect.width
                let h = det.rect.height
                
                guard w > 0, h > 0 else {
                    print("❌ Pattern[\(i)] has zero dimension: \(det.rect)")
                    return false
                }
                
                let ratio = max(w, h) / min(w, h)
                print("🔲 Pattern[\(i)] size: \(w)x\(h), ratio: \(String(format: "%.2f", ratio))")
                
                if ratio > (1.0 + squareTolerance) {
                    print("❌ Pattern[\(i)] is not square enough: ratio=\(String(format: "%.2f", ratio))")
                    return false
                }
            }
            
            print("✅ All 6 Pattern boxes are complete squares")
            return true
            
        } catch {
            print("❌ TFLite pattern validation error: \(error.localizedDescription)")
            return false
        }
    }
    
    private func startTiltCheckTimer() {
        stopTiltCheckTimer()
        // Check every 1.5s — frequent enough to feel live, cheap enough not to block
        tiltCheckTimer = Timer.scheduledTimer(
            withTimeInterval: 1.5,
            repeats: true
        ) { [weak self] _ in
            self?.performLiveTiltCheck()
        }
        RunLoop.main.add(tiltCheckTimer!, forMode: .common)
    }

    private func stopTiltCheckTimer() {
        tiltCheckTimer?.invalidate()
        tiltCheckTimer = nil
    }

    /// Physical-size estimate for the AxionCode class from a per-frame
    /// YOLO detection pass. Uses the QR-class rect as a known-size
    /// reference — the printed QR is either 7 mm or 8 mm, so we report
    /// BOTH interpretations. Whichever matches your print is the true
    /// physical size.
    ///
    /// Called from `performLiveTiltCheck` so the log fires every ~1.5 s
    /// as the user frames the code — you can watch the estimates live
    /// while positioning. No-ops silently on frames that don't detect
    /// an AxionCode class (very common while the user is still
    /// pointing at background).
    ///
    /// Math:
    ///   pixelsPerMm(assume 7mm QR) = QR_width_px / 7
    ///   AxionCode size mm          = AxionCode_width_px / pixelsPerMm
    ///
    /// If both AxionCode measurements come out visually reasonable
    /// (12–20 mm for the assume-7mm branch, 14–22 mm for assume-8mm),
    /// the crop is in-frame and well-focused. Wildly off values
    /// (> 40 mm or < 5 mm) indicate YOLO returned a bogus rect for
    /// one of the two classes.
    private func logAxionCodePhysicalSizeIfPresent(from detections: [Detection]) {
        guard let bestAxion = detections
                .filter({ $0.classId == YOLOClass.axionCode.rawValue })
                .sorted(by: { $0.confidence > $1.confidence })
                .first else {
            return
        }
        let axionPxLong = max(bestAxion.rect.width, bestAxion.rect.height)

        let bestQR = detections
            .filter { $0.classId == YOLOClass.qr.rawValue }
            .sorted { $0.confidence > $1.confidence }
            .first

        if let qr = bestQR, qr.rect.width > 0 {
            let qrPxLong   = max(qr.rect.width, qr.rect.height)
            let pxPerMm7   = qrPxLong / 7.0
            let pxPerMm8   = qrPxLong / 8.0
            let axionMmIf7 = axionPxLong / pxPerMm7
            let axionMmIf8 = axionPxLong / pxPerMm8
            print(String(format: "📏 AxionCode size — QR ref: %.0f px | AxionCode: %.0f px | assume QR=7mm → AxionCode ≈ %.1f mm | assume QR=8mm → AxionCode ≈ %.1f mm (conf axion=%.2f qr=%.2f)",
                         qrPxLong,
                         axionPxLong,
                         axionMmIf7,
                         axionMmIf8,
                         bestAxion.confidence,
                         qr.confidence))
        } else {
            print(String(format: "📏 AxionCode size — QR class not detected on this frame; pixel size only: %.0f × %.0f (conf axion=%.2f)",
                         bestAxion.rect.width,
                         bestAxion.rect.height,
                         bestAxion.confidence))
        }
    }

    private func performLiveTiltCheck() {
        // Skip if QR already detected, or a tilt check is already in-flight,
        // or the app is backgrounded (no point running TFLite on stale frames).
        guard !isAppInBackground, !isQRCodeDetected, !isTiltChecking else { return }
        isTiltChecking = true

        captureFrameForValidation { [weak self] image in
            guard let self = self, let image = image else {
                self?.isTiltChecking = false
                return
            }

            Task.detached(priority: .utility) {
                do {
                    let detections = try TFLiteInference.run(
                        on: image,
                        modelName: "model",
                        bundle: AxionBundle.bundle
                    )

                    // Per-frame physical-size log for the AxionCode. Fires
                    // silently on frames without an AxionCode detection
                    // (still very common while framing), so no console
                    // spam when the user is pointing at the background.
                    self.logAxionCodePhysicalSizeIfPresent(from: detections)

                    let (isTilted, angle) = self.checkRotation(detections: detections)

                    // Reuse the same detection pass to drive auto-zoom — the
                    // patterns rect tells us exactly how big the QR currently
                    // appears, so we can nudge the lens until it just fills
                    // the scan window.
                    let patternRects = detections
                        .filter { $0.classId == YOLOClass.pattern.rawValue }
                        .map { $0.rect }
                    let frameSize = CGSize(
                        width: image.cgImage?.width ?? Int(image.size.width),
                        height: image.cgImage?.height ?? Int(image.size.height)
                    )
                    let frameLong = CGFloat(max(image.cgImage?.width  ?? Int(image.size.width),
                                                image.cgImage?.height ?? Int(image.size.height)))

                    // "Far" = the patterns are tiny relative to the frame, AND auto-zoom has
                    // already gone almost all the way to maxZoom trying to fix it. Combining
                    // both signals avoids false positives while auto-zoom is still ramping up
                    // at the start of a scan.
                    //
                    // Threshold picked empirically:
                    //   - autoZoomTargetFraction = 0.90 of scanWindowSize.width (250pt) inside
                    //     a ~850pt preview = target ~26% of the frame's longest dim.
                    //   - Even at the 8x maxZoom, the smallest we can let patterns get and
                    //     still hit that target is ~26 / 8 ≈ 3.3%. We use 5% to leave headroom
                    //     so we only fire the "far" message when there's genuinely no way for
                    //     auto-zoom to save us.
                    // ── Far-distance gate + DIAGNOSTICS ────────────────────
                    // Compute multiple candidate "size" signals from YOLO
                    // and log them all every tick so you can pick the one
                    // that tracks distance best:
                    //   • patternUnion — union of all 6 pattern rects
                    //     (current decision driver; falls apart when YOLO
                    //     misses patterns at far range)
                    //   • qrBox        — the single QR-class rect, the most
                    //     direct measure of "how big does the code look"
                    //   • axionBox     — AxionCode-class rect
                    //   • alignBox     — AlignmentPattern-class rect
                    //
                    // Each is reported as a fraction of the frame's longest
                    // dim, so they're directly comparable.
                    //
                    // Read the console while holding "too far" — whichever
                    // value reliably stays small at far range and grows at
                    // close range is the one to drive the decision from.
                    let patternCountForFar = patternRects.count

                    func bestRect(for classId: Int) -> CGRect? {
                        detections
                            .filter { $0.classId == classId }
                            .sorted { $0.confidence > $1.confidence }
                            .first?
                            .rect
                    }
                    func fraction(of rect: CGRect?) -> CGFloat {
                        guard let r = rect, !r.isNull, frameLong > 0 else { return 0 }
                        return max(r.width, r.height) / frameLong
                    }

                    let patternUnionRect = patternRects.reduce(CGRect.null) { $0.union($1) }
                    let qrRect       = bestRect(for: YOLOClass.qr.rawValue)
                    let axionRect    = bestRect(for: YOLOClass.axionCode.rawValue)
                    let alignRect    = bestRect(for: YOLOClass.alignmentPattern.rawValue)

                    let patternFraction = fraction(of: patternUnionRect.isNull ? nil : patternUnionRect)
                    let qrFraction      = fraction(of: qrRect)
                    let axionFraction   = fraction(of: axionRect)
                    let alignFraction   = fraction(of: alignRect)

                    // Current decision still uses the pattern-union signal —
                    // change the line below once you've picked a better
                    // signal from the log (e.g. swap `patternFraction` for
                    // `qrFraction`, or take the max of several).
                    let countOK          = patternCountForFar >= 2
                    let frameOK          = frameLong > 0
            
                    let fractionTooSmall = patternFraction < 0.05
                    let zoomNearMax      = self.currentZoom >= (self.maxZoom * 0.85)
                    let isUserFar        = countOK && frameOK && fractionTooSmall && zoomNearMax

                    print(String(
                        format: "🔭 far-check: frameLong=%.0f zoom=%.2f (max=%.2f, nearMaxThr=%.2f) | counts: patterns=%d qr=%@ axion=%@ align=%@ | fractions: patternUnion=%.4f qr=%.4f axion=%.4f align=%.4f | gates: countOK=%@ fractionTooSmall=%@ zoomNearMax=%@ → isUserFar=%@",
                        frameLong,
                        self.currentZoom,
                        self.maxZoom,
                        self.maxZoom * 0.85,
                        patternCountForFar,
                        qrRect    == nil ? "0" : "1",
                        axionRect == nil ? "0" : "1",
                        alignRect == nil ? "0" : "1",
                        patternFraction,
                        qrFraction,
                        axionFraction,
                        alignFraction,
                        countOK          ? "Y" : "N",
                        fractionTooSmall ? "Y" : "N",
                        zoomNearMax      ? "Y" : "N",
                        isUserFar        ? "Y" : "N"
                    ))
                    
                    
                    await MainActor.run {
                        self.isTiltChecking = false

                        // Auto-zoom regardless of tilt status — getting the
                        // patterns into the box is the first thing the user
                        // needs help with.
                        self.maybeApplyAutoZoom(patternRects: patternRects, frameSize: frameSize)

                        // ── QR-in-scan-window gate ─────────────────────
                        // If YOLO found a QR-class rect, check how much
                        // of it is inside the four-corner overlay. Less
                        // than `qrInScanWindowMinOverlap` → block the
                        // scan timer until the user re-frames.
                        //
                        // When YOLO found NO QR-class rect, treat it as
                        // "no reason to block" so existing gates
                        // (motion/focus/sharpness) apply unchanged.
                        let wasInWindow = self.isQRSufficientlyInScanWindow
                        let inWindowNow: Bool
                        if let qr = qrRect {
                            let overlap = self.qrToScanWindowOverlap(
                                yoloRect: qr,
                                bufferLandscapeSize: frameSize)
                            print(String(format: "🪟 qr-in-window overlap=%.2f (threshold=%.2f)",
                                         overlap, self.qrInScanWindowMinOverlap))
                            inWindowNow = overlap >= self.qrInScanWindowMinOverlap
                        } else {
                            // No QR detected at all — don't hold the
                            // gate based on stale state.
                            inWindowNow = true
                        }
                        self.isQRSufficientlyInScanWindow = inWindowNow
                        if wasInWindow && !inWindowNow {
                            // Falling edge: cancel active timer + reset
                            // the progress bar so the user sees the
                            // countdown stop. `pendingScanTimerStart`
                            // stays true so we auto-resume once they
                            // re-frame.
                            self.cancelActiveScanTimer()
                            self.progressDisplayLink?.invalidate()
                            self.progressDisplayLink = nil
                            self.scanProgressView?.setProgress(0, animated: false)
                            print("⏸ scan timer cancelled — QR not sufficiently in scan window")
                        } else if !wasInWindow && inWindowNow {
                            // Rising edge: user re-framed, try to arm
                            // the timer again (still subject to the
                            // other gates).
                            print("▶️ QR back in scan window — re-evaluating gate")
                            self.reevaluateScanTimerGate()
                        }

                        // Only update label if we're still in idle scanning state
                        guard !self.isQRCodeDetected else { return }

                        // Sharpness / focus messages take priority — if the
                        // frame isn't capture-ready yet, tell the user that
                        // first so they don't think the app is broken.
                        if self.isAutoFocusAdjusting {
                            self.instructionLabel.text = "Focusing…"
                            self.instructionLabel.textColor = .yellow
                            return
                        }
                        // "Too close" guidance takes priority over the
                        // generic "waiting for sharp focus" hint — when
                        // the lens is parked at the near-focus limit no
                        // amount of waiting will resolve the blur. Tell
                        // the user to physically move back.
                        if self.userIsTooCloseToFocus {
                            self.instructionLabel.text = "Move phone slightly farther away"
                            self.instructionLabel.textColor = .yellow
                            return
                        }
                        if !self.isFrameSharp {
                            self.instructionLabel.text = "Hold steady — waiting for sharp focus"
                            self.instructionLabel.textColor = .yellow
                            return
                        }

                        if isUserFar {
//                            self.instructionLabel.text = "You are far. Come closer"
//                            self.instructionLabel.textColor = .yellow
                            return
                        }
                        if isTilted {
                            // angle > 0 means right side is LOWER → user needs to rotate counter-clockwise (left)
                            // angle < 0 means left side is LOWER → user needs to rotate clockwise (right)
                            let instruction = angle > 0 ? "Rotate slightly left ↺" : "Rotate slightly right ↻"
                            self.instructionLabel.text = instruction
                            self.instructionLabel.textColor = .yellow
                        } else if !detections.isEmpty {
                            // Detections exist but not tilted — show normal hint
                            self.instructionLabel.text = "Hold steady — scanning…"
                            self.instructionLabel.textColor = .white
                        } else {
                            // Nothing detected at all — reset to default
                            self.instructionLabel.text = "Make sure the QR Code is centred\nand clearly visible"
                            self.instructionLabel.textColor = .white
                        }
                    }
                } catch {
                    await MainActor.run {
                        self.isTiltChecking = false
                    }
                    print("⚠️ Live tilt check error: \(error.localizedDescription)")
                }
            }
        }
    }

    // MARK: - Auto-zoom (fit YOLO patterns into the scan window)
    /// Given the 6 (or more) Pattern rects from YOLO and the size of the frame
    /// they were detected in, nudge videoZoomFactor so the patterns occupy
    /// roughly `autoZoomTargetFraction` of the scan window. Bails out if the
    /// user has touched the slider — once a user takes manual control we keep
    /// out of their way for the rest of the session (resets on
    /// `resetDetection`).
    private func maybeApplyAutoZoom(patternRects: [CGRect], frameSize: CGSize) {
        // Respect manual override permanently until reset.
        guard !userZoomOverride else { return }
        // Don't ramp the zoom while the user is framing the code OUTSIDE
        // the scan window — otherwise auto-zoom climbs to e.g. 4.3x on
        // a code that's at the top of the preview, and when the user
        // re-frames into the brackets the code is now too zoomed and
        // blurred to decode. Same gate the scan timer uses; the moment
        // the user re-frames so the QR overlaps the window, the next
        // performLiveTiltCheck tick flips this back to true and auto-
        // zoom resumes from whatever zoom factor we'd reached so far.
        guard isQRSufficientlyInScanWindow else {
            print("🔭 auto-zoom skipped — QR not sufficiently inside scan window")
            return
        }
        // Need at least 4 patterns to have a stable bounding-box estimate
        // (occasionally one pattern is occluded or below the conf threshold).
        guard patternRects.count >= 4 else { return }
        guard videoDevice != nil else { return }
        guard frameSize.width > 0, frameSize.height > 0 else { return }

        // Throttle — don't ride the lens motor harder than necessary.
        let now = CACurrentMediaTime()
        if now - lastAutoZoomTime < autoZoomInterval { return }

        // Union of all pattern rects in the raw frame's pixel coords.
        let union = patternRects.reduce(CGRect.null) { $0.union($1) }
        guard !union.isNull, union.width > 0, union.height > 0 else { return }

        // Compare longest-dim → longest-dim so orientation doesn't matter.
        // The patterns form a square arrangement around the QR, so taking
        // max(width, height) gives a stable estimate of the QR's apparent size.
        let patternLong = max(union.width, union.height)
        let frameLong = max(frameSize.width, frameSize.height)
        let currentFraction = patternLong / frameLong
        guard currentFraction > 0 else { return }

        // Target = scan window's longest dim relative to the preview's longest
        // dim, scaled down by the desired fill (0.90 → patterns at ~90% of the
        // box, matching the reference screenshot's tight fit).
        let previewBounds = previewView?.bounds ?? view.bounds
        let previewLong = max(previewBounds.width, previewBounds.height)
        guard previewLong > 0 else { return }
        let scanLong = max(scanWindowSize.width, scanWindowSize.height)
        let targetFraction = (scanLong * autoZoomTargetFraction) / previewLong

        let ratio = targetFraction / currentFraction

        // INCREASE-ONLY policy: auto-zoom exists to help users who are too
        // far away (patterns appear small in the frame). If the patterns
        // are already at or above the target size, we leave the camera
        // alone — pulling the zoom back would visually fight a user who is
        // already in a good position.
        //
        //   ratio > 1.0  → patterns too small → zoom IN (continue)
        //   ratio ≤ 1.0  → patterns large enough → leave zoom alone (bail)
        guard ratio > 1.0 else {
            lastAutoZoomTime = now
            return
        }

        // Deadband — ignore small "needs zoom-in" ratios so the camera
        // doesn't hunt by ±0.1x between checks.
        guard (ratio - 1.0) > autoZoomDeadband else {
            // We're within the deadband, treat as "fitted" and stop touching
            // the lens. Still update the throttle timestamp so we don't spam
            // the deadband check.
            lastAutoZoomTime = now
            return
        }

        var newZoom = currentZoom * ratio
        // Clamp per-step movement for smooth visual transition. Lower bound
        // is currentZoom itself (not currentZoom - autoZoomMaxStep) because
        // we never want this code path to produce a smaller zoom value.
        newZoom = max(currentZoom, min(currentZoom + autoZoomMaxStep, newZoom))
        // Clamp to device-supported range.
        newZoom = max(minZoom, min(maxZoom, newZoom))

        // Skip no-op changes after clamping.
        guard abs(newZoom - currentZoom) > 0.05 else {
            lastAutoZoomTime = now
            return
        }

        lastAutoZoomTime = now
        currentZoom = newZoom
        zoomSlider?.setValue(Float(newZoom), animated: true)
        zoomLabel?.text = String(format: "%.1fx", newZoom)
        setZoom(newZoom)
        // Lens is about to move — assume we'll need to re-focus, so drop the
        // sharpness flag and let the gate re-arm when it settles.
        isFrameSharp = false
        print("🔭 auto-zoom \(String(format: "%.2f", currentFraction))→target \(String(format: "%.2f", targetFraction)) ⇒ \(String(format: "%.1fx", newZoom))")
    }
    private func checkRotation(detections: [Detection]) -> (isTilted: Bool, angle: Double) {
        let patterns = detections
            .filter { $0.classId == YOLOClass.pattern.rawValue }
            .sorted { $0.rect.minX < $1.rect.minX } // left → right, consistent ordering

        guard patterns.count >= 2 else {
            return (false, 0)
        }

        // Use leftmost and rightmost pattern for the most stable baseline
        let leftPattern  = patterns.first!
        let rightPattern = patterns.last!

        let p1 = CGPoint(x: leftPattern.rect.midX,  y: leftPattern.rect.midY)
        let p2 = CGPoint(x: rightPattern.rect.midX, y: rightPattern.rect.midY)

        // Angle of the line from left pattern → right pattern relative to horizontal
        // Positive angle = tilted right (clockwise), Negative = tilted left (counter-clockwise)
        let angle = atan2(p2.y - p1.y, p2.x - p1.x) * 180 / .pi

        print("🔄 Tilt angle: \(String(format: "%.1f", angle))° (left:\(p1), right:\(p2))")

        let isTilted = abs(angle) > 15.0 // raise from 10° to reduce false positives
        return (isTilted, Double(angle))
    }
    
    // MARK: - TFLite Validation (no UI drawing, just class check)
    private func validateWithObjectDetection(completion: @escaping (_ hasAllClasses: Bool, _ image: UIImage?) -> Void) {
        guard let device = videoDevice else {
            completion(false, nil)
            return
        }

        // Capture a live frame for detection
        captureFrameForValidation { [weak self] image in
            guard let self = self, let image = image else {
                completion(false, nil)
                return
            }

            Task {
                do {
                    let detections = try TFLiteInference.run(
                        on: image,
                        modelName: "model",
                        bundle: AxionBundle.bundle
                    )

                    // Count detections per class. We need the FULL layout
                    // present, not just at-least-one-of-each — the printed
                    // AxionCode has a fixed geometry:
                    //   • alignmentPattern × 1  (the band above the QR)
                    //   • axionCode        × 1  (the whole-code outer box)
                    //   • pattern          × 6  (the 6 outer QR-like squares)
                    //   • qr               × 1  (the central QR)
                    // Total: 9 detections. Anything less means one of the
                    // patterns is occluded, out of frame, or misdetected —
                    // in which case /validate/ would receive a partial crop
                    // and the server's authenticity model would judge
                    // against incomplete data.
                    //
                    // For `pattern` specifically we require AT LEAST 6
                    // (not exactly 6) — YOLO occasionally double-detects
                    // one of the outer squares with two overlapping boxes
                    // at slightly different confidences before NMS trims
                    // them. Requiring "== 6" would spuriously reject
                    // those otherwise-valid frames. All other classes are
                    // required to be exactly 1 for the same reason: a
                    // second axionCode / QR / alignment band in frame
                    // would mean the user's pointing at two codes at
                    // once, which we don't want to validate.
                    let counts = Dictionary(grouping: detections, by: { $0.classId })
                        .mapValues { $0.count }
                    let alignCount = counts[YOLOClass.alignmentPattern.rawValue] ?? 0
                    let axionCount = counts[YOLOClass.axionCode.rawValue]         ?? 0
                    let patternCount = counts[YOLOClass.pattern.rawValue]         ?? 0
                    let qrCount    = counts[YOLOClass.qr.rawValue]                ?? 0
                    let totalCount = alignCount + axionCount + patternCount + qrCount

                    let hasAllClasses =
                        alignCount   == 1 &&
                        axionCount   == 1 &&
                        patternCount >= 6 &&
                        qrCount      == 1

                    print(String(format: "🔍 TFLite class counts — align=%d axion=%d pattern=%d qr=%d (total=%d)",
                                 alignCount, axionCount, patternCount, qrCount, totalCount))
                    print("🔍 Required: align=1, axion=1, pattern≥6, qr=1 (total ≥ 9)")
                    print("🔍 hasAllClasses = \(hasAllClasses)")

                    DispatchQueue.main.async {
                        // Pass the same frame we just analysed back to the
                        // caller so it can hand it to the /validate/ fallback
                        // without spending another capture round-trip.
                        completion(hasAllClasses, image)
                    }
                } catch {
                    print("❌ TFLite detection error: \(error.localizedDescription)")
                    DispatchQueue.main.async {
                        completion(false, nil)
                    }
                }
            }
        }
    }

    // MARK: - Capture single frame for TFLite (no photo delegate, no freeze)
    private func captureFrameForValidation(completion: @escaping (UIImage?) -> Void) {
        // Use the video data output to grab the latest pixel buffer
        // We do this by temporarily storing a one-shot callback.
        //
        // RACE GUARD: if a previous one-shot completion is still pending (e.g.
        // a live tilt check is waiting for the next frame and `scanTimerFired`
        // races in with `validateWithObjectDetection`), release the old one
        // with `nil` first. Without this the old caller's cleanup never runs
        // — that's how `isTiltChecking` used to get stuck at `true` after the
        // first scan and auto-zoom would stop working.
        if let existing = self.validationFrameCompletion {
            self.validationFrameCompletion = nil
            DispatchQueue.main.async { existing(nil) }
        }
        self.validationFrameCompletion = completion
    }

    // Add this property at the top of your class alongside other properties:
    // private var validationFrameCompletion: ((UIImage?) -> Void)?
    // MARK: - AVCapturePhotoCaptureDelegate
    // MARK: - AVCapturePhotoCaptureDelegate
//    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
//        if let error = error {
////            print("❌ Photo processing error: \(error.localizedDescription)")
//            ProgressHUD.shared.hide()
//            resetDetection()
//            return
//        }
//        
//        guard let imageData = photo.fileDataRepresentation() else {
//            print("❌ Could not get image data")
//            ProgressHUD.shared.hide()
//            resetDetection()
//            return
//        }
//        
//        print("✅ Captured photo successfully")
//        
//        // Process the image
//        guard let ciImage = CIImage(data: imageData) else {
//            print("❌ Could not create CIImage from data")
//            ProgressHUD.shared.hide()
//            resetDetection()
//            return
//        }
//        
//        DispatchQueue.global(qos: .userInitiated).async {
//            // Save original for debugging
//            let context = CIContext()
//            if let cgImage = context.createCGImage(ciImage, from: ciImage.extent) {
//                let originalImage = UIImage(cgImage: cgImage)
////                UIImageWriteToSavedPhotosAlbum(originalImage, nil, nil, nil)
//            }
//            
//            // Try multiple cropping methods
//            var croppedImage: UIImage?
//            
//            // Method 1: Enhanced CIDetector with scale/rotation
//            croppedImage = self.cropSquareNow(ciImage)
//            
//            // Method 2: Fallback to Vision bounds if available
//            if croppedImage == nil, let detected = self.detectedBarcode {
//                print("🔄 Falling back to Vision-based cropping")
//                croppedImage = self.cropUsingVisionObservation(ciImage, observation: detected)
//            }
//            
//            // Method 3: Last resort - center crop
//            if croppedImage == nil {
//                print("🔄 Using center crop as last resort")
//                croppedImage = self.manualCenterCrop(ciImage)
//            }
//            
//            guard let finalImage = croppedImage else {
//                print("❌ All cropping methods failed")
//                DispatchQueue.main.async {
//                    ProgressHUD.shared.hide()
//                    self.instructionLabel.text = "Failed to process image"
//                    self.resetDetection()
//                }
//                return
//            }
//            
//            // Save cropped image for verification
//            UIImageWriteToSavedPhotosAlbum(finalImage, nil, nil, nil)
//            
//            // Check image quality
//
//            if !self.isImageBlurry(finalImage, threshold: 70) {
//                DispatchQueue.main.async {
//                    self.sendImagetoModelAPI(image: finalImage, testingLabel: self.testingLabel) { result in
//                        switch result {
//                        case .success(let src):
//                            print("Image uploaded successfully. Source URL: \(src)")
//                        case .failure(let error):
//                            print("Error uploading image: \(error.localizedDescription)")
//                        }
//                    }
//                    self.instructionLabel.text = "Capture Complete!"
//                }
//            }
//            else {
//                print("❌ Cropped image is blurry")
//                DispatchQueue.main.async {
//                    self.instructionLabel.text = "Image is blurry - try holding steady"
//                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
//                        ProgressHUD.shared.hide()
//                        self.resetDetection()
//                    }
//                }
//            }
//        }
//    }
    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
        if let error = error {
            print("❌ Photo processing error: \(error.localizedDescription)")
            ProgressHUD.shared.hide()
            resetDetection()
            return
        }

        guard let imageData = photo.fileDataRepresentation() else {
            print("❌ Could not get image data")
            ProgressHUD.shared.hide()
            resetDetection()
            return
        }

        print("✅ Captured photo successfully")

        guard let ciImage = CIImage(data: imageData) else {
            print("❌ Could not create CIImage from data")
            ProgressHUD.shared.hide()
            resetDetection()
            return
        }

        // /VALIDATE/ PHOTO HOOK ─────────────────────────────────────────
        // scanTimerFired's hasAllClasses branch installs
        // `pendingValidatePhotoCompletion` before triggering capturePhoto(),
        // so the resulting high-res CIImage is routed to /validate/ upload
        // with photo-output native resolution (~4032×3024). The /predict/
        // pipeline below MUST NOT run in that case — those two paths are
        // mutually exclusive per capture.
        if let validateCompletion = self.pendingValidatePhotoCompletion {
            self.pendingValidatePhotoCompletion = nil
            print("🛟 photoOutput → pendingValidatePhotoCompletion (/validate/ high-res path)")
            validateCompletion(ciImage)
            return
        }

        // FAKE-PATH HOOK ────────────────────────────────────────────────
        // Legacy hook used by the older fake-flow: same mechanism as
        // above but for a different callsite. Kept intact for whichever
        // code path still relies on it.
        if let fakeCompletion = self.pendingFakePhotoCompletion {
            self.pendingFakePhotoCompletion = nil
        self.pendingValidatePhotoCompletion = nil
            print("🛟 photoOutput → pendingFakePhotoCompletion (fake path)")
            fakeCompletion(ciImage)
            return
        }

        Task.detached(priority: .userInitiated) {
            // Step 1: Convert full photo to UIImage for TFLite validation
            let context = CIContext()
//            guard let cgFull = context.createCGImage(ciImage, from: ciImage.extent) else {
//                print("❌ Could not create CGImage from full CIImage")
//                DispatchQueue.main.async {
//                    ProgressHUD.shared.hide()
//                    self.resetDetection()
//                }
//                return
//            }
//            let fullImage = UIImage(cgImage: cgFull, scale: 1.0, orientation: .up)
//
//            // Step 2: Validate patterns on the FULL captured frame (not the crop)
//            // This ensures we're checking the actual photo taken, not a crop
//            // derived from a potentially stale/moved bounding box
//            let patternsValid = await self.validatePatternBoxes(fullImage)
//            guard patternsValid else {
//                await self.showToast(message: "QR pattern incomplete — try again")
//                print("❌ Pattern validation failed on full frame — skipping sendImagetoModelAPI")
//                DispatchQueue.main.async {
//                    ProgressHUD.shared.hide()
//                    self.instructionLabel.text = "QR pattern incomplete — try again"
//                    DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
//                        self.resetDetection()
//                    }
//                }
//                return
//            }
//
//            print("✅ Pattern validation passed on full frame — proceeding to crop")
//
//            // Step 3: Now crop using the stored bounding box (patterns confirmed present)
//            var finalImage = self.cropSquareNow(ciImage)
//
//            // Only fall back to center crop if primary fails
//            if finalImage == nil {
//                print("⚠️ cropSquareNow failed — using center crop fallback")
//                finalImage = self.manualCenterCrop(ciImage)
//            }
//
//            guard let imageToSend = finalImage else {
//                print("❌ All cropping methods failed")
//                DispatchQueue.main.async {
//                    ProgressHUD.shared.hide()
//                    self.instructionLabel.text = "Failed to process image"
//                    self.resetDetection()
//                }
//                return
//            }
            // --- NEW STEP 1: CROP FIRST ---
                // We attempt to crop based on the Vision bounding box detected earlier
                var croppedImage = self.cropSquareNow(ciImage)

                // Fallback to center crop if the Vision-based crop fails
                if croppedImage == nil {
                    print("⚠️ cropSquareNow failed — using center crop fallback")
                    croppedImage = self.manualCenterCrop(ciImage)
                }

                guard let imageToValidate = croppedImage else {
                    print("❌ All cropping methods failed")
                    DispatchQueue.main.async {
                                ProgressHUD.shared.hide()
                                self.instructionLabel.text = "Failed to process image"
                                self.resetDetection()
                            }
                    return
                }
            if self.isRunningInTestFlight() {
                // Save cropped image for verification/debugging
                //TODO
//                UIImageWriteToSavedPhotosAlbum(imageToValidate, nil, nil, nil)
            }
                // --- NEW STEP 2: VALIDATE ON THE CROP ---
                // Run the TFLite pattern check on the small, cropped image.
                // Vision has already decoded the QR by the time we get here
                // (that's literally what armed the scan timer), so the
                // strongest "this is a real QR" signal has already fired.
                // The pattern-box check is now ADVISORY ONLY by default — we
                // log its verdict for crop tuning, but never block the
                // upload on it. The previous hard-gate behaviour was firing
                // the "QR pattern incomplete — try again" toast even on
                // perfectly framed scans, just because the crop padding
                // wasn't generous enough to keep all 6 outer pattern boxes
                // whole. Users were bouncing off it repeatedly even though
                // their framing was fine.
                //
                // To restore the hard gate while debugging crops, flip
                // `enforcePatternBoxValidation` to `true` at the top of the
                // class. See its doc comment for the full rationale.
                let patternsValid = await self.validatePatternBoxes(imageToValidate)
                if patternsValid {
                    print("✅ Pattern validation passed on the crop!")
                } else if self.enforcePatternBoxValidation {
                    print("❌ Pattern validation failed on the CROPPED image — blocking (enforcePatternBoxValidation=true)")
                    await self.showToast(message: "QR pattern incomplete — try again")
                    DispatchQueue.main.async {
                        ProgressHUD.shared.hide()
                        self.instructionLabel.text = "QR pattern incomplete — try again"
                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
                            self.resetDetection()
                        }
                    }
                    return
                } else {
                    print("ℹ️ Pattern validation failed on the CROPPED image — proceeding anyway (enforcePatternBoxValidation=false). Server /predict/ will be the authoritative judgement.")
                }

                // Pattern validated — stop the guidance audio immediately.
                self.audioQueue.async { [weak self] in
                    self?.audioPlayer?.stop()
                    self?.audioPlayer = nil
                }




            // Step 4: Blur check on the cropped image
            if !self.isImageBlurry(imageToValidate, threshold: 70) {
                DispatchQueue.main.async {
                    // QR is validated and we're about to upload — kill motion
                    // monitoring so the accelerometer/gyro updates aren't
                    // pu\relevant scan-timer gate while the
                    // network request is in flight. Re-armed by the next
                    // resetDetection()/restartScan() if the user scans again.
                    self.stopMotionMonitoring()
                    self.sendImagetoModelAPI(image: imageToValidate, testingLabel: self.testingLabel) { result in
                        switch result {
                        case .success(let src):
                            print("✅ Image uploaded successfully. Source URL: \(src)")
                        case .failure(let error):
                            print("❌ Error uploading image: \(error.localizedDescription)")
                        }
                    }
                    self.instructionLabel.text = "Capture Complete!"
                }
            } else {
                print("❌ Cropped image is blurry")
                DispatchQueue.main.async {
                    self.instructionLabel.text = "Image is blurry - try holding steady"
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
                        ProgressHUD.shared.hide()
                        self.resetDetection()
                    }
                }
            }
        }
    }
    // MARK: - Helper Methods
    private func resetDetection() {
        self.zoomLabel.text = "3.5x"
        // 1. Cancel any pending operations
        NSObject.cancelPreviousPerformRequests(withTarget: self)
        processingTimer?.invalidate()
        processingTimer = nil
        self.startScanTimer()
        // 2. Reset all detection states
        isQRCodeDetected = false
        detectedBarcode = nil
        lastBarcode = nil
        // Show the overlay guide again — see restartScan() for the same.
        overlayImageView?.isHidden = false
        performRequestCount = 0
        currentZoom = 3.5 // Reset zoom to 3.5x (raised from 2.5x for wide-only camera + higher MFD headroom)
        // Clear focus/sharpness/auto-zoom state — see restartScan() for the
        // rationale on reading device.isAdjustingFocus rather than forcing
        // `true` (otherwise the gate stays blocked forever after the first scan).
        userZoomOverride = false
        lastAutoZoomTime = 0
        isFrameSharp = false
        consecutiveSharpProbes = 0
        userIsTooCloseToFocus = false
        isAutoFocusAdjusting = videoDevice?.isAdjustingFocus ?? false
        lastSharpnessCheckTime = 0
        // Far-detection state — see restartScan() for the same reset.
        isUserCurrentlyFar = false
        consecutiveFarFrames = 0
        consecutiveCloseFrames = 0
        lastFarCheckTime = 0
        isFarDetectionInflight = false
        // Same reasoning — release the tilt-check guard so auto-zoom resumes.
        isTiltChecking = false
        // Always start a fresh scan at the default 6s window — see
        // restartScan() for the same reset.
        scanInterval = scanIntervalDefault
        isInExtendedScanMode = false
        // Discard any unconsumed validation-path capture closure — see
        // restartScan() for the same reset.
        pendingFakePhotoCompletion = nil
        // Pre-capture validation state — see attemptPreCaptureValidation.
        // Same reset restartScan does so a re-scan after an error alert
        // starts from a clean loop state.
        preCaptureValidationAttempts = 0
        isCommittedToCapture = false

        DispatchQueue.main.async {
            // 3. Reset UI
            self.instructionLabel.text = "Point camera at a QR code"
            self.instructionLabel.textColor = .red
            self.updateDetectionStatus(isDetected: false)
            self.zoomSlider.value = Float(self.currentZoom) // Reset slider position
            
            // Update zoom label if you added it
            // self.zoomLabel.text = "2.5x"
            
            // 4. Handle device configuration
            guard let device = self.videoDevice else { return }
            
            do {
                try device.lockForConfiguration()

                // Reset zoom to 2.5x
                device.videoZoomFactor = 3.5

                // Same continuous-AF/AE reset as restartScan() — see the
                // matching block there for the rationale. Without this,
                // the lens stays locked at the just-rejected frame's
                // distance and the next capture round is again blurry.
                if device.isFocusModeSupported(.continuousAutoFocus) {
                    device.focusMode = .continuousAutoFocus
                } else if device.isFocusModeSupported(.autoFocus) {
                    device.focusMode = .autoFocus
                }
                if device.isExposureModeSupported(.continuousAutoExposure) {
                    device.exposureMode = .continuousAutoExposure
                } else if device.isExposureModeSupported(.autoExpose) {
                    device.exposureMode = .autoExpose
                }
                print("🎯 resetDetection: focus/exposure → continuous")

                // NOTE: previous "maintain torch state" logic was
                // gated on `device.isTorchActive`, which is FALSE
                // whenever the session has been stopped (e.g. after
                // the result VC was pushed). That meant the torch was
                // never re-engaged on a fresh scan, which is the
                // "icon ON but LED OFF" desync bug.
                // engageTorchAfterRestart() below forces the LED on
                // and resyncs the button regardless of the prior state.

                device.unlockForConfiguration()
                print("✅ Device reset with 3.5x zoom")

            } catch {
                print("❌ Could not reset device configuration: \(error)")
            }

            // 5. Restart session if needed, then re-engage torch + sync
            // button. Same shape as restartScan() — see that block and
            // engageTorchAfterRestart() for the rationale.
            if let session = self.captureSession, !session.isRunning {
                DispatchQueue.global(qos: .userInitiated).asyncAfter(deadline: .now() + 0.1) {
                    session.startRunning()
                    print("✅ Capture session restarted with 3.5x zoom")
                    self.engageTorchAfterRestart()
                }
            } else {
                self.engageTorchAfterRestart()
            }
            
            // 6. Re-enable preview
            self.videoPreviewLayer.connection?.isEnabled = true
        }
    }
    

    
    func sendImagetoModelAPI(image: UIImage, testingLabel: String, completion: @escaping (Result<String, Error>) -> Void) {
        let imageToSend: UIImage = {
               let size = CGSize(width: image.size.height, height: image.size.width)
               UIGraphicsBeginImageContextWithOptions(size, false, image.scale)
               let context = UIGraphicsGetCurrentContext()!
               // Move origin to center, rotate, then draw
               context.translateBy(x: size.width / 2, y: size.height / 2)
               context.rotate(by: .pi / 2) // 90° clockwise
               image.draw(in: CGRect(
                   x: -image.size.width / 2,
                   y: -image.size.height / 2,
                   width: image.size.width,
                   height: image.size.height
               ))
               let rotated = UIGraphicsGetImageFromCurrentImageContext()!
               UIGraphicsEndImageContext()
               return rotated
           }()
        // Sharpen the rotated upload image before JPEG encoding. Gated by
        // `applyUnsharpenForUpload` — falls through unchanged if disabled
        // or if any CIFilter step fails.
        let imageToSendSharp = self.sharpenedForUpload(imageToSend)

        let boundary = "Boundary-\(UUID().uuidString)"
        if self.isRunningInTestFlight() {
            UIImageWriteToSavedPhotosAlbum(imageToSendSharp, nil, nil, nil)
        }
        // Prepare the multipart form data
        var body = Data()

        // Add image data to the request
        let filename = "uploaded_image.jpg"
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"file\"; filename=\"\(filename)\"\r\n".data(using: .utf8)!)
        body.append("Content-Type: image/jpeg\r\n\r\n".data(using: .utf8)!)

        guard let imageData = imageToSendSharp.jpegData(compressionQuality: self.uploadJpegQuality) else {
            completion(.failure(NSError(domain: "ImageError", code: -1, userInfo: [NSLocalizedDescriptionKey: "Failed to convert image to JPEG"])))
            return
        }
        print(String(format: "📤 /predict/ JPEG payload bytes=%d quality=%.2f sharpen=%@",
                     imageData.count, Double(self.uploadJpegQuality),
                     self.applyUnsharpenForUpload ? "Y" : "N"))

        body.append(imageData)
        body.append("\r\n".data(using: .utf8)!)
        body.append("--\(boundary)--\r\n".data(using: .utf8)!)

        // Create the request
        //prod
//        164.52.221.51:9000/docs#/
//        var request = URLRequest(url: URL(string: "http://3.7.254.234:8089/predict/")!)
        //june2
        //staging
       var request = URLRequest(url: URL(string: "http://164.52.221.51:9000/predict/")!)
//        var request = URLRequest(url: URL(string: "http://13.203.201.117:8080/predict/")!)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "accept")
        request.setValue("asdnkj62df21asd1", forHTTPHeaderField: "auth-id")
        request.setValue("asf1323sfa6s5", forHTTPHeaderField: "auth-token")
        let appInfo = Bundle.main.infoDictionary
//        request.setValue("sdnakjdnlasnd", forHTTPHeaderField: "auth-id")
//        request.setValue("asdhagsdh7878q22", forHTTPHeaderField: "auth-token")
       
        // Printing type is now derived from the decoded QR code's first
        // character via `derivedPrintingTypeFromDetectedQR()` ('d'/'e'
        // → digital, 'o' → offset, anything else → digital). This
        // overrides the host-app-supplied `self.printingType` for the
        // /predict/ call site so the server gets a consistent value
        // based on the actual QR encoding.
        request.setValue(testingLabel, forHTTPHeaderField: "Testinglabel")
        let derivedPrintingType = self.derivedPrintingTypeFromDetectedQR()
        request.setValue(derivedPrintingType, forHTTPHeaderField: "Printingtype")
        request.setValue(self.axionDeviceFamilyName(), forHTTPHeaderField: "DeviceFamily")
        request.setValue(self.axionPersistentDeviceId(), forHTTPHeaderField: "LinkedUserID")
        request.setValue("ios", forHTTPHeaderField: "DeviceType")
        request.setValue("\(appInfo?["CFBundleShortVersionString"] as? String ?? "-")(\(appInfo?[kCFBundleVersionKey as String] as? String ?? "-"))", forHTTPHeaderField: "AppVersion")

        // ── Device-state headers (new) ─────────────────────────────
        // BatteryLevel: integer percent string. UIDevice returns
        //   0.0–1.0 when monitoring is enabled (see viewDidLoad);
        //   -1.0 if disabled or unknown. We surface "-1" rather than
        //   coercing to 0% so the server can distinguish "no signal"
        //   from "completely flat battery".
        let batteryLevelRaw = UIDevice.current.batteryLevel  // 0.0–1.0 or -1.0
        let batteryLevelString: String = batteryLevelRaw >= 0
            ? "\(Int(round(batteryLevelRaw * 100)))"
            : "-1"
        request.setValue(batteryLevelString, forHTTPHeaderField: "BatteryLevel")

        // FlashStatus: "yes" / "no". Source of truth is the AVCapture-
        //   Device's `isTorchActive` — it reflects the actual hardware
        //   state (torch could be requested ON but thermally throttled
        //   OFF by iOS, for instance), which is what the server cares
        //   about. The class-level `torchMode` would also work but
        //   wouldn't catch thermal-throttle / hardware-off cases.
        //   videoDevice can technically be nil between setup and the
        //   first capture; default to "no" in that window — /predict/
        //   doesn't fire before viewDidAppear so the nil branch is
        //   essentially unreachable in practice, but it's harmless if
        //   it does take that path.
        let flashStatusString = (self.videoDevice?.isTorchActive ?? false) ? "yes" : "no"
        request.setValue(flashStatusString, forHTTPHeaderField: "FlashStatus")

        // AmbientLightLux: integer-string estimate sampled from the
        //   most recent video frame's EXIF BrightnessValue. See
        //   sampleAmbientLux() for the BV → lux conversion. Rounded
        //   to an integer because the server-side schema in the
        //   example takes a string like "15526", not "15526.42".
        let ambientLux = self.currentAmbientLuxEstimate()
        let ambientLuxString = "\(Int(round(ambientLux)))"
        request.setValue(ambientLuxString, forHTTPHeaderField: "AmbientLightLux")

        request.httpBody = body
        //        request.setValue("iphone SE", forHTTPHeaderField: "device-details")
        //TODO
//        request.setValue("test", forHTTPHeaderField: "DeviceType")
//        request.setValue("", forHTTPHeaderField: "DeviceFamily")
//        request.setValue("", forHTTPHeaderField: "LinkedUserID")


        print("Testinglabel: '\(testingLabel)'  Printingtype: '\(derivedPrintingType)' (derived from QR='\(self.detectedQRCodeValue ?? "nil")', host hint='\(self.printingType)')")
        print(String(format: "📊 /predict/ device state → battery=%@ flash=%@ AmbientLightLux=%@",
                     batteryLevelString, flashStatusString, ambientLuxString))
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            // Handle the response on main thread
            DispatchQueue.main.async {
                if let error = error {
                    self.showAlert(title: "Error", message: error.localizedDescription)
                    completion(.failure(error))
                    self.restartScan()
                    return
                }
                
                guard let httpResponse = response as? HTTPURLResponse else {
                    let error = NSError(domain: "NetworkError", code: -2, userInfo: [NSLocalizedDescriptionKey: "Invalid response"])
                    self.showAlert(title: "Error", message: "Invalid server response")
                    completion(.failure(error))
                    return
                }
                
                guard let data = data else {
                    let error = NSError(domain: "NetworkError", code: -3, userInfo: [NSLocalizedDescriptionKey: "No data received"])
                    self.showAlert(title: "Error", message: "No data received from server")
                    completion(.failure(error))
                    return
                }
                
                // Debug print the raw response
                let rawResponse = String(data: data, encoding: .utf8) ?? "Unable to decode response"
//                print("Raw response:", rawResponse)
//                self.showAlert(title: "Raw Response", message: rawResponse)
//                ProgressHUD.shared.hide()
                do {
                    let decoder = JSONDecoder()
                    let resp = try decoder.decode(PredictResponse.self, from: data)
                    let finalResult = resp.Data?.finalResult?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "Unknown"
                    let uuid = resp.Data?.uuid?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "Unknown"
                    print("Final Result from API: '\(finalResult)'")

                    // Decide whether original (case-insensitive)
                    var isOriginal = finalResult.lowercased() == "original"
//                    isOriginal = true
                    // Present result screen on main queue
//                    DispatchQueue.main.async {
//                        // hide any progress indicator first
//                        ProgressHUD.shared.hide()
//
//                        // instantiate and present the result VC
//                        let resultVC = ResultViewController(result: finalResult, isOriginal: isOriginal)
////                        self.restartScan()
//                        // present full-screen
//                        resultVC.scannerVC = self
//                        resultVC.modalPresentationStyle = .fullScreen
//                        // If this VC is inside a navigation controller you returned from wrapper,
//                        // present on the navigation controller if needed. Present from self.
//                        self.present(resultVC, animated: true)
//                    
//                    }
                    
                    if(isOriginal){
                        if self.isRunningInTestFlight() {
                            self.showToast(message: "Prediction - Original")
                        }
//                            self.uploadImage(image, imageType: "CROP",prediction: "original")
                        //bhar
            
                        self.makeApiCall_new(with: (12.948321152557963, 77.57733825952174),imageToSendSharp: imageToSendSharp, path: "IOS/com.acviss.app/0123459876/0123459876_17082020181440432.jpg", uCode: testingLabel, modelOutcome: "True", uuid: uuid)
                    }
                    else if (finalResult.lowercased() == "fake"){
                        if self.isRunningInTestFlight() {
                            self.showToast(message: "Prediction - Fake")
                        }

                        self.makeApiCall_new(with: (12.948321152557963, 77.57733825952174),imageToSendSharp: imageToSendSharp, path: "IOS/com.acviss.app/0123459876/0123459876_17082020181440432.jpg", uCode: testingLabel, modelOutcome: "False", uuid: uuid)
                    }
                    else{
                        if self.isRunningInTestFlight() {
                            self.showToast(message: finalResult)
                        }

                        self.makeApiCall_new(with: (12.948321152557963, 77.57733825952174),imageToSendSharp: imageToSendSharp, path: "IOS/com.acviss.app/0123459876/0123459876_17082020181440432.jpg", uCode: testingLabel, modelOutcome: finalResult, uuid: uuid)
                    }
                    completion(.success("Final Result: \(finalResult)"))
                } catch {
                    print("Failed to parse PredictResponse:", error)
                    DispatchQueue.main.async {
                        ProgressHUD.shared.hide()
                        self.showAlert(title: "Error", message: "Invalid server response")
                        // fallback behavior: restart scan
                        self.restartScan()
                    }
                    completion(.failure(error))
                }
                // Continue with your JSON parsing here...
                // Make sure to call completion handler on main thread if needed
            }
        }

        task.resume()
    }

    // MARK: - /validate/ fallback API
    /// Called from the 6-second scanTimerFired path when YOLO sees all 4
    /// required classes but Vision never decoded the QR string. We forward the
    /// same frame to the /validate/ endpoint which can sometimes recover the
    /// payload server-side. Three response branches per product spec:
    ///   • final_result == "Original" + non-empty qr_value
    ///         → use qr_value as the QR string and continue the normal flow
    ///           (makeApiCall_new with modelOutcome = "True").
    ///   • final_result != "Original"
    ///         → show the fake-product screen and stop.
    ///   • final_result == "Original" + empty/missing qr_value
    ///         → restart the scan with a 15-second extended window. If THAT
    ///           one also times out, scanTimerFired commits to the fake
    ///           screen (isInExtendedScanMode guard).
    ///
    /// Request body / headers are identical to sendImagetoModelAPI — only the
    /// URL and the response handling differ.

    /// Small log helper — turns `UIImage.Orientation` into a short string
    /// so the debug log doesn't print as a bare `3`. Used by the
    /// orientation-bake step in /validate/ uploads.
    private func orientationDebugName(_ o: UIImage.Orientation) -> String {
        switch o {
        case .up:            return "up"
        case .down:          return "down"
        case .left:          return "left"
        case .right:         return "right"
        case .upMirrored:    return "upMirrored"
        case .downMirrored:  return "downMirrored"
        case .leftMirrored:  return "leftMirrored"
        case .rightMirrored: return "rightMirrored"
        @unknown default:    return "unknown"
        }
    }

    func sendImagetoValidationAPI(ciImage: CIImage, testingLabel: String, completion: @escaping (Result<String, Error>) -> Void) {
        ProgressHUD.shared.show(in: view, message: "Validating.Please dont move..")
        self.freezePreview()
        // ── PIPELINE MIRROR OF sendImagetoModelAPI (/predict/) ────────
        //
        // Signature note: this function takes a CIImage directly (not a
        // UIImage) so the JPEG-backed CIImage from photoOutput can flow
        // through unchanged. Previously we took a UIImage, which forced
        // the caller to render the CIImage into a CGImage first — that
        // extra full-frame render pass introduced a color-space
        // round-trip AND blew away the JPEG's DCT-block alignment
        // advantage, producing crops that were subtly softer than
        // /predict/'s. Taking a CIImage means the ORIGINAL JPEG data
        // stays lazy all the way to cropWithPadding's final
        // createCGImage — which renders exactly the crop region once,
        // same as /predict/.
        //
        // Pipeline (identical ordering to sendImagetoModelAPI):
        //   1. Crop via cropUsingPreferredStrategy on the CIImage — no
        //      round-trip, no extra render.
        //   2. Rotate the cropped landscape UIImage 90° CW to portrait.
        //   3. Sharpen + JPEG encode.

        print(String(format: "🧭 /validate/ high-res CIImage received → %.0fx%.0f (routed straight from photoOutput, no round-trip)",
                     ciImage.extent.width, ciImage.extent.height))

        // Step 1: crop in landscape (same helper /predict/ uses).
        // The CIImage is JPEG-backed and stays lazy until cropWithPadding
        // materialises the crop region via createCGImage — same as
        // /predict/'s cropSquareNow.
        let croppedLandscapeRaw: UIImage = {
            if let cropped = self.cropUsingPreferredStrategy(ciImage) {
                print(String(format: "✂️ /validate/ preferred-strategy crop applied → %.0fx%.0f (landscape)",
                             cropped.size.width, cropped.size.height))
                return cropped
            } else {
                // Fallback: render the full CIImage to a landscape
                // UIImage if the crop pipeline returned nil. This is
                // the RARE case where TFLite doesn't find the code on
                // the high-res photo — server still handles the full
                // frame, just less accurately. Only render happens here.
                print("⚠️ /validate/ preferred-strategy crop unavailable — rendering full landscape frame as fallback")
                let ctx = CIContext()
                guard let cgFull = ctx.createCGImage(ciImage, from: ciImage.extent) else {
                    // Catastrophic — shouldn't happen for a valid CIImage.
                    // Return a 1×1 placeholder so downstream doesn't crash;
                    // the upload will proceed but produce a garbage result
                    // that the server will reject cleanly.
                    print("❌ /validate/ fallback render failed — proceeding with empty UIImage")
                    return UIImage()
                }
                return UIImage(cgImage: cgFull, scale: 1.0, orientation: .up)
            }
        }()

        // Step 2b (was): Lanczos upsample to match /predict/'s pixel scale.
        // Removed — /validate/ now goes through AVCapturePhotoOutput (see
        // pendingValidatePhotoCompletion setup in scanTimerFired's
        // hasAllClasses branch), so it receives native ~4032×3024 pixels
        // just like /predict/. No upsampling needed; the crop is already
        // at photo-output pixel scale.
        let croppedLandscape: UIImage = croppedLandscapeRaw

        // Step 3: 90° CW rotation to portrait — pixel-identical to the
        // rotation sendImagetoModelAPI does. Same UIGraphicsBeginImage-
        // ContextWithOptions call shape (kept verbatim so future edits
        // stay in sync between the two upload paths).
        let imageToSend: UIImage = {
            let size = CGSize(width: croppedLandscape.size.height,
                              height: croppedLandscape.size.width)
            UIGraphicsBeginImageContextWithOptions(size, false, croppedLandscape.scale)
            let context = UIGraphicsGetCurrentContext()!
            context.translateBy(x: size.width / 2, y: size.height / 2)
            context.rotate(by: .pi / 2) // 90° clockwise
            croppedLandscape.draw(in: CGRect(
                x: -croppedLandscape.size.width / 2,
                y: -croppedLandscape.size.height / 2,
                width: croppedLandscape.size.width,
                height: croppedLandscape.size.height
            ))
            let rotated = UIGraphicsGetImageFromCurrentImageContext()!
            UIGraphicsEndImageContext()
            return rotated
        }()

        let appInfo = Bundle.main.infoDictionary
        // Step 4: sharpen + JPEG encode — same treatment as /predict/.
        // Gated by `applyUnsharpenForUpload` inside sharpenedForUpload.
        let imageToSendSharp = self.sharpenedForUpload(imageToSend)

        let boundary = "Boundary-\(UUID().uuidString)"
        if self.isRunningInTestFlight() {
            UIImageWriteToSavedPhotosAlbum(imageToSendSharp, nil, nil, nil)
        }
        // Prepare the multipart form data — identical shape to /predict/.
        var body = Data()

        let filename = "uploaded_image.jpg"
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"file\"; filename=\"\(filename)\"\r\n".data(using: .utf8)!)
        body.append("Content-Type: image/jpeg\r\n\r\n".data(using: .utf8)!)

        guard let imageData = imageToSendSharp.jpegData(compressionQuality: self.uploadJpegQuality) else {
            completion(.failure(NSError(domain: "ImageError", code: -1, userInfo: [NSLocalizedDescriptionKey: "Failed to convert image to JPEG"])))
            return
        }
        print(String(format: "📤 /validate/ JPEG payload bytes=%d quality=%.2f sharpen=%@",
                     imageData.count, Double(self.uploadJpegQuality),
                     self.applyUnsharpenForUpload ? "Y" : "N"))

        body.append(imageData)
        body.append("\r\n".data(using: .utf8)!)
        body.append("--\(boundary)--\r\n".data(using: .utf8)!)
//prod
//        var request = URLRequest(url: URL(string: "http://3.7.254.234:8089/validate/")!)
        //staging
        // Only difference from sendImagetoModelAPI: /validate/ instead of /predict/.
        var request = URLRequest(url: URL(string: "http://164.52.221.51:9000/validate/")!)

        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "accept")
        request.setValue("asdnkj62df21asd1", forHTTPHeaderField: "auth-id")
        request.setValue("asf1323sfa6s5", forHTTPHeaderField: "auth-token")
        let batteryLevelRaw = UIDevice.current.batteryLevel  // 0.0–1.0 or -1.0
        let batteryLevelString: String = batteryLevelRaw >= 0
            ? "\(Int(round(batteryLevelRaw * 100)))"
            : "-1"
        request.setValue(batteryLevelString, forHTTPHeaderField: "BatteryLevel")

        // FlashStatus: "yes" / "no". Source of truth is the AVCapture-
        //   Device's `isTorchActive` — it reflects the actual hardware
        //   state (torch could be requested ON but thermally throttled
        //   OFF by iOS, for instance), which is what the server cares
        //   about. The class-level `torchMode` would also work but
        //   wouldn't catch thermal-throttle / hardware-off cases.
        //   videoDevice can technically be nil between setup and the
        //   first capture; default to "no" in that window — /predict/
        //   doesn't fire before viewDidAppear so the nil branch is
        //   essentially unreachable in practice, but it's harmless if
        //   it does take that path.
        let flashStatusString = (self.videoDevice?.isTorchActive ?? false) ? "yes" : "no"
        request.setValue(flashStatusString, forHTTPHeaderField: "FlashStatus")

        // AmbientLightLux: integer-string estimate sampled from the
        //   most recent video frame's EXIF BrightnessValue. See
        //   sampleAmbientLux() for the BV → lux conversion. Rounded
        //   to an integer because the server-side schema in the
        //   example takes a string like "15526", not "15526.42".
        let ambientLux = self.currentAmbientLuxEstimate()
        let ambientLuxString = "\(Int(round(ambientLux)))"
        request.setValue(ambientLuxString, forHTTPHeaderField: "AmbientLightLux")
        request.setValue(testingLabel, forHTTPHeaderField: "Testinglabel")
        let derivedPrintingType = self.derivedPrintingTypeFromDetectedQR()
        request.setValue(derivedPrintingType, forHTTPHeaderField: "Printingtype")
        request.setValue(self.axionDeviceFamilyName(), forHTTPHeaderField: "DeviceFamily")
        request.setValue(self.axionPersistentDeviceId(), forHTTPHeaderField: "LinkedUserID")
        request.setValue("ios", forHTTPHeaderField: "DeviceType")
        request.setValue("\(appInfo?["CFBundleShortVersionString"] as? String ?? "-")(\(appInfo?[kCFBundleVersionKey as String] as? String ?? "-"))", forHTTPHeaderField: "AppVersion")
        request.httpBody = body
        print("[/validate/] Testinglabel: '\(testingLabel)'  Printingtype: '\(self.printingType)'")

        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                // Always hide the spinner — scanTimerFired showed one before
                // kicking us off.
               

                if let error = error {
                    self.showAlert(title: "Error", message: error.localizedDescription)
                    completion(.failure(error))
                    ProgressHUD.shared.hide()
                    self.restartScan()
                    return
                }

                guard let httpResponse = response as? HTTPURLResponse else {
                    let err = NSError(domain: "NetworkError", code: -2, userInfo: [NSLocalizedDescriptionKey: "Invalid response"])
                    self.showAlert(title: "Error", message: "Invalid server response")
                    ProgressHUD.shared.hide()
                    completion(.failure(err))
                    return
                }

                guard let data = data else {
                    let err = NSError(domain: "NetworkError", code: -3, userInfo: [NSLocalizedDescriptionKey: "No data received"])
                    self.showAlert(title: "Error", message: "No data received from server")
                    ProgressHUD.shared.hide()
                    completion(.failure(err))
                    return
                }

                let rawResponse = String(data: data, encoding: .utf8) ?? "<undecodable>"
                print("[/validate/] HTTP \(httpResponse.statusCode) raw: \(rawResponse)")

                do {
                    ProgressHUD.shared.hide()
                    // NOTE: /validate/ wraps the payload under lowercase
                    // `data`, whereas /predict/ uses `Data`. We use a
                    // dedicated ValidateResponse type rather than munging
                    // PredictResponse so both can evolve independently.
                    let resp = try JSONDecoder().decode(ValidateResponse.self, from: data)
                    let finalResult = resp.data?.finalResult?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
                    let uuid        = resp.data?.uuid?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "Unknown"
                    let qrValue     = resp.data?.qrValue?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
                    let isOriginal  = finalResult.lowercased() == "original"

                    print("[/validate/] final_result='\(finalResult)' qr_value='\(qrValue)' uuid='\(uuid)'")
                    if isOriginal && !qrValue.isEmpty {
                        if self.isRunningInTestFlight() {
                            self.showToast(message: "Validate - Original")
                        }
             
                        self.detectedQRCodeValue = qrValue
                        
                        
                        self.makeApiCall_new(with: (12.948321152557963, 77.57733825952174),imageToSendSharp: imageToSendSharp, path: "IOS/com.acviss.app/0123459876/0123459876_17082020181440432.jpg", uCode: qrValue, modelOutcome: "True", uuid: uuid)
                        self.restartScan()
                        completion(.success("Validate Original: \(qrValue)"))
                    }
                   else if isOriginal  {
                        // ✓ Branch A — server recovered the QR; treat as Original
                        //   and continue the normal flow.
                        if self.isRunningInTestFlight() {
                            self.showToast(message: "Validate - Original")
                        }

                       self.makeApiCall_new(with: (12.948321152557963, 77.57733825952174),imageToSendSharp: imageToSendSharp, path: "IOS/com.acviss.app/0123459876/0123459876_17082020181440432.jpg", uCode: "", modelOutcome: "True", uuid: uuid)
                        self.restartScan()
                        completion(.success("Validate Original: \(qrValue)"))

                    }
                    else if (finalResult.lowercased() == "fake"){
                        if self.isRunningInTestFlight() {
                            self.showToast(message: "Validate - Fake")
                        }

                        self.makeApiCall_new(with: (12.948321152557963, 77.57733825952174),imageToSendSharp: imageToSendSharp, path: "IOS/com.acviss.app/0123459876/0123459876_17082020181440432.jpg", uCode: "", modelOutcome: "False", uuid: uuid)
                    }
                    else {
                        // ✗ Branch B — server says it's fake (or hand-rolled
                        // a guidance string in final_result like "Code is too
                        // small or too far away. Please zoom in and try
                        // again."). Pass the message through so the user
                        // sees the actual server reason instead of the
                        // generic "fake label" line.
                        if self.isRunningInTestFlight() {
                            self.showToast(message: finalResult)
                        }
//                        self.simulateFakeProductDetails(messageOverride: finalResult)
                        self.makeApiCall_new(with: (12.948321152557963, 77.57733825952174),imageToSendSharp: imageToSendSharp, path: "IOS/com.acviss.app/0123459876/0123459876_17082020181440432.jpg", uCode: "", modelOutcome: finalResult, uuid: uuid)
                        self.restartScan()
                        completion(.success("Validate Fake: \(finalResult)"))

                    }
                } catch {
                    print("[/validate/] Failed to parse ValidateResponse: \(error)")
//                    self.showAlert(title: "Error", message: "Invalid server response")
                    self.restartScan()
                    completion(.failure(error))
                }
            }
        }

        task.resume()
    }

    /// Re-runs the scan flow but with the periodic-capture window extended to
    /// 15 seconds and `isInExtendedScanMode = true` so a second timeout goes
    /// straight to simulateFakeProductDetails (no validation-API loop).
    ///
    /// The CADisplayLink-driven progress bar reads `scanInterval` on every
    /// tick, so setting it to 15 here automatically stretches the on-screen
    /// progress bar over the new window — no extra UI plumbing needed.
    private func restartScanWithExtendedInterval() {
        print("🔁 Extending scan window to \(scanIntervalExtended)s for one retry")
        // Plain reset first — wipes all the focus/sharpness/auto-zoom state.
        // restartScan() itself sets scanInterval back to default and clears
        // isInExtendedScanMode, so we MUST set them again AFTER it runs.
        restartScan()
        scanInterval = scanIntervalExtended
        isInExtendedScanMode = true
        // restartScan() already armed a 6s timer via resetScanTimer(); replace
        // it with one that reflects the new interval.
        resetScanTimer()
    }

    // MARK: - v3 authenticity-verification helper (one-off, not called)
    //
    // Mirrors the reference curl exactly: every header and every form
    // field is hardcoded with the values from the curl, and only the
    // `image` parameter is caller-provided. Not wired into any scan
    // flow — exists in the file so it can be invoked later when needed.
    //
    // Reference curl:
    //   curl --location --request POST \
    //     'https://acvissgen.test.acviss.co/api/v3/authenticity-verification-v3/' \
    //     --header 'auth-id: NWHM1PQGM3SG57XESN28' \
    //     ...
    //     --form 'image=@"/Users/apple/Downloads/overlay.png"'
    //
    // - parameter image: The image to send as the multipart `image`
    //   field. PNG-encoded server-side because the reference curl uploads
    //   a .png file (most multipart consumers default the Content-Type
    //   off the filename extension, so we mirror that).
    // - parameter completion: Called on the main queue with the raw
    //   response body (as a String) on success or the underlying error
    //   on failure.
    // MARK: - v3 helpers (persistent device-id, marketing-name resolver)

    /// Returns the persistent linked-user-id we send as the
    /// `linked_user_id` header on the v3 endpoint. Generated once on the
    /// first call ever made on this device (as a `UUID().uuidString`,
    /// 36 characters with hyphens, e.g.
    /// "E621E1F8-C36C-495A-93FC-0C247A3E6E5F") and persisted in
    /// UserDefaults under `axion.linkedUserDeviceId`. All subsequent
    /// calls return the same value — within this app session and across
    /// launches — so the server can correlate scans from the same device.
    private func axionPersistentDeviceId() -> String {
        let key = "axion.linkedUserDeviceId"
        // Accept any stored value that round-trips through UUID. This
        // means legacy 16-digit IDs from a previous build will fail the
        // parse and get replaced with a UUID on the next call — fine
        // because the server already accepts any string here.
        if let existing = UserDefaults.standard.string(forKey: key),
           UUID(uuidString: existing) != nil {
            return existing
        }
        let identifier = UUID().uuidString
        UserDefaults.standard.set(identifier, forKey: key)
        UserDefaults.standard.synchronize()
        print("🆔 axionPersistentDeviceId generated NEW id (one-time): \(identifier)")
        return identifier
    }

    /// Returns the marketing name of the current device (e.g.
    /// "iPhone 16 Pro Max") for the v3 `device_family` form field.
    /// Reads the hardware identifier via `uname` (or the simulator's
    /// `SIMULATOR_MODEL_IDENTIFIER` env var on the simulator) and maps
    /// known identifiers to marketing names. Unknown identifiers fall
    /// back to the raw identifier string so the server can still log
    /// or translate it server-side rather than receiving "Unknown".
    private func axionDeviceFamilyName() -> String {
        let identifier: String
        if let simulatorId = ProcessInfo.processInfo.environment["SIMULATOR_MODEL_IDENTIFIER"], !simulatorId.isEmpty {
            identifier = simulatorId
        } else {
            var systemInfo = utsname()
            uname(&systemInfo)
            identifier = withUnsafePointer(to: &systemInfo.machine) {
                $0.withMemoryRebound(to: CChar.self, capacity: 1) {
                    String(cString: $0)
                }
            }
        }

        switch identifier {
        // iPhone 16 series
        case "iPhone17,1": return "iPhone 16 Pro"
        case "iPhone17,2": return "iPhone 16 Pro Max"
        case "iPhone17,3": return "iPhone 16"
        case "iPhone17,4": return "iPhone 16 Plus"
        case "iPhone17,5": return "iPhone 16e"
        // iPhone 15 series
        case "iPhone15,4": return "iPhone 15"
        case "iPhone15,5": return "iPhone 15 Plus"
        case "iPhone16,1": return "iPhone 15 Pro"
        case "iPhone16,2": return "iPhone 15 Pro Max"
        // iPhone 14 series
        case "iPhone14,7": return "iPhone 14"
        case "iPhone14,8": return "iPhone 14 Plus"
        case "iPhone15,2": return "iPhone 14 Pro"
        case "iPhone15,3": return "iPhone 14 Pro Max"
        // iPhone 13 series
        case "iPhone14,4": return "iPhone 13 mini"
        case "iPhone14,5": return "iPhone 13"
        case "iPhone14,2": return "iPhone 13 Pro"
        case "iPhone14,3": return "iPhone 13 Pro Max"
        // iPhone 12 series
        case "iPhone13,1": return "iPhone 12 mini"
        case "iPhone13,2": return "iPhone 12"
        case "iPhone13,3": return "iPhone 12 Pro"
        case "iPhone13,4": return "iPhone 12 Pro Max"
        // iPhone 11 series
        case "iPhone12,1": return "iPhone 11"
        case "iPhone12,3": return "iPhone 11 Pro"
        case "iPhone12,5": return "iPhone 11 Pro Max"
        // iPhone SE
        case "iPhone12,8": return "iPhone SE (2nd generation)"
        case "iPhone14,6": return "iPhone SE (3rd generation)"
        // Older iPhones (selection)
        case "iPhone11,2": return "iPhone XS"
        case "iPhone11,4", "iPhone11,6": return "iPhone XS Max"
        case "iPhone11,8": return "iPhone XR"
        case "iPhone10,3", "iPhone10,6": return "iPhone X"
        // Fall back to the raw identifier — better than "Unknown".
        default:
            return identifier.isEmpty ? "iPhone Unknown" : identifier
        }
    }

    /// Derives the `Printingtype` HTTP header value for `/predict/`
    /// uploads from the first character of `detectedQRCodeValue`:
    ///
    ///   • Starts with 'd' or 'e' → "digital"
    ///   • Starts with 'o'        → "offset"
    ///   • Anything else (or nil) → "digital"  (safe default)
    ///
    /// Case-insensitive on the first character. The check ignores
    /// leading whitespace so a stray space in the decoded payload
    /// doesn't force the default branch.
    private func derivedPrintingTypeFromDetectedQR() -> String {
        guard let raw = detectedQRCodeValue?.trimmingCharacters(in: .whitespacesAndNewlines),
              let firstChar = raw.first else {
            return "digital"
        }
        switch firstChar.lowercased() {
        case "d", "e": return "digital"
        case "o":      return "offset"
        default:       return "digital"
        }
    }

    /// Three-way mapping for the `ai_predection` field sent to the
    /// /authenticity-verification-v3/ endpoint. Callers in
    /// sendImagetoModelAPI pass:
    ///
    ///   • "True"  — /predict/ returned "original" → server expects "Original"
    ///   • "False" — /predict/ returned anything that isn't "original" →
    ///               server expects "Fake"
    ///   • anything else (e.g. a free-form `final_result` message from
    ///               /validate/ like "Code is too small or too far away.
    ///               Please zoom in and try again.") — pass through verbatim
    ///               so the server stores the actual reason rather than
    ///               being forced into "Fake".
    ///
    /// Case-insensitive match on the two enum values; the passthrough
    /// branch preserves the original casing/punctuation/spacing.
    ///
    /// Used by both makeApiCall_new and makeApiCall_old so the wire
    /// behaviour stays in sync across the two paths.
    private func aiPredectionMapped(from modelOutcome: String) -> String {
        switch modelOutcome.lowercased() {
        case "true":  return "Original"
        case "false": return "Fake"
        default:      return modelOutcome
        }
    }

    /// Snapshot of the three device-state values the server correlates
    /// scan outcomes against, returned as multipart form-field tuples.
    /// Used by both `sendImageToAuthenticityVerificationWithImage` and
    /// `makeApiCall_new` so the wire format stays identical across the
    /// two upload paths.
    ///
    /// Fields:
    ///   • BatteryLevel     — integer percent string ("87"), or "-1" if
    ///                        UIDevice can't report it (monitoring off,
    ///                        simulator). Kept as a sentinel rather than
    ///                        collapsed to "0" so the server can tell
    ///                        "unknown" from "actually empty".
    ///   • FlashStatus      — "yes" / "no", driven by the AVCaptureDevice's
    ///                        `isTorchActive` — reflects actual hardware
    ///                        state (thermal throttling can force this to
    ///                        false even when torchMode == .on).
    ///   • AmbientLightLux  — integer-string lux estimate from the latest
    ///                        video frame's EXIF BrightnessValue; see
    ///                        `sampleAmbientLux(from:)` for the BV → lux
    ///                        conversion (K = 2.5).
    ///
    /// All three are computed cheaply enough to sample at upload time
    /// (no caching required beyond the videoQueue-fed lux estimate).
    private func deviceStateFormFields() -> [(name: String, value: Any)] {
        let batteryLevelRaw = UIDevice.current.batteryLevel   // 0.0–1.0 or -1.0
        let batteryLevelString: String = batteryLevelRaw >= 0
            ? "\(Int(round(batteryLevelRaw * 100)))"
            : "-1"
        let flashStatusString = (self.videoDevice?.isTorchActive ?? false) ? "yes" : "no"
        let ambientLuxString = "\(Int(round(self.currentAmbientLuxEstimate())))"
        return [
            ("BatteryLevel",    batteryLevelString),
            ("FlashStatus",     flashStatusString),
            ("AmbientLightLux", ambientLuxString),
        ]
    }

    func sendImageToAuthenticityVerificationWithImage(
        image: UIImage, deviceId: String, ai_predection:String, device_family:String,
        completion: @escaping (Result<String, Error>) -> Void
    ) {
        
//        guard let url = URL(string: "https://acvissgen.acviss.co/api/v3/authenticity-verification-v3/") else {
//            completion(.failure(NSError(domain: "AuthVerifyV3", code: -1,
//                                        userInfo: [NSLocalizedDescriptionKey: "Invalid URL"])))
//            return
//        }
        
        guard let url = URL(string: "https://acvissgen.test.acviss.co/api/v3/authenticity-verification-v3/") else {
            completion(.failure(NSError(domain: "AuthVerifyV3", code: -1,
                                        userInfo: [NSLocalizedDescriptionKey: "Invalid URL"])))
            return
        }

        let boundary = "Boundary-\(UUID().uuidString)"

        // 1) Headers — exact set from the curl, including the session cookie.
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
//        request.setValue("5D681Z2F48NBN6EQ5ICM", forHTTPHeaderField: "auth-id")
//        request.setValue("ISI920B03UCFMG20L42ATEPJAPR2BRP7OEBLFIL6", forHTTPHeaderField: "auth-token")
//        request.setValue("IOS_SDK", forHTTPHeaderField: "device-type")
//        request.setValue("278", forHTTPHeaderField: "customer_id")
//        request.setValue(deviceId, forHTTPHeaderField: "linked_user_id")
//        request.setValue(Bundle.main.bundleIdentifier!, forHTTPHeaderField: "app-id")
        
        // BatteryLevel / FlashStatus / AmbientLightLux moved from
        // HTTP headers into the multipart form body — see the
        // `+ deviceStateFormFields()` append on formFields below.
        // Server team's expected schema puts these alongside
        // `location`, `device_family`, etc.


        request.setValue("NWHM1PQGM3SG57XESN28", forHTTPHeaderField: "auth-id")
        request.setValue("U6VDR10QC3VOMW7BPKEXLEQD1OSF6Y3UNJ44JYJJ", forHTTPHeaderField: "auth-token")
        request.setValue("IOS", forHTTPHeaderField: "device-type")
        request.setValue("628", forHTTPHeaderField: "customer_id")
        request.setValue(deviceId, forHTTPHeaderField: "linked_user_id")
        request.setValue(Bundle.main.bundleIdentifier!, forHTTPHeaderField: "app-id")

        // 2) Form fields — kept in declaration order to match curl. Mixed
        //    types: most are strings, `bypass_pdf_loyalty` is a Bool. Two
        //    string values in the curl include literal quote characters
        //    (captured_frame_url, captured_frame_path) and are preserved
        //    exactly so the body bytes match. The writer below serialises
        //    each value per-type before appending.
        let formFields: [(name: String, value: Any)] = [
            ("ucode_data",          ""),
            ("captured_frame_url",  ""),                                             // literal: "<quote> <quote>"
            ("location",            self.currentLocationJSONString()),
            ("captured_frame_path", "\"test\""),                                 // literal: "<quote>cbgdtactdatyc<quote>"
            ("bypass_pdf_loyalty",  true),                                                // Bool — serialised as "true"/"false"
            ("ai_predection",       ai_predection),
            ("uuid",                "54448545478"),
            ("device_family",       device_family),
        ] + deviceStateFormFields()   // appends BatteryLevel, FlashStatus, AmbientLightLux

        var body = Data()
        for field in formFields {
            // Serialise the value based on its actual Swift type. Wire
            // format stays plain-text per multipart/form-data (no JSON
            // typing at the field level), but the Swift source reflects
            // semantics: Bool stays Bool, String stays String.
            let valueString: String
            switch field.value {
            case let b as Bool:   valueString = b ? "true" : "false"
            case let s as String: valueString = s
            default:              valueString = "\(field.value)"
            }
            body.append("--\(boundary)\r\n".data(using: .utf8)!)
            body.append("Content-Disposition: form-data; name=\"\(field.name)\"\r\n\r\n".data(using: .utf8)!)
            body.append("\(valueString)\r\n".data(using: .utf8)!)
        }

        // 3) Image part — PNG to match the file extension in the curl.
        guard let imageData = image.pngData() else {
            completion(.failure(NSError(domain: "AuthVerifyV3", code: -2,
                                        userInfo: [NSLocalizedDescriptionKey: "Failed to PNG-encode image"])))
            return
        }
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"image\"; filename=\"overlay.png\"\r\n".data(using: .utf8)!)
        body.append("Content-Type: image/png\r\n\r\n".data(using: .utf8)!)
        body.append(imageData)
        body.append("\r\n".data(using: .utf8)!)

        // 4) Closing boundary.
        body.append("--\(boundary)--\r\n".data(using: .utf8)!)
        request.httpBody = body

        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                if let error = error {
                    print("❌ /authenticity-verification-v3/ error: \(error.localizedDescription)")
                    
                    completion(.failure(error))
                    return
                }
                guard let httpResp = response as? HTTPURLResponse else {
                    let err = NSError(domain: "AuthVerifyV3", code: -3,
                                      userInfo: [NSLocalizedDescriptionKey: "Invalid response"])
                  
                    completion(.failure(err))
                    return
                }
                let rawBody = data.flatMap { String(data: $0, encoding: .utf8) } ?? "<no body>"
                print("📤 /authenticity-verification-v3/ HTTP \(httpResp.statusCode) bytes=\(data?.count ?? 0)")
                if self.isRunningInTestFlight() {
                    // Save cropped image for verification/debugging
                    UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
                }
                completion(.success(rawBody))
            }
        }.resume()
    }

    func isRunningInTestFlight() -> Bool {
        if let receiptURL = Bundle.main.appStoreReceiptURL {
            return receiptURL.lastPathComponent == "sandboxReceipt"
        }
        return false
    }
    func showToast(message: String, duration: Double = 2.0) {
        let toastLabel = UILabel()
        toastLabel.text = message
        toastLabel.font = UIFont.systemFont(ofSize: 14)
        toastLabel.textColor = .white
        toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.7)
        toastLabel.textAlignment = .center
        toastLabel.numberOfLines = 0
        
        toastLabel.alpha = 0.0
        toastLabel.layer.cornerRadius = 10
        toastLabel.clipsToBounds = true
        
        let maxSizeTitle = CGSize(width: self.view.bounds.size.width - 40, height: self.view.bounds.size.height)
        var expectedSize = toastLabel.sizeThatFits(maxSizeTitle)
        expectedSize.width += 20
        expectedSize.height += 10
        
        toastLabel.frame = CGRect(
            x: (self.view.frame.size.width - expectedSize.width) / 2,
            y: self.view.frame.size.height - 120,
            width: expectedSize.width,
            height: expectedSize.height
        )
        
        self.view.addSubview(toastLabel)
        
        UIView.animate(withDuration: 0.5, animations: {
            toastLabel.alpha = 1.0
        }) { _ in
            UIView.animate(withDuration: 0.5, delay: duration, options: .curveEaseOut, animations: {
                toastLabel.alpha = 0.0
            }, completion: { _ in
                toastLabel.removeFromSuperview()
            })
        }
    }
    
    private func makeApiCall_new(with coordinates: (latitude: Double, longitude: Double) = (latitude: 0.0, longitude: 0.0),
                                 imageToSendSharp: UIImage,
                                 path: String,
                                 uCode: String,
                                 modelOutcome: String,
                                 uuid: String) {
        // Bail with a print() on every failure path — no completion handler
        // on this function signature, so we can't call back to a caller.
        // Caller can monitor the printed log lines (📤 / ❌ prefixes) for
        // diagnostics during development.
        print("/authenticity-verification-v3/ api starts")

        // Three-way mapping for the ai_predection field — see
        // aiPredectionMapped() for the rationale. Local binding so the
        // form-fields literal below stays terse.
        let aiPredection = self.aiPredectionMapped(from: modelOutcome)
//        guard let url = URL(string: "https://acvissgen.acviss.co/api/v3/authenticity-verification-v3/") else {
//            print("❌ /authenticity-verification-v3/ invalid URL")
//            return
//        }
        guard let url = URL(string: "https://acvissgen.test.acviss.co/api/v3/authenticity-verification-v3/") else {
            print("❌ /authenticity-verification-v3/ invalid URL")
            return
        }


        let boundary = "Boundary-\(UUID().uuidString)"

        // 1) Headers — exact set from the curl, including the session cookie.
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
//        request.setValue("5D681Z2F48NBN6EQ5ICM", forHTTPHeaderField: "auth-id")
//        request.setValue("ISI920B03UCFMG20L42ATEPJAPR2BRP7OEBLFIL6", forHTTPHeaderField: "auth-token")
//        request.setValue("IOS_SDK", forHTTPHeaderField: "device-type")
//        request.setValue("278", forHTTPHeaderField: "customer_id")
//        request.setValue(Bundle.main.bundleIdentifier!, forHTTPHeaderField: "app-id")
        // BatteryLevel / FlashStatus / AmbientLightLux moved from
        // HTTP headers into the multipart form body — see the
        // `+ deviceStateFormFields()` append on formFields below.
        // Server team's expected schema puts these alongside
        // `location`, `device_family`, etc.


        request.setValue("NWHM1PQGM3SG57XESN28", forHTTPHeaderField: "auth-id")
        request.setValue("U6VDR10QC3VOMW7BPKEXLEQD1OSF6Y3UNJ44JYJJ", forHTTPHeaderField: "auth-token")
        request.setValue("IOS", forHTTPHeaderField: "device-type")
        request.setValue("628", forHTTPHeaderField: "customer_id")
        request.setValue(Bundle.main.bundleIdentifier!, forHTTPHeaderField: "app-id")
//        
        request.setValue(self.axionPersistentDeviceId(), forHTTPHeaderField: "linked_user_id")

        // 2) Form fields — kept in declaration order to match curl. Mixed
        //    types: most are strings, `bypass_pdf_loyalty` is a Bool. Two
        //    string values in the curl include literal quote characters
        //    (captured_frame_url, captured_frame_path) and are preserved
        //    exactly so the body bytes match. The writer below serialises
        //    each value per-type before appending.
        let formFields: [(name: String, value: Any)] = [
            ("ucode_data",          detectedQRCodeValue ?? ""),
            ("captured_frame_url",  ""),                                             // literal: "<quote> <quote>"
            ("location",            self.currentLocationJSONString()),
            ("captured_frame_path", "\"test\""),                                          // literal: "<quote>test<quote>"
            ("bypass_pdf_loyalty",  true),                                                // Bool — serialised as "true"/"false"
            ("ai_predection",       aiPredection),
            ("uuid",                uuid),
            ("device_family",       self.axionDeviceFamilyName()),
        ] + deviceStateFormFields()   // appends BatteryLevel, FlashStatus, AmbientLightLux

        var body = Data()
        for field in formFields {
            // Serialise the value based on its actual Swift type. Wire
            // format stays plain-text per multipart/form-data (no JSON
            // typing at the field level), but the Swift source reflects
            // semantics: Bool stays Bool, String stays String.
            let valueString: String
            switch field.value {
            case let b as Bool:   valueString = b ? "true" : "false"
            case let s as String: valueString = s
            default:              valueString = "\(field.value)"
            }
            body.append("--\(boundary)\r\n".data(using: .utf8)!)
            body.append("Content-Disposition: form-data; name=\"\(field.name)\"\r\n\r\n".data(using: .utf8)!)
            body.append("\(valueString)\r\n".data(using: .utf8)!)
        }

        // 3) Image part — PNG to match the file extension in the curl.
        //    Parameter is `imageToSendSharp` (was incorrectly referenced as
        //    `image` before — `image` doesn't exist in this signature).
        guard let imageData = imageToSendSharp.pngData() else {
            print("❌ /authenticity-verification-v3/ failed to PNG-encode image")
            return
        }
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"image\"; filename=\"overlay.png\"\r\n".data(using: .utf8)!)
        body.append("Content-Type: image/png\r\n\r\n".data(using: .utf8)!)
        body.append(imageData)
        body.append("\r\n".data(using: .utf8)!)

        // 4) Closing boundary.
        body.append("--\(boundary)--\r\n".data(using: .utf8)!)
        request.httpBody = body

        URLSession.shared.dataTask(with: request) { data, response, error in
            DispatchQueue.main.async {
                ProgressHUD.shared.hide()
                self.scanTimer?.invalidate()
                self.scanTimer = nil
                self.stopProgressAnimation(finalProgress: 1.0)
                self.audioQueue.async { [weak self] in
                    self?.audioPlayer?.stop()
                    self?.audioPlayer = nil
                }

                if let error = error {
                    print("❌ /authenticity-verification-v3/ error: \(error.localizedDescription)")
                    return
                }
                guard let httpResp = response as? HTTPURLResponse else {
                    print("❌ /authenticity-verification-v3/ invalid HTTP response")
                    return
                }
                print("📤 /authenticity-verification-v3/ HTTP \(httpResp.statusCode) bytes=\(data?.count ?? 0)")

                // ── Parse JSON ─────────────────────────────────────────
                // The old code did `data as? [String: Any]` which can
                // never succeed (Data isn't a dictionary). Use
                // JSONSerialization to actually decode the response
                // body into a [String: Any] dict.
                guard let data = data else {
                    print("❌ /authenticity-verification-v3/ no response body")
                    return
                }
                let parsed: Any?
                do {
                    parsed = try JSONSerialization.jsonObject(with: data,
                                                              options: .mutableLeaves)
                } catch {
                    print("❌ /authenticity-verification-v3/ JSON parse failed: \(error.localizedDescription)")
                    if let raw = String(data: data, encoding: .utf8) {
                        print("    raw body: \(raw.prefix(500))")
                    }
                    return
                }
                guard let responseJson = parsed as? [String: Any] else {
                    print("❌ /authenticity-verification-v3/ response is not a top-level object")
                    return
                }

                print("acvissScanProductInfo 222 \(responseJson)")
                // The new server envelope nests both response_code AND
                // data under "result", whereas AcvissProdDetailsView-
                // Model.configureData expects `data` at the TOP level
                // of whatever dict it receives (so simulateFakeProduct-
                // Details, which feeds the flat-shaped fake_details.json,
                // also keeps working). Unwrap once here so the viewmodel
                // gets the shape it expects. Fall back to the full
                // response if the envelope is missing `result` so a
                // future server-shape rollback doesn't crash.
                let resultDict = responseJson["result"] as? [String: Any]
                if resultDict == nil {
                    print("⚠️ /authenticity-verification-v3/ response missing top-level 'result' — passing full body as fallback")
                }
                let viewModelInput = resultDict ?? responseJson

                let responseCode = resultDict?["response_code"] as? Int
                let isSuccess = (responseCode == 100 || responseCode == 110)
                self.resetDetection()

                let prodView = UIHostingController(
                    rootView: AcvissProdDetailsView(isSuccess: isSuccess,
                                                    jsonResult: viewModelInput)
                )
                prodView.title = "Product Details"

                if let nav = self.navigationController {
                    // We have a navigation controller — push normally.
                    nav.pushViewController(prodView, animated: true)
                } else {
                    // No navigation controller — wrap in one so we get a
                    // nav bar and close button, then present modally.
                    let nav = UINavigationController(rootViewController: prodView)
                    nav.modalPresentationStyle = .fullScreen
                    prodView.navigationItem.leftBarButtonItem = UIBarButtonItem(
                        barButtonSystemItem: .close,
                        target: self,
                        action: #selector(self.prodDetailsCloseTapped)
                    )
                    self.present(nav, animated: true, completion: nil)
                }
            }
        }.resume()
    }
    
    private func makeApiCall_old(with coordinates: (latitude: Double, longitude: Double) = (latitude: 0.0, longitude: 0.0),imageToSendSharp:UIImage, path: String, uCode : String, modelOutcome: String, uuid: String) {
             
              let location: [String: Double] = [
                  "latitude": coordinates.latitude,
                  "longitude": coordinates.longitude
              ]
            var parameters: [String: Any] = [
                
                "ucode_data": uCode,
                
            ]
        
        if let qrCodeValue = detectedQRCodeValue {
            parameters["ucode_data"] = qrCodeValue
//            parameters["ucode_data"] = String(qrCodeValue.dropLast())
//            parameters["ucode_data"] = "e1~19_278,2y00u0s9mqd10fqe,2"
           }
            
              parameters["location"] = location
              parameters["captured_frame_path"] = path
              parameters["unique_id"] = "23232323"
//              parameters["yellow_code_response"] = modelOutcome
        //new optimized
//        parameters["is_dgc"] = modelOutcome
        
        
        parameters["bypass_pdf_loyalty"] = true
//        parameters["ai_predection"] = "Original"
        // Same three-way mapping makeApiCall_new uses — extracted into
        // aiPredectionMapped() so both API paths emit identical wire
        // values. Passes through any non-"true"/"false" value verbatim
        // (e.g. server-side guidance strings from /validate/'s
        // final_result) instead of forcing it to "Fake".
        parameters["ai_predection"] = self.aiPredectionMapped(from: modelOutcome)

        parameters["uuid"] = uuid
//              parameters["yellow_code_response"] = "True"
//        ProgressHUD.shared.hide()
//        self.simulateProductDetails()
//        return
//
        
//              print("acvission verification parameters \(parameters)")
              NetworkManager.shared.makeAPICall(
                  httpMethod: .post,
                  endPoint: .AuthenticityYelloCodeVerificationV3,
                  parameters: parameters,
                  viewController: nil,
                  errorHandlers: [.HandledByViewController],
                  type: .WithoutLoader,
                  result: { data,error  in

           
                      ProgressHUD.shared.hide()
                      self.scanTimer?.invalidate()
                      self.scanTimer = nil
                      self.stopProgressAnimation(finalProgress: 1.0)
                      self.audioQueue.async { [weak self] in
                          self?.audioPlayer?.stop()
                          self?.audioPlayer = nil
                      }
                      
//                      self.lapsedSeconds = 0
                      if data != nil, let responseJson = data as? [String : Any] {
                          print("acvissScanProductInfo 222 \(responseJson)")
                          
                          DispatchQueue.main.async {
                              let responseCode = responseJson["response_code"] as? Int
//                              let responseCode = (jsonResult["result"] as? [String: Any])?["response_code"] as? Int
                              let isSuccess = (responseCode == 100 || responseCode == 110)
                              self.resetDetection()
                              // create the SwiftUI view and hosting controller
                              let prodView = UIHostingController(rootView: AcvissProdDetailsView(isSuccess: isSuccess, jsonResult: responseJson))
                              prodView.title = "Product Details" // shown in nav bar

                              DispatchQueue.main.async {
                                  if let nav = self.navigationController {
                                      // we have a navigation controller — push normally
                                      nav.pushViewController(prodView, animated: true)
                                  } else {
                                      // no navigation controller — present one modally so we get a nav bar and back button
                                      let nav = UINavigationController(rootViewController: prodView)
                                      nav.modalPresentationStyle = .fullScreen // or .automatic / .pageSheet as you prefer

                                      // optional: configure nav appearance (optional)
                                      // nav.navigationBar.prefersLargeTitles = false
                                      prodView.navigationItem.leftBarButtonItem = UIBarButtonItem(
                                                          barButtonSystemItem: .close,
                                                          target: self,
                                                          action: #selector(self.prodDetailsCloseTapped)
                                                      )
                                      self.present(nav, animated: true, completion: nil)
                                  }
                              }
//                              let prodView = UIHostingController(rootView: AcvissProdDetailsView(isSuccess: response_code == 100, jsonResult: responseJson ?? [:]))
//                                  self.navigationController?.pushViewController(prodView, animated: true)
                          }
                    
                      } else {
//                          self.isAcvissCodeAPISuccess = false
                      }
                  }
              )
          }
    @objc private func prodDetailsCloseTapped() {
        // If VisionViewController presented the nav controller, dismiss it
        self.presentedViewController?.dismiss(animated: true, completion: nil)
    }
    private func showAlert(title: String, message: String) {
        DispatchQueue.main.async {
            // Get the current key window's root view controller
            guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
                  let window = windowScene.windows.first,
                  let rootViewController = window.rootViewController else {
                print("No root view controller found")
                return
            }
            
            // Find the topmost presented view controller
            var topController = rootViewController
            while let presentedViewController = topController.presentedViewController {
                topController = presentedViewController
            }
            
            // Only present if the view controller's view is in the window hierarchy
            if topController.view.window != nil {
                let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default) { [weak self] _ in
                    // Call restartScan when OK is tapped
                    self?.restartScan()
                    self?.resetScanTimer()
                })
                topController.present(alert, animated: true)
            } else {
                print("View controller not in window hierarchy - delaying alert presentation")
                // Retry after a delay if needed
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    self.showAlert(title: title, message: message)
                }
            }
        }
    }
 
    // Replace cropSquareNow with this new function
//    func cropSquareNow(_ image: CIImage?) -> UIImage? {
//        guard let ciImage = image else {
//            print("No CIImage provided")
//            return nil
//        }
//        
//        guard let observation = self.detectedBarcode else {
//            print("❌ No stored barcode observation available")
//            return nil
//        }
//        
//        print("Starting QR code square cropping using Vision observation")
//        print("Original image extent: \(ciImage.extent)")
//        
//        let context = CIContext()
//        
//        // The key insight: Vision detected the QR in video frames with orientation .up
//        // But the captured photo might have different EXIF orientation
//        // We need to work with the image in its natural orientation
//        
//        let imageSize = ciImage.extent
//        print("Image size: \(imageSize)")
//        
//        // Vision's bounding box is in normalized coordinates (0-1)
//        // and uses bottom-left origin (UIKit/Vision coordinate system)
//        let boundingBox = observation.boundingBox
//        print("Vision bounding box (normalized): \(boundingBox)")
//        
//        // Try different coordinate transformations to find the QR code
//        let transformations: [(name: String, transform: (CGRect) -> CGRect)] = [
//            // Standard Vision to CIImage (flip Y)
//            ("Standard flip Y", { box in
//                CGRect(
//                    x: box.origin.x * imageSize.width,
//                    y: (1 - box.origin.y - box.height) * imageSize.height,
//                    width: box.width * imageSize.width,
//                    height: box.height * imageSize.height
//                )
//            }),
//            // Try without Y flip (in case image is already oriented)
//            ("No Y flip", { box in
//                CGRect(
//                    x: box.origin.x * imageSize.width,
//                    y: box.origin.y * imageSize.height,
//                    width: box.width * imageSize.width,
//                    height: box.height * imageSize.height
//                )
//            }),
//            // Rotated 90 degrees (landscape)
//            ("Rotated 90", { box in
//                CGRect(
//                    x: box.origin.y * imageSize.width,
//                    y: box.origin.x * imageSize.height,
//                    width: box.height * imageSize.width,
//                    height: box.width * imageSize.height
//                )
//            }),
//            // Rotated 90 with Y flip
//            ("Rotated 90 + flip", { box in
//                CGRect(
//                    x: (1 - box.origin.y - box.height) * imageSize.width,
//                    y: box.origin.x * imageSize.height,
//                    width: box.height * imageSize.width,
//                    height: box.width * imageSize.height
//                )
//            })
//        ]
//        
//        var bestCropImage: UIImage?
//        
//        for (name, transform) in transformations {
//            print("\n🔍 Trying transformation: \(name)")
//            
//            let qrRect = transform(boundingBox)
//            print("   QR rect in image coords: \(qrRect)")
//            
//            // Validate the rectangle is within bounds
//            guard qrRect.minX >= 0 && qrRect.minY >= 0 &&
//                  qrRect.maxX <= imageSize.width && qrRect.maxY <= imageSize.height else {
//                print("   ❌ Rectangle out of bounds")
//                continue
//            }
//            
//            // Add padding (60% total = 1.60x)
//            let paddingMultiplier: CGFloat = 2.2
//            let paddedWidth = qrRect.width * paddingMultiplier
//            let paddedHeight = qrRect.height * paddingMultiplier
//            
//            // Make it square
//            let squareSize = max(paddedWidth, paddedHeight)
//            
//            // Calculate crop rect centered on QR code
//            let cropRect = CGRect(
//                x: qrRect.midX - squareSize / 2,
//                y: qrRect.midY - squareSize / 2,
//                width: squareSize,
//                height: squareSize
//            )
//            
//            print("   Calculated crop rect: \(cropRect)")
//            
//            // Ensure crop rect is within image bounds
//            let adjustedCropRect = cropRect.intersection(imageSize)
//            
//            guard !adjustedCropRect.isEmpty &&
//                  adjustedCropRect.width > 100 &&
//                  adjustedCropRect.height > 100 else {
//                print("   ❌ Crop rect too small or empty")
//                continue
//            }
//            
//            print("   Adjusted crop rect: \(adjustedCropRect)")
//            
//            // Crop the image
//            let croppedCIImage = ciImage.cropped(to: adjustedCropRect)
//            
//            // Convert to UIImage
//            guard let cgImage = context.createCGImage(croppedCIImage, from: croppedCIImage.extent) else {
//                print("   ❌ Failed to create CGImage")
//                continue
//            }
//            
//            let croppedImage = UIImage(cgImage: cgImage, scale: 1.0, orientation: .up)
//            
//            // Verify this crop actually contains a QR code using CIDetector
//            if verifyQRCodeInImage(croppedImage) {
//                print("   ✅ QR code verified in cropped image!")
//                bestCropImage = croppedImage
//                break
//            } else {
//                print("   ⚠️ Could not verify QR in this crop, trying next...")
//            }
//        }
//        
//        if let finalImage = bestCropImage {
//            print("\n✅ Successfully created verified cropped image with size: \(finalImage.size)")
//            return finalImage
//        }
////        else
////        {
////            
//////                    DispatchQueue.main.async {
//////                        self.showAlert(title: "Scan again",
//////                                     message: "Looks like there is some issue with your environment. Please ensure the following and try again:\n\n1) Good lighting\n2) Stable hands\n3) Clean Lens of Camera")
//////                        ProgressHUD.shared.hide()
//////                        self.restartScan()
//////                    }
//////
////            DispatchQueue.main.async {
////                self.showAlertLightingconditions(
////                    title: "Scan again",
////                    message: """
////            Looks like there is some issue with your environment. Please ensure the following and try again:
////
////            1) Good lighting
////            2) Stable hands
////            3) Clean Lens of Camera
////            """,
////                    onOk: {
////                        // 🔥 runs only when the user taps OK
////                        ProgressHUD.shared.hide()
////                        self.restartScan()
////                    }
////                )
////            }
////            return nil
////        }
//        
//        print("\n❌ Could not find valid crop with any transformation")
//        
//        // Last resort: Use the first reasonable crop even without verification
//        for (name, transform) in transformations {
//            let qrRect = transform(boundingBox)
//            let paddingMultiplier: CGFloat = 1.60
//            let paddedWidth = qrRect.width * paddingMultiplier
//            let paddedHeight = qrRect.height * paddingMultiplier
//            let squareSize = max(paddedWidth, paddedHeight)
//            
//            let cropRect = CGRect(
//                x: qrRect.midX - squareSize / 2,
//                y: qrRect.midY - squareSize / 2,
//                width: squareSize,
//                height: squareSize
//            )
//            
//            let adjustedCropRect = cropRect.intersection(imageSize)
//            
//            if !adjustedCropRect.isEmpty && adjustedCropRect.width > 100 {
//                let croppedCIImage = ciImage.cropped(to: adjustedCropRect)
//                if let cgImage = context.createCGImage(croppedCIImage, from: croppedCIImage.extent) {
//                    print("⚠️ Using unverified crop from: \(name)")
//                    return UIImage(cgImage: cgImage, scale: 1.0, orientation: .up)
//                }
//            }
//        }
//        
//        return nil
//    }

    // MARK: - Helpers used by the validation (/validate/) path
    /// Crop the centre 60% of an image — used by the belt-and-braces
    /// sharpness probe inside the validation-path so peripheral background
    /// blur doesn't mask centre-frame focus loss.
    /// Crispness pipeline for the upload crop. Chain of Core Image
    /// filters designed to preserve QR module edges through the JPEG
    /// encode step and give the backend team the "distinct pixels"
    /// they asked for. Each step is individually gated so you can
    /// A/B any subset on the same device by flipping constants.
    ///
    /// Pipeline (in order — order matters):
    ///
    ///   1. Optional Lanczos upscale (applyUpscaleBeforeSharpen).
    ///      Doing upscale FIRST lets the unsharp/contrast passes
    ///      operate on more pixels, giving finer-grained edge
    ///      enhancement than sharpening then upscaling would.
    ///      OFF by default — triples upload size.
    ///
    ///   2. CIUnsharpMask (applyUnsharpenForUpload).
    ///      Lifts edges by subtracting a blurred copy from the
    ///      original. Radius tuned to match module pixel scale
    ///      (see unsharpenRadius doc); intensity dialed up to
    ///      make the edge lift decisive rather than subtle.
    ///
    ///   3. CIColorControls contrast (applyContrastBoostForUpload).
    ///      Pushes near-black pixels blacker and near-white pixels
    ///      whiter, sharpening the black-vs-white distinction the
    ///      backend model uses to read module state. Applied AFTER
    ///      unsharp so the edge halos get the contrast treatment
    ///      too.
    ///
    /// Any step failure short-circuits back to the previous stage's
    /// output — the upload always happens. Falls back to the raw
    /// input image if the first stage's CGImage extraction fails.

    private func sharpenedForUpload(_ image: UIImage) -> UIImage {
        guard let cgImage = image.cgImage else { return image }
        var current = CIImage(cgImage: cgImage)
        let ctx = CIContext(options: nil)

        // Step 1: Lanczos upscale (optional — off by default).
        if applyUpscaleBeforeSharpen, let lanczos = CIFilter(name: "CILanczosScaleTransform") {
            lanczos.setValue(current, forKey: kCIInputImageKey)
            lanczos.setValue(uploadUpscaleFactor, forKey: kCIInputScaleKey)
            lanczos.setValue(1.0, forKey: kCIInputAspectRatioKey)
            if let up = lanczos.outputImage {
                current = up
            }
        }

        // Step 2: Unsharp mask.
        if applyUnsharpenForUpload, let unsharp = CIFilter(name: "CIUnsharpMask") {
            unsharp.setValue(current, forKey: kCIInputImageKey)
            unsharp.setValue(unsharpenRadius, forKey: kCIInputRadiusKey)
            unsharp.setValue(unsharpenIntensity, forKey: kCIInputIntensityKey)
            if let sharpened = unsharp.outputImage {
                current = sharpened
            }
        }

        // Step 3: Contrast boost.
        if applyContrastBoostForUpload, let contrast = CIFilter(name: "CIColorControls") {
            contrast.setValue(current, forKey: kCIInputImageKey)
            contrast.setValue(uploadContrastFactor, forKey: kCIInputContrastKey)
            // Saturation/brightness left at defaults — we only want
            // to boost the black-vs-white distinction, not shift
            // colour balance.
            if let boosted = contrast.outputImage {
                current = boosted
            }
        }

        // Bake to CGImage. Falls back to the raw input image if the
        // final render fails so the upload still happens.
        guard let outCG = ctx.createCGImage(current, from: current.extent) else { return image }
        print(String(format: "🪄 crispness pipeline: upscale=%@ unsharp=%@(r=%.1f,i=%.1f) contrast=%@(x%.2f) → %dx%d",
                     applyUpscaleBeforeSharpen ? "Y×\(uploadUpscaleFactor)" : "N",
                     applyUnsharpenForUpload ? "Y" : "N",
                     Double(unsharpenRadius), Double(unsharpenIntensity),
                     applyContrastBoostForUpload ? "Y" : "N",
                     Double(uploadContrastFactor),
                     outCG.width, outCG.height))
        return UIImage(cgImage: outCG, scale: image.scale, orientation: image.imageOrientation)
    }

    private func centerScanRegion(of image: UIImage) -> UIImage? {
        guard let cgImage = image.cgImage else { return nil }
        let w = CGFloat(cgImage.width)
        let h = CGFloat(cgImage.height)
        guard w > 0, h > 0 else { return nil }
        let side = min(w, h) * 0.6
        let cropRect = CGRect(
            x: (w - side) / 2,
            y: (h - side) / 2,
            width: side,
            height: side
        )
        guard let cropped = cgImage.cropping(to: cropRect) else { return nil }
        return UIImage(cgImage: cropped, scale: image.scale, orientation: image.imageOrientation)
    }

    /// Shared crop-with-padding primitive used by `cropAroundTFLiteQR`.
    /// Mirrors the geometry of `cropSquareNow` (centre point + padding
    /// multiplier, clamped to the image extent, refuse tiny crops).
    private func cropWithPadding(_ ciImage: CIImage,
                                 rect: CGRect,
                                 paddingMultiplier: CGFloat) -> UIImage? {
        let expandedW = rect.width  * paddingMultiplier
        let expandedH = rect.height * paddingMultiplier
        let cropRect = CGRect(
            x: rect.midX - expandedW / 2,
            y: rect.midY - expandedH / 2,
            width:  expandedW,
            height: expandedH
        )

        // COORDINATE-SPACE CONVERSION: YOLO's rect comes from a CGImage
        // (top-left origin). CIImage.cropped(to:) expects a rect in
        // CIImage-native BOTTOM-left origin coordinates. Passing the
        // top-left rect straight in produces a crop that's vertically
        // offset by `imageHeight - rectY - rectHeight` pixels — the
        // "extra padding on one side, clipped on the other" symptom.
        //
        // The X axis is the same in both spaces (left-to-right), so we
        // only flip Y. imageHeight comes from ciImage.extent (the same
        // coordinate space we're converting into, so no round-trip
        // through a UIImage.size that might be orientation-adjusted).
        let imgH = ciImage.extent.height
        let flippedRect = CGRect(
            x: cropRect.minX,
            y: imgH - cropRect.maxY,
            width:  cropRect.width,
            height: cropRect.height
        )

        // Clamp against the CIImage extent AFTER flipping so the
        // intersection math is done in CIImage-space too.
        let clampedRect = flippedRect.intersection(ciImage.extent)
        guard !clampedRect.isEmpty,
              clampedRect.width > 100,
              clampedRect.height > 100 else {
            print("❌ TFLite-derived crop rect invalid after clamping: \(clampedRect) (input rect was \(rect), image extent \(ciImage.extent))")
            return nil
        }
        let context = CIContext()
        let cropped = ciImage.cropped(to: clampedRect)
        guard let cgImage = context.createCGImage(cropped, from: cropped.extent) else {
            return nil
        }
        return UIImage(cgImage: cgImage, scale: 1.0, orientation: .up)
    }

    /// Used by the validation-API path when Vision never decoded the QR
    /// (so `detectedBarcode` is nil and `cropSquareNow` returns nil).
    /// Runs TFLite on the high-res photo, picks the QR-class detection (or
    /// falls back to the union of Pattern detections), and applies the same
    /// 3x padding that `cropSquareNow` uses so the crop sent to /validate/
    /// matches the crop sent to /predict/ in shape.
    /// Crop to the exact bounding box of YOLO's AxionCode-class
    /// detection (class ID 1). The AxionCode rect already encompasses
    /// the QR + 6 outer pattern boxes + alignment band — i.e. the full
    /// printed code area, the red bounding box visible in the model's
    /// detection overlay. No padding multiplier is applied because the
    /// AxionCode rect IS the desired crop; padding would just add
    /// background pixels we don't want.
    ///
    /// Used as the PRIMARY crop strategy by both `cropSquareNow`
    /// (Vision-decoded path) and `cropAroundTFLiteQR` (validation
    /// fallback path). Returns nil if TFLite doesn't find an
    /// AxionCode detection — caller is expected to fall through to
    /// its previous crop logic in that case.
    private func cropToAxionCodeBoundary(_ ciImage: CIImage) -> UIImage? {
        let context = CIContext()
        guard let cgFull = context.createCGImage(ciImage, from: ciImage.extent) else {
            print("❌ cropToAxionCodeBoundary: createCGImage failed")
            return nil
        }
        let fullImage = UIImage(cgImage: cgFull, scale: 1.0, orientation: .up)

        let detections: [Detection]
        do {
            detections = try TFLiteInference.run(
                on: fullImage,
                modelName: "model",
                bundle: AxionBundle.bundle
            )
        } catch {
            print("❌ cropToAxionCodeBoundary: TFLite error \(error.localizedDescription)")
            return nil
        }

        // Pick the highest-confidence AxionCode detection. There's
        // typically exactly one in frame; if YOLO ever returns more than
        // one (e.g. two codes visible at once), the more confident one
        // wins.
        let axionDetections = detections
            .filter { $0.classId == YOLOClass.axionCode.rawValue }
            .sorted { $0.confidence > $1.confidence }
        guard let bestAxion = axionDetections.first else {
            print("⚠️ cropToAxionCodeBoundary: no AxionCode-class detection in high-res photo")
            return nil
        }

        print(String(format: "🟥 cropToAxionCodeBoundary: AxionCode rect (%.0f, %.0f, %.0f, %.0f) conf=%.2f padding=%.2f",
                     bestAxion.rect.minX, bestAxion.rect.minY,
                     bestAxion.rect.width, bestAxion.rect.height,
                     bestAxion.confidence,
                     cropAxionCodePaddingMultiplier))

        // DEBUG: render the AxionCode bbox on top of the full-res frame
        // and save it to Photos. With cropAxionCodePaddingMultiplier=1.0
        // and useQrPhysicalPaddingCrop=false, this blue box is EXACTLY
        // the region that gets sent to /predict/ — the debug save is a
        // 1:1 preview of the upload crop. Colour matches the reference
        // YOLO overlay (cyan/blue, "Axioncode CONF").
        // Gated on TestFlight so production users don't fill up their
        // photo library with debug frames. Turn `saveAxionCodeDebugFrame`
        // off if it gets noisy.
        if saveAxionCodeDebugFrame, isRunningInTestFlight() {
            let annotated = drawDetectionBox(on: fullImage,
                                             rect: bestAxion.rect,
                                             color: UIColor(red: 0.20, green: 0.60, blue: 1.00, alpha: 1.0),
                                             label: String(format: "Axioncode %.2f", bestAxion.confidence))
            // Rotate landscape → portrait so the paper reads upright
            // when we open Photos. Boxes rotate with the pixels (they
            // were drawn before the rotation) so no coordinate math.
            let portraitAnnotated = rotatedPortrait(annotated)
            //TODO
//            UIImageWriteToSavedPhotosAlbum(portraitAnnotated, nil, nil, nil)
            print("🎨 Saved AxionCode-debug frame to Photos (portrait, full frame with blue bbox overlay)")
        }

        // Small padding (default 1.08 → ~4% on each side) keeps the 6
        // outer pattern boxes intact when YOLO's AxionCode rect lands a
        // few pixels inside one of them. The user reported corner-
        // pattern clipping on grey-paper captures at 1.0 padding.
        return cropWithPadding(ciImage,
                               rect: bestAxion.rect,
                               paddingMultiplier: cropAxionCodePaddingMultiplier)
    }

    /// Debug flag: when true (and running in TestFlight), each
    /// AxionCode-class detection gets saved to the Photos library as
    /// the full-res frame with a blue bbox drawn around the detected
    /// rect and a "Axioncode <conf>" label — matching the style of the
    /// YOLO model-output overlay you'd see in Netron. Purpose: visually
    /// verify that the bbox YOLO is delivering matches what your eye
    /// would call the "code area", so you can diagnose crop-off-by-N-
    /// pixels issues without instrumenting a whole preview render pass.
    ///
    /// Turn OFF for release / when the debug frames become noise.
    private let saveAxionCodeDebugFrame: Bool = true

    /// Rotate `image` 90° clockwise, baking the rotation into actual
    /// pixels (so downstream consumers like UIImageWriteToSavedPhotosAlbum
    /// see a portrait image, not a landscape image with orientation
    /// metadata saying "rotate me on display").
    ///
    /// Used by the debug-frame save path. The raw high-res photo from
    /// AVCapturePhotoOutput comes out in the sensor's native landscape
    /// orientation — the box-drawing pass runs on that landscape image
    /// because YOLO's Detection.rect values are in that pixel space.
    /// Then this helper flips the annotated result to portrait so it
    /// looks "right" when we open Photos.
    ///
    /// Trick used: wrap the source cgImage in a new UIImage with
    /// `.right` orientation (metadata saying "rotate 90° CW for
    /// display"), then re-render at the orientation-honouring `.size`,
    /// which UIGraphicsImageRenderer + `image.draw(in:)` bakes into
    /// real pixels. Same pattern the /validate/ upload path uses to
    /// normalise its input orientation.
    private func rotatedPortrait(_ image: UIImage) -> UIImage {
        guard let cg = image.cgImage else { return image }
        let wrapped = UIImage(cgImage: cg, scale: image.scale, orientation: .right)
        let renderer = UIGraphicsImageRenderer(size: wrapped.size)
        return renderer.image { _ in
            wrapped.draw(in: CGRect(origin: .zero, size: wrapped.size))
        }
    }

    /// Draw a labelled bounding box on a copy of `image` and return
    /// the annotated UIImage. Box is stroked with `color`, label sits
    /// just above the box's top-left (or just below if the box is at
    /// the top edge of the image — avoids the label being off-screen
    /// for full-frame captures).
    ///
    /// `rect` must be in the image's PIXEL coordinate space (same
    /// space YOLO's Detection.rect uses). Line thickness scales with
    /// image size so a 4032×3024 photo shows a visible box, not a
    /// hairline.
    private func drawDetectionBox(on image: UIImage,
                                   rect: CGRect,
                                   color: UIColor,
                                   label: String) -> UIImage {
        let imageSize = image.size
        let renderer = UIGraphicsImageRenderer(size: imageSize)
        return renderer.image { ctx in
            // Base image first, then overlay.
            image.draw(in: CGRect(origin: .zero, size: imageSize))

            let cg = ctx.cgContext
            // Line thickness proportional to image longest side so the
            // box is visible on 4K captures. 0.4% of the longest side
            // is roughly a 12-16 px line on a typical iPhone photo.
            let lineWidth = max(4.0, min(imageSize.width, imageSize.height) * 0.004)
            cg.setStrokeColor(color.cgColor)
            cg.setLineWidth(lineWidth)
            cg.stroke(rect)

            // Label above the box (or below if we'd otherwise go
            // negative). Same colour swatch behind text for readability.
            let fontSize = max(24.0, min(imageSize.width, imageSize.height) * 0.02)
            let attrs: [NSAttributedString.Key: Any] = [
                .font: UIFont.boldSystemFont(ofSize: fontSize),
                .foregroundColor: UIColor.white
            ]
            let text = label as NSString
            let textSize = text.size(withAttributes: attrs)
            let pad: CGFloat = fontSize * 0.25

            var labelOrigin = CGPoint(x: rect.minX,
                                      y: rect.minY - textSize.height - pad * 2)
            if labelOrigin.y < 0 {
                labelOrigin.y = rect.minY + pad
            }
            let labelBg = CGRect(x: labelOrigin.x,
                                 y: labelOrigin.y,
                                 width: textSize.width + pad * 2,
                                 height: textSize.height + pad * 2)
            cg.setFillColor(color.cgColor)
            cg.fill(labelBg)
            text.draw(at: CGPoint(x: labelBg.minX + pad,
                                  y: labelBg.minY + pad),
                      withAttributes: attrs)
        }
    }

    /// QR-class + physical-padding crop.
    ///
    /// Strategy:
    ///   1. Run YOLO on the high-res photo, take the highest-confidence
    ///      QR-class detection.
    ///   2. Use its width in pixels as a scale reference against
    ///      `expectedQRSizeCm` to compute pixels-per-cm on the print.
    ///   3. Expand the QR rect by `qrPhysicalPaddingCm` on every side
    ///      (converted to pixels via that scale).
    ///   4. Crop and return.
    ///
    /// Why this is more robust than the AxionCode-class path:
    /// the AxionCode bbox drifts because the class boundary is fuzzy
    /// (where exactly does the "code area" end vs the printed border
    /// texture?). The QR-class bbox is anchored to a well-defined
    /// high-contrast rectangle. When we anchor our crop to that
    /// tight rect and expand outward physically, we're much less
    /// sensitive to bbox jitter.
    ///
    /// Returns nil if:
    ///   • createCGImage fails
    ///   • TFLite errors
    ///   • no QR-class detection is present
    ///   • the QR rect has zero width (shouldn't happen but defensive)
    ///   • the clamped crop is < 100 px in either dimension (means
    ///     the QR was detected against the edge of the frame and the
    ///     expanded rect got mostly clipped away)
    private func cropToQRWithPhysicalPadding(_ ciImage: CIImage) -> UIImage? {
        let context = CIContext()
        guard let cgFull = context.createCGImage(ciImage, from: ciImage.extent) else {
            print("❌ cropToQRWithPhysicalPadding: createCGImage failed")
            return nil
        }
        let fullImage = UIImage(cgImage: cgFull, scale: 1.0, orientation: .up)

        let detections: [Detection]
        do {
            detections = try TFLiteInference.run(
                on: fullImage,
                modelName: "model",
                bundle: AxionBundle.bundle
            )
        } catch {
            print("❌ cropToQRWithPhysicalPadding: TFLite error \(error.localizedDescription)")
            return nil
        }

        let qrDetections = detections
            .filter { $0.classId == YOLOClass.qr.rawValue }
            .sorted { $0.confidence > $1.confidence }
        guard let bestQR = qrDetections.first else {
            print("⚠️ cropToQRWithPhysicalPadding: no QR-class detection in high-res photo")
            return nil
        }

        // DEBUG: since the QR-strategy short-circuits before
        // cropToAxionCodeBoundary ever runs (see cropUsingPreferredStrategy),
        // we surface the AxionCode-class debug frame from HERE too —
        // same TFLite pass, no extra inference cost. Draws the AxionCode
        // rect in blue and (if a QR-class hit exists) the QR rect in a
        // contrasting green so you can see both boundaries side-by-side.
        if saveAxionCodeDebugFrame, isRunningInTestFlight() {
            let axionForDebug = detections
                .filter { $0.classId == YOLOClass.axionCode.rawValue }
                .sorted { $0.confidence > $1.confidence }
                .first
            var annotated = fullImage
            if let axion = axionForDebug {
                annotated = drawDetectionBox(on: annotated,
                                             rect: axion.rect,
                                             color: UIColor(red: 0.20, green: 0.60, blue: 1.00, alpha: 1.0),
                                             label: String(format: "Axioncode %.2f", axion.confidence))
            } else {
                print("ℹ️ debug annotator: no AxionCode-class detection on this frame — only QR box will be drawn")
            }
            annotated = drawDetectionBox(on: annotated,
                                         rect: bestQR.rect,
                                         color: UIColor(red: 0.20, green: 0.90, blue: 0.40, alpha: 1.0),
                                         label: String(format: "QR %.2f", bestQR.confidence))
            // Same rotate-to-portrait step as the AxionCode-only path,
            // so both debug save call sites produce visually consistent
            // portrait frames in Photos.
            let portraitAnnotated = rotatedPortrait(annotated)
            //TODO
//            UIImageWriteToSavedPhotosAlbum(portraitAnnotated, nil, nil, nil)
            print("🎨 Saved debug frame to Photos (portrait, blue=AxionCode bbox, green=QR bbox used for crop)")
        }

        let qrWidthPx = bestQR.rect.width
        guard qrWidthPx > 0 else {
            print("⚠️ cropToQRWithPhysicalPadding: QR rect has zero width")
            return nil
        }

        // Convert 0.7 cm padding into pixels using the QR width as our
        // physical scale reference. See `expectedQRSizeCm` for why we
        // default to the smaller (safer) size assumption.
        let pixelsPerCm = qrWidthPx / expectedQRSizeCm
        let paddingPx = qrPhysicalPaddingCm * pixelsPerCm

        print(String(format: "🟦 cropToQRWithPhysicalPadding: QR rect (%.0f, %.0f, %.0f, %.0f) conf=%.2f qrSizeAssumed=%.2fcm padCm=%.2f pxPerCm=%.1f padPx=%.0f",
                     bestQR.rect.minX, bestQR.rect.minY,
                     bestQR.rect.width, bestQR.rect.height,
                     bestQR.confidence,
                     expectedQRSizeCm,
                     qrPhysicalPaddingCm,
                     pixelsPerCm,
                     paddingPx))

        // insetBy with NEGATIVE dx/dy expands the rect symmetrically.
        let expandedRect = bestQR.rect.insetBy(dx: -paddingPx, dy: -paddingPx)

        // COORDINATE-SPACE FLIP: same top-left → bottom-left conversion
        // cropWithPadding does. YOLO's rect is CGImage/top-left origin,
        // CIImage.cropped(to:) wants bottom-left. Skip this and the
        // crop ends up vertically offset relative to what YOLO marked.
        let imgH = ciImage.extent.height
        let flippedRect = CGRect(
            x: expandedRect.minX,
            y: imgH - expandedRect.maxY,
            width:  expandedRect.width,
            height: expandedRect.height
        )

        // Intersect with ciImage.extent so we never crop outside the
        // sensor pixels — the sides that would extend past the image
        // get clipped to the image edge, which is fine. Done AFTER
        // flipping so the intersection is in the same coordinate space.
        let clampedRect = flippedRect.intersection(ciImage.extent)
        guard !clampedRect.isEmpty,
              clampedRect.width > 100,
              clampedRect.height > 100 else {
            print("❌ cropToQRWithPhysicalPadding: crop rect invalid after clamping: \(clampedRect)")
            return nil
        }
        print(String(format: "✂️ cropToQRWithPhysicalPadding: final crop %.0fx%.0f (expanded from QR %.0fx%.0f by %.0f px per side)",
                     clampedRect.width, clampedRect.height,
                     bestQR.rect.width, bestQR.rect.height,
                     paddingPx))

        let cropped = ciImage.cropped(to: clampedRect)
        guard let cgImage = context.createCGImage(cropped, from: cropped.extent) else {
            print("❌ cropToQRWithPhysicalPadding: final createCGImage failed")
            return nil
        }
        return UIImage(cgImage: cgImage, scale: 1.0, orientation: .up)
    }

    /// Central "which crop strategy?" wrapper. The three call sites
    /// (`sendImagetoValidationAPI`, `cropAroundTFLiteQR`, `cropSquareNow`)
    /// all route through this so flipping `useQrPhysicalPaddingCrop`
    /// changes behaviour globally without editing each call site.
    ///
    /// Order when the flag is on:
    ///   1. try cropToQRWithPhysicalPadding
    ///   2. on nil, fall through to cropToAxionCodeBoundary
    ///
    /// Order when the flag is off:
    ///   1. cropToAxionCodeBoundary only
    private func cropUsingPreferredStrategy(_ ciImage: CIImage) -> UIImage? {
        if useQrPhysicalPaddingCrop {
            if let physical = cropToQRWithPhysicalPadding(ciImage) {
                return physical
            }
            print("↩️ cropUsingPreferredStrategy: physical-padding returned nil, falling back to AxionCode-class")
        }
        return cropToAxionCodeBoundary(ciImage)
    }

    private func cropAroundTFLiteQR(_ ciImage: CIImage) -> UIImage? {
        // PRIMARY: preferred strategy — see cropUsingPreferredStrategy.
        // With the current feature flag it's the QR-class + physical
        // padding (0.7 cm per side) path, falling back internally to
        // the AxionCode-class + percentage padding crop.
        if let bestCrop = cropUsingPreferredStrategy(ciImage) {
            return bestCrop
        }

        // FALLBACK 1: QR-class crop with padding. Used only when
        // AxionCode wasn't detected (rare — usually means the user is
        // very far or the code is partially occluded).
        let context = CIContext()
        guard let cgFull = context.createCGImage(ciImage, from: ciImage.extent) else {
            print("❌ cropAroundTFLiteQR: createCGImage failed")
            return nil
        }
        let fullImage = UIImage(cgImage: cgFull, scale: 1.0, orientation: .up)

        do {
            let detections = try TFLiteInference.run(
                on: fullImage,
                modelName: "model",
                bundle: AxionBundle.bundle
            )

            let qrDetections = detections
                .filter { $0.classId == YOLOClass.qr.rawValue }
                .sorted { $0.confidence > $1.confidence }
            if let bestQR = qrDetections.first {
                print("🟦 cropAroundTFLiteQR: AxionCode missing — using QR-class rect \(bestQR.rect) padding=\(cropQRPaddingMultiplier)")
                return cropWithPadding(ciImage,
                                       rect: bestQR.rect,
                                       paddingMultiplier: cropQRPaddingMultiplier)
            }

            // FALLBACK 2: union of pattern rects.
            let patternRects = detections
                .filter { $0.classId == YOLOClass.pattern.rawValue }
                .map { $0.rect }
            if !patternRects.isEmpty {
                let unionRect = patternRects.reduce(CGRect.null) { $0.union($1) }
                print("🟧 cropAroundTFLiteQR: no QR-class detection — using union of \(patternRects.count) patterns \(unionRect)")
                return cropWithPadding(ciImage,
                                       rect: unionRect,
                                       paddingMultiplier: 1.2)
            }

            print("❌ cropAroundTFLiteQR: no AxionCode / QR / pattern detections")
            return nil
        } catch {
            print("❌ cropAroundTFLiteQR: TFLite error \(error.localizedDescription)")
            return nil
        }
    }

    func cropSquareNow(_ image: CIImage?) -> UIImage? {
        guard let ciImage = image else {
            print("❌ No CIImage provided")
            return nil
        }

        // PRIMARY: preferred strategy — see cropUsingPreferredStrategy.
        // With the current feature flag it's the QR-class + physical
        // padding (0.7 cm per side) path, falling back internally to
        // the AxionCode-class + percentage padding crop. Costs one
        // extra TFLite invocation (~50-100 ms on device) either way.
        if let bestCrop = cropUsingPreferredStrategy(ciImage) {
            return bestCrop
        }

        // FALLBACK: original Vision-bbox + padding crop. Used when
        // TFLite doesn't find an AxionCode detection on the photo
        // (rare — usually means the user moved between the Vision
        // decode and the high-res capture).
        guard let observation = self.detectedBarcode else {
            print("❌ cropSquareNow: AxionCode crop returned nil AND no stored Vision barcode — cannot crop")
            return nil
        }

        let imageExtent = ciImage.extent
        let imageW = imageExtent.width
        let imageH = imageExtent.height
        let bb = observation.boundingBox  // normalized, bottom-left origin

        print("📐 cropSquareNow falling back to Vision bbox")
        print("📐 Image extent: \(imageExtent)")
        print("📐 Vision bounding box: \(bb)")

        // Vision and CIImage both use bottom-left origin — no Y-flip needed.
        // CIImage(data:) already EXIF-corrects the photo to portrait orientation.
        let qrX = bb.origin.x * imageW
        let qrY = bb.origin.y * imageH
        let qrW = bb.width  * imageW
        let qrH = bb.height * imageH

        let qrRectInImage = CGRect(x: qrX, y: qrY, width: qrW, height: qrH)
        print("📐 QR rect in image pixels: \(qrRectInImage)")

        // Centralised padding tunable. See cropQRPaddingMultiplier's
        // declaration for the full empirical history (1.5×/2.0×/2.2×/
        // 2.5×/3.0×) — current value of 2.2× gives QR + 6 outer
        // patterns edge-to-edge with a thin safety strip.
        let paddingMultiplier: CGFloat = self.cropQRPaddingMultiplier

        let expandedW = qrW * paddingMultiplier
        let expandedH = qrH * paddingMultiplier

        let cropRect = CGRect(
            x: qrRectInImage.midX - expandedW / 2,
            y: qrRectInImage.midY - expandedH / 2,
            width:  expandedW,
            height: expandedH
        )
        print("📐 Desired crop rect: \(cropRect)")

        let clampedRect = cropRect.intersection(imageExtent)
        guard !clampedRect.isEmpty,
              clampedRect.width > 100,
              clampedRect.height > 100 else {
            print("❌ Crop rect invalid after clamping: \(clampedRect)")
            return nil
        }
        print("📐 Clamped crop rect: \(clampedRect)")

        let context = CIContext()
        let cropped = ciImage.cropped(to: clampedRect)

        guard let cgImage = context.createCGImage(cropped, from: cropped.extent) else {
            print("❌ Failed to create CGImage")
            return nil
        }

        let result = UIImage(cgImage: cgImage, scale: 1.0, orientation: .up)
        print("✅ Crop successful: \(result.size)")
        return result
    }
    private func showAlertLightingconditions(
        title: String,
        message: String,
        onOk: (() -> Void)? = nil
    ) {
        DispatchQueue.main.async {
            // Get current topmost VC
            guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
                  let window = windowScene.windows.first,
                  let root = window.rootViewController else {
                return
            }

            var top = root
            while let presented = top.presentedViewController {
                top = presented
            }

            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)

            alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in
                onOk?()   // 🔥 callback when user taps OK
            })

            top.present(alert, animated: true)
        }
    }
    // Helper function to verify QR code exists in cropped image
    private func verifyQRCodeInImage(_ image: UIImage) -> Bool {
        guard let cgImage = image.cgImage else { return false }
        
        let ciImage = CIImage(cgImage: cgImage)
        let context = CIContext()
        
        guard let detector = CIDetector(
            ofType: CIDetectorTypeQRCode,
            context: context,
            options: [CIDetectorAccuracy: CIDetectorAccuracyHigh]
        ) else {
            return false
        }
        
        let features = detector.features(in: ciImage)
        return !features.isEmpty
    }

    // Fallback method when QR detection fails
    private func manualCenterCrop(_ ciImage: CIImage) -> UIImage? {
        print("🔄 Using manual center crop fallback")
        let context = CIContext()
        
        let extent = ciImage.extent
        let size = min(extent.width, extent.height)
        let center = CGPoint(x: extent.midX, y: extent.midY)
        
        let cropRect = CGRect(
            x: center.x - size / 2,
            y: center.y - size / 2,
            width: size,
            height: size
        )
        
        let croppedCIImage = ciImage.cropped(to: cropRect)
        
        guard let cgImage = context.createCGImage(croppedCIImage, from: croppedCIImage.extent) else {
            return nil
        }
        
        return UIImage(cgImage: cgImage, scale: 1.0, orientation: .up)
    }


    private func cropUsingVisionObservation(_ ciImage: CIImage, observation: VNBarcodeObservation) -> UIImage? {
        let context = CIContext()
        let imageSize = ciImage.extent
        
        print("Image size: \(imageSize)")
        print("Vision bounding box (normalized): \(observation.boundingBox)")
        
        // Vision uses normalized coordinates (0-1) with bottom-left origin
        // Convert to CIImage coordinates (top-left origin, pixel values)
        let boundingBox = observation.boundingBox
        
        // Calculate the QR code rect in image coordinates
        // Flip Y coordinate because Vision uses bottom-left origin
        let x = boundingBox.origin.x * imageSize.width
        let y = (1 - boundingBox.origin.y - boundingBox.height) * imageSize.height
        let width = boundingBox.width * imageSize.width
        let height = boundingBox.height * imageSize.height
        
        let qrRect = CGRect(x: x, y: y, width: width, height: height)
        print("QR rect in image coordinates: \(qrRect)")
        
        // Add padding (60% total = 1.60x)
        let paddingMultiplier: CGFloat = 1.60
        let paddedWidth = width * paddingMultiplier
        let paddedHeight = height * paddingMultiplier
        
        // Make it square using the larger dimension
        let squareSize = max(paddedWidth, paddedHeight)
        
        // Center the square on the QR code
        let cropRect = CGRect(
            x: qrRect.midX - squareSize / 2,
            y: qrRect.midY - squareSize / 2,
            width: squareSize,
            height: squareSize
        )
        
        print("Calculated crop rect: \(cropRect)")
        
        // Clamp to image bounds
        let adjustedCropRect = cropRect.intersection(imageSize)
        
        guard !adjustedCropRect.isEmpty else {
            print("❌ Crop rect is empty after intersection")
            return nil
        }
        
        print("Adjusted crop rect: \(adjustedCropRect)")
        
        // Crop the image
        let croppedCIImage = ciImage.cropped(to: adjustedCropRect)
        
        // Convert to UIImage
        guard let cgImage = context.createCGImage(croppedCIImage, from: croppedCIImage.extent) else {
            print("❌ Failed to create CGImage")
            return nil
        }
        
        let finalImage = UIImage(cgImage: cgImage, scale: 1.0, orientation: .up)
        print("✅ Successfully created cropped image with size: \(finalImage.size)")
        
        return finalImage
    }


}

// MARK: - CLLocationManagerDelegate

extension QRCodeScannerViewController: CLLocationManagerDelegate {

    /// Fires once on initial permission decision and again on every
    /// subsequent change (e.g. user toggles permission in Settings while
    /// the app is alive). iOS 14+ delivers this; on iOS 13 the older
    /// `locationManager(_:didChangeAuthorization:)` signature would
    /// fire — but our minimum deployment in practice is iOS 14+, so we
    /// only implement the new one.
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        let status = manager.authorizationStatus
        print("📍 authorization changed → \(authorizationStatusDescription(status))")
        switch status {
        case .authorizedWhenInUse, .authorizedAlways:
            manager.startUpdatingLocation()
        case .denied, .restricted:
            // User explicitly declined or device policy blocks location.
            // Stop trying and leave currentLatitude/currentLongitude at
            // 0.0 — that's the spec'd fallback for the API form field.
            manager.stopUpdatingLocation()
            currentLatitude = 0.0
            currentLongitude = 0.0
        case .notDetermined:
            // Still waiting for the user's decision on the prompt. Do
            // nothing; the next call into this method will route us.
            break
        @unknown default:
            break
        }
    }

    /// Standard delivery callback. We just stash the most recent
    /// coordinate — no filtering by accuracy/timestamp because hundred-
    /// metre accuracy is already plenty for "where was this scan
    /// performed", and the system's distance filter prevents the
    /// callback from firing on tiny jitters.
    func locationManager(_ manager: CLLocationManager,
                         didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else { return }
        currentLatitude = location.coordinate.latitude
        currentLongitude = location.coordinate.longitude
        print(String(format: "📍 location fix lat=%.7f lon=%.7f acc=%.0fm",
                     currentLatitude, currentLongitude,
                     location.horizontalAccuracy))
    }

    /// Failure callback — usually "location services are disabled"
    /// (settings-wide kill switch) or transient GPS unavailability.
    /// Same as denied: leave coords at 0.0 so the API gets the fallback.
    func locationManager(_ manager: CLLocationManager,
                         didFailWithError error: Error) {
        print("⚠️ location manager error: \(error.localizedDescription)")
    }
}



///
///
///Without FAR implementation////
///
///
///
///
//import UIKit
//import SwiftUI
//import AVFoundation
//import Vision
//import CoreImage
//import AVFoundation
//import CoreMotion
//
//
//final class QRCodeScannerViewController: UIViewController, AVCaptureVideoDataOutputSampleBufferDelegate, AVCapturePhotoCaptureDelegate {
//    
//    // MARK: - UI Elements
//    private var previewView: UIView!
//    var testingLabel: String = "Original"
//    // Forwarded to the model API as `Printingtype`. Set by the host via presentScanner().
//    var printingType: String = "digital"
//    private var audioButton: UIButton!
//    private var audioPlayer: AVAudioPlayer?
//    private var isAudioEnabled: Bool = true
////    private var resultImageView: UIImageView!
//    private var instructionLabel: UILabel!
//    private var logoImageView: UIImageView!
//    private var stage1Label: UILabel!
//    private var stage2Label: UILabel!
//    private var stage3Label: UILabel!
//    private var refreshButton: UIButton!
//    private var cornerBoxLayer = CAShapeLayer()
//    private let dimOverlayLayer = CAShapeLayer()
//    // Central scan-window size used by both the dim overlay cutout and the corner brackets.
//    private let scanWindowSize = CGSize(width: 250, height: 250)
//    private let scanWindowCornerRadius: CGFloat = 16
//    /// Semi-transparent guide image shown inside the scan window so the
//    /// user can physically align the code with the guide. Loaded from
//    /// the "overlay" asset in `AxionBundle.bundle`.
//    private var overlayImageView: UIImageView!
//    /// Alpha for the overlay guide — 0.0 invisible, 1.0 fully opaque.
//    /// 0.45 keeps the live preview readable through the guide. Tune as
//    /// needed.
//    private let overlayImageAlpha: CGFloat = 0.45
//    private var statusLabel: UILabel!
//    private var torchButton: UIButton!
//    private var processingTimer: Timer?
//    private let processingTimeout: TimeInterval = 5.0 // 5 seconds timeout
//    private var closeButton: UIButton!
//    private var isClosing = false
//    var onClose: (() -> Void)?
//    private var focusButton: UIButton!
//    private var focusStatusView: UIView!
//    private var validationFrameCompletion: ((UIImage?) -> Void)?
//    // Set on the validation-API path (scanTimerFired + hasAllClasses) so that
//    // the next photo arriving at `photoOutput(_:didFinishProcessingPhoto:)`
//    // is handed to this closure instead of running the genuine `/predict/`
//    // pipeline. Consumed exactly once; cleared as soon as it fires.
//    private var pendingFakePhotoCompletion: ((CIImage?) -> Void)?
//    // MARK: - AVFoundation Properties
//    private var captureSession: AVCaptureSession!
//    private var videoPreviewLayer: AVCaptureVideoPreviewLayer!
//    private var videoDevice: AVCaptureDevice?
//    private var videoDataOutput: AVCaptureVideoDataOutput!
//    private var photoOutput: AVCapturePhotoOutput!
//    
//    // Timer that will trigger periodic sends
//    private var scanTimer: Timer?
//    // Mutable so we can switch to the extended 15s retry window after the
//    // /validate/ fallback returns "Original" with an empty qr_value. The
//    // progress bar's CADisplayLink reads this same property every tick, so
//    // updating it transparently lengthens the countdown UI as well.
//    private var scanInterval: TimeInterval = 10.0
//    private let scanIntervalDefault: TimeInterval = 10.0
//    private let scanIntervalExtended: TimeInterval = 15.0
//    // True once we've already taken our one retry with the extended window.
//    // If the extended timer also expires we go straight to the fake-product
//    // screen rather than looping the validation API again.
//    private var isInExtendedScanMode: Bool = false
//
//    // Progress bar driven by the scan interval
//    private var scanProgressView: UIProgressView!
//    private var progressDisplayLink: CADisplayLink?
//    private var progressStartTime: CFTimeInterval = 0
//
//    // Motion-stability gating: scan timer only runs while the device is fairly steady.
//    private let motionManager = CMMotionManager()
//    // Start above the threshold so we don't claim "stable" before we have evidence.
//    private var smoothedMotion: Double = 1.0
//    // Tunable: combined accel + rotation magnitude allowed for "steady hand-held".
//    // Small hand sway: ~0.02–0.05.  Moving phone toward QR: ~0.20+.
//    private let motionStabilityThreshold: Double = 0.10
//    // Whether we currently consider the device steady enough to count.
//    private var isMotionStable: Bool = false
//    // Whether the caller wants the scan timer running (gets gated by stability).
//    private var pendingScanTimerStart: Bool = false
//    // Small guard to avoid overlapping network uploads
//    private var isUploading: Bool = false
//    private var pendingTestingLabel: String? = nil
//    
//    private var tiltCheckTimer: Timer?
//    private var isTiltChecking: Bool = false
//    
//    // Optional: keep last captured image if you prefer sending an already-captured image
//    private var lastCapturedImage: UIImage?
//    
//    // MARK: - Vision Properties
//    private var visionRequests = [VNRequest]()
//    private var isQRCodeDetected = false
//    // Store the observation itself to get accurate bounding box later
//    private var detectedBarcode: VNBarcodeObservation?
//    
//    private var performRequestCount = 0
//    private var lastBarcode: VNBarcodeObservation?
//    private var lastDetectionTime: Date?
//    
//    
//    private var zoomSlider: UISlider!
//    private var currentZoom: CGFloat = 2.5
//    private let minZoom: CGFloat = 1.0
//    private let maxZoom: CGFloat = 8.0
//    private let zoomStep: CGFloat = 0.1
//    private var zoomLabel: UILabel!
//    private var detectedQRCodeValue: String?
//    private var isAudioSessionConfigured = false
//
//    // MARK: - App lifecycle gating
//    // True while the app is not active (background or inactive). Every
//    // periodic/throttled piece of work in this controller checks this flag
//    // first so we don't burn battery — or worse, fire the periodic upload —
//    // while the user can't even see the camera.
//    private var isAppInBackground: Bool = false
//
//    // MARK: - Focus / sharpness gating
//    // True while the camera's autofocus is mid-adjustment. We never arm the scan
//    // timer while this is true so the periodic upload can't fire on a blurry frame.
//    private var isAutoFocusAdjusting: Bool = true
//    // Updated from a throttled Laplacian-variance probe on the live preview buffer.
//    private var isFrameSharp: Bool = false
//    // Throttle the live sharpness probe — Laplacian is the most expensive thing
//    // we do per-frame so cap it to ~3 Hz.
//    private var lastSharpnessCheckTime: CFTimeInterval = 0
//    private let sharpnessCheckInterval: CFTimeInterval = 0.35
//    // Live-preview Laplacian-variance threshold. Kept for reference and
//    // for the belt-and-braces sharpness check inside scanTimerFired's
//    // pre-capture branch — Laplacian is cheap and good enough as a
//    // coarse first filter there. NOT used by the main live-probe gate
//    // anymore; see `liveTenengradThreshold` below.
//    private let liveSharpnessThreshold: Double = 500.0
//    // Live-preview TENENGRAD threshold (0-100 scale). This is what now
//    // gates the scan timer. Tenengrad is far more discriminating than
//    // Laplacian on uniformly soft "user is too close" frames where
//    // sensor noise can fool a Laplacian-variance threshold into
//    // declaring sharp. Real on-device readings on a tack-sharp Axion
//    // code crop sit in the 60-90 range; visibly blurry close-to-focus
//    // frames sit under 25. 35 is a wide-margin reject line.
//    private let liveTenengradThreshold: Double = 35.0
//    // Hysteresis: require N consecutive sharp probes before flipping
//    // `isFrameSharp` from false → true. Any single blurry probe flips it
//    // straight back to false (asymmetric debounce). This kills the class
//    // of bug where a single noise-driven "sharp" reading during an AF
//    // transition arms the timer prematurely.
//    private let sharpnessHysteresisRequired: Int = 2
//    private var consecutiveSharpProbes: Int = 0
//    // Flagged true when the live probe says blurry AND lensPosition is at
//    // the near-focus limit, meaning the user is physically inside the
//    // camera's minimum focus distance — no amount of waiting will resolve
//    // it. The label flow uses this to prompt "Move slightly farther away"
//    // instead of the generic "Hold steady" hint.
//    private var userIsTooCloseToFocus: Bool = false
//    // The threshold under which we consider the lens "parked at near
//    // limit". On the iPhone wide camera lensPosition is 0..1 (0=near,
//    // 1=far); when the lens has given up it sits exactly at 0, but we
//    // give a tiny tolerance for floating-point reads.
//    private let lensPositionTooCloseThreshold: Float = 0.05
//    // KVO registration latch so we never add/remove the observer twice.
//    private var focusObserversRegistered: Bool = false
//
//    // MARK: - Auto-zoom (fit 6 YOLO patterns into the scan window)
//    // Once the user touches the slider we hand control to them and keep it.
//    private var userZoomOverride: Bool = false
//    // Throttle auto-zoom corrections so the lens isn't constantly hunting.
//    private var lastAutoZoomTime: CFTimeInterval = 0
//    private let autoZoomInterval: CFTimeInterval = 0.7
//    // Target fill: patterns should occupy ~90% of the scan window (tight fit,
//    // matches the on-screen reference). Tunable.
//    private let autoZoomTargetFraction: CGFloat = 0.90
//    // Don't react to tiny ratios — within ±8% of target we consider it "fitted".
//    private let autoZoomDeadband: CGFloat = 0.08
//    // Cap per-step zoom change so the camera moves smoothly, not in jumps.
//    private let autoZoomMaxStep: CGFloat = 0.6
//
//    private let audioQueue = DispatchQueue(label: "com.axion.scanner.audio",
//                                           qos: .background)
//    deinit {
//        print("QRCodeScannerViewController deallocated")
//    }
//    
//    // MARK: - Lifecycle Methods
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        setupUI()
//        setupCamera()
//        registerAppLifecycleObservers()
//    }
//
//    // MARK: - App background / foreground gating
//
//    private func registerAppLifecycleObservers() {
//        let nc = NotificationCenter.default
//
//        // 1) Legacy UIApplication notifications. These fire process-wide,
//        //    INCLUDING in scene-based hosts — but only when ALL scenes go
//        //    inactive (i.e. on iPad multi-scene they may not fire when the
//        //    user just backgrounds one window). Still register them as the
//        //    primary signal.
//        nc.addObserver(self,
//                       selector: #selector(handleAppWillResignActive),
//                       name: UIApplication.willResignActiveNotification,
//                       object: nil)
//        nc.addObserver(self,
//                       selector: #selector(handleAppDidBecomeActive),
//                       name: UIApplication.didBecomeActiveNotification,
//                       object: nil)
//        // Also catch the harder transition — when the app/scene moves all
//        // the way to background. Useful when the host suspends quickly.
//        nc.addObserver(self,
//                       selector: #selector(handleAppWillResignActive),
//                       name: UIApplication.didEnterBackgroundNotification,
//                       object: nil)
//        nc.addObserver(self,
//                       selector: #selector(handleAppDidBecomeActive),
//                       name: UIApplication.willEnterForegroundNotification,
//                       object: nil)
//
//        // 2) UIScene notifications (iOS 13+). These fire per-scene, which
//        //    is the right signal in modern host apps — UIApplication
//        //    notifications can miss scene-only transitions on iPadOS.
//        //    Observing both is safe: the handlers are idempotent (they
//        //    just flip isAppInBackground and call teardown/restart) so a
//        //    duplicate notification is harmless.
//        if #available(iOS 13.0, *) {
//            nc.addObserver(self,
//                           selector: #selector(handleSceneWillDeactivate),
//                           name: UIScene.willDeactivateNotification,
//                           object: nil)
//            nc.addObserver(self,
//                           selector: #selector(handleSceneDidActivate),
//                           name: UIScene.didActivateNotification,
//                           object: nil)
//            nc.addObserver(self,
//                           selector: #selector(handleSceneWillDeactivate),
//                           name: UIScene.didEnterBackgroundNotification,
//                           object: nil)
//            nc.addObserver(self,
//                           selector: #selector(handleSceneDidActivate),
//                           name: UIScene.willEnterForegroundNotification,
//                           object: nil)
//        }
//
//        // 3) Belt-and-braces — if we got presented AFTER the host already
//        //    went inactive, the notifications above won't fire until the
//        //    state changes. Resync from current app state right now so
//        //    isAppInBackground is correct even on first launch.
//        let state = UIApplication.shared.applicationState
//        print("📲 registerAppLifecycleObservers — initial UIApplication.applicationState = \(state.rawValue) (0=active 1=inactive 2=background)")
//        isAppInBackground = (state != .active)
//    }
//
//    private func unregisterAppLifecycleObservers() {
//        let nc = NotificationCenter.default
//        // Removing by name is cheap and tolerates "wasn't registered" — we
//        // can blanket-remove everything we might have added without
//        // tracking iOS-version variants.
//        nc.removeObserver(self, name: UIApplication.willResignActiveNotification, object: nil)
//        nc.removeObserver(self, name: UIApplication.didBecomeActiveNotification, object: nil)
//        nc.removeObserver(self, name: UIApplication.didEnterBackgroundNotification, object: nil)
//        nc.removeObserver(self, name: UIApplication.willEnterForegroundNotification, object: nil)
//        if #available(iOS 13.0, *) {
//            nc.removeObserver(self, name: UIScene.willDeactivateNotification, object: nil)
//            nc.removeObserver(self, name: UIScene.didActivateNotification, object: nil)
//            nc.removeObserver(self, name: UIScene.didEnterBackgroundNotification, object: nil)
//            nc.removeObserver(self, name: UIScene.willEnterForegroundNotification, object: nil)
//        }
//    }
//
//    // MARK: - UIScene bridge
//
//    /// Scene-level deactivation handler. In scene-based hosts (most modern
//    /// apps) this fires reliably; the UIApplication-level notifications can
//    /// miss the transition entirely. Forwards to the existing handler so
//    /// teardown logic lives in one place.
//    @available(iOS 13.0, *)
//    @objc private func handleSceneWillDeactivate(_ note: Notification) {
//        print("🎬 UIScene event \(note.name.rawValue) — forwarding to teardown")
//        handleAppWillResignActive()
//    }
//
//    /// Scene-level activation handler — mirror of handleSceneWillDeactivate.
//    @available(iOS 13.0, *)
//    @objc private func handleSceneDidActivate(_ note: Notification) {
//        print("🎬 UIScene event \(note.name.rawValue) — forwarding to re-arm")
//        handleAppDidBecomeActive()
//    }
//
//    // MARK: - Public hooks for the host app
//
//    /// Public escape hatch for host integrators. If the SDK's auto-detection
//    /// somehow misses the background transition in your app (rare but
//    /// possible in odd lifecycle setups), call this from your host's
//    /// `scene(_:willResignActive:)` / `applicationWillResignActive` and the
//    /// scanner will tear down cleanly. Idempotent; safe to call extra times.
//    @objc public func sdkHostDidEnterBackground() {
//        print("🪝 sdkHostDidEnterBackground() — host signalled background")
//        handleAppWillResignActive()
//    }
//
//    /// Mirror of `sdkHostDidEnterBackground` for the foreground path. Call
//    /// from your host's `scene(_:didBecomeActive:)` /
//    /// `applicationDidBecomeActive` if the SDK isn't picking up the event.
//    @objc public func sdkHostDidBecomeActive() {
//        print("🪝 sdkHostDidBecomeActive() — host signalled foreground")
//        handleAppDidBecomeActive()
//    }
//
//    /// Fires for both background and the brief "inactive" state (control
//    /// centre, incoming call, app switcher). Full teardown — every periodic
//    /// hardware subscriber (CMMotionManager / AVCaptureSession / audio /
//    /// timers) is stopped here so the OS sees the app as truly idle while
//    /// backgrounded. Foreground path (`handleAppDidBecomeActive`) re-arms
//    /// everything if the scanner view is still on screen.
//    @objc private func handleAppWillResignActive() {
//        let state = UIApplication.shared.applicationState
//        print("📴 handleAppWillResignActive — UIApplication.applicationState=\(state.rawValue) (0=active 1=inactive 2=background)")
//        // Idempotent: if we're already torn down (e.g. multiple lifecycle
//        // notifications fire in quick succession across UIApplication +
//        // UIScene), bail out without doing the work twice.
//        guard !isAppInBackground else {
//            print("📴 already torn down — ignoring duplicate notification")
//            return
//        }
//        isAppInBackground = true
//
//        // 1) Timers + display link. cancelActiveScanTimer() doesn't touch
//        //    pendingScanTimerStart so the foreground handler knows we still
//        //    want to be scanning.
//        cancelActiveScanTimer()
//        stopTiltCheckTimer()
//        progressDisplayLink?.invalidate()
//        progressDisplayLink = nil
//        DispatchQueue.main.async { [weak self] in
//            self?.scanProgressView?.setProgress(0, animated: false)
//        }
//
//        // 2) THE BUG FIX — stop CMMotionManager. Without this the
//        //    accelerometer/gyro keep streaming at 30 Hz while the app is
//        //    backgrounded.
//        stopMotionMonitoring()
//
//        // 3) Stop AVCaptureSession explicitly. iOS pauses it on background
//        //    automatically, but stopping it cleanly releases the camera
//        //    hardware and matches the foreground startRunning() call.
//        if let session = self.captureSession, session.isRunning {
//            DispatchQueue.global(qos: .userInitiated).async {
//                session.stopRunning()
//                print("📷 capture session stopped (background)")
//            }
//        }
//
//        // 4) Audio — pause the guidance loop. We resume from where it left
//        //    off on didBecomeActive.
//        audioQueue.async { [weak self] in
//            self?.audioPlayer?.pause()
//        }
//
//        // 5) Discard pending one-shot frame callbacks. Once we go to bg the
//        //    video queue stops emitting frames, so these closures would
//        //    never fire. On foreground we'd risk consuming the first fresh
//        //    frame for a stale validation/fake-photo request.
//        validationFrameCompletion = nil
//        pendingFakePhotoCompletion = nil
//
//        // 6) Drop sharpness so we don't sail back into foreground with a
//        //    stale "frame is sharp" reading from before we left. Also
//        //    force the next sharpness probe to actually run, not throttle.
//        //    Reset the hysteresis counter too — N consecutive sharp
//        //    probes after backgrounding starts from scratch.
//        isFrameSharp = false
//        consecutiveSharpProbes = 0
//        userIsTooCloseToFocus = false
//        lastSharpnessCheckTime = 0
//        // Same for focus — assume the worst until KVO/device-state says
//        // otherwise on the next foreground tick.
//        isAutoFocusAdjusting = true
//        // Release the tilt-check guard so the foreground re-arm can start
//        // a fresh tick (otherwise a stuck `true` would silently disable
//        // auto-zoom + guidance after returning to foreground).
//        isTiltChecking = false
//    }
//
//    /// Re-arm the whole pipeline on foreground, BUT only if the scanner is
//    /// actually still on screen. If the user backgrounded into the scanner
//    /// then navigated away to a different VC, we don't want to start the
//    /// camera back up under the new screen.
//    @objc private func handleAppDidBecomeActive() {
//        let state = UIApplication.shared.applicationState
//        print("🟢 handleAppDidBecomeActive — UIApplication.applicationState=\(state.rawValue) isAppInBackground(before)=\(isAppInBackground)")
//        // Idempotent: avoid spamming startRunning/audio/restart calls when
//        // multiple lifecycle notifications fire in quick succession.
//        guard isAppInBackground else {
//            print("🟢 already foregrounded — ignoring duplicate notification")
//            return
//        }
//        isAppInBackground = false
//
//        // Bail if the scanner VC isn't visible — e.g., the user came back
//        // to a different screen, or this VC is mid-dismiss.
//        guard self.isViewLoaded, self.view.window != nil else {
//            print("🟢 app became active but scanner not on screen — skipping re-arm")
//            return
//        }
//        print("🟢 app became active — restarting scan pipeline (scanner is on screen)")
//
//        // 1) Bring the camera hardware back. startRunning() is a blocking
//        //    call so it must go on a background queue.
//        if let session = self.captureSession, !session.isRunning {
//            DispatchQueue.global(qos: .userInitiated).async { [weak self] in
//                session.startRunning()
//                print("📷 capture session restarted (foreground)")
//
//                // Once the session is alive, restart the rest from main —
//                // these all touch UIKit / RunLoop state.
//                DispatchQueue.main.async { [weak self] in
//                    self?.resumeScanPipelineForForeground()
//                }
//            }
//        } else {
//            // Session was already running for some reason — skip the queue
//            // hop and resume directly.
//            resumeScanPipelineForForeground()
//        }
//    }
//
//    /// Re-arms the non-camera parts of the pipeline. Called from the
//    /// capture-session restart completion so we don't try to run scans
//    /// against a paused session.
//    private func resumeScanPipelineForForeground() {
//        // Resync focus state from the device — KVO doesn't fire on its own
//        // just because we came back to the foreground.
//        isAutoFocusAdjusting = videoDevice?.isAdjustingFocus ?? false
//
//        // Make sure the lens is in continuous AF/AE — see resumeContinuousAutoFocus()
//        // for why this is necessary on every entry path (one-shot AF used
//        // during the validation-path capture leaves the lens `.locked`).
//        resumeContinuousAutoFocus()
//
//        // Resume guidance audio if it was enabled when we backgrounded.
//        audioQueue.async { [weak self] in
//            guard let self = self, self.isAudioEnabled else { return }
//            self.audioPlayer?.play()
//        }
//
//        // startScanTimer() idempotently re-arms motion monitoring (via
//        // the guard in startMotionMonitoring) and the tilt-check timer,
//        // then either arms the 6-second countdown right away or holds at
//        // 0% until focus + sharpness + motion gates pass.
//        if pendingScanTimerStart {
//            startScanTimer()
//        }
//    }
//
//    override func viewDidAppear(_ animated: Bool) {
//        super.viewDidAppear(animated)
//        
//        // Step 1: Start camera session on background thread
//        DispatchQueue.global(qos: .userInitiated).async {
//            guard let session = self.captureSession, !session.isRunning else { return }
//            session.startRunning()
//            print("✅ Capture session started")
//            
//            // Step 2: Torch AFTER session is running (needs active session)
//            DispatchQueue.main.async {
//                self.toggleTorch()
//            }
//            
//            // Step 3: Audio completely separate — never on main thread
//            self.audioQueue.async { [weak self] in
//                self?.startAudioIfNeeded()
//            }
//            
//            // Step 4: Timer on main thread (gated by motion stability)
//            DispatchQueue.main.async {
//                self.startMotionMonitoring()
//                self.startScanTimer()
//            }
//        }
//    }
//  func startScanTimer() {
//        // Caller wants the countdown running — but only let it tick when the
//        // frame is genuinely capture-ready (steady + focused + sharp).
//        pendingScanTimerStart = true
//        cancelActiveScanTimer()
//
//        // Re-arm motion monitoring in case a previous scan torn it down
//        // (we stop it just before the upload to save power). This is a
//        // no-op if monitoring is already active.
//        startMotionMonitoring()
//
//        // Tilt + auto-zoom analysis runs independently of the countdown so the
//        // user keeps getting guidance even while the timer is gated.
//        startTiltCheckTimer()
//
//        guard canArmScanTimerNow() else {
//            // Hold at 0% until the gating condition clears.
//            progressDisplayLink?.invalidate()
//            progressDisplayLink = nil
//            DispatchQueue.main.async { [weak self] in
//                self?.scanProgressView?.setProgress(0, animated: false)
//            }
//            print("⏸ scan timer waiting — \(currentArmBlockReason())")
//            return
//        }
//
//        scanTimer = Timer.scheduledTimer(timeInterval: scanInterval,
//                                         target: self,
//                                         selector: #selector(scanTimerFired),
//                                         userInfo: nil,
//                                         repeats: true)
//        RunLoop.main.add(scanTimer!, forMode: .common)
//        print("⏱️ scan timer started")
//        startProgressAnimation()
//    }
//
//    /// All gating conditions for the periodic capture timer in one place. We
//    /// only let the 6-second countdown run when every one is satisfied — that
//    /// way the timer can't fire on a moving / unfocused / blurry frame and
//    /// upload garbage to the model API.
//    private func canArmScanTimerNow() -> Bool {
//        return !isAppInBackground
//            && isMotionStable
//            && !isAutoFocusAdjusting
//            && isFrameSharp
//    }
//
//    /// Diagnostic helper — names whichever gate is currently blocking us so the
//    /// logs are useful when debugging field reports.
//    private func currentArmBlockReason() -> String {
//        if isAppInBackground { return "app in background" }
//        if !isMotionStable { return "motion not stable" }
//        if isAutoFocusAdjusting { return "autofocus still adjusting" }
//        if !isFrameSharp { return "frame not sharp yet" }
//        return "ready"
//    }
//
//    private func stopScanTimer(finalProgress: Float = 1.0) {
//        // Caller no longer wants the countdown running.
//        pendingScanTimerStart = false
//        cancelActiveScanTimer()
//        // Full stop — also drop the live tilt/auto-zoom analyzer.
//        stopTiltCheckTimer()
//        print("⏹️ scan timer stopped")
//        stopProgressAnimation(finalProgress: finalProgress)
//    }
//
//    /// Cancel the underlying countdown Timer without touching the "want it running"
//    /// intent or the progress bar — used by the motion / focus / sharpness gates
//    /// so we can resume once the frame is capture-ready again.
//    ///
//    /// NOTE: the tilt + auto-zoom analysis timer is intentionally NOT stopped here.
//    /// We want live guidance and auto-zoom corrections to keep happening even
//    /// while the scan countdown is gated.
//    private func cancelActiveScanTimer() {
//        scanTimer?.invalidate()
//        scanTimer = nil
//    }
//
//    /// Pause the countdown while the user is actively interacting with a control
//    /// (zoom slider drag, etc.). Cancels the underlying timer and snaps the bar
//    /// back to 0% without clearing `pendingScanTimerStart`, so a follow-up
//    /// `startScanTimer()` can resume cleanly.
//    private func pauseScanIntervalForInteraction() {
//        cancelActiveScanTimer()
//        progressDisplayLink?.invalidate()
//        progressDisplayLink = nil
//        DispatchQueue.main.async { [weak self] in
//            self?.scanProgressView?.setProgress(0, animated: false)
//        }
//    }
//
//    // MARK: - Scan-interval progress
//
//    private func startProgressAnimation() {
//        progressDisplayLink?.invalidate()
//        progressStartTime = CACurrentMediaTime()
//
//        DispatchQueue.main.async { [weak self] in
//            self?.scanProgressView?.setProgress(0, animated: false)
//        }
//
//        let link = CADisplayLink(target: self, selector: #selector(updateScanProgress))
//        link.add(to: .main, forMode: .common)
//        progressDisplayLink = link
//    }
//
//    private func stopProgressAnimation(finalProgress: Float) {
//        progressDisplayLink?.invalidate()
//        progressDisplayLink = nil
//        DispatchQueue.main.async { [weak self] in
//            self?.scanProgressView?.setProgress(finalProgress, animated: false)
//        }
//    }
//
//    @objc private func updateScanProgress() {
//        guard scanInterval > 0 else { return }
//        let elapsed = CACurrentMediaTime() - progressStartTime
//        let fraction = Float(min(max(elapsed / scanInterval, 0), 1))
//        scanProgressView?.setProgress(fraction, animated: false)
//
//        // Once we hit 100%, no need to keep ticking; the timer fire will reset it.
//        if fraction >= 1.0 {
//            progressDisplayLink?.invalidate()
//            progressDisplayLink = nil
//        }
//    }
//
//    // MARK: - Motion stability (gates the scan timer)
//
//    private func startMotionMonitoring() {
//        guard motionManager.isDeviceMotionAvailable else {
//            // Device has no motion data — fall back to "always stable" so we don't
//            // wedge the scanner on hardware that can't report it.
//            isMotionStable = true
//            if pendingScanTimerStart { startScanTimer() }
//            return
//        }
//        guard !motionManager.isDeviceMotionActive else { return }
//
//        motionManager.deviceMotionUpdateInterval = 1.0 / 30.0   // 30 Hz is plenty
//        motionManager.startDeviceMotionUpdates(to: .main) { [weak self] motion, _ in
//            guard let self = self, let motion = motion else { return }
//
//            let a = motion.userAcceleration
//            let r = motion.rotationRate
//            let accelMag = sqrt(a.x * a.x + a.y * a.y + a.z * a.z)
//            let rotMag   = sqrt(r.x * r.x + r.y * r.y + r.z * r.z)
//
//            // Combine: acceleration dominates, rotation adds a smaller contribution.
//            let combined = accelMag + 0.1 * rotMag
//
//            // Exponential moving average — α=0.2 gives ~150 ms time constant at 30 Hz.
//            let alpha = 0.2
//            self.smoothedMotion = alpha * combined + (1 - alpha) * self.smoothedMotion
////            print("motion: \(self.smoothedMotion)")
//            let stableNow = self.smoothedMotion < self.motionStabilityThreshold
//            if stableNow != self.isMotionStable {
//                self.isMotionStable = stableNow
//                self.handleStabilityChange(stable: stableNow)
//            }
//        }
//    }
//
//    private func stopMotionMonitoring() {
//        if motionManager.isDeviceMotionActive {
//            motionManager.stopDeviceMotionUpdates()
//        }
//    }
//
//    private func handleStabilityChange(stable: Bool) {
//        if stable {
//            print("🟢 motion stable — re-evaluating scan timer gate")
//            // Re-evaluate gate; will arm only if focus + sharpness also pass.
//            reevaluateScanTimerGate()
//        } else {
//            print("🟠 motion detected — pausing scan timer, resetting progress to 0")
//            // Pause the underlying Timer but KEEP tilt/auto-zoom running so the
//            // user still gets guidance, and keep the "we want this running"
//            // intent so it auto-resumes once steady.
//            cancelActiveScanTimer()
//            progressDisplayLink?.invalidate()
//            progressDisplayLink = nil
//            DispatchQueue.main.async { [weak self] in
//                self?.scanProgressView?.setProgress(0, animated: false)
//            }
//        }
//    }
//
//    /// Called whenever any gating signal changes (motion / focus / sharpness).
//    /// Hops to main so KVO + video-queue callers don't trample the timer.
//    private func reevaluateScanTimerGate() {
//        DispatchQueue.main.async { [weak self] in
//            guard let self = self else { return }
//            guard self.pendingScanTimerStart else { return }
//            if self.scanTimer == nil, self.canArmScanTimerNow() {
//                self.startScanTimer()
//            }
//        }
//    }
//
//    private func resetScanTimer() {
//        stopScanTimer()
//        startScanTimer()
//    }
//    
//    @objc private func scanTimerFired() {
//        // Skip if we're already processing a detected QR or uploading
//        guard !isQRCodeDetected, !isUploading else {
//            print("⏱️ scanTimer skipped (isQRCodeDetected=\(isQRCodeDetected), isUploading=\(isUploading))")
//            return
//        }
//
//        // Second-chance gate: even if the timer was armed earlier, the frame
//        // may have drifted out of focus / motion since. Re-check before firing
//        // so we don't burn the periodic upload on a bad frame.
//        guard canArmScanTimerNow() else {
//            print("⏱️ scanTimer fired but gate failed — \(currentArmBlockReason()); resetting countdown")
//            // Cancel the active Timer, hold the progress bar at 0%, and let
//            // the gate re-arm when conditions return.
//            cancelActiveScanTimer()
//            progressDisplayLink?.invalidate()
//            progressDisplayLink = nil
//            DispatchQueue.main.async { [weak self] in
//                self?.scanProgressView?.setProgress(0, animated: false)
//            }
//            return
//        }
//
//        // Mark that this capture is periodic and should upload with this label
//
//        print("⏰ scanTimer fired — capturing photo for periodic upload")
//        pendingTestingLabel = "Prod"
//
//        stopScanTimer()
//        
//        validateWithObjectDetection { [weak self] hasAllClasses, capturedImage in
//            guard let self = self else { return }
//            
//            if hasAllClasses {
//                // Capture the next live frame, fire the v3 authenticity-
//                // verification upload with that image, THEN show the fake-product
//                // screen. Capture-BEFORE-navigate matters because the fake screen
//                // push triggers viewWillDisappear which stops the AVCaptureSession
//                // — if we captured after, no frames would arrive to fulfil the
//                // completion. A 500 ms safety timeout guarantees the fake screen
//                // still shows even if the camera died and never delivers a frame.
//                var fakeScreenShown = false
//                let showFakeScreenOnce: () -> Void = { [weak self] in
//                    guard let self = self, !fakeScreenShown else { return }
//                    fakeScreenShown = true
//                    self.simulateFakeProductDetails()
//                }
//
//                self.captureFrameForValidation { [weak self] image in
//                    guard let self = self else { return }
//                    if let image = image {
//                        self.sendImageToAuthenticityVerificationWithImage(
//                            image: image,
//                            deviceId: self.axionPersistentDeviceId(),
//                            ai_predection: "Fake timeout",
//                            device_family: self.axionDeviceFamilyName()
//                        ) { result in
//                            switch result {
//                            case .success(let body):
//                                print("✅ /authenticity-verification-v3/ success: \(body.prefix(200))")
//                            case .failure(let err):
//                                print("❌ /authenticity-verification-v3/ failure: \(err.localizedDescription)")
//                            }
//                        }
//                    } else {
//                        print("⚠️ /authenticity-verification-v3/ skipped — no live frame captured")
//                    }
//                    showFakeScreenOnce()
//                }
//
//                // Safety net — if the camera doesn't deliver a frame within 500 ms
//                // (e.g. session interrupted, app backgrounded mid-fire), proceed to
//                // the fake screen anyway. `showFakeScreenOnce` is idempotent.
//                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
//                    if !fakeScreenShown {
//                        print("⚠️ /authenticity-verification-v3/ frame capture timed out — proceeding to fake screen")
//                        showFakeScreenOnce()
//                    }
//                }
//            }
//            else{
//                self.showAlert(title: "QR not validated", message: "The QR label could not be verified as original. This product may be invalid.")
//                self.captureFrameForValidation { [weak self] image in
//                    guard let self = self else { return }
//                    if let image = image {
//                        self.sendImageToAuthenticityVerificationWithImage(
//                            image: image,
//                            deviceId: self.axionPersistentDeviceId(),
//                            ai_predection: "The QR label could not be verified as original. This product may be invalid.",
//                            device_family: self.axionDeviceFamilyName()
//                        ) { result in
//                            switch result {
//                            case .success(let body):
//                                print("✅ /authenticity-verification-v3/ success: \(body.prefix(200))")
//                            case .failure(let err):
//                                print("❌ /authenticity-verification-v3/ failure: \(err.localizedDescription)")
//                            }
//                        }
//                    } else {
//                        print("⚠️ /authenticity-verification-v3/ skipped — no live frame captured")
//                    }
//                  
//                }
//            }
//        }
//        
//     
////        self.showAlert(title: "QR not validated", message: "The QR label could not be verified as original. This product may be invalid.")
////        validateWithObjectDetection { [weak self] hasAllClasses, capturedImage in
////              guard let self = self else { return }
////
////              if hasAllClasses {
////                  // All 4 classes found — Vision still couldn't decode the QR
////                  // payload though. Two cases:
////                  //   1) We've already retried with the extended 15s window —
////                  //      this is the second timeout, commit to fake screen.
////                  //   2) First timeout — try the /validate/ fallback before
////                  //      giving up. It may recover the qr_value server-side,
////                  //      mark it as fake, or ask us to retry once more.
////                  if self.isInExtendedScanMode {
////                      print("⚠️ All classes detected after extended retry — showing Fake QR")
////                      self.simulateFakeProductDetails()
////                      return
////                  }
////
////                  // Belt-and-braces sharpness check on the centre region of
////                  // the very frame TFLite just ran on. The periodic
////                  // sharpness probe samples every ~0.35s and the lens can
////                  // drift between samples — if the all-classes-present
////                  // frame is itself blurry, restart the countdown so the
////                  // next tick fires on a genuinely sharp frame instead of
////                  // committing to a fuzzy high-res capture.
////                  if let validationImage = capturedImage {
////                      let region = self.centerScanRegion(of: validationImage) ?? validationImage
////                      if self.isImageBlurry(region, threshold: Float(self.liveSharpnessThreshold)) {
////                          print("⚠️ Validation frame (scan region) is blurry — resetting scan timer instead of capturing")
////                          self.isFrameSharp = false
////                          self.startScanTimer()
////                          return
////                      }
////                  }
////
////                  print("🛟 First timeout with all classes — capturing high-res photo for /validate/ crop")
////
////                  // Match the genuine-path pipeline exactly: snap a
////                  // full-resolution photo (respects current videoZoomFactor),
////                  // crop the same way we crop `imageToValidate` before
////                  // sendImagetoModelAPI, and only then forward to
////                  // /validate/. The photoOutput delegate sees the closure
////                  // we install below and routes the capture to us instead
////                  // of running the /predict/ pipeline.
////                  //
////                  // cropSquareNow needs `self.detectedBarcode`, which is
////                  // nil on the fake path because Vision couldn't decode the
////                  // QR — so it'll return nil and we fall through to the
////                  // TFLite-derived crop (cropAroundTFLiteQR), which uses
////                  // the same 3x padding so the validate crop matches the
////                  // predict crop in shape.
////                  self.pendingFakePhotoCompletion = { [weak self] highResCIImage in
////                      guard let self = self else { return }
////
////                      guard let ciImage = highResCIImage else {
////                          print("⚠️ High-res photo capture failed — showing fake screen as fallback")
////                          self.simulateFakeProductDetails()
////                          return
////                      }
////
////                      Task.detached(priority: .userInitiated) {
////                          // 1. Try the Vision-bbox crop first. Almost always
////                          //    nil on the fake path (detectedBarcode is
////                          //    nil), but cheap and handles edge cases where
////                          //    Vision did briefly latch on.
////                          var cropped = self.cropSquareNow(ciImage)
////
////                          // 2. Fall back to a TFLite-based QR crop with the
////                          //    same 3x padding as cropSquareNow.
////                          if cropped == nil {
////                              print("⚠️ cropSquareNow failed — trying TFLite-based QR crop")
////                              cropped = self.cropAroundTFLiteQR(ciImage)
////                          }
////
////                          guard let imageToValidate = cropped else {
////                              await MainActor.run {
////                                  // No usable crop — nothing to send to
////                                  // /validate either. Go straight to the
////                                  // fake screen, same as the pre-validate
////                                  // behaviour.
////                                  print("⚠️ Both Vision and TFLite crops failed — falling back to fake screen")
//////                                  self.simulateFakeProductDetails()
////                              }
////                              return
////                          }
////
////                          // 3. Final sharpness gate on the actual crop we're
////                          //    about to upload. Two metrics, both must pass:
////                          //
////                          //    (a) Laplacian variance — fast, catches the
////                          //        coarse "obviously soft" cases.
////                          //    (b) Tenengrad score (0-100) — mirrors the
////                          //        server-side Python `sharpness_score`.
////                          //        Tenengrad is more sensitive to fine-detail
////                          //        edge strength than Laplacian, which is
////                          //        exactly what we need for Axion-code prints
////                          //        where the pattern microstructure matters
////                          //        but the overall image can look "okay".
////                          //
////                          //    Either failing → reset timer, do not upload,
////                          //    do not show fake screen.
////                          if self.isImageBlurry(imageToValidate, threshold: self.validateCropSharpnessThreshold) {
////                              await MainActor.run {
////                                  print("⚠️ High-res crop failed Laplacian gate (threshold=\(self.validateCropSharpnessThreshold)) — resetting scan timer")
////                                  self.isFrameSharp = false
////                                  self.startScanTimer()
////                              }
////                              return
////                          }
////                          let tenengrad = self.sharpnessScore(imageToValidate)
////                          if tenengrad < self.validateCropTenengradThreshold {
////                              await MainActor.run {
////                                  print(String(format: "⚠️ High-res crop failed Tenengrad gate (score=%.2f < threshold=%.0f) — resetting scan timer, NOT uploading and NOT showing fake screen",
////                                               tenengrad, self.validateCropTenengradThreshold))
////                                  self.isFrameSharp = false
////                                  self.startScanTimer()
////                              }
////                              return
////                          }
////                          print(String(format: "✅ High-res crop passed sharpness gates (Tenengrad=%.2f) — proceeding to /validate/", tenengrad))
////
////                          // 4. Same pattern-square TFLite check used before
////                          //    /predict/ — guarantees the persisted /validate/
////                          //    frame has all 6 patterns visible.
////                          let patternsValid = await self.validatePatternBoxes(imageToValidate)
////
////                          await MainActor.run {
////                              if patternsValid {
////                                  print("✅ Pattern validation passed on tight high-res crop — forwarding to /validate/")
////                                  // Debug-only save matching the
////                                  // /predict/ TestFlight save.
////                                  if self.isRunningInTestFlight() {
////                                      UIImageWriteToSavedPhotosAlbum(imageToValidate, nil, nil, nil)
////                                  }
////                              } else {
////                                  print("⚠️ Pattern validation failed on tight high-res crop — forwarding to /validate/ anyway (server side decides)")
////                              }
////
////                              // Hand the crop to /validate/. Branch
////                              // handling lives inside the API method:
////                              //  - Original + qr_value → makeApiCall_new
////                              //  - not Original       → simulateFakeProductDetails(with final_result)
////                              //  - Original + empty   → restartScanWithExtendedInterval
////                              ProgressHUD.shared.show(in: self.view, message: "Validating…")
////                              self.sendImagetoValidationAPI(
////                                  image: imageToValidate,
////                                  testingLabel: "Prod"
////                              ) { _ in
////                                  // Branches handled inside the API
////                                  // call — nothing to do here.
////                              }
////                          }
////                      }
////                  }
////
////                  // Kick off the actual photo capture. The delegate routes
////                  // the result into pendingFakePhotoCompletion above.
////                  //
////                  // Uses the focus-lock-and-wait variant so the lens is
////                  // verifiably stable at the moment the shutter fires —
////                  // the live-preview sharpness probe above tells us the
////                  // frame was sharp ~0-300 ms ago, but the lens can drift
////                  // in the window between the probe and the actual photo
////                  // capture. captureSharpPhotoForValidation waits for
////                  // isAdjustingFocus/isAdjustingExposure to settle (or
////                  // gives up after ~600 ms) before pulling the trigger.
////                  self.captureSharpPhotoForValidation()
////
////              } else {
////                  // Classes missing — genuinely unreadable / not an axion code
////                  print("❌ Not all classes detected — showing QR not validated alert")
////                  self.showAlert(title: "QR not validated", message: "The QR label could not be verified as original. This product may be invalid.")
////              }
////          }
//    }
//
//    
//    override func viewWillDisappear(_ animated: Bool) {
//        super.viewWillDisappear(animated)
//        if self.captureSession?.isRunning == true {
//            self.captureSession.stopRunning()
//        }
//        stopScanTimer()
//        stopMotionMonitoring()
//        stopMonitoringFocusState()
//        unregisterAppLifecycleObservers()
//    }
//    
////    override func viewDidLayoutSubviews() {
////        super.viewDidLayoutSubviews()
////        updateCornerBoxes()
////    }
//    override func viewDidLayoutSubviews() {
//        super.viewDidLayoutSubviews()
//
//        // 🔑 THIS IS MANDATORY
//        videoPreviewLayer?.frame = previewView.bounds
//        cornerBoxLayer.frame = previewView.bounds
//        dimOverlayLayer.frame = previewView.bounds
//
//        // your existing logic
//        updateDimOverlay()
//        updateCornerBoxes()
//
//        // Z-order fix for the overlay guide image: setupCamera appends
//        // videoPreviewLayer / dimOverlayLayer / cornerBoxLayer AFTER
//        // setupUI added overlayImageView as a subview, so the camera
//        // layers end up on top and the overlay is hidden behind the
//        // opaque video. bringSubviewToFront idempotently re-pins the
//        // overlay to the top sublayer position. Safe to call repeatedly.
//        if let overlay = overlayImageView {
//            previewView.bringSubviewToFront(overlay)
//        }
//    }
//
//    private func setupUI() {
//        view.backgroundColor = .black
//        
//        // Preview view (full screen)
//        previewView = UIView()
//        previewView.translatesAutoresizingMaskIntoConstraints = false
//        view.addSubview(previewView)
//        
//        // Instruction label
//        instructionLabel = UILabel()
//        instructionLabel.translatesAutoresizingMaskIntoConstraints = false
//        instructionLabel.text = "Make sure the QR Code is centred\nand clearly visible"
//        instructionLabel.textColor = .white
//        instructionLabel.textAlignment = .center
//        instructionLabel.numberOfLines = 0
//        instructionLabel.font = .systemFont(ofSize: 18, weight: .medium)
//        view.addSubview(instructionLabel)
//
//        // Scan-interval progress bar (sits just below the instruction label)
//        scanProgressView = UIProgressView(progressViewStyle: .bar)
//        scanProgressView.translatesAutoresizingMaskIntoConstraints = false
//        scanProgressView.progressTintColor = UIColor(red: 0.20, green: 0.70, blue: 1.00, alpha: 1.0)
//        scanProgressView.trackTintColor = UIColor.white.withAlphaComponent(0.25)
//        scanProgressView.layer.cornerRadius = 3
//        scanProgressView.clipsToBounds = true
//        scanProgressView.progress = 0
//        view.addSubview(scanProgressView)
//        
//        // Add this near the top of setupUI() after instructionLabel creation
//        closeButton = UIButton(type: .system)
//        closeButton.translatesAutoresizingMaskIntoConstraints = false
//        closeButton.setImage(UIImage(systemName: "chevron.left"), for: .normal)
//        closeButton.tintColor = .white
//        closeButton.backgroundColor = UIColor(white: 0.0, alpha: 0.35)
//        closeButton.layer.cornerRadius = 20
//        closeButton.addTarget(self, action: #selector(closeTapped), for: .touchUpInside)
//        view.addSubview(closeButton)
//        // Make sure the button is always on top so touches reach it
//        view.bringSubviewToFront(closeButton)
//        audioButton = UIButton(type: .system)
//        audioButton.translatesAutoresizingMaskIntoConstraints = false
//
//        let config = UIImage.SymbolConfiguration(pointSize: 20, weight: .semibold)
//        audioButton.setImage(
//            UIImage(systemName: "speaker.wave.2.fill")?.withConfiguration(config),
//            for: .normal
//        )
//
//        audioButton.tintColor = .white
//        audioButton.backgroundColor = UIColor.black.withAlphaComponent(0.35)
//        audioButton.layer.cornerRadius = 22
//        audioButton.clipsToBounds = true
//
//        audioButton.addTarget(self, action: #selector(toggleAudio), for: .touchUpInside)
//        view.addSubview(audioButton)
//        // Prevent preview view intercepting touches (preview is passive)
//        previewView.isUserInteractionEnabled = false
//
//        NSLayoutConstraint.activate([
//            closeButton.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 16),
//            closeButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 12),
//            closeButton.widthAnchor.constraint(equalToConstant: 40),
//            closeButton.heightAnchor.constraint(equalToConstant: 40),
//            audioButton.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -16),
//                audioButton.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 12),
//                audioButton.widthAnchor.constraint(equalToConstant: 44),
//                audioButton.heightAnchor.constraint(equalToConstant: 44)
//        ])
//
//        
//        // Status label (for "QR Code detected")
//        statusLabel = UILabel()
//        statusLabel.translatesAutoresizingMaskIntoConstraints = false
//        statusLabel.text = ""
//        statusLabel.textColor = .white
//        statusLabel.textAlignment = .center
//        statusLabel.font = .systemFont(ofSize: 16, weight: .medium)
//        statusLabel.alpha = 0
//        view.addSubview(statusLabel)
//        
//        // Zoom slider
//        zoomSlider = UISlider()
//        zoomSlider.translatesAutoresizingMaskIntoConstraints = false
//        zoomSlider.minimumValue = Float(minZoom)
//        zoomSlider.maximumValue = Float(maxZoom)
//        zoomSlider.value = Float(currentZoom)
//        zoomSlider.minimumTrackTintColor = .white
//        zoomSlider.maximumTrackTintColor = .darkGray
//        zoomSlider.addTarget(self, action: #selector(zoomSliderValueChanged(_:)), for: .valueChanged)
//        // Reset the 5-second countdown while the user is dragging the slider, and
//        // restart it once they lift their finger.
//        zoomSlider.addTarget(self, action: #selector(zoomSliderTouchBegan), for: .touchDown)
//        zoomSlider.addTarget(self, action: #selector(zoomSliderTouchEnded),
//                             for: [.touchUpInside, .touchUpOutside, .touchCancel])
//        view.addSubview(zoomSlider)
//        
//        // In setupUI(), add:
//        zoomLabel = UILabel()
//        zoomLabel.translatesAutoresizingMaskIntoConstraints = false
//        zoomLabel.text = "\(currentZoom)x"
//        zoomLabel.textColor = .white
//        zoomLabel.textAlignment = .center
//        zoomLabel.font = .systemFont(ofSize: 14, weight: .medium)
//        view.addSubview(zoomLabel)
//        
//        focusButton = UIButton(type: .system)
//                focusButton.translatesAutoresizingMaskIntoConstraints = false
//                focusButton.setImage(UIImage(systemName: "scope"), for: .normal)
//                focusButton.tintColor = .white
//                focusButton.addTarget(self, action: #selector(triggerAutoFocus), for: .touchUpInside)
//                view.addSubview(focusButton)
//        
//                // Add constraints for focus button
//                NSLayoutConstraint.activate([
//                    focusButton.topAnchor.constraint(equalTo: scanProgressView.bottomAnchor, constant: 16),
//                    focusButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
//                    focusButton.widthAnchor.constraint(equalToConstant: 44),
//                    focusButton.heightAnchor.constraint(equalToConstant: 44)
//                ])
//        
//        // Bottom controls
//        let bottomControls = UIStackView()
//        bottomControls.translatesAutoresizingMaskIntoConstraints = false
//        bottomControls.axis = .horizontal
//        bottomControls.alignment = .center
//        bottomControls.distribution = .equalCentering
//        view.addSubview(bottomControls)
//        
//        // Refresh button
//        refreshButton = UIButton(type: .system)
//        refreshButton.translatesAutoresizingMaskIntoConstraints = false
//        refreshButton.setImage(UIImage(systemName: "arrow.clockwise"), for: .normal)
//        refreshButton.tintColor = .white
//        refreshButton.addTarget(self, action: #selector(restartScan), for: .touchUpInside)
//        bottomControls.addArrangedSubview(refreshButton)
//        
//        // Logo image (center)
//        let logoImageView = UIImageView()
//        logoImageView.translatesAutoresizingMaskIntoConstraints = false
//        logoImageView.image = UIImage(named: "logo_placeholder")
//        logoImageView.contentMode = .scaleAspectFit
//        bottomControls.addArrangedSubview(logoImageView)
//        
//        NSLayoutConstraint.activate([
//            logoImageView.widthAnchor.constraint(lessThanOrEqualTo: view.widthAnchor, multiplier: 0.4),
//            logoImageView.heightAnchor.constraint(equalToConstant: 40)
//        ])
//        
//        // Torch button
//        torchButton = UIButton(type: .system)
//        torchButton.translatesAutoresizingMaskIntoConstraints = false
//        torchButton.setImage(UIImage(systemName: "bolt.fill"), for: .normal)
//        torchButton.tintColor = .white
//        torchButton.addTarget(self, action: #selector(torchButtonTapped), for: .touchUpInside)
//        bottomControls.addArrangedSubview(torchButton)
//        
//        // Translucent dim overlay (clear window in the centre, dark elsewhere)
//        dimOverlayLayer.fillRule = .evenOdd
//        dimOverlayLayer.fillColor = UIColor.black.withAlphaComponent(0.55).cgColor
//        dimOverlayLayer.frame = previewView.bounds
//        previewView.layer.addSublayer(dimOverlayLayer)
//
//        // Corner boxes
//        cornerBoxLayer.strokeColor = UIColor.red.cgColor
//        cornerBoxLayer.lineWidth = 3.0
//        cornerBoxLayer.fillColor = UIColor.clear.cgColor
//        cornerBoxLayer.frame = previewView.bounds
//        previewView.layer.addSublayer(cornerBoxLayer)
//
//        // Overlay guide image — semi-transparent, sized to match the
//        // scan window, centred inside the preview. Subviews render above
//        // sublayers, so this sits naturally on top of videoPreviewLayer,
//        // dimOverlayLayer, and cornerBoxLayer — exactly where the corner
//        // brackets visually frame it.
//        overlayImageView = UIImageView()
//        overlayImageView.translatesAutoresizingMaskIntoConstraints = false
//        // EXPLICIT framework bundle. Without `in: AxionBundle.bundle`,
//        // UIImage(named:) defaults to Bundle.main (the host app) and the
//        // SDK's framework-embedded asset won't be found.
//        let loadedOverlay = UIImage(named: "overlay",
//                                    in: AxionBundle.bundle,
//                                    compatibleWith: nil)
//        overlayImageView.image = loadedOverlay
//        print("🖼️ overlayImageView image loaded: \(loadedOverlay == nil ? "NIL — check asset name + framework bundle" : "OK size=\(loadedOverlay!.size)")")
//        overlayImageView.contentMode = .scaleAspectFit
//        overlayImageView.alpha = overlayImageAlpha
//        overlayImageView.isUserInteractionEnabled = false   // never absorb taps
//        previewView.addSubview(overlayImageView)
//        NSLayoutConstraint.activate([
//            overlayImageView.centerXAnchor.constraint(equalTo: previewView.centerXAnchor),
//            overlayImageView.centerYAnchor.constraint(equalTo: previewView.centerYAnchor),
//            overlayImageView.widthAnchor.constraint(equalToConstant: scanWindowSize.width),
//            overlayImageView.heightAnchor.constraint(equalToConstant: scanWindowSize.height)
//        ])
//        
//        // Constraints
//        NSLayoutConstraint.activate([
//            previewView.topAnchor.constraint(equalTo: view.topAnchor),
//            previewView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
//            previewView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
//            previewView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
//            
//            instructionLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 20),
//            instructionLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40),
//            instructionLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -40),
//
//            scanProgressView.topAnchor.constraint(equalTo: instructionLabel.bottomAnchor, constant: 12),
//            scanProgressView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40),
//            scanProgressView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -40),
//            scanProgressView.heightAnchor.constraint(equalToConstant: 6),
//            
//            statusLabel.centerYAnchor.constraint(equalTo: view.centerYAnchor),
//            statusLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40),
//            statusLabel.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -40),
//            
//            zoomSlider.bottomAnchor.constraint(equalTo: bottomControls.topAnchor, constant: -20),
//            zoomSlider.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40),
//            zoomSlider.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -40),
//            zoomLabel.bottomAnchor.constraint(equalTo: zoomSlider.topAnchor, constant: -8),
//            zoomLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
//            
//            bottomControls.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -30),
//            bottomControls.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 40),
//            bottomControls.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -40),
//            bottomControls.heightAnchor.constraint(equalToConstant: 50)
//        ])
//
//        updateDimOverlay()
//        updateCornerBoxes()
//    }
//    
//    @objc private func toggleAudio() {
//        isAudioEnabled.toggle()
//
//        let iconName = isAudioEnabled ? "speaker.wave.2.fill" : "speaker.slash.fill"
//        let config = UIImage.SymbolConfiguration(pointSize: 20, weight: .semibold)
//
//        DispatchQueue.main.async {
//            self.audioButton.setImage(
//                UIImage(systemName: iconName)?.withConfiguration(config),
//                for: .normal
//            )
//        }
//
//        audioQueue.async {
//            if self.isAudioEnabled {
//                self.startAudioIfNeeded()
//            } else {
//                self.audioPlayer?.pause()
//            }
//        }
//    }
//    private func configureAudioSessionIfNeeded() {
//        guard !isAudioSessionConfigured else { return }
//
//        // Run entirely on the audio queue — never touch main thread
//        do {
//            let session = AVAudioSession.sharedInstance()
//            try session.setCategory(.playback, mode: .default, options: [.mixWithOthers])
//            try session.setActive(true)
//            isAudioSessionConfigured = true
//            print("✅ Audio session configured")
//        } catch {
//            print("❌ Audio session error: \(error)")
//        }
//    }
//    /// Show the fake-product screen.
//    ///
//    /// - parameter messageOverride: Optional human-readable string to surface
//    ///   to the user via `AcvissProdDetailsViewModel.productMessageText`. When
//    ///   provided we splice it into `data.message` of the parsed
//    ///   `fake_details.json` so the existing configureData() pipeline picks
//    ///   it up as the `.Message` section (no view-model changes required).
//    ///   When `nil`, the bundled JSON's default message is shown.
//    ///
//    ///   The /validate/ endpoint's `final_result` (e.g. "Code is too small or
//    ///   too far away. Please zoom in and try again.") gets passed through
//    ///   here so the user sees the actual server-side reason rather than the
//    ///   generic "fake label" line.
//    private func simulateFakeProductDetails(messageOverride: String? = nil) {
//        guard let url = AxionBundle.bundle.url(forResource: "fake_details", withExtension: "json") else {
//            print("❌ fake_details.json not found in AxionBundle.bundle")
//            return
//        }
//
//        do {
//            let data = try Data(contentsOf: url)
//            let any = try JSONSerialization.jsonObject(with: data, options: .mutableLeaves)
//
//            guard var jsonResult = any as? [String: Any] else {
//                print("❌ fake_details.json is not a valid [String: Any] dictionary")
//                return
//            }
//
//            // Splice the override into data.message so configureData() picks
//            // it up as the .Message TableData row and productMessageText
//            // returns it verbatim.
//            if let override = messageOverride?.trimmingCharacters(in: .whitespacesAndNewlines),
//               !override.isEmpty {
//                var dataDict = (jsonResult["data"] as? [String: Any]) ?? [:]
//                dataDict["message"] = override
//                jsonResult["data"] = dataDict
//                print("📝 simulateFakeProductDetails messageOverride='\(override)'")
//            }
//
//            let responseCode = jsonResult["response_code"] as? Int
//            let isSuccess = (responseCode == 100)
//
//            self.resetDetection()
//
//            let prodView = UIHostingController(rootView: AcvissProdDetailsView(isSuccess: isSuccess, jsonResult: jsonResult))
//            prodView.title = "Product Details"
//
//            DispatchQueue.main.async {
//                if let nav = self.navigationController {
//                    nav.pushViewController(prodView, animated: true)
//                } else {
//                    let nav = UINavigationController(rootViewController: prodView)
//                    nav.modalPresentationStyle = .fullScreen
//                    prodView.navigationItem.leftBarButtonItem = UIBarButtonItem(
//                        barButtonSystemItem: .close,
//                        target: self,
//                        action: #selector(self.prodDetailsCloseTapped)
//                    )
//                    self.present(nav, animated: true, completion: nil)
//                }
//            }
//        } catch {
//            print("❌ simulateProductDetails: error reading JSON — \(error)")
//        }
//    }
//    private func startAudioIfNeeded() {
//        // Already on audioQueue — stay here entirely
//        guard isAudioEnabled else { return }
//
//        if let player = audioPlayer {
//            if !player.isPlaying { player.play() }
//            return
//        }
//
//        // Configure session here on audioQueue, not main thread
//        configureAudioSessionIfNeeded()
//
//        guard let url = AxionBundle.bundle.url(
//            forResource: "America",
//            withExtension: "m4a"
//        ) else {
//            print("❌ Audio file not found in AxionBundle.bundle")
//            return
//        }
//
//        do {
//            let player = try AVAudioPlayer(contentsOf: url)
//            player.numberOfLoops = 1
//            player.prepareToPlay()
//            audioPlayer = player
//            if isAudioEnabled { player.play() }
//        } catch {
//            print("❌ Audio init error: \(error.localizedDescription)")
//        }
//    }
//
//
//    @available(iOS 13.0, *)
//        private func monitorFocusState() {
//            guard let device = videoDevice else { return }
//            // Re-entrancy guard: registering the same observer twice will crash
//            // when we later try to remove it.
//            guard !focusObserversRegistered else { return }
//
//            device.addObserver(self, forKeyPath: "adjustingFocus", options: [.new, .initial], context: nil)
//            device.addObserver(self, forKeyPath: "lensPosition", options: [.new], context: nil)
//            focusObserversRegistered = true
//        }
//
//        private func stopMonitoringFocusState() {
//            guard focusObserversRegistered, let device = videoDevice else { return }
//            device.removeObserver(self, forKeyPath: "adjustingFocus")
//            device.removeObserver(self, forKeyPath: "lensPosition")
//            focusObserversRegistered = false
//        }
//
//        override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
//            if keyPath == "adjustingFocus" {
//                if let adjusting = change?[.newKey] as? Bool {
//                    // Update the gating flag on the main thread (KVO can fire
//                    // on arbitrary threads).
//                    DispatchQueue.main.async { [weak self] in
//                        guard let self = self else { return }
//                        let wasAdjusting = self.isAutoFocusAdjusting
//                        self.isAutoFocusAdjusting = adjusting
//                        self.updateFocusStatus(isFocused: !adjusting)
//                        // When focus locks back in, give the scan timer a
//                        // chance to arm. Sharpness sampler will confirm the
//                        // frame actually settled before the countdown starts.
//                        if wasAdjusting && !adjusting {
//                            // Force a fresh sharpness sample on next frame.
//                            self.isFrameSharp = false
//                            self.lastSharpnessCheckTime = 0
//                            self.reevaluateScanTimerGate()
//                        } else if adjusting && !wasAdjusting {
//                            // Lens is hunting — assume frame is no longer sharp
//                            // and pause the countdown immediately.
//                            self.isFrameSharp = false
//                            self.cancelActiveScanTimer()
//                            self.progressDisplayLink?.invalidate()
//                            self.progressDisplayLink = nil
//                            self.scanProgressView?.setProgress(0, animated: false)
//                            self.instructionLabel?.text = "Focusing…"
//                            self.instructionLabel?.textColor = .yellow
//                        }
//                    }
//                }
//            }
//        }
//        private func setupFocusStatusIndicator() {
//            focusStatusView = UIView()
//            focusStatusView.translatesAutoresizingMaskIntoConstraints = false
//            focusStatusView.backgroundColor = .red
//            focusStatusView.layer.cornerRadius = 4
//            focusStatusView.alpha = 0
//            view.addSubview(focusStatusView)
//    
//            NSLayoutConstraint.activate([
//                focusStatusView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 10),
//                focusStatusView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -10),
//                focusStatusView.widthAnchor.constraint(equalToConstant: 8),
//                focusStatusView.heightAnchor.constraint(equalToConstant: 8)
//            ])
//        }
//    
//        private func updateFocusStatus(isFocused: Bool) {
//            // setupFocusStatusIndicator() is opt-in; guard so we don't crash if
//            // it was never invoked by the host integration.
//            guard let dot = self.focusStatusView else { return }
//            UIView.animate(withDuration: 0.3) {
//                dot.backgroundColor = isFocused ? .green : .red
//                dot.alpha = isFocused ? 1 : 0.5
//            }
//        }
//    
//    @objc private func closeTapped() {
//        // prevent multiple taps
//        guard !isClosing else { return }
//        isClosing = true
//        stopScanTimer()
//        stopMotionMonitoring()
//        stopMonitoringFocusState()
//        unregisterAppLifecycleObservers()
//        closeButton.isEnabled = false
//        audioQueue.async { [weak self] in
//            self?.audioPlayer?.stop()
//            self?.audioPlayer = nil
//        }
//        // Stop capture session on background queue — wait until it finishes
//        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
//            guard let self = self else { return }
//
//            if let session = self.captureSession, session.isRunning {
//                session.stopRunning() // blocking call — will return when stopped
//                print("✅ capture session stopped")
//            }
//
//            // Remove any observers/timers that might keep VC alive
//            DispatchQueue.main.async {
//                self.processingTimer?.invalidate()
//                self.processingTimer = nil
//
//                // If you added KVO observers (e.g., on device), remove them safely:
//                // try? self.videoDevice?.removeObserver(self, forKeyPath: "adjustingFocus")
//
//                // If VC is embedded in a navigation controller, dismiss the whole nav
//                if let nav = self.navigationController, nav.presentingViewController != nil {
//                    nav.dismiss(animated: true) {
//                        self.onClose?()
//                        self.cleanupAfterDismiss()
//                    }
//                } else {
//                    self.dismiss(animated: true) {
//                        self.onClose?()
//                        self.cleanupAfterDismiss()
//                    }
//                }
//            }
//        }
//    }
//
//    private func cleanupAfterDismiss() {
//        // Optional: tidy up to ensure deinit happens
//        self.captureSession = nil
//        self.videoDevice = nil
//        self.videoPreviewLayer?.removeFromSuperlayer()
//        self.videoPreviewLayer = nil
//        self.isClosing = false
//    }
//        @objc private func triggerAutoFocus() {
//            guard let device = videoDevice else { return }
//
//            do {
//                try device.lockForConfiguration()
//
//                // Trigger autofocus
//                if device.isFocusModeSupported(.autoFocus) {
//                    device.focusMode = .autoFocus
//                }
//
//                // Trigger auto exposure
//                if device.isExposureModeSupported(.autoExpose) {
//                    device.exposureMode = .autoExpose
//                }
//
//                device.unlockForConfiguration()
//
//                // Show feedback
//                showFocusFeedback()
//
//            } catch {
//                print("❌ Auto focus trigger failed: \(error)")
//            }
//        }
//
//    /// Restore the lens + exposure to *continuous* AF/AE so the camera
//    /// keeps refocusing as the user moves toward a new code. We have to do
//    /// this explicitly on every reset path because two code sites flip the
//    /// device into one-shot mode and leave it there:
//    ///   • `captureSharpPhotoForValidation` sets `.autoFocus` before the
//    ///     /validate/ shutter. That's a one-shot mode — AVFoundation
//    ///     transitions to `.locked` after convergence and stays locked.
//    ///   • The manual focusButton's `triggerAutoFocus` does the same.
//    ///
//    /// Without this call, after a scan completes and the user taps
//    /// "Scan Again", the lens stays focused at the previous code's
//    /// distance — the user has to tap the focusButton to unstick it.
//    /// Mirrors the genuine-path → /predict/ flow which similarly benefits
//    /// from continuous AF resuming between scans.
//    private func resumeContinuousAutoFocus() {
//        guard let device = videoDevice else { return }
//        do {
//            try device.lockForConfiguration()
//            if device.isFocusModeSupported(.continuousAutoFocus) {
//                device.focusMode = .continuousAutoFocus
//            } else if device.isFocusModeSupported(.autoFocus) {
//                // Fallback: at least kick off one AF cycle so the lens
//                // doesn't sit at the previous lock point.
//                device.focusMode = .autoFocus
//            }
//            if device.isExposureModeSupported(.continuousAutoExposure) {
//                device.exposureMode = .continuousAutoExposure
//            } else if device.isExposureModeSupported(.autoExpose) {
//                device.exposureMode = .autoExpose
//            }
//            device.unlockForConfiguration()
//            print("🎯 resumed continuous AF/AE")
//        } catch {
//            print("❌ resumeContinuousAutoFocus: lockForConfiguration failed — \(error.localizedDescription)")
//        }
//    }
//    
//        private func showFocusFeedback() {
//            let generator = UIImpactFeedbackGenerator(style: .medium)
//            generator.impactOccurred()
//    
//            UIView.animate(withDuration: 0.2, animations: {
//                self.focusButton.transform = CGAffineTransform(scaleX: 1.3, y: 1.3)
//            }) { _ in
//                UIView.animate(withDuration: 0.2) {
//                    self.focusButton.transform = CGAffineTransform.identity
//                }
//            }
//        }
//        private func optimizeForLowLight() {
//            guard let device = videoDevice else { return }
//    
//            do {
//                try device.lockForConfiguration()
//    
//                // Enable low light boost if available
//                if device.isLowLightBoostSupported {
//                    device.automaticallyEnablesLowLightBoostWhenAvailable = true
//                    print("✅ Low light boost enabled")
//                }
//    
//                // Set longer exposure if needed for low light
//                if device.isExposureModeSupported(.custom) {
//                    // You can adjust these values based on testing
//                    let minISO = device.activeFormat.minISO
//                    let maxISO = device.activeFormat.maxISO
//                    device.setExposureModeCustom(duration: CMTimeMake(value: 1, timescale: 30),
//                                                 iso: max(minISO * 2, min(maxISO, minISO * 4)),
//                                                 completionHandler: nil)
//                }
//    
//                device.unlockForConfiguration()
//    
//            } catch {
//                print("❌ Low light optimization failed: \(error)")
//            }
//        }
//        // MARK: - Update Detection Status
//        private func updateDetectionStatus(isDetected: Bool) {
//            DispatchQueue.main.async {
//                if isDetected {
//                    self.cornerBoxLayer.strokeColor = UIColor.green.cgColor
//                    self.statusLabel.text = "Align QR code in the frame"
//                    UIView.animate(withDuration: 0.3) {
//                        self.statusLabel.alpha = 1
//                    }
//                } else {
//                    self.cornerBoxLayer.strokeColor = UIColor.red.cgColor
//                    self.statusLabel.text = "Scanning..."
//                    UIView.animate(withDuration: 0.3) {
//                        self.statusLabel.alpha = 0
//                    }
//                }
//            }
//        }
//        // Call this when QR code is detected
//        //        private func qrCodeDetected() {
//        //            cornerBoxLayer.strokeColor = UIColor.green.cgColor
//        //            statusLabel.text = "QR Code detected"
//        //            ProgressHUD.shared.show(in: view, message: "Processing...")
//        //            UIView.animate(withDuration: 0.3) {
//        //                self.statusLabel.alpha = 1
//        //            }
//        //        }
//    
//        private func freezePreview() {
//            DispatchQueue.main.async {
//                self.videoPreviewLayer.connection?.isEnabled = false
//            }
//        }
//
//    // MARK: - Corner Box Drawing
//    private func createStageView(number: String, title: String, isActive: Bool) -> UIStackView {
//            let container = UIStackView()
//            container.axis = .vertical
//            container.alignment = .center
//            container.spacing = 4
//            
//            let numberLabel = UILabel()
//            numberLabel.text = number
//            numberLabel.textColor = isActive ? .white : .lightGray
//            numberLabel.font = .systemFont(ofSize: 16, weight: .bold)
//            
//            let titleLabel = UILabel()
//            titleLabel.text = title
//            titleLabel.textColor = isActive ? .white : .lightGray
//            titleLabel.font = .systemFont(ofSize: 14, weight: .medium)
//            
//            container.addArrangedSubview(numberLabel)
//            container.addArrangedSubview(titleLabel)
//            
//            return container
//        }
//    // Returns the rect of the central clear scan window in previewView coordinates.
//    private func scanWindowRect() -> CGRect {
//        let viewBounds = previewView.bounds
//        return CGRect(
//            x: viewBounds.midX - scanWindowSize.width / 2,
//            y: viewBounds.midY - scanWindowSize.height / 2,
//            width: scanWindowSize.width,
//            height: scanWindowSize.height
//        )
//    }
//
//    // Builds the translucent overlay: full-bounds rect with a rounded cutout in the centre.
//    private func updateDimOverlay() {
//        let viewBounds = previewView.bounds
//        guard !viewBounds.isEmpty else { return }
//
//        let outer = UIBezierPath(rect: viewBounds)
//        let cutout = UIBezierPath(roundedRect: scanWindowRect(),
//                                  cornerRadius: scanWindowCornerRadius)
//        outer.append(cutout)
//        outer.usesEvenOddFillRule = true
//
//        dimOverlayLayer.path = outer.cgPath
//    }
//
//    // Update your updateCornerBoxes method to handle empty bounds:
//    private func updateCornerBoxes() {
//        let path = UIBezierPath()
//        let boxSize: CGFloat = 40 // Increased from 30 to 40
//        let viewBounds = previewView.bounds
//        guard !viewBounds.isEmpty else { return }
//
//        // Centered box dimensions (shared with the dim overlay cutout)
//        let rect = scanWindowRect()
//        let centerX = rect.minX
//        let centerY = rect.minY
//        let centerBoxWidth = rect.width
//        let centerBoxHeight = rect.height
//
//        // Top left (adjusted to be centered)
//        path.move(to: CGPoint(x: centerX, y: centerY + boxSize))
//        path.addLine(to: CGPoint(x: centerX, y: centerY))
//        path.addLine(to: CGPoint(x: centerX + boxSize, y: centerY))
//
//        // Top right
//        path.move(to: CGPoint(x: centerX + centerBoxWidth - boxSize, y: centerY))
//        path.addLine(to: CGPoint(x: centerX + centerBoxWidth, y: centerY))
//        path.addLine(to: CGPoint(x: centerX + centerBoxWidth, y: centerY + boxSize))
//
//        // Bottom left
//        path.move(to: CGPoint(x: centerX, y: centerY + centerBoxHeight - boxSize))
//        path.addLine(to: CGPoint(x: centerX, y: centerY + centerBoxHeight))
//        path.addLine(to: CGPoint(x: centerX + boxSize, y: centerY + centerBoxHeight))
//
//        // Bottom right
//        path.move(to: CGPoint(x: centerX + centerBoxWidth - boxSize, y: centerY + centerBoxHeight))
//        path.addLine(to: CGPoint(x: centerX + centerBoxWidth, y: centerY + centerBoxHeight))
//        path.addLine(to: CGPoint(x: centerX + centerBoxWidth, y: centerY + centerBoxHeight - boxSize))
//
//        cornerBoxLayer.path = path.cgPath
//    }
//    
//   
//    
//    // MARK: - Torch Button Action
//    // MARK: - Torch Button Action
//    @objc private func toggleTorchButton() {
//        toggleTorch()
//    }
//
//    /// User-initiated torch tap (different from the auto-toggle on launch).
//    /// Resets the 5-second countdown so the periodic scan doesn't fire mid-adjustment.
//    @objc private func torchButtonTapped() {
//        toggleTorch()
//        startScanTimer()
//    }
//
//    @objc private func toggleTorch() {
//        guard let device = videoDevice, device.hasTorch else {
//            torchButton.isHidden = true
//            return
//        }
//        
//        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
//            guard let self = self else { return }
//            
//            do {
//                try device.lockForConfiguration()
//                
//                let newMode: AVCaptureDevice.TorchMode = device.torchMode == .off ? .on : .off
//                var success = true
//                
//                if newMode == .on {
//                    // Try to turn on with max brightness
//                    do {
//                        try device.setTorchModeOn(level: AVCaptureDevice.maxAvailableTorchLevel)
//                    } catch {
//                        success = false
//                        print("Failed to set torch level: \(error)")
//                    }
//                } else {
//                    device.torchMode = .off
//                }
//                
//                device.unlockForConfiguration()
//                
//                // Update UI on main thread
//                DispatchQueue.main.async {
//                    if success {
//                        self.torchButton.tintColor = newMode == .on ? .yellow : .white
//                        print("🔦 Torch toggled: \(newMode == .on ? "ON" : "OFF")")
//                    } else {
//                        self.torchButton.tintColor = .white
//                        print("⚠️ Torch operation failed")
//                    }
//                }
//            } catch {
//                print("❌ Torch error: \(error)")
//                DispatchQueue.main.async {
//                    self.torchButton.tintColor = .white
//                }
//            }
//        }
//    }
//    // MARK: - Update Detection Status
//
//    @objc public func restartScan() {
//        print("🔄 Restarting scan...")
//        self.zoomLabel.text = "3.5x"
//        // 1. Reset all detection states
//        self.isQRCodeDetected = false
//        self.detectedBarcode = nil
//        self.lastBarcode = nil
//        self.performRequestCount = 0
//        self.currentZoom = 3.5 // Reset zoom to 3.5x (raised from 2.5x for wide-only camera + higher MFD headroom)
//        // Show the overlay guide again — fresh scan, fresh visual aid.
//        self.overlayImageView?.isHidden = false
//        // Clear focus/sharpness/auto-zoom state — every scan starts fresh and
//        // the user is no longer locked out of auto-zoom even if they touched
//        // the slider previously.
//        //
//        // NOTE: read the real device focus state rather than assuming the lens
//        // is still adjusting. KVO on `adjustingFocus` only fires when the lens
//        // MOVES — if it's already settled, an artificial `true` here would
//        // never get flipped back and the scan timer gate would stay blocked
//        // forever (= "progress bar doesn't start after first scan").
//        self.userZoomOverride = false
//        self.lastAutoZoomTime = 0
//        self.isFrameSharp = false
//        self.consecutiveSharpProbes = 0
//        self.userIsTooCloseToFocus = false
//        self.isAutoFocusAdjusting = self.videoDevice?.isAdjustingFocus ?? false
//        self.lastSharpnessCheckTime = 0
//        // Tilt-check guard can get stuck `true` if a `captureFrameForValidation`
//        // completion was overwritten before it fired. Force-release it so the
//        // next 1.5 s tick can run and auto-zoom resumes.
//        self.isTiltChecking = false
//        // Always start a fresh scan at the default 6s window. The
//        // /validate/ extended-retry path will set these back up afterwards
//        // (see restartScanWithExtendedInterval()).
//        self.scanInterval = self.scanIntervalDefault
//        self.isInExtendedScanMode = false
//        // Discard any unconsumed validation-path capture closure — a fresh
//        // scan should never inherit a stale callback from the previous one.
//        self.pendingFakePhotoCompletion = nil
//        self.pendingValidatePhotoCompletion = nil
//        NSObject.cancelPreviousPerformRequests(withTarget: self)
//        
//        // 2. Reset UI
//        self.updateDetectionStatus(isDetected: false)
//        self.instructionLabel.text = "Point camera at a QR code"
//        self.zoomSlider.value = Float(self.currentZoom) // Reset slider position
//        
//        // Update zoom label if you added it
//        // self.zoomLabel.text = "2.5x"
//        
////        ProgressHUD.shared.hide()
//        
//        // 3. Re-enable preview first
//        self.videoPreviewLayer.connection?.isEnabled = true
//        
//        // 4. Reset camera configuration with proper zoom
//        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
//            guard let self = self else { return }
//            
//            // 4a. Configure device with 2.5x zoom
//            if let device = self.videoDevice {
//                do {
//                    try device.lockForConfiguration()
//
//                    // Reset zoom to 2.5x
//                    device.videoZoomFactor = 3.5
//                    print("✅ Zoom reset to 3.5x")
//
//                    // Return the lens + exposure to CONTINUOUS AF/AE in the
//                    // same lock-cycle so the camera autofocuses on the
//                    // next code without the user tapping the focusButton.
//                    // Without this, the previous scan left the device in
//                    // `.locked` (a side-effect of the one-shot `.autoFocus`
//                    // used during validation capture) and stays there.
//                    if device.isFocusModeSupported(.continuousAutoFocus) {
//                        device.focusMode = .continuousAutoFocus
//                    } else if device.isFocusModeSupported(.autoFocus) {
//                        device.focusMode = .autoFocus
//                    }
//                    if device.isExposureModeSupported(.continuousAutoExposure) {
//                        device.exposureMode = .continuousAutoExposure
//                    } else if device.isExposureModeSupported(.autoExpose) {
//                        device.exposureMode = .autoExpose
//                    }
//                    print("🎯 restartScan: focus/exposure → continuous")
//
//                    device.unlockForConfiguration()
//                } catch {
//                    print("❌ Could not reset zoom: \(error)")
//                }
//            }
//
//            // 4b. Restart session properly
//            if let session = self.captureSession {
//                if !session.isRunning {
//                    // Add slight delay to ensure clean restart
//                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
//                        session.startRunning()
//                        print("✅ Capture session restarted with 3.5x zoom")
//                    }
//                } else {
//                    print("ℹ️ Session already running")
//                }
//            }
//        }
//        self.resetScanTimer()
//        audioQueue.async { [weak self] in
//            guard let self = self else { return }
//            if self.isAudioEnabled {
//                self.audioPlayer?.currentTime = 0
//                self.audioPlayer?.play()
//            }
//        }
//    }
//    
//    // MARK: - Live sharpness probe (gates the scan timer)
//    /// Cheap Laplacian-variance estimate on the central crop of the live
//    /// preview frame. Called from `captureOutput` and throttled to
//    /// `sharpnessCheckInterval` so we don't murder the CPU. When the variance
//    /// crosses `liveSharpnessThreshold`, the scan timer gate flips and the
//    /// 6-second countdown is allowed to arm — until then the timer is held at
//    /// 0% and the user is told to hold steady.
//    private func sampleFrameSharpness(_ pixelBuffer: CVPixelBuffer) {
//        // Skip sharpness work entirely while backgrounded — the camera
//        // session is paused, frames are stale, and we don't want to flip
//        // `isFrameSharp = true` just before we read the gate.
//        if isAppInBackground { return }
//        let now = CACurrentMediaTime()
//        if now - lastSharpnessCheckTime < sharpnessCheckInterval { return }
//        lastSharpnessCheckTime = now
//
//        // Switched from Laplacian variance to Tenengrad because on uniformly
//        // soft frames (close-to-focus, user inside minimum focus distance)
//        // Laplacian was being fooled by sensor noise. Tenengrad responds
//        // to real edge content and discriminates that case correctly.
//        let tenengrad = computeCentralTenengradScore(pixelBuffer)
//        let probeSharp = tenengrad >= liveTenengradThreshold
//
//        // Read lensPosition off the video device — 0.0 means the lens has
//        // parked at its NEAR-focus limit. If the user is physically
//        // closer than the minimum focus distance, the lens parks here and
//        // can't recover no matter how long it tries; the right thing is
//        // to tell them to move back.
//        let lensPosition: Float = self.videoDevice?.lensPosition ?? -1
//
//        // Hop to main: state read by timer-arm gate + UI hint, plus the
//        // hysteresis counter is read/written here too.
//        DispatchQueue.main.async { [weak self] in
//            guard let self = self else { return }
//
//            // Per-probe log so you can see real Tenengrad scores from the
//            // device and tune `liveTenengradThreshold` from data — not
//            // just the single line on a flip. Keep `🔬` so it's easy to
//            // grep, and include lensPosition for the "too close"
//            // diagnosis path below.
//            print(String(format: "🔬 sharpness probe tenengrad=%.2f (threshold=%.0f) lensPos=%.3f → probeSharp=%@, consecutiveSharp=%d, currentlyArmed=%@",
//                         tenengrad,
//                         self.liveTenengradThreshold,
//                         Double(lensPosition),
//                         probeSharp ? "Y" : "N",
//                         self.consecutiveSharpProbes,
//                         self.isFrameSharp ? "Y" : "N"))
//
//            // Hysteresis:
//            //   • Sharp probe → bump consecutive count, only flip
//            //     `isFrameSharp = true` once we've seen N in a row.
//            //   • Blurry probe → reset count to 0 AND flip
//            //     `isFrameSharp = false` immediately (asymmetric debounce
//            //     so a single blurry frame stops the progress bar).
//            let wasSharp = self.isFrameSharp
//            if probeSharp {
//                self.consecutiveSharpProbes += 1
//                if self.consecutiveSharpProbes >= self.sharpnessHysteresisRequired {
//                    self.isFrameSharp = true
//                }
//            } else {
//                self.consecutiveSharpProbes = 0
//                self.isFrameSharp = false
//            }
//
//            // "Too close" detection: blurry AND lensPosition parked at
//            // near-focus limit. This is the case where the user is inside
//            // the camera's minimum focus distance and the lens has given
//            // up — no further focusing will help, the user must back off.
//            // Sharp probes always clear the flag.
//            if probeSharp {
//                self.userIsTooCloseToFocus = false
//            } else if lensPosition >= 0,
//                      lensPosition < self.lensPositionTooCloseThreshold {
//                if !self.userIsTooCloseToFocus {
//                    print("📏 user appears too close (lensPos=\(String(format: "%.3f", Double(lensPosition))) at near limit, tenengrad=\(String(format: "%.2f", tenengrad)))")
//                }
//                self.userIsTooCloseToFocus = true
//            } else {
//                // Blurry but lens still hunting somewhere mid-range — not
//                // necessarily "too close". Clear the flag.
//                self.userIsTooCloseToFocus = false
//            }
//
//            if self.isFrameSharp != wasSharp {
//                print("📷 sharpness flipped → \(self.isFrameSharp ? "SHARP" : "blurry") (tenengrad=\(String(format: "%.2f", tenengrad)), lensPos=\(String(format: "%.3f", Double(lensPosition))))")
//                if self.isFrameSharp {
//                    // Try to arm the countdown now.
//                    self.reevaluateScanTimerGate()
//                } else if self.scanTimer != nil {
//                    // Was armed, just went blurry — pause the countdown but
//                    // leave pendingScanTimerStart=true so it auto-resumes.
//                    self.cancelActiveScanTimer()
//                    self.progressDisplayLink?.invalidate()
//                    self.progressDisplayLink = nil
//                    self.scanProgressView?.setProgress(0, animated: false)
//                }
//            } else if !self.isFrameSharp && self.scanTimer != nil {
//                // Belt-and-braces: even if state didn't FLIP this probe (we
//                // were already blurry), make sure the progress bar isn't
//                // somehow still advancing. Cheap idempotent reset.
//                self.cancelActiveScanTimer()
//                self.progressDisplayLink?.invalidate()
//                self.progressDisplayLink = nil
//                self.scanProgressView?.setProgress(0, animated: false)
//            }
//        }
//    }
//
//    /// Run a Laplacian-3x3 over a centre crop of the live pixel buffer and
//    /// return the variance of its grayscale output. Mirrors `isImageBlurry`
//    /// but works directly on a CVPixelBuffer and only inspects the centre to
//    /// stay cheap enough for ~3 Hz sampling.
//    /// Live-preview Tenengrad sharpness score (0-100 scale, matches the
//    /// server-side Python and the post-capture `sharpnessScore` used for
//    /// `/validate/` decisions).
//    ///
//    /// Why this exists alongside the Laplacian version: on uniformly soft
//    /// frames (the close-to-focus case where the user is inside the
//    /// camera's minimum focus distance) Laplacian variance is dominated by
//    /// sensor noise and gives misleadingly high values. Tenengrad
//    /// (Sobel-based gradient magnitude) responds to actual edge content
//    /// and discriminates "blurry with noise" from "sharp" much more
//    /// cleanly. We use a smaller working size (256 px) than the
//    /// post-capture path's 800 px to keep ~3 Hz sampling cheap.
//    private func computeCentralTenengradScore(_ pixelBuffer: CVPixelBuffer) -> Double {
//        let full = CIImage(cvPixelBuffer: pixelBuffer)
//        let extent = full.extent
//        guard extent.width > 0, extent.height > 0 else { return 0 }
//
//        // Centre crop covering ~50% of the shorter dim — same region as
//        // the Laplacian probe.
//        let side = min(extent.width, extent.height) * 0.5
//        let cropRect = CGRect(
//            x: extent.midX - side / 2,
//            y: extent.midY - side / 2,
//            width: side, height: side
//        )
//        var ciImage = full.cropped(to: cropRect)
//        ciImage = ciImage.transformed(by: CGAffineTransform(translationX: -cropRect.minX, y: -cropRect.minY))
//
//        // Downscale to 256 wide for cheap inner loop. Tenengrad is
//        // scale-stable in the 200-800 range — the score doesn't shift
//        // meaningfully across that range on the same scene.
//        let targetWidth: CGFloat = 256.0
//        let scale = min(1.0, targetWidth / ciImage.extent.width)
//        if scale < 1.0 {
//            ciImage = ciImage.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
//        }
//
//        // Luminance (BT.601 weights — matches OpenCV's cvtColor default).
//        guard let colorMatrix = CIFilter(name: "CIColorMatrix") else { return 0 }
//        colorMatrix.setValue(ciImage, forKey: kCIInputImageKey)
//        colorMatrix.setValue(CIVector(x: 0.299, y: 0.299, z: 0.299, w: 0), forKey: "inputRVector")
//        colorMatrix.setValue(CIVector(x: 0.587, y: 0.587, z: 0.587, w: 0), forKey: "inputGVector")
//        colorMatrix.setValue(CIVector(x: 0.114, y: 0.114, z: 0.114, w: 0), forKey: "inputBVector")
//        colorMatrix.setValue(CIVector(x: 0, y: 0, z: 0, w: 0), forKey: "inputBiasVector")
//        guard let gray = colorMatrix.outputImage else { return 0 }
//
//        // Render to a tight RGBA8 buffer (same pattern as the Laplacian
//        // helper — R==G==B because the image is already grayscale).
//        let ctx = CIContext(options: nil)
//        let outExtent = gray.extent.integral
//        guard let outCG = ctx.createCGImage(gray, from: outExtent) else { return 0 }
//        let w = outCG.width
//        let h = outCG.height
//        guard w >= 3, h >= 3 else { return 0 }
//
//        let bytesPerRow = w * 4
//        let bufferSize = bytesPerRow * h
//        guard let data = malloc(bufferSize) else { return 0 }
//        defer { free(data) }
//
//        let colorSpace = CGColorSpaceCreateDeviceRGB()
//        guard let cctx = CGContext(data: data,
//                                   width: w, height: h,
//                                   bitsPerComponent: 8, bytesPerRow: bytesPerRow,
//                                   space: colorSpace,
//                                   bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else {
//            return 0
//        }
//        cctx.draw(outCG, in: CGRect(x: 0, y: 0, width: w, height: h))
//
//        // Open-coded Sobel — same arithmetic as `sharpnessScore`,
//        // operating on the R channel. Stride by 4 because we rendered to
//        // RGBA, not single-channel grayscale.
//        let ptr = data.bindMemory(to: UInt8.self, capacity: bufferSize)
//        var sumSq: Double = 0
//        var count = 0
//        for y in 1..<(h - 1) {
//            let rowAbove = (y - 1) * w
//            let rowSame  =  y      * w
//            let rowBelow = (y + 1) * w
//            for x in 1..<(w - 1) {
//                let p00 = Int(ptr[(rowAbove + (x - 1)) * 4])
//                let p01 = Int(ptr[(rowAbove + x      ) * 4])
//                let p02 = Int(ptr[(rowAbove + (x + 1)) * 4])
//                let p10 = Int(ptr[(rowSame  + (x - 1)) * 4])
//                let p12 = Int(ptr[(rowSame  + (x + 1)) * 4])
//                let p20 = Int(ptr[(rowBelow + (x - 1)) * 4])
//                let p21 = Int(ptr[(rowBelow + x      ) * 4])
//                let p22 = Int(ptr[(rowBelow + (x + 1)) * 4])
//
//                let gx = -p00 + p02 - (p10 << 1) + (p12 << 1) - p20 + p22
//                let gy = -p00 - (p01 << 1) - p02 + p20 + (p21 << 1) + p22
//
//                sumSq += Double(gx * gx + gy * gy)
//                count += 1
//            }
//        }
//        guard count > 0 else { return 0 }
//        let meanSq = sumSq / Double(count)
//
//        // Same normalisation as the post-capture `sharpnessScore` and the
//        // Python — clip(meanSq / 2000 × 100, 0, 100).
//        return min(100.0, max(0.0, meanSq / 2000.0 * 100.0))
//    }
//
//    private func computeCentralLaplacianVariance(_ pixelBuffer: CVPixelBuffer) -> Double {
//        let full = CIImage(cvPixelBuffer: pixelBuffer)
//        let extent = full.extent
//        guard extent.width > 0, extent.height > 0 else { return 0 }
//
//        // Centre crop covering ~50% of the shorter dim — this is the area the
//        // user is aiming the scan window at, regardless of buffer orientation.
//        let side = min(extent.width, extent.height) * 0.5
//        let cropRect = CGRect(
//            x: extent.midX - side / 2,
//            y: extent.midY - side / 2,
//            width: side, height: side
//        )
//        var ciImage = full.cropped(to: cropRect)
//        // Re-anchor at origin so filters render predictably.
//        ciImage = ciImage.transformed(by: CGAffineTransform(translationX: -cropRect.minX, y: -cropRect.minY))
//
//        // Downscale to ~256 wide — variance is scale-stable enough and this
//        // keeps the read-back tiny.
//        let targetWidth: CGFloat = 256.0
//        let scale = min(1.0, targetWidth / ciImage.extent.width)
//        if scale < 1.0 {
//            ciImage = ciImage.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
//        }
//
//        // → luminance
//        guard let colorMatrix = CIFilter(name: "CIColorMatrix") else { return 0 }
//        colorMatrix.setValue(ciImage, forKey: kCIInputImageKey)
//        colorMatrix.setValue(CIVector(x: 0.299, y: 0.299, z: 0.299, w: 0), forKey: "inputRVector")
//        colorMatrix.setValue(CIVector(x: 0.587, y: 0.587, z: 0.587, w: 0), forKey: "inputGVector")
//        colorMatrix.setValue(CIVector(x: 0.114, y: 0.114, z: 0.114, w: 0), forKey: "inputBVector")
//        colorMatrix.setValue(CIVector(x: 0, y: 0, z: 0, w: 0), forKey: "inputBiasVector")
//        guard let gray = colorMatrix.outputImage else { return 0 }
//
//        // → Laplacian
//        let kernel: [CGFloat] = [
//            -1, -1, -1,
//            -1,  8, -1,
//            -1, -1, -1
//        ]
//        guard let conv = CIFilter(name: "CIConvolution3X3") else { return 0 }
//        conv.setValue(gray, forKey: kCIInputImageKey)
//        conv.setValue(CIVector(values: kernel, count: 9), forKey: "inputWeights")
//        conv.setValue(0.0, forKey: "inputBias")
//        guard let lap = conv.outputImage else { return 0 }
//
//        let ctx = CIContext(options: nil)
//        let outExtent = lap.extent.integral
//        guard let outCG = ctx.createCGImage(lap, from: outExtent) else { return 0 }
//
//        let w = outCG.width
//        let h = outCG.height
//        let bytesPerRow = w * 4
//        let bufferSize = bytesPerRow * h
//        guard let data = malloc(bufferSize) else { return 0 }
//        defer { free(data) }
//
//        let colorSpace = CGColorSpaceCreateDeviceRGB()
//        guard let cctx = CGContext(data: data,
//                                   width: w, height: h,
//                                   bitsPerComponent: 8, bytesPerRow: bytesPerRow,
//                                   space: colorSpace,
//                                   bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else {
//            return 0
//        }
//        cctx.draw(outCG, in: CGRect(x: 0, y: 0, width: w, height: h))
//
//        let ptr = data.bindMemory(to: UInt8.self, capacity: bufferSize)
//        var sum: Double = 0
//        var sumSq: Double = 0
//        let count = w * h
//        for i in 0..<count {
//            let v = Double(ptr[i * 4])
//            sum += v
//            sumSq += v * v
//        }
//        guard count > 0 else { return 0 }
//        let mean = sum / Double(count)
//        return (sumSq / Double(count)) - mean * mean
//    }
//
//    func isImageBlurry(_ image: UIImage, threshold: Float = 1000.0) -> Bool {
//        guard let cgImage = image.cgImage else { return false }
//
//        // 1) Create CIImage
//        var ciImage = CIImage(cgImage: cgImage)
//
//        // 2) Downscale to fixed width (helps make threshold stable)
//        let targetWidth: CGFloat = 600.0
//        let scale = min(1.0, targetWidth / ciImage.extent.width)
//        if scale < 1.0 {
//            ciImage = ciImage.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
//        }
//
//        // 3) Convert to luminance (grayscale) using CIColorMatrix
//        let colorMatrixFilter = CIFilter(name: "CIColorMatrix")!
//        // Luminance weights: 0.299, 0.587, 0.114
//        colorMatrixFilter.setValue(ciImage, forKey: kCIInputImageKey)
//        colorMatrixFilter.setValue(CIVector(x: 0.299, y: 0.299, z: 0.299, w: 0), forKey: "inputRVector")
//        colorMatrixFilter.setValue(CIVector(x: 0.587, y: 0.587, z: 0.587, w: 0), forKey: "inputGVector")
//        colorMatrixFilter.setValue(CIVector(x: 0.114, y: 0.114, z: 0.114, w: 0), forKey: "inputBVector")
//        colorMatrixFilter.setValue(CIVector(x: 0, y: 0, z: 0, w: 0), forKey: "inputBiasVector")
//        guard let gray = colorMatrixFilter.outputImage else { return false }
//
//        // 4) Apply Laplacian using CIConvolution3X3
//        let kernel: [CGFloat] = [
//            -1, -1, -1,
//            -1,  8, -1,
//            -1, -1, -1
//        ]
//        let convFilter = CIFilter(name: "CIConvolution3X3")!
//        convFilter.setValue(gray, forKey: kCIInputImageKey)
//        convFilter.setValue(CIVector(values: kernel, count: 9), forKey: "inputWeights")
//        convFilter.setValue(0.0, forKey: "inputBias")
//        guard let laplacianImage = convFilter.outputImage else { return false }
//
//        // 5) Render the laplacian result to RGBA8 (we'll read the R channel — it's grayscale)
//        let context = CIContext(options: nil)
//        let extent = laplacianImage.extent.integral
//        guard let outCG = context.createCGImage(laplacianImage, from: extent) else { return false }
//
//        // 6) Read pixel bytes
//        let width = outCG.width
//        let height = outCG.height
//        let bytesPerRow = width * 4
//        let bufferSize = bytesPerRow * height
//        guard let data = malloc(bufferSize) else { return false }
//        defer { free(data) }
//
//        let colorSpace = CGColorSpaceCreateDeviceRGB()
//        guard let ctx = CGContext(data: data,
//                                  width: width,
//                                  height: height,
//                                  bitsPerComponent: 8,
//                                  bytesPerRow: bytesPerRow,
//                                  space: colorSpace,
//                                  bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue) else {
//            return false
//        }
//        ctx.draw(outCG, in: CGRect(x: 0, y: 0, width: width, height: height))
//
//        // 7) Compute mean and variance on the R channel (grayscale)
//        let ptr = data.bindMemory(to: UInt8.self, capacity: bufferSize)
//        var sum: Double = 0
//        var sumSq: Double = 0
//        let pixelCount = width * height
//
//        for i in 0..<pixelCount {
//            let r = Double(ptr[i * 4]) // R channel; image is grayscale so R==G==B
//            sum += r
//            sumSq += r * r
//        }
//
//        let n = Double(pixelCount)
//        guard n > 0 else { return false }
//
//        let mean = sum / n
//        let variance = (sumSq / n) - (mean * mean) // E[x^2] - (E[x])^2
//
//        print("isImageBlurry: laplacian variance = \(variance)  (mean = \(mean))")
//
//        // 8) Decide blur: low variance => blurry
//        return variance < Double(threshold)
//    }
//
//    // MARK: - Tenengrad sharpness score (mirrors server-side Python)
//    /// Native iOS port of the host team's Python `sharpness_score` —
//    /// returns a Tenengrad sharpness score in 0-100 where higher = sharper.
//    ///
//    /// Algorithm (matches `cv2.Sobel(..., CV_64F, ksize=3)` exactly):
//    ///   1. Render the image to an 8-bit grayscale buffer (no premult, no
//    ///      RGBA — that's what cv2.IMREAD_GRAYSCALE delivers).
//    ///   2. Compute Sobel X and Sobel Y per pixel with full Int precision
//    ///      (the Python uses Float64; our Int range is wider than the
//    ///      ±1020 max Sobel response on [0,255] input so we don't lose
//    ///      data, and Int arithmetic is significantly faster than CIFilter
//    ///      round-tripping through 8-bit RGBA which would clamp the
//    ///      negative half of the gradient).
//    ///   3. score = mean(sobelx² + sobely²) over the inner (W-2)×(H-2)
//    ///      region (cv2 produces zeros at the borders; we just skip them).
//    ///   4. Normalise: clip(score / 2000 × 100, 0, 100).
//    ///
//    /// Returns 0 on any failure path.
//    private func sharpnessScore(_ image: UIImage) -> Double {
//        guard let cgImage = image.cgImage else { return 0 }
//
//        // 1) Downscale to ~800 px wide for speed. Tenengrad is scale-stable
//        //    enough that a 2-3× downsample barely shifts the score, but
//        //    cuts inner-loop pixel count by ~10× on a high-res photo.
//        //    Skip if already small.
//        let originalW = cgImage.width
//        let originalH = cgImage.height
//        guard originalW > 0, originalH > 0 else { return 0 }
//        let targetMaxDim = 800
//        let scale: Double
//        if max(originalW, originalH) > targetMaxDim {
//            scale = Double(targetMaxDim) / Double(max(originalW, originalH))
//        } else {
//            scale = 1.0
//        }
//        let scaledW = max(3, Int(Double(originalW) * scale))
//        let scaledH = max(3, Int(Double(originalH) * scale))
//
//        // 2) Render to a tight 8-bit grayscale buffer. CGColorSpace.gray
//        //    + alpha:.none gives one byte per pixel — matches cv2's
//        //    grayscale layout exactly so no per-pixel channel arithmetic
//        //    is needed in the hot loop.
//        let bytesPerRow = scaledW
//        let bufferSize = bytesPerRow * scaledH
//        guard let data = malloc(bufferSize) else { return 0 }
//        defer { free(data) }
//
//        let colorSpace = CGColorSpaceCreateDeviceGray()
//        let bitmapInfo = CGImageAlphaInfo.none.rawValue
//        guard let ctx = CGContext(data: data,
//                                  width: scaledW,
//                                  height: scaledH,
//                                  bitsPerComponent: 8,
//                                  bytesPerRow: bytesPerRow,
//                                  space: colorSpace,
//                                  bitmapInfo: bitmapInfo) else {
//            return 0
//        }
//        ctx.draw(cgImage, in: CGRect(x: 0, y: 0, width: scaledW, height: scaledH))
//
//        let ptr = data.bindMemory(to: UInt8.self, capacity: bufferSize)
//
//        // 3) Sobel kernels, applied in the inner loop directly. Reading
//        //    9 neighbours per pixel; the multiply-add pattern below is
//        //    the same arithmetic OpenCV does, just open-coded.
//        //
//        //   Sobel X:                Sobel Y:
//        //     -1  0  1                -1 -2 -1
//        //     -2  0  2                 0  0  0
//        //     -1  0  1                 1  2  1
//        //
//        // Skip the 1-pixel border to match cv2's default BORDER_REFLECT_101
//        // contribution on the inner region. (cv2 zeros the border in
//        // practice for the boundary pixels we skip; the difference at
//        // image scale ≥ ~200 px is negligible.)
//        var sumSq: Double = 0
//        var count = 0
//        for y in 1..<(scaledH - 1) {
//            let rowAbove  = (y - 1) * scaledW
//            let rowSame   =  y      * scaledW
//            let rowBelow  = (y + 1) * scaledW
//            for x in 1..<(scaledW - 1) {
//                let p00 = Int(ptr[rowAbove + (x - 1)])
//                let p01 = Int(ptr[rowAbove + x])
//                let p02 = Int(ptr[rowAbove + (x + 1)])
//                let p10 = Int(ptr[rowSame  + (x - 1)])
//                // p11 = centre — not used by either kernel.
//                let p12 = Int(ptr[rowSame  + (x + 1)])
//                let p20 = Int(ptr[rowBelow + (x - 1)])
//                let p21 = Int(ptr[rowBelow + x])
//                let p22 = Int(ptr[rowBelow + (x + 1)])
//
//                // Sobel X = -p00 + p02 - 2·p10 + 2·p12 - p20 + p22
//                let gx = -p00 + p02 - (p10 << 1) + (p12 << 1) - p20 + p22
//                // Sobel Y = -p00 - 2·p01 - p02 + p20 + 2·p21 + p22
//                let gy = -p00 - (p01 << 1) - p02 + p20 + (p21 << 1) + p22
//
//                sumSq += Double(gx * gx + gy * gy)
//                count += 1
//            }
//        }
//        guard count > 0 else { return 0 }
//        let meanSq = sumSq / Double(count)
//
//        // 4) Same normalisation as the Python: meanSq / 2000 * 100,
//        //    clipped to [0, 100].
//        let normalised = min(100.0, max(0.0, meanSq / 2000.0 * 100.0))
//        print(String(format: "📐 sharpnessScore: meanSq=%.1f → score=%.2f (image: %dx%d → %dx%d)",
//                     meanSq, normalised, originalW, originalH, scaledW, scaledH))
//        return normalised
//    }
//
//    // MARK: - Camera Setup
//    private func setupCamera() {
//        captureSession = AVCaptureSession()
//        captureSession.sessionPreset = .photo // Use photo preset for high-resolution images
//
//        // 1. Pick the best available rear camera.
//        //
//        // Fallback chain — on each phone we take the first one that exists:
//        //   • .builtInTripleCamera   — iPhone 11/12/13/14/15 Pro & Pro Max
//        //   • .builtInDualWideCamera — iPhone 13, 14, 15, 16 (non-Pro)
//        //   • .builtInWideAngleCamera — everything older
//        //
//        // Why this matters: the triple and dual-wide virtual devices
//        // include the ULTRA-WIDE physical lens, which is the only lens
//        // with macro autofocus on iPhone. When `automaticallyAdjusts-
//        // VideoZoomFactor` is true on the input (default), AVFoundation
//        // auto-switches to ultra-wide and engages macro mode when the
//        // user holds the phone closer than ~12 cm — exactly the
//        // "suddenly snaps sharp" experience Scandit delivers. On older
//        // phones we fall through to the wide camera and behave as before.
//        let pickedDevice: AVCaptureDevice? = {
//            if let triple = AVCaptureDevice.default(.builtInTripleCamera, for: .video, position: .back) {
//                print("📷 picked .builtInTripleCamera (macro-capable)")
//                return triple
//            }
//            if let dualWide = AVCaptureDevice.default(.builtInDualWideCamera, for: .video, position: .back) {
//                print("📷 picked .builtInDualWideCamera (macro-capable)")
//                return dualWide
//            }
//            print("📷 picked .builtInWideAngleCamera (no macro)")
//            return AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .back)
//        }()
//
//        guard let device = pickedDevice else {
//            print("Failed to get the camera device.")
//            instructionLabel.text = "Camera not available."
//            return
//        }
//        self.videoDevice = device
//
//        // 2. Create the video input
//        guard let videoInput = try? AVCaptureDeviceInput(device: device) else {
//            print("Failed to create video input.")
//            return
//        }
//
//        // Note on auto-macro mode: when this device is a multi-cam virtual
//        // device (.builtInTripleCamera or .builtInDualWideCamera),
//        // AVFoundation automatically switches to the ultra-wide constituent
//        // lens when the focus subject moves closer than ~12 cm. No flag
//        // needs to be set — selecting the right device above is what
//        // unlocks this. On older single-lens phones the wide-only device
//        // doesn't support macro and we behave as we did before.
//        if #available(iOS 13.0, *), device.isVirtualDevice {
//            print("📷 device is virtual (constituents=\(device.constituentDevices.count)) — auto-macro will engage when held close")
//        }
//
//        if captureSession.canAddInput(videoInput) {
//            captureSession.addInput(videoInput)
//        }
//
//        // 3. Create the video data output
//        videoDataOutput = AVCaptureVideoDataOutput()
//        videoDataOutput.setSampleBufferDelegate(self, queue: DispatchQueue(label: "videoQueue"))
//        if captureSession.canAddOutput(videoDataOutput) {
//            captureSession.addOutput(videoDataOutput)
//        }
//
//        // 4. Create the photo output for capturing images
//        photoOutput = AVCapturePhotoOutput()
//        if captureSession.canAddOutput(photoOutput) {
//            captureSession.addOutput(photoOutput)
//        }
//
//        // 4b. Enable max-resolution capture on the photo output so when we
//        // ask for a high-res photo in `capturePhoto()`, the output is
//        // actually configured to deliver one. Without this we cap around
//        // 1920x1440 on dual-wide hardware even though the sensor would
//        // hand us 4032x3024. This is the single biggest contributor to
//        // the resolution gap vs Scandit.
//        if #available(iOS 16.0, *) {
//            photoOutput.maxPhotoQualityPrioritization = .quality
//        } else {
//            photoOutput.isHighResolutionCaptureEnabled = true
//        }
//        
//        // 5. Setup the preview layer
//        videoPreviewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
//        videoPreviewLayer.videoGravity = .resizeAspectFill
//        previewView.layer.addSublayer(videoPreviewLayer)
//        
//        previewView.layer.insertSublayer(dimOverlayLayer, above: videoPreviewLayer)
//        previewView.layer.insertSublayer(cornerBoxLayer, above: dimOverlayLayer)
//        // Check torch availability
//            if let device = videoDevice {
//                torchButton.isHidden = !device.hasTorch
//            } else {
//                torchButton.isHidden = true
//            }
//        // Set initial frame for the preview layer
////        DispatchQueue.main.async {
////            self.videoPreviewLayer.frame = self.previewView.bounds
////        }
//        justZoom()
//        // Start KVO on adjustingFocus / lensPosition so we can gate the scan
//        // timer on focus lock and react instantly when the lens starts hunting.
//        if #available(iOS 13.0, *) {
//            monitorFocusState()
//        }
//        // 6. Setup Vision request
//        setupVision()
//    }
//    
//    
//    
//    // MARK: - Vision Setup
//    private func setupVision() {
//        // Create a barcode detection request
//        let barcodeRequest = VNDetectBarcodesRequest { [weak self] request, error in
//            self?.processBarcodes(for: request, error: error)
//        }
//        // We are interested in QR codes
//        barcodeRequest.symbologies = [.qr]
//        self.visionRequests = [barcodeRequest]
//    }
//    
////    private func setupVision() {
////        let barcodeRequest = VNDetectBarcodesRequest { [weak self] request, error in
////            self?.processBarcodes(for: request, error: error)
////        }
////        barcodeRequest.symbologies = [.qr]
////
////        // Use the latest revision for better detection at angles
////        if #available(iOS 14.0, *) {
////            barcodeRequest.revision = VNDetectBarcodesRequestRevision1
////        }
////
////        self.visionRequests = [barcodeRequest]
////    }
//    
//    // MARK: - AVCaptureVideoDataOutputSampleBufferDelegate
//    func captureOutput(_ output: AVCaptureOutput, didOutput sampleBuffer: CMSampleBuffer, from connection: AVCaptureConnection) {
//        
//        
//        // If we've already detected a QR code and are in the process of capturing, don't process more frames.
//        // ── One-shot frame grab for TFLite validation ──────────────
//          if let validationCompletion = validationFrameCompletion {
//              validationFrameCompletion = nil   // consume immediately — fire once only
//              
//              if let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) {
//                  let ciImage  = CIImage(cvPixelBuffer: pixelBuffer)
//                  let context  = CIContext()
//                  if let cgImage = context.createCGImage(ciImage, from: ciImage.extent) {
//                      let image = UIImage(cgImage: cgImage,
//                                          scale: 1.0,
//                                          orientation: .right)
//                      DispatchQueue.main.async { validationCompletion(image) }
//                  } else {
//                      DispatchQueue.main.async { validationCompletion(nil) }
//                  }
//              } else {
//                  DispatchQueue.main.async { validationCompletion(nil) }
//              }
//              return   // don't run normal QR scanning on this frame
//          }
//        
//        if isQRCodeDetected { return }
//
//        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }
//
//        // Throttled live sharpness probe — flips `isFrameSharp` and arms /
//        // disarms the scan-timer gate. Cheap enough to run on the video queue
//        // at ~3 Hz; see sampleFrameSharpness() for the throttle.
//        sampleFrameSharpness(pixelBuffer)
//
//        // Perform the vision request on the pixel buffer
//        var requestOptions: [VNImageOption: Any] = [:]
//        if let cameraIntrinsicData = CMGetAttachment(sampleBuffer, key: kCMSampleBufferAttachmentKey_CameraIntrinsicMatrix, attachmentModeOut: nil) {
//            requestOptions = [.cameraIntrinsics: cameraIntrinsicData]
//        }
//        
//        let imageRequestHandler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, orientation: .up, options: requestOptions)
//        
//        do {
//            try imageRequestHandler.perform(self.visionRequests)
//        } catch {
//            print("Failed to perform Vision request: \(error)")
//        }
//    }
//    
//    // MARK: - Update your barcode detection method
//
//    
//
////    private func processBarcodes(for request: VNRequest, error: Error?) {
////        DispatchQueue.main.async { [weak self] in
////            guard let self = self else { return }
////
////            // Throttle
////            if let lastTime = self.lastDetectionTime,
////               Date().timeIntervalSince(lastTime) < 0.3 {
////                return
////            }
////            self.lastDetectionTime = Date()
////
////            if let error = error {
////                print("❌ Vision error: \(error.localizedDescription)")
////                return
////            }
////
////            guard let results = request.results,
////                  let barcode = results.first as? VNBarcodeObservation,
////                  barcode.confidence > 0.9,
////                  self.isQRCodeFullyVisible(barcode)
////            else {
////                self.updateDetectionStatus(isDetected: false)
////                return
////            }
////
////            // Store the QR code value
////            if let qrCodeValue = barcode.payloadStringValue {
////                self.detectedQRCodeValue = qrCodeValue
////                print("📱 QR Code full visible: \(qrCodeValue)")
////            }
////
////
////            // Only reset timer if QR code has changed
////            if let last = self.lastBarcode,
////               last.payloadStringValue == barcode.payloadStringValue {
////                // same QR → do nothing, timer already running
////            } else {
////                self.lastBarcode = barcode
////                NSObject.cancelPreviousPerformRequests(withTarget: self,
////                                                       selector: #selector(self.handleStabilizedQRCode),
////                                                       object: nil)
////                self.perform(#selector(self.handleStabilizedQRCode), with: nil, afterDelay: 0.5)
////                print("🔍 New QR detected – stabilization timer started")
////            }
////        }
////    }
//    private func processBarcodes(for request: VNRequest, error: Error?) {
//        DispatchQueue.main.async { [weak self] in
//            guard let self = self else { return }
//            
//            // 1. Throttle check
//            if let lastTime = self.lastDetectionTime,
//               Date().timeIntervalSince(lastTime) < 0.3 {
//                return
//            }
//            self.lastDetectionTime = Date()
//            
//            if let error = error {
//                print("❌ Vision error: \(error.localizedDescription)")
//                return
//            }
//
//            // 2. Initial Results check
//            guard let results = request.results,
//                  let barcode = results.first as? VNBarcodeObservation else {
//                // This is the most common state while waving the phone around
//                self.updateDetectionStatus(isDetected: false)
//                return
//            }
//
//            print("🔍 Found potential QR...")
//
//            // 3. Confidence Log
//            print("📊 Confidence: \(barcode.confidence)")
//            if barcode.confidence <= 0.9 {
//                print("⚠️ Dropped: Confidence too low (\(barcode.confidence))")
//                self.updateDetectionStatus(isDetected: false)
//                return
//            }
//
//            // 4. Visibility Log
//            let visible = self.isQRCodeFullyVisible(barcode)
//            print("👁️ Is Fully Visible: \(visible)")
//            if !visible {
//                print("⚠️ Dropped: QR is partially off-screen or too small")
//                self.updateDetectionStatus(isDetected: false)
//                return
//            }
//
//            // --- IF IT REACHES HERE, ALL GUARDS PASSED ---
//            print("✅ ALL CHECKS PASSED - Proceeding to payload")
//
//            // Store the QR code value
//            if let qrCodeValue = barcode.payloadStringValue {
//                self.detectedQRCodeValue = qrCodeValue
//                print("📱 QR Code detected: \(qrCodeValue)")
//            }
//
//            // Stabilization Logic
//            if let last = self.lastBarcode,
//               last.payloadStringValue == barcode.payloadStringValue {
//                // same QR
//            } else {
//                self.lastBarcode = barcode
//                NSObject.cancelPreviousPerformRequests(withTarget: self,
//                                                       selector: #selector(self.handleStabilizedQRCode),
//                                                       object: nil)
//                self.perform(#selector(self.handleStabilizedQRCode), with: nil, afterDelay: 0.5)
//                print("🔍 New QR detected – stabilization timer started")
//            }
//        }
//    }
//
//
//    @objc private func handleStabilizedQRCode() {
//        guard let barcode = self.lastBarcode, !self.isQRCodeDetected else {
//            print("⚠️ No barcode available or already processing")
//            return
//        }
//        stopTiltCheckTimer()
//        // Capture a weak reference to avoid retain cycles
//        ProgressHUD.shared.show(in: view, message: "Processing.Please dont move..")
//        print("✅ QR Code stabilized - processing")
//        self.isQRCodeDetected = true
//        self.updateDetectionStatus(isDetected: true)
//        self.detectedBarcode = barcode
//        self.freezePreview()
//        // Hide the overlay guide — its job is done once we have a
//        // decoded QR. resetDetection / restartScan show it again.
//        self.overlayImageView?.isHidden = true
//        
//        // Give a small delay to ensure everything is ready
//        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { [weak self] in
//            self?.zoomAndCapture()
//        }
//    }
//    private func isQRCodeFullyVisible(_ barcode: VNBarcodeObservation) -> Bool {
//        // Convert normalized coordinates to view coordinates
//        let boundingBox = barcode.boundingBox
//        
//        // Check if all corners are within the image bounds (0-1 range)
//        let topLeft = CGPoint(x: boundingBox.minX, y: boundingBox.maxY)
//        let topRight = CGPoint(x: boundingBox.maxX, y: boundingBox.maxY)
//        let bottomLeft = CGPoint(x: boundingBox.minX, y: boundingBox.minY)
//        let bottomRight = CGPoint(x: boundingBox.maxX, y: boundingBox.minY)
//        
//        // Define a small margin (e.g., 5% of the frame)
//        let margin: CGFloat = 0.05
//        
//        // Check all corners are within the frame with margin
//        let isFullyVisible =
//            topLeft.x > margin && topLeft.y < (1 - margin) &&
//            topRight.x < (1 - margin) && topRight.y < (1 - margin) &&
//            bottomLeft.x > margin && bottomLeft.y > margin &&
//            bottomRight.x < (1 - margin) && bottomRight.y > margin
//        
//        // Additional check for the black circle (assuming it's part of the QR code)
//        // We can check if the bounding box is large enough relative to the frame
//        let minRelativeSize: CGFloat = 0.3 // At least 30% of frame width/height
//        let isLargeEnough =
//            boundingBox.width > minRelativeSize &&
//            boundingBox.height > minRelativeSize
//        
////        return isFullyVisible && isLargeEnough
//        return isFullyVisible
//    }
////    private func isQRCodeFullyVisible(_ barcode: VNBarcodeObservation) -> Bool {
////        // 1. Get the actual corners (these stay accurate even if QR is diagonal)
////        let corners = [
////            barcode.topLeft,
////            barcode.topRight,
////            barcode.bottomLeft,
////            barcode.bottomRight
////        ]
////
////        let margin: CGFloat = 0.05
////
////        // 2. Check if every individual corner is within the screen bounds
////        for corner in corners {
////            if corner.x < margin || corner.x > (1 - margin) ||
////               corner.y < margin || corner.y > (1 - margin) {
////                print("⚠️ Corner outside margin: \(corner)")
////                return false
////            }
////        }
////
////        // 3. Check for "Steep Angle" (Optional)
////        // If the QR is too diagonal, the TFLite model might struggle later.
////        // You can check the width/height ratio of the bounding box.
////        let bb = barcode.boundingBox
////        let aspect = bb.width / bb.height
////        if aspect < 0.5 || aspect > 2.0 {
////            print("⚠️ Angle too steep (aspect ratio: \(aspect))")
////            return false
////        }
////
////        return true
////    }
//    @objc private func zoomSliderValueChanged(_ sender: UISlider) {
//        let roundedValue = round(sender.value / Float(zoomStep)) * Float(zoomStep)
//        sender.value = roundedValue
//
//        let newZoom = CGFloat(roundedValue)
//        currentZoom = newZoom
//
//        // Update zoom label
//        zoomLabel.text = String(format: "%.1fx", newZoom)
//
//        setZoom(newZoom)
//    }
//
//    @objc private func zoomSliderTouchBegan() {
//        // User started dragging the slider — pause the countdown AND hand
//        // zoom control over to them for the rest of the session. Auto-zoom
//        // will stay out of the way until resetDetection() (or scan refresh)
//        // clears the flag.
//        userZoomOverride = true
//        pauseScanIntervalForInteraction()
//    }
//
//    @objc private func zoomSliderTouchEnded() {
//        // User lifted finger — restart the 5-second countdown (gated by motion).
//        startScanTimer()
//    }
//
//    private func setZoom(_ zoom: CGFloat) {
//        guard let device = videoDevice else { return }
//        
//        do {
//            try device.lockForConfiguration()
//            
//            // Apply zoom with clamping to device limits
//            let clampedZoom = max(minZoom, min(zoom, maxZoom))
//            device.videoZoomFactor = clampedZoom
//            
//            device.unlockForConfiguration()
//            
//            print("🔍 Zoom set to: \(clampedZoom)x")
//            
//        } catch {
//            print("❌ Could not set zoom: \(error)")
//        }
//    }
//    func justZoom() {
//        guard let device = videoDevice else { return }
//        
//        do {
//            try device.lockForConfiguration()
//            
//            // Use currentZoom instead of hardcoded value
//            device.videoZoomFactor = max(1.0, min(currentZoom, device.activeFormat.videoMaxZoomFactor))
//            
//            device.unlockForConfiguration()
//            
//        } catch {
//            print("Could not lock device for configuration: \(error)")
//        }
//    }
//    // MARK: - Camera Actions (Zoom and Capture)
//    private func zoomAndCapture() {
//        guard let device = videoDevice else { return }
//        
//        do {
//            //            try device.lockForConfiguration()
//            //
//            //            // --- Zoom Logic ---
//            //            // Let's zoom to a factor of 2.0x. You can adjust this.
//            //            // We clamp the value to be within the device's available zoom range.
//            //            let desiredZoomFactor: CGFloat = 2.0
//            //            device.videoZoomFactor = max(1.0, min(desiredZoomFactor, device.activeFormat.videoMaxZoomFactor))
//            //
//            //            device.unlockForConfiguration()
//            
//            // Give the camera a moment to adjust focus and exposure after zooming.
//            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
//                self.capturePhoto()
//            }
//            
//        } catch {
//            print("Could not lock device for configuration: \(error)")
//        }
//    }
//    
//    private func capturePhoto() {
//        let settings: AVCapturePhotoSettings
//
//        // Use a high-resolution format if available by creating the settings with a format dictionary.
//        if self.photoOutput.availablePhotoPixelFormatTypes.contains(kCVPixelFormatType_420YpCbCr8BiPlanarFullRange) {
//            settings = AVCapturePhotoSettings(format: [kCVPixelBufferPixelFormatTypeKey as String: kCVPixelFormatType_420YpCbCr8BiPlanarFullRange])
//        } else {
//            // Fallback to default settings if the desired format is not available.
//            settings = AVCapturePhotoSettings()
//        }
//
//        // Ask for the highest resolution the sensor can deliver. Without
//        // these knobs the photo output caps around 1920×1440 even on a
//        // 4032×3024 sensor, which is the single biggest reason our
//        // cropped uploads end up at ~800×800 vs Scandit's ~2000×2000.
//        if #available(iOS 16.0, *) {
//            // iOS 16+: use the modern photo-quality + maxPhotoDimensions API.
//            settings.photoQualityPrioritization = .quality
//            let maxDims = photoOutput.maxPhotoDimensions
//            if maxDims.width > 0 && maxDims.height > 0 {
//                settings.maxPhotoDimensions = maxDims
//            }
//        } else {
//            // iOS 13-15: use the legacy isHighResolutionPhotoEnabled flag.
//            settings.isHighResolutionPhotoEnabled = true
//        }
//
//        photoOutput.capturePhoto(with: settings, delegate: self)
//    }
//
//    // MARK: - Sharpness-aware capture for the /validate/ path
//    /// Maximum time we'll wait for the lens to settle before snapping. Most
//    /// AF converges in <250 ms when the live preview was already in focus;
//    /// 600 ms is generous headroom for hard cases (low light, scene change).
//    private let validateFocusSettleMaxWait: TimeInterval = 0.6
//    /// Threshold used by the high-res crop's blur check inside
//    /// `pendingFakePhotoCompletion`. The live-preview threshold (70) is
//    /// tuned for ~256-wide downscaled frames; full-resolution Axion-code
//    /// crops produce Laplacian variance an order of magnitude higher, so a
//    /// far stricter floor is appropriate here. Tune in-field if real-world
//    /// crops are getting rejected.
//    private let validateCropSharpnessThreshold: Float = 200
//    /// Tenengrad sharpness threshold (0-100 scale, matches server-side
//    /// Python `sharpness_score`). Crops scoring BELOW this value never
//    /// reach /validate/ — the timer is reset and we try again. The Python
//    /// scale produces ~80+ for a tack-sharp print, ~30-50 for visible-but-
//    /// soft, ~10-25 for obviously blurry. We start at 50 to reject most
//    /// soft frames; tune from the log output if real-world hits are too
//    /// strict or too lenient.
//    private let validateCropTenengradThreshold: Double = 50
//
//    // MARK: - Upload image-quality knobs
//    //
//    // These exist together so you can A/B them against Scandit on the
//    // same device by flipping one constant at a time.
//
//    /// JPEG quality for both /predict/ and /validate/ uploads. The default
//    /// 0.8 used to dissolve fine print detail (offset-printer dots merged
//    /// into smears) at the sizes we upload. 0.95 keeps the print structure
//    /// visible without ballooning the payload (~30% larger than 0.8 in
//    /// practice).
//    private let uploadJpegQuality: CGFloat = 0.95
//    /// Padding multiplier around the QR rect when cropping for upload.
//    /// 3.0× is the proven value — anything tighter (we tried 1.5×) cuts
//    /// off some of the 6 outer pattern boxes around the QR, which makes
//    /// the post-crop `validatePatternBoxes` check fail with "QR pattern
//    /// incomplete — try again". 2.0× is theoretically the minimum that
//    /// keeps the patterns inside the crop, 3.0× adds a safety margin
//    /// for off-centre or tilted captures. Used by both `cropSquareNow`
//    /// and `cropAroundTFLiteQR`. Stays as a tunable constant so future
//    /// experiments can move it without grepping for two call sites.
//    private let cropQRPaddingMultiplier: CGFloat = 3.0
//    /// Whether to apply `CIUnsharpMask` to the cropped image before
//    /// JPEG-encoding it for upload. The mask emphasises edges so print
//    /// dots stay crisp through the encode step. Turn off if you want to
//    /// compare raw-vs-sharpened uploads against Scandit.
//    private let applyUnsharpenForUpload: Bool = true
//    /// CIUnsharpMask `inputRadius`. 2.0 is a moderate halo width that
//    /// crisps edges without producing visible ringing on small text.
//    private let unsharpenRadius: CGFloat = 2.0
//    /// CIUnsharpMask `inputIntensity`. 0.5 is moderate sharpening.
//    /// Above 0.8 starts looking artificially crunchy on smooth gradients.
//    private let unsharpenIntensity: CGFloat = 0.5
//
//    /// Validation-path capture. Triggers a fresh AF/AE cycle, polls
//    /// `device.isAdjustingFocus` / `isAdjustingExposure` until they're
//    /// false (or we hit `validateFocusSettleMaxWait`), then runs the
//    /// regular `capturePhoto` so the shutter only fires once the lens is
//    /// stable. This kills the class of bug where the live-preview probe
//    /// said "sharp" but the lens drifted in the ~200 ms between the timer
//    /// firing and the shutter actually releasing.
//    private func captureSharpPhotoForValidation() {
//        guard let device = videoDevice else {
//            // No device? Fall back to the original behaviour so the flow
//            // doesn't hang.
//            capturePhoto()
//            return
//        }
//
//        // Kick a fresh AF/AE cycle. `.autoFocus` resnaps once and then
//        // returns to `.locked` until disturbed — exactly what we want for
//        // a one-shot still capture.
//        do {
//            try device.lockForConfiguration()
//            if device.isFocusModeSupported(.autoFocus) {
//                device.focusMode = .autoFocus
//            }
//            if device.isExposureModeSupported(.autoExpose) {
//                device.exposureMode = .autoExpose
//            }
//            device.unlockForConfiguration()
//        } catch {
//            print("⚠️ captureSharpPhotoForValidation: lockForConfiguration failed — \(error.localizedDescription)")
//            // Continue anyway — better to capture a possibly-blurry frame
//            // than to deadlock the flow.
//            capturePhoto()
//            return
//        }
//
//        // Poll for convergence on the main thread. KVO would be cleaner
//        // but it'd require teardown plumbing and we want a small,
//        // self-contained helper.
//        let start = CACurrentMediaTime()
//        let pollInterval: TimeInterval = 0.04 // ~25 Hz, cheap
//        func poll() {
//            let elapsed = CACurrentMediaTime() - start
//            let stillAdjusting = (videoDevice?.isAdjustingFocus ?? false)
//                || (videoDevice?.isAdjustingExposure ?? false)
//            if !stillAdjusting {
//                print(String(format: "🎯 validate-path AF/AE converged after %.2f s — capturing", elapsed))
//                capturePhoto()
//                return
//            }
//            if elapsed >= validateFocusSettleMaxWait {
//                print(String(format: "⏰ validate-path AF/AE didn't settle within %.2f s — capturing anyway", elapsed))
//                capturePhoto()
//                return
//            }
//            DispatchQueue.main.asyncAfter(deadline: .now() + pollInterval) {
//                poll()
//            }
//        }
//        poll()
//    }
//    private func debugImageInfo(_ ciImage: CIImage, _ barcode: VNBarcodeObservation?) {
//        print("=== DEBUG IMAGE INFO ===")
//        print("CIImage extent: \(ciImage.extent)")
//        print("CIImage properties: \(ciImage.properties)")
//        
//        if let barcode = barcode {
//            print("Barcode boundingBox: \(barcode.boundingBox)")
//            print("Barcode confidence: \(barcode.confidence)")
//            print("Barcode payload: \(barcode.payloadStringValue ?? "nil")")
//            
//            // Convert to image coordinates for debugging
//            let imageSize = ciImage.extent.size
//            let originX = barcode.boundingBox.origin.x * imageSize.width
//            let originY = (1 - barcode.boundingBox.origin.y - barcode.boundingBox.height) * imageSize.height
//            let width = barcode.boundingBox.width * imageSize.width
//            let height = barcode.boundingBox.height * imageSize.height
//            
//            print("Barcode in image coordinates: (\(originX), \(originY), \(width), \(height))")
//        }
//        print("========================")
//    }
//    
//    // MARK: - Validate Pattern Boxes Are Complete Squares
//    private func validatePatternBoxes(_ image: UIImage) async -> Bool {
//        do {
//            let detections = try TFLiteInference.run(
//                on: image,
//                modelName: "model",
//                bundle: AxionBundle.bundle
//            )
//            
//            // Filter only "Pattern" class detections (classId == 2)
//            let patternDetections = detections.filter {
//                $0.classId == YOLOClass.pattern.rawValue
//            }
//            
//            print("🔲 Pattern detections found: \(patternDetections.count)")
//            
//            // Must have exactly 6 Pattern boxes
//            guard patternDetections.count >= 6 else {
//                print("❌ Pattern count mismatch: expected 6, got \(patternDetections.count)")
//                return false
//            }
//            
//            // Each Pattern box must be a complete square
//            // A box is a square if width ≈ height within a tolerance of 30%
//            let squareTolerance: CGFloat = 0.30
//            
//            for (i, det) in patternDetections.enumerated() {
//                let w = det.rect.width
//                let h = det.rect.height
//                
//                guard w > 0, h > 0 else {
//                    print("❌ Pattern[\(i)] has zero dimension: \(det.rect)")
//                    return false
//                }
//                
//                let ratio = max(w, h) / min(w, h)
//                print("🔲 Pattern[\(i)] size: \(w)x\(h), ratio: \(String(format: "%.2f", ratio))")
//                
//                if ratio > (1.0 + squareTolerance) {
//                    print("❌ Pattern[\(i)] is not square enough: ratio=\(String(format: "%.2f", ratio))")
//                    return false
//                }
//            }
//            
//            print("✅ All 6 Pattern boxes are complete squares")
//            return true
//            
//        } catch {
//            print("❌ TFLite pattern validation error: \(error.localizedDescription)")
//            return false
//        }
//    }
//    
//    private func startTiltCheckTimer() {
//        stopTiltCheckTimer()
//        // Check every 1.5s — frequent enough to feel live, cheap enough not to block
//        tiltCheckTimer = Timer.scheduledTimer(
//            withTimeInterval: 1.5,
//            repeats: true
//        ) { [weak self] _ in
//            self?.performLiveTiltCheck()
//        }
//        RunLoop.main.add(tiltCheckTimer!, forMode: .common)
//    }
//
//    private func stopTiltCheckTimer() {
//        tiltCheckTimer?.invalidate()
//        tiltCheckTimer = nil
//    }
//
//    private func performLiveTiltCheck() {
//        // Skip if QR already detected, or a tilt check is already in-flight,
//        // or the app is backgrounded (no point running TFLite on stale frames).
//        guard !isAppInBackground, !isQRCodeDetected, !isTiltChecking else { return }
//        isTiltChecking = true
//
//        captureFrameForValidation { [weak self] image in
//            guard let self = self, let image = image else {
//                self?.isTiltChecking = false
//                return
//            }
//
//            Task.detached(priority: .utility) {
//                do {
//                    let detections = try TFLiteInference.run(
//                        on: image,
//                        modelName: "model",
//                        bundle: AxionBundle.bundle
//                    )
//
//                    let (isTilted, angle) = self.checkRotation(detections: detections)
//
//                    // Reuse the same detection pass to drive auto-zoom — the
//                    // patterns rect tells us exactly how big the QR currently
//                    // appears, so we can nudge the lens until it just fills
//                    // the scan window.
//                    let patternRects = detections
//                        .filter { $0.classId == YOLOClass.pattern.rawValue }
//                        .map { $0.rect }
//                    let frameSize = CGSize(
//                        width: image.cgImage?.width ?? Int(image.size.width),
//                        height: image.cgImage?.height ?? Int(image.size.height)
//                    )
//                    let frameLong = CGFloat(max(image.cgImage?.width  ?? Int(image.size.width),
//                                                image.cgImage?.height ?? Int(image.size.height)))
//
//                    // "Far" = the patterns are tiny relative to the frame, AND auto-zoom has
//                    // already gone almost all the way to maxZoom trying to fix it. Combining
//                    // both signals avoids false positives while auto-zoom is still ramping up
//                    // at the start of a scan.
//                    //
//                    // Threshold picked empirically:
//                    //   - autoZoomTargetFraction = 0.90 of scanWindowSize.width (250pt) inside
//                    //     a ~850pt preview = target ~26% of the frame's longest dim.
//                    //   - Even at the 8x maxZoom, the smallest we can let patterns get and
//                    //     still hit that target is ~26 / 8 ≈ 3.3%. We use 5% to leave headroom
//                    //     so we only fire the "far" message when there's genuinely no way for
//                    //     auto-zoom to save us.
//                    // ── Far-distance gate + DIAGNOSTICS ────────────────────
//                    // Compute multiple candidate "size" signals from YOLO
//                    // and log them all every tick so you can pick the one
//                    // that tracks distance best:
//                    //   • patternUnion — union of all 6 pattern rects
//                    //     (current decision driver; falls apart when YOLO
//                    //     misses patterns at far range)
//                    //   • qrBox        — the single QR-class rect, the most
//                    //     direct measure of "how big does the code look"
//                    //   • axionBox     — AxionCode-class rect
//                    //   • alignBox     — AlignmentPattern-class rect
//                    //
//                    // Each is reported as a fraction of the frame's longest
//                    // dim, so they're directly comparable.
//                    //
//                    // Read the console while holding "too far" — whichever
//                    // value reliably stays small at far range and grows at
//                    // close range is the one to drive the decision from.
//                    let patternCountForFar = patternRects.count
//
//                    func bestRect(for classId: Int) -> CGRect? {
//                        detections
//                            .filter { $0.classId == classId }
//                            .sorted { $0.confidence > $1.confidence }
//                            .first?
//                            .rect
//                    }
//                    func fraction(of rect: CGRect?) -> CGFloat {
//                        guard let r = rect, !r.isNull, frameLong > 0 else { return 0 }
//                        return max(r.width, r.height) / frameLong
//                    }
//
//                    let patternUnionRect = patternRects.reduce(CGRect.null) { $0.union($1) }
//                    let qrRect       = bestRect(for: YOLOClass.qr.rawValue)
//                    let axionRect    = bestRect(for: YOLOClass.axionCode.rawValue)
//                    let alignRect    = bestRect(for: YOLOClass.alignmentPattern.rawValue)
//
//                    let patternFraction = fraction(of: patternUnionRect.isNull ? nil : patternUnionRect)
//                    let qrFraction      = fraction(of: qrRect)
//                    let axionFraction   = fraction(of: axionRect)
//                    let alignFraction   = fraction(of: alignRect)
//
//                    // Current decision still uses the pattern-union signal —
//                    // change the line below once you've picked a better
//                    // signal from the log (e.g. swap `patternFraction` for
//                    // `qrFraction`, or take the max of several).
//                    let countOK          = patternCountForFar >= 2
//                    let frameOK          = frameLong > 0
//                    let fractionTooSmall = patternFraction < 0.05
//                    let zoomNearMax      = self.currentZoom >= (self.maxZoom * 0.85)
//                    let isUserFar        = countOK && frameOK && fractionTooSmall && zoomNearMax
//
//                    print(String(
//                        format: "🔭 far-check: frameLong=%.0f zoom=%.2f (max=%.2f, nearMaxThr=%.2f) | counts: patterns=%d qr=%@ axion=%@ align=%@ | fractions: patternUnion=%.4f qr=%.4f axion=%.4f align=%.4f | gates: countOK=%@ fractionTooSmall=%@ zoomNearMax=%@ → isUserFar=%@",
//                        frameLong,
//                        self.currentZoom,
//                        self.maxZoom,
//                        self.maxZoom * 0.85,
//                        patternCountForFar,
//                        qrRect    == nil ? "0" : "1",
//                        axionRect == nil ? "0" : "1",
//                        alignRect == nil ? "0" : "1",
//                        patternFraction,
//                        qrFraction,
//                        axionFraction,
//                        alignFraction,
//                        countOK          ? "Y" : "N",
//                        fractionTooSmall ? "Y" : "N",
//                        zoomNearMax      ? "Y" : "N",
//                        isUserFar        ? "Y" : "N"
//                    ))
//                    
//                    
//                    await MainActor.run {
//                        self.isTiltChecking = false
//
//                        // Auto-zoom regardless of tilt status — getting the
//                        // patterns into the box is the first thing the user
//                        // needs help with.
//                        self.maybeApplyAutoZoom(patternRects: patternRects, frameSize: frameSize)
//
//                        // Only update label if we're still in idle scanning state
//                        guard !self.isQRCodeDetected else { return }
//
//                        // Sharpness / focus messages take priority — if the
//                        // frame isn't capture-ready yet, tell the user that
//                        // first so they don't think the app is broken.
//                        if self.isAutoFocusAdjusting {
//                            self.instructionLabel.text = "Focusing…"
//                            self.instructionLabel.textColor = .yellow
//                            return
//                        }
//                        // "Too close" guidance takes priority over the
//                        // generic "waiting for sharp focus" hint — when
//                        // the lens is parked at the near-focus limit no
//                        // amount of waiting will resolve the blur. Tell
//                        // the user to physically move back.
//                        if self.userIsTooCloseToFocus {
//                            self.instructionLabel.text = "Move phone slightly farther away"
//                            self.instructionLabel.textColor = .yellow
//                            return
//                        }
//                        if !self.isFrameSharp {
//                            self.instructionLabel.text = "Hold steady — waiting for sharp focus"
//                            self.instructionLabel.textColor = .yellow
//                            return
//                        }
//
//                        if isUserFar {
//                            self.instructionLabel.text = "You are far. Come closer"
//                            self.instructionLabel.textColor = .yellow
//                            return
//                        }
//                        if isTilted {
//                            // angle > 0 means right side is LOWER → user needs to rotate counter-clockwise (left)
//                            // angle < 0 means left side is LOWER → user needs to rotate clockwise (right)
//                            let instruction = angle > 0 ? "Rotate slightly left ↺" : "Rotate slightly right ↻"
//                            self.instructionLabel.text = instruction
//                            self.instructionLabel.textColor = .yellow
//                        } else if !detections.isEmpty {
//                            // Detections exist but not tilted — show normal hint
//                            self.instructionLabel.text = "Hold steady — scanning…"
//                            self.instructionLabel.textColor = .white
//                        } else {
//                            // Nothing detected at all — reset to default
//                            self.instructionLabel.text = "Make sure the QR Code is centred\nand clearly visible"
//                            self.instructionLabel.textColor = .white
//                        }
//                    }
//                } catch {
//                    await MainActor.run {
//                        self.isTiltChecking = false
//                    }
//                    print("⚠️ Live tilt check error: \(error.localizedDescription)")
//                }
//            }
//        }
//    }
//
//    // MARK: - Auto-zoom (fit YOLO patterns into the scan window)
//    /// Given the 6 (or more) Pattern rects from YOLO and the size of the frame
//    /// they were detected in, nudge videoZoomFactor so the patterns occupy
//    /// roughly `autoZoomTargetFraction` of the scan window. Bails out if the
//    /// user has touched the slider — once a user takes manual control we keep
//    /// out of their way for the rest of the session (resets on
//    /// `resetDetection`).
//    private func maybeApplyAutoZoom(patternRects: [CGRect], frameSize: CGSize) {
//        // Respect manual override permanently until reset.
//        guard !userZoomOverride else { return }
//        // Need at least 4 patterns to have a stable bounding-box estimate
//        // (occasionally one pattern is occluded or below the conf threshold).
//        guard patternRects.count >= 4 else { return }
//        guard videoDevice != nil else { return }
//        guard frameSize.width > 0, frameSize.height > 0 else { return }
//
//        // Throttle — don't ride the lens motor harder than necessary.
//        let now = CACurrentMediaTime()
//        if now - lastAutoZoomTime < autoZoomInterval { return }
//
//        // Union of all pattern rects in the raw frame's pixel coords.
//        let union = patternRects.reduce(CGRect.null) { $0.union($1) }
//        guard !union.isNull, union.width > 0, union.height > 0 else { return }
//
//        // Compare longest-dim → longest-dim so orientation doesn't matter.
//        // The patterns form a square arrangement around the QR, so taking
//        // max(width, height) gives a stable estimate of the QR's apparent size.
//        let patternLong = max(union.width, union.height)
//        let frameLong = max(frameSize.width, frameSize.height)
//        let currentFraction = patternLong / frameLong
//        guard currentFraction > 0 else { return }
//
//        // Target = scan window's longest dim relative to the preview's longest
//        // dim, scaled down by the desired fill (0.90 → patterns at ~90% of the
//        // box, matching the reference screenshot's tight fit).
//        let previewBounds = previewView?.bounds ?? view.bounds
//        let previewLong = max(previewBounds.width, previewBounds.height)
//        guard previewLong > 0 else { return }
//        let scanLong = max(scanWindowSize.width, scanWindowSize.height)
//        let targetFraction = (scanLong * autoZoomTargetFraction) / previewLong
//
//        let ratio = targetFraction / currentFraction
//
//        // INCREASE-ONLY policy: auto-zoom exists to help users who are too
//        // far away (patterns appear small in the frame). If the patterns
//        // are already at or above the target size, we leave the camera
//        // alone — pulling the zoom back would visually fight a user who is
//        // already in a good position.
//        //
//        //   ratio > 1.0  → patterns too small → zoom IN (continue)
//        //   ratio ≤ 1.0  → patterns large enough → leave zoom alone (bail)
//        guard ratio > 1.0 else {
//            lastAutoZoomTime = now
//            return
//        }
//
//        // Deadband — ignore small "needs zoom-in" ratios so the camera
//        // doesn't hunt by ±0.1x between checks.
//        guard (ratio - 1.0) > autoZoomDeadband else {
//            // We're within the deadband, treat as "fitted" and stop touching
//            // the lens. Still update the throttle timestamp so we don't spam
//            // the deadband check.
//            lastAutoZoomTime = now
//            return
//        }
//
//        var newZoom = currentZoom * ratio
//        // Clamp per-step movement for smooth visual transition. Lower bound
//        // is currentZoom itself (not currentZoom - autoZoomMaxStep) because
//        // we never want this code path to produce a smaller zoom value.
//        newZoom = max(currentZoom, min(currentZoom + autoZoomMaxStep, newZoom))
//        // Clamp to device-supported range.
//        newZoom = max(minZoom, min(maxZoom, newZoom))
//
//        // Skip no-op changes after clamping.
//        guard abs(newZoom - currentZoom) > 0.05 else {
//            lastAutoZoomTime = now
//            return
//        }
//
//        lastAutoZoomTime = now
//        currentZoom = newZoom
//        zoomSlider?.setValue(Float(newZoom), animated: true)
//        zoomLabel?.text = String(format: "%.1fx", newZoom)
//        setZoom(newZoom)
//        // Lens is about to move — assume we'll need to re-focus, so drop the
//        // sharpness flag and let the gate re-arm when it settles.
//        isFrameSharp = false
//        print("🔭 auto-zoom \(String(format: "%.2f", currentFraction))→target \(String(format: "%.2f", targetFraction)) ⇒ \(String(format: "%.1fx", newZoom))")
//    }
//    private func checkRotation(detections: [Detection]) -> (isTilted: Bool, angle: Double) {
//        let patterns = detections
//            .filter { $0.classId == YOLOClass.pattern.rawValue }
//            .sorted { $0.rect.minX < $1.rect.minX } // left → right, consistent ordering
//
//        guard patterns.count >= 2 else {
//            return (false, 0)
//        }
//
//        // Use leftmost and rightmost pattern for the most stable baseline
//        let leftPattern  = patterns.first!
//        let rightPattern = patterns.last!
//
//        let p1 = CGPoint(x: leftPattern.rect.midX,  y: leftPattern.rect.midY)
//        let p2 = CGPoint(x: rightPattern.rect.midX, y: rightPattern.rect.midY)
//
//        // Angle of the line from left pattern → right pattern relative to horizontal
//        // Positive angle = tilted right (clockwise), Negative = tilted left (counter-clockwise)
//        let angle = atan2(p2.y - p1.y, p2.x - p1.x) * 180 / .pi
//
//        print("🔄 Tilt angle: \(String(format: "%.1f", angle))° (left:\(p1), right:\(p2))")
//
//        let isTilted = abs(angle) > 15.0 // raise from 10° to reduce false positives
//        return (isTilted, Double(angle))
//    }
//    
//    // MARK: - TFLite Validation (no UI drawing, just class check)
//    private func validateWithObjectDetection(completion: @escaping (_ hasAllClasses: Bool, _ image: UIImage?) -> Void) {
//        guard let device = videoDevice else {
//            completion(false, nil)
//            return
//        }
//
//        // Capture a live frame for detection
//        captureFrameForValidation { [weak self] image in
//            guard let self = self, let image = image else {
//                completion(false, nil)
//                return
//            }
//
//            Task {
//                do {
//                    let detections = try TFLiteInference.run(
//                        on: image,
//                        modelName: "model",
//                        bundle: AxionBundle.bundle
//                    )
//
//                    // Check which class IDs were detected
//                    let detectedClassIds = Set(detections.map { $0.classId })
//                    print("🔍 TFLite detected class IDs: \(detectedClassIds)")
//
//                    // We need all 4 classes present
//                    let requiredClasses: Set<Int> = [
//                        YOLOClass.alignmentPattern.rawValue,  // 0
//                        YOLOClass.axionCode.rawValue,          // 1
//                        YOLOClass.pattern.rawValue,            // 2
//                        YOLOClass.qr.rawValue                  // 3
//                    ]
//
//                    let hasAllClasses = requiredClasses.isSubset(of: detectedClassIds)
//                    print("🔍 Has all required classes: \(hasAllClasses)")
//                    print("🔍 Detected: \(detectedClassIds), Required: \(requiredClasses)")
//
//                    DispatchQueue.main.async {
//                        // Pass the same frame we just analysed back to the
//                        // caller so it can hand it to the /validate/ fallback
//                        // without spending another capture round-trip.
//                        completion(hasAllClasses, image)
//                    }
//                } catch {
//                    print("❌ TFLite detection error: \(error.localizedDescription)")
//                    DispatchQueue.main.async {
//                        completion(false, nil)
//                    }
//                }
//            }
//        }
//    }
//
//    // MARK: - Capture single frame for TFLite (no photo delegate, no freeze)
//    private func captureFrameForValidation(completion: @escaping (UIImage?) -> Void) {
//        // Use the video data output to grab the latest pixel buffer
//        // We do this by temporarily storing a one-shot callback.
//        //
//        // RACE GUARD: if a previous one-shot completion is still pending (e.g.
//        // a live tilt check is waiting for the next frame and `scanTimerFired`
//        // races in with `validateWithObjectDetection`), release the old one
//        // with `nil` first. Without this the old caller's cleanup never runs
//        // — that's how `isTiltChecking` used to get stuck at `true` after the
//        // first scan and auto-zoom would stop working.
//        if let existing = self.validationFrameCompletion {
//            self.validationFrameCompletion = nil
//            DispatchQueue.main.async { existing(nil) }
//        }
//        self.validationFrameCompletion = completion
//    }
//
//    // Add this property at the top of your class alongside other properties:
//    // private var validationFrameCompletion: ((UIImage?) -> Void)?
//    // MARK: - AVCapturePhotoCaptureDelegate
//    // MARK: - AVCapturePhotoCaptureDelegate
////    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
////        if let error = error {
//////            print("❌ Photo processing error: \(error.localizedDescription)")
////            ProgressHUD.shared.hide()
////            resetDetection()
////            return
////        }
////
////        guard let imageData = photo.fileDataRepresentation() else {
////            print("❌ Could not get image data")
////            ProgressHUD.shared.hide()
////            resetDetection()
////            return
////        }
////
////        print("✅ Captured photo successfully")
////
////        // Process the image
////        guard let ciImage = CIImage(data: imageData) else {
////            print("❌ Could not create CIImage from data")
////            ProgressHUD.shared.hide()
////            resetDetection()
////            return
////        }
////
////        DispatchQueue.global(qos: .userInitiated).async {
////            // Save original for debugging
////            let context = CIContext()
////            if let cgImage = context.createCGImage(ciImage, from: ciImage.extent) {
////                let originalImage = UIImage(cgImage: cgImage)
//////                UIImageWriteToSavedPhotosAlbum(originalImage, nil, nil, nil)
////            }
////
////            // Try multiple cropping methods
////            var croppedImage: UIImage?
////
////            // Method 1: Enhanced CIDetector with scale/rotation
////            croppedImage = self.cropSquareNow(ciImage)
////
////            // Method 2: Fallback to Vision bounds if available
////            if croppedImage == nil, let detected = self.detectedBarcode {
////                print("🔄 Falling back to Vision-based cropping")
////                croppedImage = self.cropUsingVisionObservation(ciImage, observation: detected)
////            }
////
////            // Method 3: Last resort - center crop
////            if croppedImage == nil {
////                print("🔄 Using center crop as last resort")
////                croppedImage = self.manualCenterCrop(ciImage)
////            }
////
////            guard let finalImage = croppedImage else {
////                print("❌ All cropping methods failed")
////                DispatchQueue.main.async {
////                    ProgressHUD.shared.hide()
////                    self.instructionLabel.text = "Failed to process image"
////                    self.resetDetection()
////                }
////                return
////            }
////
////            // Save cropped image for verification
////            UIImageWriteToSavedPhotosAlbum(finalImage, nil, nil, nil)
////
////            // Check image quality
////
////            if !self.isImageBlurry(finalImage, threshold: 70) {
////                DispatchQueue.main.async {
////                    self.sendImagetoModelAPI(image: finalImage, testingLabel: self.testingLabel) { result in
////                        switch result {
////                        case .success(let src):
////                            print("Image uploaded successfully. Source URL: \(src)")
////                        case .failure(let error):
////                            print("Error uploading image: \(error.localizedDescription)")
////                        }
////                    }
////                    self.instructionLabel.text = "Capture Complete!"
////                }
////            }
////            else {
////                print("❌ Cropped image is blurry")
////                DispatchQueue.main.async {
////                    self.instructionLabel.text = "Image is blurry - try holding steady"
////                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
////                        ProgressHUD.shared.hide()
////                        self.resetDetection()
////                    }
////                }
////            }
////        }
////    }
//    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
//        if let error = error {
//            print("❌ Photo processing error: \(error.localizedDescription)")
//            ProgressHUD.shared.hide()
//            resetDetection()
//            return
//        }
//
//        guard let imageData = photo.fileDataRepresentation() else {
//            print("❌ Could not get image data")
//            ProgressHUD.shared.hide()
//            resetDetection()
//            return
//        }
//
//        print("✅ Captured photo successfully")
//
//        guard let ciImage = CIImage(data: imageData) else {
//            print("❌ Could not create CIImage from data")
//            ProgressHUD.shared.hide()
//            resetDetection()
//            return
//        }
//
//        // VALIDATION-PATH HOOK ──────────────────────────────────────────
//        // If scanTimerFired's hasAllClasses branch armed a fake-flow
//        // completion before calling capturePhoto(), route the high-res
//        // CIImage there and bail out. The /predict/ pipeline below MUST NOT
//        // run in that case — we'll send the cropped result to /validate/
//        // instead, and `simulateFakeProductDetails` is only invoked from
//        // inside the closure (or from the validate API's "not Original"
//        // branch).
//        if let fakeCompletion = self.pendingFakePhotoCompletion {
//            self.pendingFakePhotoCompletion = nil
//            self.pendingValidatePhotoCompletion = nil
//            print("🛟 photoOutput → pendingFakePhotoCompletion (validation path)")
//            fakeCompletion(ciImage)
//            return
//        }
//
//        Task.detached(priority: .userInitiated) {
//            // Step 1: Convert full photo to UIImage for TFLite validation
//            let context = CIContext()
////            guard let cgFull = context.createCGImage(ciImage, from: ciImage.extent) else {
////                print("❌ Could not create CGImage from full CIImage")
////                DispatchQueue.main.async {
////                    ProgressHUD.shared.hide()
////                    self.resetDetection()
////                }
////                return
////            }
////            let fullImage = UIImage(cgImage: cgFull, scale: 1.0, orientation: .up)
////
////            // Step 2: Validate patterns on the FULL captured frame (not the crop)
////            // This ensures we're checking the actual photo taken, not a crop
////            // derived from a potentially stale/moved bounding box
////            let patternsValid = await self.validatePatternBoxes(fullImage)
////            guard patternsValid else {
////                await self.showToast(message: "QR pattern incomplete — try again")
////                print("❌ Pattern validation failed on full frame — skipping sendImagetoModelAPI")
////                DispatchQueue.main.async {
////                    ProgressHUD.shared.hide()
////                    self.instructionLabel.text = "QR pattern incomplete — try again"
////                    DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
////                        self.resetDetection()
////                    }
////                }
////                return
////            }
////
////            print("✅ Pattern validation passed on full frame — proceeding to crop")
////
////            // Step 3: Now crop using the stored bounding box (patterns confirmed present)
////            var finalImage = self.cropSquareNow(ciImage)
////
////            // Only fall back to center crop if primary fails
////            if finalImage == nil {
////                print("⚠️ cropSquareNow failed — using center crop fallback")
////                finalImage = self.manualCenterCrop(ciImage)
////            }
////
////            guard let imageToSend = finalImage else {
////                print("❌ All cropping methods failed")
////                DispatchQueue.main.async {
////                    ProgressHUD.shared.hide()
////                    self.instructionLabel.text = "Failed to process image"
////                    self.resetDetection()
////                }
////                return
////            }
//            // --- NEW STEP 1: CROP FIRST ---
//                // We attempt to crop based on the Vision bounding box detected earlier
//                var croppedImage = self.cropSquareNow(ciImage)
//
//                // Fallback to center crop if the Vision-based crop fails
//                if croppedImage == nil {
//                    print("⚠️ cropSquareNow failed — using center crop fallback")
//                    croppedImage = self.manualCenterCrop(ciImage)
//                }
//
//                guard let imageToValidate = croppedImage else {
//                    print("❌ All cropping methods failed")
//                    DispatchQueue.main.async {
//                                ProgressHUD.shared.hide()
//                                self.instructionLabel.text = "Failed to process image"
//                                self.resetDetection()
//                            }
//                    return
//                }
//            if self.isRunningInTestFlight() {
//                // Save cropped image for verification/debugging
//                UIImageWriteToSavedPhotosAlbum(imageToValidate, nil, nil, nil)
//            }
//                // --- NEW STEP 2: VALIDATE ON THE CROP ---
//                // Now we run the TFLite pattern check on the small, cropped image
//                let patternsValid = await self.validatePatternBoxes(imageToValidate)
//                
//                guard patternsValid else {
//                    print("❌ Pattern validation failed on the CROPPED image")
//                    await self.showToast(message: "QR pattern incomplete — try again")
//                    
//                    DispatchQueue.main.async {
//                        ProgressHUD.shared.hide()
//                        self.instructionLabel.text = "QR pattern incomplete — try again"
//                        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5) {
//                            self.resetDetection()
//                        }
//                    }
//                    return
//                }
//
//                print("✅ Pattern validation passed on the crop!")
//
//                // Pattern validated — stop the guidance audio immediately.
//                self.audioQueue.async { [weak self] in
//                    self?.audioPlayer?.stop()
//                    self?.audioPlayer = nil
//                }
//
//
//
//
//            // Step 4: Blur check on the cropped image
//            if !self.isImageBlurry(imageToValidate, threshold: 70) {
//                DispatchQueue.main.async {
//                    // QR is validated and we're about to upload — kill motion
//                    // monitoring so the accelerometer/gyro updates aren't
//                    // pumping into a now-irrelevant scan-timer gate while the
//                    // network request is in flight. Re-armed by the next
//                    // resetDetection()/restartScan() if the user scans again.
//                    self.stopMotionMonitoring()
//                    self.sendImagetoModelAPI(image: imageToValidate, testingLabel: self.testingLabel) { result in
//                        switch result {
//                        case .success(let src):
//                            print("✅ Image uploaded successfully. Source URL: \(src)")
//                        case .failure(let error):
//                            print("❌ Error uploading image: \(error.localizedDescription)")
//                        }
//                    }
//                    self.instructionLabel.text = "Capture Complete!"
//                }
//            } else {
//                print("❌ Cropped image is blurry")
//                DispatchQueue.main.async {
//                    self.instructionLabel.text = "Image is blurry - try holding steady"
//                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) {
//                        ProgressHUD.shared.hide()
//                        self.resetDetection()
//                    }
//                }
//            }
//        }
//    }
//    // MARK: - Helper Methods
//    private func resetDetection() {
//        self.zoomLabel.text = "3.5x"
//        // 1. Cancel any pending operations
//        NSObject.cancelPreviousPerformRequests(withTarget: self)
//        processingTimer?.invalidate()
//        processingTimer = nil
//        self.startScanTimer()
//        // 2. Reset all detection states
//        isQRCodeDetected = false
//        detectedBarcode = nil
//        lastBarcode = nil
//        // Show the overlay guide again — see restartScan() for the same.
//        overlayImageView?.isHidden = false
//        performRequestCount = 0
//        currentZoom = 3.5 // Reset zoom to 3.5x (raised from 2.5x for wide-only camera + higher MFD headroom)
//        // Clear focus/sharpness/auto-zoom state — see restartScan() for the
//        // rationale on reading device.isAdjustingFocus rather than forcing
//        // `true` (otherwise the gate stays blocked forever after the first scan).
//        userZoomOverride = false
//        lastAutoZoomTime = 0
//        isFrameSharp = false
//        consecutiveSharpProbes = 0
//        userIsTooCloseToFocus = false
//        isAutoFocusAdjusting = videoDevice?.isAdjustingFocus ?? false
//        lastSharpnessCheckTime = 0
//        // Same reasoning — release the tilt-check guard so auto-zoom resumes.
//        isTiltChecking = false
//        // Always start a fresh scan at the default 6s window — see
//        // restartScan() for the same reset.
//        scanInterval = scanIntervalDefault
//        isInExtendedScanMode = false
//        // Discard any unconsumed validation-path capture closure — see
//        // restartScan() for the same reset.
//        pendingFakePhotoCompletion = nil
//        
//        DispatchQueue.main.async {
//            // 3. Reset UI
//            self.instructionLabel.text = "Point camera at a QR code"
//            self.instructionLabel.textColor = .red
//            self.updateDetectionStatus(isDetected: false)
//            self.zoomSlider.value = Float(self.currentZoom) // Reset slider position
//            
//            // Update zoom label if you added it
//            // self.zoomLabel.text = "2.5x"
//            
//            // 4. Handle device configuration
//            guard let device = self.videoDevice else { return }
//            
//            do {
//                try device.lockForConfiguration()
//
//                // Reset zoom to 2.5x
//                device.videoZoomFactor = 3.5
//
//                // Same continuous-AF/AE reset as restartScan() — see the
//                // matching block there for the rationale. Without this,
//                // the lens stays locked at the just-rejected frame's
//                // distance and the next capture round is again blurry.
//                if device.isFocusModeSupported(.continuousAutoFocus) {
//                    device.focusMode = .continuousAutoFocus
//                } else if device.isFocusModeSupported(.autoFocus) {
//                    device.focusMode = .autoFocus
//                }
//                if device.isExposureModeSupported(.continuousAutoExposure) {
//                    device.exposureMode = .continuousAutoExposure
//                } else if device.isExposureModeSupported(.autoExpose) {
//                    device.exposureMode = .autoExpose
//                }
//                print("🎯 resetDetection: focus/exposure → continuous")
//
//                // Maintain torch state
//                if device.hasTorch && device.isTorchActive {
//                    try device.setTorchModeOn(level: AVCaptureDevice.maxAvailableTorchLevel)
//                }
//
//                device.unlockForConfiguration()
//                print("✅ Device reset with 3.5x zoom")
//
//            } catch {
//                print("❌ Could not reset device configuration: \(error)")
//            }
//            
//            // 5. Restart session if needed
//            if let session = self.captureSession, !session.isRunning {
//                DispatchQueue.global(qos: .userInitiated).asyncAfter(deadline: .now() + 0.1) {
//                    session.startRunning()
//                    print("✅ Capture session restarted with 3.5x zoom")
//                }
//            }
//            
//            // 6. Re-enable preview
//            self.videoPreviewLayer.connection?.isEnabled = true
//        }
//    }
//    
//
//    
//    func sendImagetoModelAPI(image: UIImage, testingLabel: String, completion: @escaping (Result<String, Error>) -> Void) {
//        let imageToSend: UIImage = {
//               let size = CGSize(width: image.size.height, height: image.size.width)
//               UIGraphicsBeginImageContextWithOptions(size, false, image.scale)
//               let context = UIGraphicsGetCurrentContext()!
//               // Move origin to center, rotate, then draw
//               context.translateBy(x: size.width / 2, y: size.height / 2)
//               context.rotate(by: .pi / 2) // 90° clockwise
//               image.draw(in: CGRect(
//                   x: -image.size.width / 2,
//                   y: -image.size.height / 2,
//                   width: image.size.width,
//                   height: image.size.height
//               ))
//               let rotated = UIGraphicsGetImageFromCurrentImageContext()!
//               UIGraphicsEndImageContext()
//               return rotated
//           }()
//        // Sharpen the rotated upload image before JPEG encoding. Gated by
//        // `applyUnsharpenForUpload` — falls through unchanged if disabled
//        // or if any CIFilter step fails.
//        let imageToSendSharp = self.sharpenedForUpload(imageToSend)
//
//        let boundary = "Boundary-\(UUID().uuidString)"
//        if self.isRunningInTestFlight() {
//            UIImageWriteToSavedPhotosAlbum(imageToSendSharp, nil, nil, nil)
//        }
//        // Prepare the multipart form data
//        var body = Data()
//
//        // Add image data to the request
//        let filename = "uploaded_image.jpg"
//        body.append("--\(boundary)\r\n".data(using: .utf8)!)
//        body.append("Content-Disposition: form-data; name=\"file\"; filename=\"\(filename)\"\r\n".data(using: .utf8)!)
//        body.append("Content-Type: image/jpeg\r\n\r\n".data(using: .utf8)!)
//
//        guard let imageData = imageToSendSharp.jpegData(compressionQuality: self.uploadJpegQuality) else {
//            completion(.failure(NSError(domain: "ImageError", code: -1, userInfo: [NSLocalizedDescriptionKey: "Failed to convert image to JPEG"])))
//            return
//        }
//        print(String(format: "📤 /predict/ JPEG payload bytes=%d quality=%.2f sharpen=%@",
//                     imageData.count, Double(self.uploadJpegQuality),
//                     self.applyUnsharpenForUpload ? "Y" : "N"))
//
//        body.append(imageData)
//        body.append("\r\n".data(using: .utf8)!)
//        body.append("--\(boundary)--\r\n".data(using: .utf8)!)
//
//        // Create the request
////        var request = URLRequest(url: URL(string: "http://3.7.254.234:8089/predict/")!)
//        //june2
//        var request = URLRequest(url: URL(string: "http://164.52.221.51:9000/predict/")!)
////        var request = URLRequest(url: URL(string: "http://13.203.201.117:8080/predict/")!)
//        request.httpMethod = "POST"
//        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
//        request.setValue("application/json", forHTTPHeaderField: "accept")
//        request.setValue("asdnkj62df21asd1", forHTTPHeaderField: "auth-id")
//        request.setValue("asf1323sfa6s5", forHTTPHeaderField: "auth-token")
//        request.setValue(self.axionDeviceFamilyName(), forHTTPHeaderField: "DeviceFamily")
//        request.setValue(self.axionPersistentDeviceId(), forHTTPHeaderField: "LinkedUserID")
////        request.setValue("sdnakjdnlasnd", forHTTPHeaderField: "auth-id")
////        request.setValue("asdhagsdh7878q22", forHTTPHeaderField: "auth-token")
//        request.setValue(testingLabel, forHTTPHeaderField: "Testinglabel")
//        // Printing type is now derived from the decoded QR code's first
//        // character via `derivedPrintingTypeFromDetectedQR()` ('d'/'e'
//        // → digital, 'o' → offset, anything else → digital). This
//        // overrides the host-app-supplied `self.printingType` for the
//        // /predict/ call site so the server gets a consistent value
//        // based on the actual QR encoding.
//        let derivedPrintingType = self.derivedPrintingTypeFromDetectedQR()
//        request.setValue(derivedPrintingType, forHTTPHeaderField: "Printingtype")
//        //        request.setValue("iphone SE", forHTTPHeaderField: "device-details")
//        request.setValue("ios", forHTTPHeaderField: "DeviceType")
//        request.httpBody = body
//        print("Testinglabel: '\(testingLabel)'  Printingtype: '\(derivedPrintingType)' (derived from QR='\(self.detectedQRCodeValue ?? "nil")', host hint='\(self.printingType)')")
//        let task = URLSession.shared.dataTask(with: request) { data, response, error in
//            // Handle the response on main thread
//            DispatchQueue.main.async {
//                if let error = error {
//                    self.showAlert(title: "Error", message: error.localizedDescription)
//                    completion(.failure(error))
//                    self.restartScan()
//                    return
//                }
//                
//                guard let httpResponse = response as? HTTPURLResponse else {
//                    let error = NSError(domain: "NetworkError", code: -2, userInfo: [NSLocalizedDescriptionKey: "Invalid response"])
//                    self.showAlert(title: "Error", message: "Invalid server response")
//                    completion(.failure(error))
//                    return
//                }
//                
//                guard let data = data else {
//                    let error = NSError(domain: "NetworkError", code: -3, userInfo: [NSLocalizedDescriptionKey: "No data received"])
//                    self.showAlert(title: "Error", message: "No data received from server")
//                    completion(.failure(error))
//                    return
//                }
//                
//                // Debug print the raw response
//                let rawResponse = String(data: data, encoding: .utf8) ?? "Unable to decode response"
////                print("Raw response:", rawResponse)
////                self.showAlert(title: "Raw Response", message: rawResponse)
////                ProgressHUD.shared.hide()
//                do {
//                    let decoder = JSONDecoder()
//                    let resp = try decoder.decode(PredictResponse.self, from: data)
//                    let finalResult = resp.Data?.finalResult?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "Unknown"
//                    let uuid = resp.Data?.uuid?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "Unknown"
//                    print("Final Result from API: '\(finalResult)'")
//
//                    // Decide whether original (case-insensitive)
//                    var isOriginal = finalResult.lowercased() == "original"
////                    isOriginal = true
//                    // Present result screen on main queue
////                    DispatchQueue.main.async {
////                        // hide any progress indicator first
////                        ProgressHUD.shared.hide()
////
////                        // instantiate and present the result VC
////                        let resultVC = ResultViewController(result: finalResult, isOriginal: isOriginal)
//////                        self.restartScan()
////                        // present full-screen
////                        resultVC.scannerVC = self
////                        resultVC.modalPresentationStyle = .fullScreen
////                        // If this VC is inside a navigation controller you returned from wrapper,
////                        // present on the navigation controller if needed. Present from self.
////                        self.present(resultVC, animated: true)
////
////                    }
//                    
//                    if(isOriginal){
//                        if self.isRunningInTestFlight() {
//                            self.showToast(message: "Prediction - Original")
//                        }
////                            self.uploadImage(image, imageType: "CROP",prediction: "original")
//                        //bhar
//            
//                        self.makeApiCall_new(with: (12.948321152557963, 77.57733825952174), path: "IOS/com.acviss.app/0123459876/0123459876_17082020181440432.jpg", uCode: testingLabel, modelOutcome: "True", uuid: uuid)
//                    }
//                    else{
//                        if self.isRunningInTestFlight() {
//                            self.showToast(message: "Prediction - Fake")
//                        }
////                            self.uploadImage(image, imageType: "CROP",prediction: "fake")
////                            self.makeApiCall_new(path: "IOS/com.acviss.app/9886215384/9886215384_17082020181440432.jpg",uCode: testingLabel,modelOutcome: "False")
//                        self.makeApiCall_new(with: (12.948321152557963, 77.57733825952174), path: "IOS/com.acviss.app/0123459876/0123459876_17082020181440432.jpg", uCode: testingLabel, modelOutcome: "False", uuid: uuid)
//                    }
//                    completion(.success("Final Result: \(finalResult)"))
//                } catch {
//                    print("Failed to parse PredictResponse:", error)
//                    DispatchQueue.main.async {
//                        ProgressHUD.shared.hide()
//                        self.showAlert(title: "Error", message: "Invalid server response")
//                        // fallback behavior: restart scan
//                        self.restartScan()
//                    }
//                    completion(.failure(error))
//                }
//                // Continue with your JSON parsing here...
//                // Make sure to call completion handler on main thread if needed
//            }
//        }
//
//        task.resume()
//    }
//
//    // MARK: - /validate/ fallback API
//    /// Called from the 6-second scanTimerFired path when YOLO sees all 4
//    /// required classes but Vision never decoded the QR string. We forward the
//    /// same frame to the /validate/ endpoint which can sometimes recover the
//    /// payload server-side. Three response branches per product spec:
//    ///   • final_result == "Original" + non-empty qr_value
//    ///         → use qr_value as the QR string and continue the normal flow
//    ///           (makeApiCall_new with modelOutcome = "True").
//    ///   • final_result != "Original"
//    ///         → show the fake-product screen and stop.
//    ///   • final_result == "Original" + empty/missing qr_value
//    ///         → restart the scan with a 15-second extended window. If THAT
//    ///           one also times out, scanTimerFired commits to the fake
//    ///           screen (isInExtendedScanMode guard).
//    ///
//    /// Request body / headers are identical to sendImagetoModelAPI — only the
//    /// URL and the response handling differ.
//    func sendImagetoValidationAPI(image: UIImage, testingLabel: String, completion: @escaping (Result<String, Error>) -> Void) {
//        let imageToSend: UIImage = {
//            let size = CGSize(width: image.size.height, height: image.size.width)
//            UIGraphicsBeginImageContextWithOptions(size, false, image.scale)
//            let context = UIGraphicsGetCurrentContext()!
//            // Move origin to center, rotate, then draw
//            context.translateBy(x: size.width / 2, y: size.height / 2)
//            context.rotate(by: .pi / 2) // 90° clockwise
//            image.draw(in: CGRect(
//                x: -image.size.width / 2,
//                y: -image.size.height / 2,
//                width: image.size.width,
//                height: image.size.height
//            ))
//            let rotated = UIGraphicsGetImageFromCurrentImageContext()!
//            UIGraphicsEndImageContext()
//            return rotated
//        }()
//        // Sharpen the rotated upload image before JPEG encoding — same
//        // treatment as /predict/. Gated by `applyUnsharpenForUpload`.
//        let imageToSendSharp = self.sharpenedForUpload(imageToSend)
//
//        let boundary = "Boundary-\(UUID().uuidString)"
//        if self.isRunningInTestFlight() {
//            UIImageWriteToSavedPhotosAlbum(imageToSendSharp, nil, nil, nil)
//        }
//        // Prepare the multipart form data — identical shape to /predict/.
//        var body = Data()
//
//        let filename = "uploaded_image.jpg"
//        body.append("--\(boundary)\r\n".data(using: .utf8)!)
//        body.append("Content-Disposition: form-data; name=\"file\"; filename=\"\(filename)\"\r\n".data(using: .utf8)!)
//        body.append("Content-Type: image/jpeg\r\n\r\n".data(using: .utf8)!)
//
//        guard let imageData = imageToSendSharp.jpegData(compressionQuality: self.uploadJpegQuality) else {
//            completion(.failure(NSError(domain: "ImageError", code: -1, userInfo: [NSLocalizedDescriptionKey: "Failed to convert image to JPEG"])))
//            return
//        }
//        print(String(format: "📤 /validate/ JPEG payload bytes=%d quality=%.2f sharpen=%@",
//                     imageData.count, Double(self.uploadJpegQuality),
//                     self.applyUnsharpenForUpload ? "Y" : "N"))
//
//        body.append(imageData)
//        body.append("\r\n".data(using: .utf8)!)
//        body.append("--\(boundary)--\r\n".data(using: .utf8)!)
//
//        // Only difference from sendImagetoModelAPI: /validate/ instead of /predict/.
//        var request = URLRequest(url: URL(string: "http://164.52.221.51:9000/validate/")!)
//        request.httpMethod = "POST"
//        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
//        request.setValue("application/json", forHTTPHeaderField: "accept")
//        request.setValue("asdnkj62df21asd1", forHTTPHeaderField: "auth-id")
//        request.setValue("asf1323sfa6s5", forHTTPHeaderField: "auth-token")
//        request.setValue(testingLabel, forHTTPHeaderField: "Testinglabel")
//        request.setValue(self.printingType, forHTTPHeaderField: "Printingtype")
//        request.setValue("ios", forHTTPHeaderField: "DeviceType")
//        request.httpBody = body
//        print("[/validate/] Testinglabel: '\(testingLabel)'  Printingtype: '\(self.printingType)'")
//
//        let task = URLSession.shared.dataTask(with: request) { data, response, error in
//            DispatchQueue.main.async {
//                // Always hide the spinner — scanTimerFired showed one before
//                // kicking us off.
//                ProgressHUD.shared.hide()
//
//                if let error = error {
//                    self.showAlert(title: "Error", message: error.localizedDescription)
//                    completion(.failure(error))
//                    self.restartScan()
//                    return
//                }
//
//                guard let httpResponse = response as? HTTPURLResponse else {
//                    let err = NSError(domain: "NetworkError", code: -2, userInfo: [NSLocalizedDescriptionKey: "Invalid response"])
//                    self.showAlert(title: "Error", message: "Invalid server response")
//                    completion(.failure(err))
//                    return
//                }
//
//                guard let data = data else {
//                    let err = NSError(domain: "NetworkError", code: -3, userInfo: [NSLocalizedDescriptionKey: "No data received"])
//                    self.showAlert(title: "Error", message: "No data received from server")
//                    completion(.failure(err))
//                    return
//                }
//
//                let rawResponse = String(data: data, encoding: .utf8) ?? "<undecodable>"
//                print("[/validate/] HTTP \(httpResponse.statusCode) raw: \(rawResponse)")
//
//                do {
//                    // NOTE: /validate/ wraps the payload under lowercase
//                    // `data`, whereas /predict/ uses `Data`. We use a
//                    // dedicated ValidateResponse type rather than munging
//                    // PredictResponse so both can evolve independently.
//                    let resp = try JSONDecoder().decode(ValidateResponse.self, from: data)
//                    let finalResult = resp.data?.finalResult?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
//                    let uuid        = resp.data?.uuid?.trimmingCharacters(in: .whitespacesAndNewlines) ?? "Unknown"
//                    let qrValue     = resp.data?.qrValue?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
//                    let isOriginal  = finalResult.lowercased() == "original"
//
//                    print("[/validate/] final_result='\(finalResult)' qr_value='\(qrValue)' uuid='\(uuid)'")
//
//                    if isOriginal && !qrValue.isEmpty {
//                        // ✓ Branch A — server recovered the QR; treat as Original
//                        //   and continue the normal flow.
//                        if self.isRunningInTestFlight() {
//                            self.showToast(message: "Validate - Original")
//                        }
//                        // Make the recovered QR visible to makeApiCall_new
//                        // (it overrides uCode with detectedQRCodeValue when set).
//                        self.detectedQRCodeValue = qrValue
//                        self.makeApiCall_new(
//                            with: (12.948321152557963, 77.57733825952174),
//                            path: "IOS/com.acviss.app/0123459876/0123459876_17082020181440432.jpg",
//                            uCode: qrValue,
//                            modelOutcome: "True",
//                            uuid: uuid
//                        )
//                        completion(.success("Validate Original: \(qrValue)"))
//
//                    } else if !isOriginal {
//                        // ✗ Branch B — server says it's fake (or hand-rolled
//                        // a guidance string in final_result like "Code is too
//                        // small or too far away. Please zoom in and try
//                        // again."). Pass the message through so the user
//                        // sees the actual server reason instead of the
//                        // generic "fake label" line.
//                        if self.isRunningInTestFlight() {
//                            self.showToast(message: "Validate - Fake")
//                        }
//                        self.simulateFakeProductDetails(messageOverride: finalResult)
//                        completion(.success("Validate Fake: \(finalResult)"))
//
//                    } else {
//                        // ↺ Branch C — Original but the server couldn't pull a
//                        // qr_value either. Give the user one more chance with
//                        // the 15-second extended window.
//                        if self.isRunningInTestFlight() {
//                            self.showToast(message: "Retrying with 15s window")
//                        }
//                        self.restartScanWithExtendedInterval()
//                        completion(.success("Validate Original, empty qr_value — extending to 15s"))
//                    }
//                } catch {
//                    print("[/validate/] Failed to parse ValidateResponse: \(error)")
//                    self.showAlert(title: "Error", message: "Invalid server response")
//                    self.restartScan()
//                    completion(.failure(error))
//                }
//            }
//        }
//
//        task.resume()
//    }
//
//    /// Re-runs the scan flow but with the periodic-capture window extended to
//    /// 15 seconds and `isInExtendedScanMode = true` so a second timeout goes
//    /// straight to simulateFakeProductDetails (no validation-API loop).
//    ///
//    /// The CADisplayLink-driven progress bar reads `scanInterval` on every
//    /// tick, so setting it to 15 here automatically stretches the on-screen
//    /// progress bar over the new window — no extra UI plumbing needed.
//    private func restartScanWithExtendedInterval() {
//        print("🔁 Extending scan window to \(scanIntervalExtended)s for one retry")
//        // Plain reset first — wipes all the focus/sharpness/auto-zoom state.
//        // restartScan() itself sets scanInterval back to default and clears
//        // isInExtendedScanMode, so we MUST set them again AFTER it runs.
//        restartScan()
//        scanInterval = scanIntervalExtended
//        isInExtendedScanMode = true
//        // restartScan() already armed a 6s timer via resetScanTimer(); replace
//        // it with one that reflects the new interval.
//        resetScanTimer()
//    }
//
//    // MARK: - v3 authenticity-verification helper (one-off, not called)
//    //
//    // Mirrors the reference curl exactly: every header and every form
//    // field is hardcoded with the values from the curl, and only the
//    // `image` parameter is caller-provided. Not wired into any scan
//    // flow — exists in the file so it can be invoked later when needed.
//    //
//    // Reference curl:
//    //   curl --location --request POST \
//    //     'https://acvissgen.test.acviss.co/api/v3/authenticity-verification-v3/' \
//    //     --header 'auth-id: NWHM1PQGM3SG57XESN28' \
//    //     ...
//    //     --form 'image=@"/Users/apple/Downloads/overlay.png"'
//    //
//    // - parameter image: The image to send as the multipart `image`
//    //   field. PNG-encoded server-side because the reference curl uploads
//    //   a .png file (most multipart consumers default the Content-Type
//    //   off the filename extension, so we mirror that).
//    // - parameter completion: Called on the main queue with the raw
//    //   response body (as a String) on success or the underlying error
//    //   on failure.
//    // MARK: - v3 helpers (persistent device-id, marketing-name resolver)
//
//    /// Returns the persistent linked-user-id we send as the
//    /// `linked_user_id` header on the v3 endpoint. Generated once on the
//    /// first call ever made on this device (as a `UUID().uuidString`,
//    /// 36 characters with hyphens, e.g.
//    /// "E621E1F8-C36C-495A-93FC-0C247A3E6E5F") and persisted in
//    /// UserDefaults under `axion.linkedUserDeviceId`. All subsequent
//    /// calls return the same value — within this app session and across
//    /// launches — so the server can correlate scans from the same device.
//    private func axionPersistentDeviceId() -> String {
//        let key = "axion.linkedUserDeviceId"
//        // Accept any stored value that round-trips through UUID. This
//        // means legacy 16-digit IDs from a previous build will fail the
//        // parse and get replaced with a UUID on the next call — fine
//        // because the server already accepts any string here.
//        if let existing = UserDefaults.standard.string(forKey: key),
//           UUID(uuidString: existing) != nil {
//            return existing
//        }
//        let identifier = UUID().uuidString
//        UserDefaults.standard.set(identifier, forKey: key)
//        UserDefaults.standard.synchronize()
//        print("🆔 axionPersistentDeviceId generated NEW id (one-time): \(identifier)")
//        return identifier
//    }
//
//    /// Returns the marketing name of the current device (e.g.
//    /// "iPhone 16 Pro Max") for the v3 `device_family` form field.
//    /// Reads the hardware identifier via `uname` (or the simulator's
//    /// `SIMULATOR_MODEL_IDENTIFIER` env var on the simulator) and maps
//    /// known identifiers to marketing names. Unknown identifiers fall
//    /// back to the raw identifier string so the server can still log
//    /// or translate it server-side rather than receiving "Unknown".
//    private func axionDeviceFamilyName() -> String {
//        let identifier: String
//        if let simulatorId = ProcessInfo.processInfo.environment["SIMULATOR_MODEL_IDENTIFIER"], !simulatorId.isEmpty {
//            identifier = simulatorId
//        } else {
//            var systemInfo = utsname()
//            uname(&systemInfo)
//            identifier = withUnsafePointer(to: &systemInfo.machine) {
//                $0.withMemoryRebound(to: CChar.self, capacity: 1) {
//                    String(cString: $0)
//                }
//            }
//        }
//
//        switch identifier {
//        // iPhone 16 series
//        case "iPhone17,1": return "iPhone 16 Pro"
//        case "iPhone17,2": return "iPhone 16 Pro Max"
//        case "iPhone17,3": return "iPhone 16"
//        case "iPhone17,4": return "iPhone 16 Plus"
//        case "iPhone17,5": return "iPhone 16e"
//        // iPhone 15 series
//        case "iPhone15,4": return "iPhone 15"
//        case "iPhone15,5": return "iPhone 15 Plus"
//        case "iPhone16,1": return "iPhone 15 Pro"
//        case "iPhone16,2": return "iPhone 15 Pro Max"
//        // iPhone 14 series
//        case "iPhone14,7": return "iPhone 14"
//        case "iPhone14,8": return "iPhone 14 Plus"
//        case "iPhone15,2": return "iPhone 14 Pro"
//        case "iPhone15,3": return "iPhone 14 Pro Max"
//        // iPhone 13 series
//        case "iPhone14,4": return "iPhone 13 mini"
//        case "iPhone14,5": return "iPhone 13"
//        case "iPhone14,2": return "iPhone 13 Pro"
//        case "iPhone14,3": return "iPhone 13 Pro Max"
//        // iPhone 12 series
//        case "iPhone13,1": return "iPhone 12 mini"
//        case "iPhone13,2": return "iPhone 12"
//        case "iPhone13,3": return "iPhone 12 Pro"
//        case "iPhone13,4": return "iPhone 12 Pro Max"
//        // iPhone 11 series
//        case "iPhone12,1": return "iPhone 11"
//        case "iPhone12,3": return "iPhone 11 Pro"
//        case "iPhone12,5": return "iPhone 11 Pro Max"
//        // iPhone SE
//        case "iPhone12,8": return "iPhone SE (2nd generation)"
//        case "iPhone14,6": return "iPhone SE (3rd generation)"
//        // Older iPhones (selection)
//        case "iPhone11,2": return "iPhone XS"
//        case "iPhone11,4", "iPhone11,6": return "iPhone XS Max"
//        case "iPhone11,8": return "iPhone XR"
//        case "iPhone10,3", "iPhone10,6": return "iPhone X"
//        // Fall back to the raw identifier — better than "Unknown".
//        default:
//            return identifier.isEmpty ? "iPhone Unknown" : identifier
//        }
//    }
//
//    /// Derives the `Printingtype` HTTP header value for `/predict/`
//    /// uploads from the first character of `detectedQRCodeValue`:
//    ///
//    ///   • Starts with 'd' or 'e' → "digital"
//    ///   • Starts with 'o'        → "offset"
//    ///   • Anything else (or nil) → "digital"  (safe default)
//    ///
//    /// Case-insensitive on the first character. The check ignores
//    /// leading whitespace so a stray space in the decoded payload
//    /// doesn't force the default branch.
//    private func derivedPrintingTypeFromDetectedQR() -> String {
//        guard let raw = detectedQRCodeValue?.trimmingCharacters(in: .whitespacesAndNewlines),
//              let firstChar = raw.first else {
//            return "digital"
//        }
//        switch firstChar.lowercased() {
//        case "d", "e": return "digital"
//        case "o":      return "offset"
//        default:       return "digital"
//        }
//    }
//
//    func sendImageToAuthenticityVerificationWithImage(
//        image: UIImage, deviceId: String, ai_predection:String, device_family:String,
//        completion: @escaping (Result<String, Error>) -> Void
//    ) {
//        guard let url = URL(string: "https://acvissgen.acviss.co/api/v3/authenticity-verification-v3/") else {
//            completion(.failure(NSError(domain: "AuthVerifyV3", code: -1,
//                                        userInfo: [NSLocalizedDescriptionKey: "Invalid URL"])))
//            return
//        }
//
//        let boundary = "Boundary-\(UUID().uuidString)"
//
//        // 1) Headers — exact set from the curl, including the session cookie.
//        var request = URLRequest(url: url)
//        request.httpMethod = "POST"
//        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
//        request.setValue("5D681Z2F48NBN6EQ5ICM", forHTTPHeaderField: "auth-id")
//        request.setValue("ISI920B03UCFMG20L42ATEPJAPR2BRP7OEBLFIL6", forHTTPHeaderField: "auth-token")
//        request.setValue("IOS_SDK", forHTTPHeaderField: "device-type")
//        request.setValue("278", forHTTPHeaderField: "customer_id")
//        request.setValue(deviceId, forHTTPHeaderField: "linked_user_id")
//
//        // 2) Form fields — kept in declaration order to match curl. Mixed
//        //    types: most are strings, `bypass_pdf_loyalty` is a Bool. Two
//        //    string values in the curl include literal quote characters
//        //    (captured_frame_url, captured_frame_path) and are preserved
//        //    exactly so the body bytes match. The writer below serialises
//        //    each value per-type before appending.
//        let formFields: [(name: String, value: Any)] = [
//            ("ucode_data",          ""),
//            ("captured_frame_url",  "\" \""),                                             // literal: "<quote> <quote>"
//            ("location",            self.currentLocationJSONString()),
//            ("captured_frame_path", "\"cbgdtactdatyc\""),                                 // literal: "<quote>cbgdtactdatyc<quote>"
//            ("bypass_pdf_loyalty",  true),                                                // Bool — serialised as "true"/"false"
//            ("ai_predection",       ai_predection),
//            ("uuid",                "54448545478"),
//            ("device_family",       device_family),
//        ]
//
//        var body = Data()
//        for field in formFields {
//            // Serialise the value based on its actual Swift type. Wire
//            // format stays plain-text per multipart/form-data (no JSON
//            // typing at the field level), but the Swift source reflects
//            // semantics: Bool stays Bool, String stays String.
//            let valueString: String
//            switch field.value {
//            case let b as Bool:   valueString = b ? "true" : "false"
//            case let s as String: valueString = s
//            default:              valueString = "\(field.value)"
//            }
//            body.append("--\(boundary)\r\n".data(using: .utf8)!)
//            body.append("Content-Disposition: form-data; name=\"\(field.name)\"\r\n\r\n".data(using: .utf8)!)
//            body.append("\(valueString)\r\n".data(using: .utf8)!)
//        }
//
//        // 3) Image part — PNG to match the file extension in the curl.
//        guard let imageData = image.pngData() else {
//            completion(.failure(NSError(domain: "AuthVerifyV3", code: -2,
//                                        userInfo: [NSLocalizedDescriptionKey: "Failed to PNG-encode image"])))
//            return
//        }
//        body.append("--\(boundary)\r\n".data(using: .utf8)!)
//        body.append("Content-Disposition: form-data; name=\"image\"; filename=\"overlay.png\"\r\n".data(using: .utf8)!)
//        body.append("Content-Type: image/png\r\n\r\n".data(using: .utf8)!)
//        body.append(imageData)
//        body.append("\r\n".data(using: .utf8)!)
//
//        // 4) Closing boundary.
//        body.append("--\(boundary)--\r\n".data(using: .utf8)!)
//        request.httpBody = body
//
//        URLSession.shared.dataTask(with: request) { data, response, error in
//            DispatchQueue.main.async {
//                if let error = error {
//                    print("❌ /authenticity-verification-v3/ error: \(error.localizedDescription)")
//                    
//                    completion(.failure(error))
//                    return
//                }
//                guard let httpResp = response as? HTTPURLResponse else {
//                    let err = NSError(domain: "AuthVerifyV3", code: -3,
//                                      userInfo: [NSLocalizedDescriptionKey: "Invalid response"])
//                  
//                    completion(.failure(err))
//                    return
//                }
//                let rawBody = data.flatMap { String(data: $0, encoding: .utf8) } ?? "<no body>"
//                print("📤 /authenticity-verification-v3/ HTTP \(httpResp.statusCode) bytes=\(data?.count ?? 0)")
//                if self.isRunningInTestFlight() {
//                    // Save cropped image for verification/debugging
//                    UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
//                }
//                completion(.success(rawBody))
//            }
//        }.resume()
//    }
//
//    func isRunningInTestFlight() -> Bool {
//        if let receiptURL = Bundle.main.appStoreReceiptURL {
//            return receiptURL.lastPathComponent == "sandboxReceipt"
//        }
//        return false
//    }
//    func showToast(message: String, duration: Double = 2.0) {
//        let toastLabel = UILabel()
//        toastLabel.text = message
//        toastLabel.font = UIFont.systemFont(ofSize: 14)
//        toastLabel.textColor = .white
//        toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.7)
//        toastLabel.textAlignment = .center
//        toastLabel.numberOfLines = 0
//        
//        toastLabel.alpha = 0.0
//        toastLabel.layer.cornerRadius = 10
//        toastLabel.clipsToBounds = true
//        
//        let maxSizeTitle = CGSize(width: self.view.bounds.size.width - 40, height: self.view.bounds.size.height)
//        var expectedSize = toastLabel.sizeThatFits(maxSizeTitle)
//        expectedSize.width += 20
//        expectedSize.height += 10
//        
//        toastLabel.frame = CGRect(
//            x: (self.view.frame.size.width - expectedSize.width) / 2,
//            y: self.view.frame.size.height - 120,
//            width: expectedSize.width,
//            height: expectedSize.height
//        )
//        
//        self.view.addSubview(toastLabel)
//        
//        UIView.animate(withDuration: 0.5, animations: {
//            toastLabel.alpha = 1.0
//        }) { _ in
//            UIView.animate(withDuration: 0.5, delay: duration, options: .curveEaseOut, animations: {
//                toastLabel.alpha = 0.0
//            }, completion: { _ in
//                toastLabel.removeFromSuperview()
//            })
//        }
//    }
//    private func makeApiCall_new(with coordinates: (latitude: Double, longitude: Double) = (latitude: 0.0, longitude: 0.0), path: String, uCode : String, modelOutcome: String, uuid: String) {
//             
//              let location: [String: Double] = [
//                  "latitude": coordinates.latitude,
//                  "longitude": coordinates.longitude
//              ]
//            var parameters: [String: Any] = [
//                
//                "ucode_data": uCode,
//                
//            ]
//        
//        if let qrCodeValue = detectedQRCodeValue {
//            parameters["ucode_data"] = qrCodeValue
////            parameters["ucode_data"] = String(qrCodeValue.dropLast())
////            parameters["ucode_data"] = "e1~19_278,2y00u0s9mqd10fqe,2"
//           }
//            
//              parameters["location"] = location
//              parameters["captured_frame_path"] = path
//              parameters["unique_id"] = "23232323"
////              parameters["yellow_code_response"] = modelOutcome
//        //new optimized
////        parameters["is_dgc"] = modelOutcome
//        
//        
//        parameters["bypass_pdf_loyalty"] = true
////        parameters["ai_predection"] = "Original"
//        parameters["ai_predection"] = modelOutcome == "True" ? "Original" : "Fake"
//
//        parameters["uuid"] = uuid
////              parameters["yellow_code_response"] = "True"
////        ProgressHUD.shared.hide()
////        self.simulateProductDetails()
////        return
////
//        
////              print("acvission verification parameters \(parameters)")
//              NetworkManager.shared.makeAPICall(
//                  httpMethod: .post,
//                  endPoint: .AuthenticityYelloCodeVerificationV3,
//                  parameters: parameters,
//                  viewController: nil,
//                  errorHandlers: [.HandledByViewController],
//                  type: .WithoutLoader,
//                  result: { data,error  in
//
//           
//                      ProgressHUD.shared.hide()
//                      self.scanTimer?.invalidate()
//                      self.scanTimer = nil
//                      self.stopProgressAnimation(finalProgress: 1.0)
//                      self.audioQueue.async { [weak self] in
//                          self?.audioPlayer?.stop()
//                          self?.audioPlayer = nil
//                      }
//                      
////                      self.lapsedSeconds = 0
//                      if data != nil, let responseJson = data as? [String : Any] {
//                          print("acvissScanProductInfo 222 \(responseJson)")
//                          
//                          DispatchQueue.main.async {
//                              let responseCode = responseJson["response_code"] as? Int
////                              let responseCode = (jsonResult["result"] as? [String: Any])?["response_code"] as? Int
//                              let isSuccess = (responseCode == 100 || responseCode == 110)
//                              self.resetDetection()
//                              // create the SwiftUI view and hosting controller
//                              let prodView = UIHostingController(rootView: AcvissProdDetailsView(isSuccess: isSuccess, jsonResult: responseJson))
//                              prodView.title = "Product Details" // shown in nav bar
//
//                              DispatchQueue.main.async {
//                                  if let nav = self.navigationController {
//                                      // we have a navigation controller — push normally
//                                      nav.pushViewController(prodView, animated: true)
//                                  } else {
//                                      // no navigation controller — present one modally so we get a nav bar and back button
//                                      let nav = UINavigationController(rootViewController: prodView)
//                                      nav.modalPresentationStyle = .fullScreen // or .automatic / .pageSheet as you prefer
//
//                                      // optional: configure nav appearance (optional)
//                                      // nav.navigationBar.prefersLargeTitles = false
//                                      prodView.navigationItem.leftBarButtonItem = UIBarButtonItem(
//                                                          barButtonSystemItem: .close,
//                                                          target: self,
//                                                          action: #selector(self.prodDetailsCloseTapped)
//                                                      )
//                                      self.present(nav, animated: true, completion: nil)
//                                  }
//                              }
////                              let prodView = UIHostingController(rootView: AcvissProdDetailsView(isSuccess: response_code == 100, jsonResult: responseJson ?? [:]))
////                                  self.navigationController?.pushViewController(prodView, animated: true)
//                          }
//                    
//                      } else {
////                          self.isAcvissCodeAPISuccess = false
//                      }
//                  }
//              )
//          }
//    @objc private func prodDetailsCloseTapped() {
//        // If VisionViewController presented the nav controller, dismiss it
//        self.presentedViewController?.dismiss(animated: true, completion: nil)
//    }
//    private func showAlert(title: String, message: String) {
//        DispatchQueue.main.async {
//            // Get the current key window's root view controller
//            guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
//                  let window = windowScene.windows.first,
//                  let rootViewController = window.rootViewController else {
//                print("No root view controller found")
//                return
//            }
//            
//            // Find the topmost presented view controller
//            var topController = rootViewController
//            while let presentedViewController = topController.presentedViewController {
//                topController = presentedViewController
//            }
//            
//            // Only present if the view controller's view is in the window hierarchy
//            if topController.view.window != nil {
//                let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
//                alert.addAction(UIAlertAction(title: "OK", style: .default) { [weak self] _ in
//                    // Call restartScan when OK is tapped
//                    self?.restartScan()
//                    self?.resetScanTimer()
//                })
//                topController.present(alert, animated: true)
//            } else {
//                print("View controller not in window hierarchy - delaying alert presentation")
//                // Retry after a delay if needed
//                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
//                    self.showAlert(title: title, message: message)
//                }
//            }
//        }
//    }
// 
//    // Replace cropSquareNow with this new function
////    func cropSquareNow(_ image: CIImage?) -> UIImage? {
////        guard let ciImage = image else {
////            print("No CIImage provided")
////            return nil
////        }
////
////        guard let observation = self.detectedBarcode else {
////            print("❌ No stored barcode observation available")
////            return nil
////        }
////
////        print("Starting QR code square cropping using Vision observation")
////        print("Original image extent: \(ciImage.extent)")
////
////        let context = CIContext()
////
////        // The key insight: Vision detected the QR in video frames with orientation .up
////        // But the captured photo might have different EXIF orientation
////        // We need to work with the image in its natural orientation
////
////        let imageSize = ciImage.extent
////        print("Image size: \(imageSize)")
////
////        // Vision's bounding box is in normalized coordinates (0-1)
////        // and uses bottom-left origin (UIKit/Vision coordinate system)
////        let boundingBox = observation.boundingBox
////        print("Vision bounding box (normalized): \(boundingBox)")
////
////        // Try different coordinate transformations to find the QR code
////        let transformations: [(name: String, transform: (CGRect) -> CGRect)] = [
////            // Standard Vision to CIImage (flip Y)
////            ("Standard flip Y", { box in
////                CGRect(
////                    x: box.origin.x * imageSize.width,
////                    y: (1 - box.origin.y - box.height) * imageSize.height,
////                    width: box.width * imageSize.width,
////                    height: box.height * imageSize.height
////                )
////            }),
////            // Try without Y flip (in case image is already oriented)
////            ("No Y flip", { box in
////                CGRect(
////                    x: box.origin.x * imageSize.width,
////                    y: box.origin.y * imageSize.height,
////                    width: box.width * imageSize.width,
////                    height: box.height * imageSize.height
////                )
////            }),
////            // Rotated 90 degrees (landscape)
////            ("Rotated 90", { box in
////                CGRect(
////                    x: box.origin.y * imageSize.width,
////                    y: box.origin.x * imageSize.height,
////                    width: box.height * imageSize.width,
////                    height: box.width * imageSize.height
////                )
////            }),
////            // Rotated 90 with Y flip
////            ("Rotated 90 + flip", { box in
////                CGRect(
////                    x: (1 - box.origin.y - box.height) * imageSize.width,
////                    y: box.origin.x * imageSize.height,
////                    width: box.height * imageSize.width,
////                    height: box.width * imageSize.height
////                )
////            })
////        ]
////
////        var bestCropImage: UIImage?
////
////        for (name, transform) in transformations {
////            print("\n🔍 Trying transformation: \(name)")
////
////            let qrRect = transform(boundingBox)
////            print("   QR rect in image coords: \(qrRect)")
////
////            // Validate the rectangle is within bounds
////            guard qrRect.minX >= 0 && qrRect.minY >= 0 &&
////                  qrRect.maxX <= imageSize.width && qrRect.maxY <= imageSize.height else {
////                print("   ❌ Rectangle out of bounds")
////                continue
////            }
////
////            // Add padding (60% total = 1.60x)
////            let paddingMultiplier: CGFloat = 2.2
////            let paddedWidth = qrRect.width * paddingMultiplier
////            let paddedHeight = qrRect.height * paddingMultiplier
////
////            // Make it square
////            let squareSize = max(paddedWidth, paddedHeight)
////
////            // Calculate crop rect centered on QR code
////            let cropRect = CGRect(
////                x: qrRect.midX - squareSize / 2,
////                y: qrRect.midY - squareSize / 2,
////                width: squareSize,
////                height: squareSize
////            )
////
////            print("   Calculated crop rect: \(cropRect)")
////
////            // Ensure crop rect is within image bounds
////            let adjustedCropRect = cropRect.intersection(imageSize)
////
////            guard !adjustedCropRect.isEmpty &&
////                  adjustedCropRect.width > 100 &&
////                  adjustedCropRect.height > 100 else {
////                print("   ❌ Crop rect too small or empty")
////                continue
////            }
////
////            print("   Adjusted crop rect: \(adjustedCropRect)")
////
////            // Crop the image
////            let croppedCIImage = ciImage.cropped(to: adjustedCropRect)
////
////            // Convert to UIImage
////            guard let cgImage = context.createCGImage(croppedCIImage, from: croppedCIImage.extent) else {
////                print("   ❌ Failed to create CGImage")
////                continue
////            }
////
////            let croppedImage = UIImage(cgImage: cgImage, scale: 1.0, orientation: .up)
////
////            // Verify this crop actually contains a QR code using CIDetector
////            if verifyQRCodeInImage(croppedImage) {
////                print("   ✅ QR code verified in cropped image!")
////                bestCropImage = croppedImage
////                break
////            } else {
////                print("   ⚠️ Could not verify QR in this crop, trying next...")
////            }
////        }
////
////        if let finalImage = bestCropImage {
////            print("\n✅ Successfully created verified cropped image with size: \(finalImage.size)")
////            return finalImage
////        }
//////        else
//////        {
//////
////////                    DispatchQueue.main.async {
////////                        self.showAlert(title: "Scan again",
////////                                     message: "Looks like there is some issue with your environment. Please ensure the following and try again:\n\n1) Good lighting\n2) Stable hands\n3) Clean Lens of Camera")
////////                        ProgressHUD.shared.hide()
////////                        self.restartScan()
////////                    }
////////
//////            DispatchQueue.main.async {
//////                self.showAlertLightingconditions(
//////                    title: "Scan again",
//////                    message: """
//////            Looks like there is some issue with your environment. Please ensure the following and try again:
//////
//////            1) Good lighting
//////            2) Stable hands
//////            3) Clean Lens of Camera
//////            """,
//////                    onOk: {
//////                        // 🔥 runs only when the user taps OK
//////                        ProgressHUD.shared.hide()
//////                        self.restartScan()
//////                    }
//////                )
//////            }
//////            return nil
//////        }
////
////        print("\n❌ Could not find valid crop with any transformation")
////
////        // Last resort: Use the first reasonable crop even without verification
////        for (name, transform) in transformations {
////            let qrRect = transform(boundingBox)
////            let paddingMultiplier: CGFloat = 1.60
////            let paddedWidth = qrRect.width * paddingMultiplier
////            let paddedHeight = qrRect.height * paddingMultiplier
////            let squareSize = max(paddedWidth, paddedHeight)
////
////            let cropRect = CGRect(
////                x: qrRect.midX - squareSize / 2,
////                y: qrRect.midY - squareSize / 2,
////                width: squareSize,
////                height: squareSize
////            )
////
////            let adjustedCropRect = cropRect.intersection(imageSize)
////
////            if !adjustedCropRect.isEmpty && adjustedCropRect.width > 100 {
////                let croppedCIImage = ciImage.cropped(to: adjustedCropRect)
////                if let cgImage = context.createCGImage(croppedCIImage, from: croppedCIImage.extent) {
////                    print("⚠️ Using unverified crop from: \(name)")
////                    return UIImage(cgImage: cgImage, scale: 1.0, orientation: .up)
////                }
////            }
////        }
////
////        return nil
////    }
//
//    // MARK: - Helpers used by the validation (/validate/) path
//    /// Crop the centre 60% of an image — used by the belt-and-braces
//    /// sharpness probe inside the validation-path so peripheral background
//    /// blur doesn't mask centre-frame focus loss.
//    /// Apply CIUnsharpMask to an image right before JPEG-encoding it for
//    /// upload. The mask emphasises edges so offset-printer dots survive
//    /// the JPEG quantiser instead of being smeared together. Gated by
//    /// `applyUnsharpenForUpload` so you can A/B the change on the same
//    /// device. Falls back to the input image on any failure so the
//    /// upload still happens.
//    private func sharpenedForUpload(_ image: UIImage) -> UIImage {
//        guard applyUnsharpenForUpload else { return image }
//        guard let cgImage = image.cgImage else { return image }
//        let ciImage = CIImage(cgImage: cgImage)
//        guard let filter = CIFilter(name: "CIUnsharpMask") else { return image }
//        filter.setValue(ciImage, forKey: kCIInputImageKey)
//        filter.setValue(unsharpenRadius, forKey: kCIInputRadiusKey)
//        filter.setValue(unsharpenIntensity, forKey: kCIInputIntensityKey)
//        guard let output = filter.outputImage else { return image }
//        let ctx = CIContext(options: nil)
//        guard let outCG = ctx.createCGImage(output, from: output.extent) else { return image }
//        return UIImage(cgImage: outCG, scale: image.scale, orientation: image.imageOrientation)
//    }
//
//    private func centerScanRegion(of image: UIImage) -> UIImage? {
//        guard let cgImage = image.cgImage else { return nil }
//        let w = CGFloat(cgImage.width)
//        let h = CGFloat(cgImage.height)
//        guard w > 0, h > 0 else { return nil }
//        let side = min(w, h) * 0.6
//        let cropRect = CGRect(
//            x: (w - side) / 2,
//            y: (h - side) / 2,
//            width: side,
//            height: side
//        )
//        guard let cropped = cgImage.cropping(to: cropRect) else { return nil }
//        return UIImage(cgImage: cropped, scale: image.scale, orientation: image.imageOrientation)
//    }
//
//    /// Shared crop-with-padding primitive used by `cropAroundTFLiteQR`.
//    /// Mirrors the geometry of `cropSquareNow` (centre point + padding
//    /// multiplier, clamped to the image extent, refuse tiny crops).
//    private func cropWithPadding(_ ciImage: CIImage,
//                                 rect: CGRect,
//                                 paddingMultiplier: CGFloat) -> UIImage? {
//        let expandedW = rect.width  * paddingMultiplier
//        let expandedH = rect.height * paddingMultiplier
//        let cropRect = CGRect(
//            x: rect.midX - expandedW / 2,
//            y: rect.midY - expandedH / 2,
//            width:  expandedW,
//            height: expandedH
//        )
//        let clampedRect = cropRect.intersection(ciImage.extent)
//        guard !clampedRect.isEmpty,
//              clampedRect.width > 100,
//              clampedRect.height > 100 else {
//            print("❌ TFLite-derived crop rect invalid after clamping: \(clampedRect)")
//            return nil
//        }
//        let context = CIContext()
//        let cropped = ciImage.cropped(to: clampedRect)
//        guard let cgImage = context.createCGImage(cropped, from: cropped.extent) else {
//            return nil
//        }
//        return UIImage(cgImage: cgImage, scale: 1.0, orientation: .up)
//    }
//
//    /// Used by the validation-API path when Vision never decoded the QR
//    /// (so `detectedBarcode` is nil and `cropSquareNow` returns nil).
//    /// Runs TFLite on the high-res photo, picks the QR-class detection (or
//    /// falls back to the union of Pattern detections), and applies the same
//    /// 3x padding that `cropSquareNow` uses so the crop sent to /validate/
//    /// matches the crop sent to /predict/ in shape.
//    private func cropAroundTFLiteQR(_ ciImage: CIImage) -> UIImage? {
//        let context = CIContext()
//        guard let cgFull = context.createCGImage(ciImage, from: ciImage.extent) else {
//            print("❌ cropAroundTFLiteQR: createCGImage failed")
//            return nil
//        }
//        let fullImage = UIImage(cgImage: cgFull, scale: 1.0, orientation: .up)
//
//        do {
//            let detections = try TFLiteInference.run(
//                on: fullImage,
//                modelName: "model",
//                bundle: AxionBundle.bundle
//            )
//
//            // Prefer the highest-confidence QR-class detection — matches the
//            // semantic of `cropSquareNow` which crops around the Vision QR
//            // bounding box.
//            let qrDetections = detections
//                .filter { $0.classId == YOLOClass.qr.rawValue }
//                .sorted { $0.confidence > $1.confidence }
//            if let bestQR = qrDetections.first {
//                print("🟦 cropAroundTFLiteQR: using QR-class rect \(bestQR.rect) padding=\(cropQRPaddingMultiplier)")
//                return cropWithPadding(ciImage,
//                                       rect: bestQR.rect,
//                                       paddingMultiplier: cropQRPaddingMultiplier)
//            }
//
//            // Fallback: union of pattern rects. The 6 patterns sit just
//            // outside the QR border so they're already padded — a smaller
//            // padding multiplier is correct here.
//            let patternRects = detections
//                .filter { $0.classId == YOLOClass.pattern.rawValue }
//                .map { $0.rect }
//            if !patternRects.isEmpty {
//                let unionRect = patternRects.reduce(CGRect.null) { $0.union($1) }
//                print("🟧 cropAroundTFLiteQR: no QR-class detection — using union of \(patternRects.count) patterns \(unionRect)")
//                return cropWithPadding(ciImage,
//                                       rect: unionRect,
//                                       paddingMultiplier: 1.2)
//            }
//
//            print("❌ cropAroundTFLiteQR: no QR or pattern detections in high-res photo")
//            return nil
//        } catch {
//            print("❌ cropAroundTFLiteQR: TFLite error \(error.localizedDescription)")
//            return nil
//        }
//    }
//
//    func cropSquareNow(_ image: CIImage?) -> UIImage? {
//        guard let ciImage = image else {
//            print("❌ No CIImage provided")
//            return nil
//        }
//        guard let observation = self.detectedBarcode else {
//            print("❌ No stored barcode observation")
//            return nil
//        }
//
//        let imageExtent = ciImage.extent
//        let imageW = imageExtent.width
//        let imageH = imageExtent.height
//        let bb = observation.boundingBox  // normalized, bottom-left origin
//
//        print("📐 Image extent: \(imageExtent)")
//        print("📐 Vision bounding box: \(bb)")
//
//        // Vision and CIImage both use bottom-left origin — no Y-flip needed.
//        // CIImage(data:) already EXIF-corrects the photo to portrait orientation.
//        let qrX = bb.origin.x * imageW
//        let qrY = bb.origin.y * imageH
//        let qrW = bb.width  * imageW
//        let qrH = bb.height * imageH
//
//        let qrRectInImage = CGRect(x: qrX, y: qrY, width: qrW, height: qrH)
//        print("📐 QR rect in image pixels: \(qrRectInImage)")
//
//        // Centralised padding tunable. Originally a hard-coded 3.0x but
//        // that wasted ~75% of the available pixels on margin around the
//        // code. Driven by `cropQRPaddingMultiplier` (default 1.5×) so the
//        // crop and the auto-zoom target stay in sync — at the 1.5×
//        // setting the upload contains ~5× the QR-pixel area it did before.
//        let paddingMultiplier: CGFloat = self.cropQRPaddingMultiplier
//
//        let expandedW = qrW * paddingMultiplier
//        let expandedH = qrH * paddingMultiplier
//
//        let cropRect = CGRect(
//            x: qrRectInImage.midX - expandedW / 2,
//            y: qrRectInImage.midY - expandedH / 2,
//            width:  expandedW,
//            height: expandedH
//        )
//        print("📐 Desired crop rect: \(cropRect)")
//
//        let clampedRect = cropRect.intersection(imageExtent)
//        guard !clampedRect.isEmpty,
//              clampedRect.width > 100,
//              clampedRect.height > 100 else {
//            print("❌ Crop rect invalid after clamping: \(clampedRect)")
//            return nil
//        }
//        print("📐 Clamped crop rect: \(clampedRect)")
//
//        let context = CIContext()
//        let cropped = ciImage.cropped(to: clampedRect)
//
//        guard let cgImage = context.createCGImage(cropped, from: cropped.extent) else {
//            print("❌ Failed to create CGImage")
//            return nil
//        }
//
//        let result = UIImage(cgImage: cgImage, scale: 1.0, orientation: .up)
//        print("✅ Crop successful: \(result.size)")
//        return result
//    }
//    private func showAlertLightingconditions(
//        title: String,
//        message: String,
//        onOk: (() -> Void)? = nil
//    ) {
//        DispatchQueue.main.async {
//            // Get current topmost VC
//            guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
//                  let window = windowScene.windows.first,
//                  let root = window.rootViewController else {
//                return
//            }
//
//            var top = root
//            while let presented = top.presentedViewController {
//                top = presented
//            }
//
//            let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
//
//            alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in
//                onOk?()   // 🔥 callback when user taps OK
//            })
//
//            top.present(alert, animated: true)
//        }
//    }
//    // Helper function to verify QR code exists in cropped image
//    private func verifyQRCodeInImage(_ image: UIImage) -> Bool {
//        guard let cgImage = image.cgImage else { return false }
//        
//        let ciImage = CIImage(cgImage: cgImage)
//        let context = CIContext()
//        
//        guard let detector = CIDetector(
//            ofType: CIDetectorTypeQRCode,
//            context: context,
//            options: [CIDetectorAccuracy: CIDetectorAccuracyHigh]
//        ) else {
//            return false
//        }
//        
//        let features = detector.features(in: ciImage)
//        return !features.isEmpty
//    }
//
//    // Fallback method when QR detection fails
//    private func manualCenterCrop(_ ciImage: CIImage) -> UIImage? {
//        print("🔄 Using manual center crop fallback")
//        let context = CIContext()
//        
//        let extent = ciImage.extent
//        let size = min(extent.width, extent.height)
//        let center = CGPoint(x: extent.midX, y: extent.midY)
//        
//        let cropRect = CGRect(
//            x: center.x - size / 2,
//            y: center.y - size / 2,
//            width: size,
//            height: size
//        )
//        
//        let croppedCIImage = ciImage.cropped(to: cropRect)
//        
//        guard let cgImage = context.createCGImage(croppedCIImage, from: croppedCIImage.extent) else {
//            return nil
//        }
//        
//        return UIImage(cgImage: cgImage, scale: 1.0, orientation: .up)
//    }
//
//
//    private func cropUsingVisionObservation(_ ciImage: CIImage, observation: VNBarcodeObservation) -> UIImage? {
//        let context = CIContext()
//        let imageSize = ciImage.extent
//        
//        print("Image size: \(imageSize)")
//        print("Vision bounding box (normalized): \(observation.boundingBox)")
//        
//        // Vision uses normalized coordinates (0-1) with bottom-left origin
//        // Convert to CIImage coordinates (top-left origin, pixel values)
//        let boundingBox = observation.boundingBox
//        
//        // Calculate the QR code rect in image coordinates
//        // Flip Y coordinate because Vision uses bottom-left origin
//        let x = boundingBox.origin.x * imageSize.width
//        let y = (1 - boundingBox.origin.y - boundingBox.height) * imageSize.height
//        let width = boundingBox.width * imageSize.width
//        let height = boundingBox.height * imageSize.height
//        
//        let qrRect = CGRect(x: x, y: y, width: width, height: height)
//        print("QR rect in image coordinates: \(qrRect)")
//        
//        // Add padding (60% total = 1.60x)
//        let paddingMultiplier: CGFloat = 1.60
//        let paddedWidth = width * paddingMultiplier
//        let paddedHeight = height * paddingMultiplier
//        
//        // Make it square using the larger dimension
//        let squareSize = max(paddedWidth, paddedHeight)
//        
//        // Center the square on the QR code
//        let cropRect = CGRect(
//            x: qrRect.midX - squareSize / 2,
//            y: qrRect.midY - squareSize / 2,
//            width: squareSize,
//            height: squareSize
//        )
//        
//        print("Calculated crop rect: \(cropRect)")
//        
//        // Clamp to image bounds
//        let adjustedCropRect = cropRect.intersection(imageSize)
//        
//        guard !adjustedCropRect.isEmpty else {
//            print("❌ Crop rect is empty after intersection")
//            return nil
//        }
//        
//        print("Adjusted crop rect: \(adjustedCropRect)")
//        
//        // Crop the image
//        let croppedCIImage = ciImage.cropped(to: adjustedCropRect)
//        
//        // Convert to UIImage
//        guard let cgImage = context.createCGImage(croppedCIImage, from: croppedCIImage.extent) else {
//            print("❌ Failed to create CGImage")
//            return nil
//        }
//        
//        let finalImage = UIImage(cgImage: cgImage, scale: 1.0, orientation: .up)
//        print("✅ Successfully created cropped image with size: \(finalImage.size)")
//        
//        return finalImage
//    }
//
//
//}
//
